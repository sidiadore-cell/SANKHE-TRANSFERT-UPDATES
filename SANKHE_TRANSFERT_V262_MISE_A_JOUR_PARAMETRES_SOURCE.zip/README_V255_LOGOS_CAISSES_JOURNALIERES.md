# V255 — Logos et montants des caisses journalières sur Accueil
- Ajout du logo Wave dans la carte « WAVE — JOURNÉE ».
- Ajout du logo Orange Money dans la carte « ORANGE MONEY — JOURNÉE ».
- Montants alignés à gauche du logo, avec police plus lisible et espace adapté.
- Les soldes et calculs sous-jacents ne sont pas modifiés.
- Compilation et test visuel Windows à effectuer.
