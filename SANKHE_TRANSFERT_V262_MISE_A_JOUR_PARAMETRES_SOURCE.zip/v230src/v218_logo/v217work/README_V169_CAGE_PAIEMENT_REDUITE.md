# V169 — Cage MODE DE PAIEMENT réduite

Correction ciblée basée sur la V168.

- Réduction des dimensions de la cage « Mode de paiement ».
- Cage repositionnée légèrement plus bas pour éviter toute coupure en haut.
- Boutons WAVE / ORANGE MONEY / ESPÈCES redimensionnés.
- Zone « Paiement sélectionné » redimensionnée pour rester entièrement visible.
- Aucun changement de logique métier, de calcul de commission, de paiement différé ou de rapports.
- La bande Commission / Montant total reste derrière la cage de paiement.
