# V176 — Recherche client généralisée

- Recherche dès la première lettre du nom ou de n'importe quel prénom/nom.
- Liste affichée dans Opérations et Seddo.
- Le téléphone est rempli uniquement après sélection explicite.
- Si aucun résultat, la saisie libre reste possible.
- La liste est relue depuis SQLite à chaque recherche pour inclure immédiatement les nouveaux clients.
- Si le texte du client est modifié après une sélection, l'ancien téléphone est effacé.
