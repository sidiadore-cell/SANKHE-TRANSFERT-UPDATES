# V204/V205 — Vente UV : paiement immédiat

- Référence masquée dans Rééquilibrage.
- Vente UV : paiement immédiat uniquement par **Orange Money** ou **Espèces**.
- Paiement immédiat : aucune dette créée.
- Paiement différé : création de dette.
- Le code de la base refuse tout autre moyen de paiement pour une Vente UV immédiate.
