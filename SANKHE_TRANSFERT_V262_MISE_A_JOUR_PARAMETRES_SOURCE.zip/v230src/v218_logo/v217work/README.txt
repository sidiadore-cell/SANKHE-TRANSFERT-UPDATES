SANKHÉ TRANSFERT D'ARGENT — VERSION C#/.NET

Cette version ne nécessite PAS Python.

Technologie:
- C# / .NET 8 Windows Forms
- SQLite local
- publication Windows autonome (self-contained)
- fichier final: Sankhe Transfert.exe

Pour construire le .exe sur Windows:
1. Installer le .NET 8 SDK.
2. Double-cliquer sur CONSTRUIRE_EXE.bat.
3. Le programme crée publish\Sankhe Transfert.exe.
4. La version self-contained n'exige pas l'installation de Python ni du runtime .NET sur le PC cible.

La base de données est locale et sera enregistrée dans:
%LOCALAPPDATA%\SankheTransfert\sankhe_transfert.db

La version actuelle constitue le socle Windows: tableau de bord, base SQLite, opérations, soldes, dettes et sauvegarde. Les écrans Clients/Rapports/Import Excel/Historique avancé restent à compléter avant la mise en production.
