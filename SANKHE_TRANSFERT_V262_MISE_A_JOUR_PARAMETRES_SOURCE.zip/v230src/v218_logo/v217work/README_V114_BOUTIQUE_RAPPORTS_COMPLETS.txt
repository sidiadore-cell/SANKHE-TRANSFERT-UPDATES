SANKHÉ TRANSFERT D'ARGENT — V114

MON BOUTIQUE / RAPPORTS COMPLETS

Modifications :
- Un poste dont la journée est ouverte est signalé par un halo/fond vert transparent.
- Le Rapport Boutique affiche l'heure de chaque mouvement : distribution matin, complément de dotation (+ AJOUTER) et retour soir.
- Chaque utilisation de + AJOUTER est enregistrée avec sa date/heure et son montant Wave ou Orange Money afin d'apparaître dans les rapports.
- Le Rapport Boutique permet de filtrer Tous les postes ou un Poste 1 à Poste 6.
- Bouton IMPRIMER : imprime le rapport courant, ou le rapport du poste sélectionné.
- Bouton PDF : crée un PDF avec la même mise en page que l'impression.
- Les totaux Wave, Orange Money et des compléments + AJOUTER sont affichés en bas du rapport.
