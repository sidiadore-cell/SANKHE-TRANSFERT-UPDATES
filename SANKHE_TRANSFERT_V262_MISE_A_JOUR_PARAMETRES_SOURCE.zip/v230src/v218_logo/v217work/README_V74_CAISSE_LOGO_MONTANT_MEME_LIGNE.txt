V74 — CAISSE : LOGO À GAUCHE + MONTANT À DROITE

Modification demandée : dans la page Caisse, chaque carte affiche désormais le logo à gauche et le montant à droite, sur la même ligne/zone horizontale.
Le nombre et « FCFA » restent sur une seule ligne.
La logique des caisses et les autres pages ne sont pas modifiées.
