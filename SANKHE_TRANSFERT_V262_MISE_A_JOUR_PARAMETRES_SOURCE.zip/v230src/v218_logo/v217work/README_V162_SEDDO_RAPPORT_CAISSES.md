# V162 — Correction affichage Seddo + rapport Seddo par caisse

## Corrections
- Le bouton **VALIDER / ENREGISTRER L’OPÉRATION SEDDO** est entièrement visible : la carte de saisie a été agrandie pour éviter que le bouton soit coupé.
- Dans les rapports généraux, toute opération **Seddo** indique maintenant dans la description la ou les caisses dans lesquelles l'argent a été déposé.
- Ajout d'un bouton **RAPPORT SEDDO** dans le menu Rapports.
- Le rapport Seddo permet de choisir une période et d'afficher les opérations Seddo.
- Le rapport Seddo affiche pour chaque opération la caisse de dépôt : Wave, Orange Money et/ou caisse générale.
- Le rapport affiche les sommes cumulées par caisse, les sorties de la caisse Seddo, les commissions et le restant à encaisser.
- Le rapport Seddo peut être **imprimé** et exporté en **PDF avec la même mise en page que l'impression**.
- Les paiements Seddo différés sont pris en compte lorsqu'ils sont encaissés dans une caisse ; plusieurs encaissements peuvent être regroupés par caisse pour une même opération.
