V39 — CORRECTION DU SOLDE DE DÉPART DE CAISSE

Le solde de départ est maintenant le cash réellement disponible au début de la journée.
Il met à jour le solde Caisse même si l'historique contient déjà des mouvements des jours précédents.
Les entrées et sorties enregistrées ensuite modifient ce solde.
Le journal conserve le mouvement « Solde initial » pour la comptabilité générale.

Exemple :
Solde de départ : 20 000 000 FCFA
Entrées du jour : 0
Sorties du jour : 0
=> Caisse actuelle : 20 000 000 FCFA
