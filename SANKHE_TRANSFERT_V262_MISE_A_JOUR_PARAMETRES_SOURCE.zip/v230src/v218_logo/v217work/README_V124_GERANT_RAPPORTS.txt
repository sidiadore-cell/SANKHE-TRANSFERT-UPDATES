SANKHÉ TRANSFERT D'ARGENT — V124

NOUVEAUTÉ : NOM DU GÉRANT
- Le nom du gérant peut être saisi dans Paramètres > NOM DU GÉRANT.
- Le nom enregistré remplace « Admin » dans l'en-tête du logiciel.
- Le nom du gérant est ajouté aux rapports imprimés :
  - Rapport des opérations
  - Rapport individuel client
  - Rapport Boutique
  - Journal de caisse
- Le nom est également intégré aux pages PDF qui utilisent le même rendu que l'impression.
- Le nom est conservé dans la base de données SQLite (AppSettings, clé ManagerName).

BUILD
Lancer CONSTRUIRE_EXE.bat avec le .NET 8 SDK installé.
