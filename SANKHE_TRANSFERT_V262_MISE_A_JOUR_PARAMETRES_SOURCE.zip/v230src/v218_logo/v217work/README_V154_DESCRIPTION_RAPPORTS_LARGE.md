V154 — DESCRIPTION DES RAPPORTS LARGE ET LISIBLE

Modification :
- La colonne Description des rapports reste volontairement large.
- La grille des rapports donne davantage d'espace à Description.
- Les rapports imprimés utilisent une colonne Description élargie.
- Les rapports PDF utilisent la même largeur de Description que l'impression.
- Le rapport individuel client conserve également une Description large.
- Le texte est conservé avec retour à la ligne afin de rester lisible.
- Les autres colonnes essentielles restent présentes.
- Aucune donnée, aucun calcul et aucune logique métier n'est modifié.

Objectif : les informations comme « Rééquilibrage — Vente UV », « Rééquilibrage — Achat UV »,
les références et les détails d'opération doivent rester clairement lisibles à l'écran,
à l'impression et dans le PDF.
