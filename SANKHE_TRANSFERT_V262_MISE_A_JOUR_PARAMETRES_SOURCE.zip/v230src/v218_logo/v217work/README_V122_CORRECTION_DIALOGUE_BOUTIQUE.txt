VERSION 122 — CORRECTION DU DIALOGUE « MON BOUTIQUE »

Correction de l’affichage des fenêtres de saisie des montants Boutique.

- Les libellés « Montant Wave à ajouter » et « Montant Orange Money à ajouter » ne débordent plus sous les champs.
- La fenêtre est élargie et mieux espacée.
- Les libellés sont alignés dans une zone dédiée avec ellipsis si nécessaire.
- Les champs de saisie et le bouton VALIDER sont mieux dimensionnés.
- Le dialogue conserve l’adaptation DPI du logiciel.
