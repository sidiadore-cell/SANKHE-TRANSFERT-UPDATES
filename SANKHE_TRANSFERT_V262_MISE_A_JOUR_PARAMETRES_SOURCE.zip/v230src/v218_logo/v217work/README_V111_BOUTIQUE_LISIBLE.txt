V111 — BOUTIQUE DESIGN PLUS LISIBLE

Modifications :
- Cartes des 6 postes agrandies pour gagner en lisibilité.
- Palette simplifiée : fond sombre uniforme, texte blanc et accent cyan discret.
- Suppression des fonds colorés derrière les textes et montants.
- Montants Wave/Orange affichés en gros caractères.
- Informations de retour regroupées clairement.
- Boutons arrondis aux angles.
- Bouton « Gérer les postes » également arrondi.
- Page Boutique centrée et espacée.
- Wave retour et Orange Money retour restent affichés.
