V77 — RAPPORTS SOLDÉ / NON SOLDÉ

Dans le module Rapports :
- ajout de la colonne « Statut dette » avec Soldée / Non soldée pour les transferts, envois et remboursements liés à une dette ;
- le statut est déterminé à partir du solde restant réel de la dette ;
- le résumé de la page affiche le nombre de dettes soldées et non soldées ainsi que les montants correspondants ;
- l'impression affiche en bas les totaux des opérations, montant, commission, dette, puis le nombre et les montants des dettes soldées/non soldées ;
- l'export CSV contient également la colonne « Statut dette » ;
- la modification conserve le service de remboursement (Caisse Wave, Caisse Orange Money, Caisse générale, etc.).
