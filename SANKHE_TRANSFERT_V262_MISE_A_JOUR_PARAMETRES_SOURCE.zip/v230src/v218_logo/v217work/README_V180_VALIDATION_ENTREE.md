# V180 — Validation rapide par Entrée

- Opérations : touche Entrée valide après saisie des champs client/montant.
- Boutique : touche Entrée valide les montants Wave/Orange/espèces ; une cage vide vaut 0 FCFA.
- Seddo : touche Entrée valide après nom, téléphone, montant et choix du mode de paiement.
- La sélection client conserve son comportement : Entrée dans la liste valide d'abord le client sélectionné.
