# SANKHÉ TRANSFERT — V142

Corrections demandées sur le menu Opérations :
- élargissement des panneaux Wave et Orange Money et des cages de saisie pour améliorer la visibilité à gauche et à droite ;
- labels et champs mieux alignés et espacés ;
- zone Rééquilibrage conservée avec Nom & Prénom et Numéro ;
- boutons Vente UV / Achat UV agrandis ;
- bouton ENREGISTRER rendu visible et repositionné dans la zone Rééquilibrage ;
- bouton ANNULER reste supprimé.
