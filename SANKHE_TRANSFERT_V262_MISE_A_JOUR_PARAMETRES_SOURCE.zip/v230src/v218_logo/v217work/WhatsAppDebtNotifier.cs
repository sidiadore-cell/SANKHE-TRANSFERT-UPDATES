using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace SankheTransfert;

/// <summary>
/// Envoi d'un modèle WhatsApp Business approuvé lorsque la dette vient d'être intégralement soldée.
/// Configuration enregistrée depuis Paramètres dans la base locale ; les variables d'environnement restent un recours compatible.
/// Le modèle approuvé doit comporter 7 paramètres texte dans cet ordre :
/// client, service, dette initiale, montant du dernier paiement, moyen, date, référence.
/// </summary>
internal static class WhatsAppDebtNotifier
{
    private static readonly HttpClient Http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };

    public static async Task<(bool Success, string Message)> SendDebtSettledAsync(
        string phone, string client, string service, decimal initialAmount,
        decimal lastPayment, string paymentMethod, DateTime paidAt, string reference)
    {
        var phoneNumberId = Database.GetSetting("WhatsAppPhoneNumberId", Environment.GetEnvironmentVariable("SANKHE_WHATSAPP_PHONE_NUMBER_ID") ?? "");
        var token = Database.GetSetting("WhatsAppAccessToken", Environment.GetEnvironmentVariable("SANKHE_WHATSAPP_ACCESS_TOKEN") ?? "");
        var template = Database.GetSetting("WhatsAppTemplateName", Environment.GetEnvironmentVariable("SANKHE_WHATSAPP_TEMPLATE_NAME") ?? "");
        var language = Database.GetSetting("WhatsAppLanguageCode", Environment.GetEnvironmentVariable("SANKHE_WHATSAPP_LANGUAGE_CODE") ?? "fr");
        if (string.IsNullOrWhiteSpace(language)) language = "fr";

        if (string.IsNullOrWhiteSpace(phoneNumberId) || string.IsNullOrWhiteSpace(token) ||
            string.IsNullOrWhiteSpace(template))
            return (false, "WhatsApp non configuré : ouvrez Paramètres > WhatsApp et renseignez l’ID du numéro, le jeton d’accès et le modèle approuvé.");

        var normalizedPhone = NormalizePhone(phone);
        if (normalizedPhone.Length < 8)
            return (false, "Le numéro du client est absent ou invalide.");

        var parameters = new[]
        {
            new { type = "text", text = Safe(client) },
            new { type = "text", text = Safe(service) },
            new { type = "text", text = initialAmount.ToString("N0", System.Globalization.CultureInfo.GetCultureInfo("fr-FR")) + " FCFA" },
            new { type = "text", text = lastPayment.ToString("N0", System.Globalization.CultureInfo.GetCultureInfo("fr-FR")) + " FCFA" },
            new { type = "text", text = Safe(paymentMethod) },
            new { type = "text", text = paidAt.ToString("dd/MM/yyyy HH:mm") },
            new { type = "text", text = Safe(string.IsNullOrWhiteSpace(reference) ? "Non renseignée" : reference) }
        };

        var payload = new
        {
            messaging_product = "whatsapp",
            recipient_type = "individual",
            to = normalizedPhone,
            type = "template",
            template = new
            {
                name = template,
                language = new { code = language },
                components = new[]
                {
                    new { type = "body", parameters = parameters }
                }
            }
        };

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Post,
                $"https://graph.facebook.com/v23.0/{Uri.EscapeDataString(phoneNumberId)}/messages");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            request.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
            using var response = await Http.SendAsync(request).ConfigureAwait(false);
            var responseText = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            if (response.IsSuccessStatusCode)
                return (true, "Confirmation WhatsApp envoyée au client.");
            return (false, $"WhatsApp a refusé l'envoi (HTTP {(int)response.StatusCode}). Vérifiez le modèle approuvé, le numéro et les accès.");
        }
        catch (TaskCanceledException)
        {
            return (false, "Délai dépassé lors de l'envoi WhatsApp. La dette reste soldée dans le logiciel ; vérifiez l'historique avant tout nouvel envoi.");
        }
        catch (Exception)
        {
            return (false, "Erreur de connexion WhatsApp. La dette reste soldée dans le logiciel ; vérifiez la connexion et la configuration.");
        }
    }

    private static string NormalizePhone(string phone)
    {
        if (string.IsNullOrWhiteSpace(phone)) return "";
        var digits = new string(phone.Where(char.IsDigit).ToArray());
        // Numéro local sénégalais : conversion en format international 221 + numéro.
        if (digits.Length == 9) digits = "221" + digits;
        return digits;
    }

    private static string Safe(string value) =>
        string.IsNullOrWhiteSpace(value) ? "Non renseigné" : value.Trim();
}
