SANKHÉ TRANSFERT — V6

Corrections :
- Dettes séparées : Dette Wave et Dette Orange Money.
- Dette totale affichée séparément.
- Les dettes sont calculées par service à partir des opérations enregistrées.
- Le menu Nouvelle opération est centré au milieu de la page.
- Nouvelle opération affiche en haut un résumé Dette Wave / Dette Orange Money / Dette totale.
- Mise en page compacte et centrée.

Compilation :
Ouvrir le projet SankheTransfert.csproj avec Visual Studio 2022 + .NET 8, puis générer en Release.
