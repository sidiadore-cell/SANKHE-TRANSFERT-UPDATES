# V166 — Correction professionnelle de l'affichage Seddo

- Réorganisation verticale de la carte « Nouvelle opération client ».
- Le bloc « Mode de paiement du client » est maintenant entièrement à l'intérieur de la carte, sans chevauchement avec le calcul de commission.
- Les boutons WAVE / ORANGE MONEY / ESPÈCES restent entièrement visibles.
- La confirmation « Paiement sélectionné » dispose d'une cage plus haute et lisible.
- La case « Paiement différé » et le bouton de validation sont séparés du bloc de paiement.
- La carte « Mouvements de caisse » a la même hauteur que la carte principale.
- La bande « À ENCAISSER » est déplacée sous les deux cartes pour éviter tout chevauchement.
- L'historique Seddo est déplacé plus bas en conséquence.
- Aucun changement de logique métier : le paiement différé annule toujours le mode de paiement jusqu'au règlement.
