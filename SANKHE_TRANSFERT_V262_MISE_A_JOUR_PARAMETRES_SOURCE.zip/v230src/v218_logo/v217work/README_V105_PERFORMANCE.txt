V105 — PERFORMANCE

Optimisations :
- SQLite WAL, cache partagé, pooling et busy timeout.
- Index sur opérations, dettes, paiements et mouvements de caisse.
- Requêtes de rapports sans conditions OR inutiles afin de mieux utiliser les index.
- Une seule lecture SQLite pour les indicateurs principaux du tableau de bord.
- Tri des paiements sans fonction datetime pour exploiter l’index.
- Conservation du cache des images et du double-buffering existants.

Objectif : navigation plus rapide, chargements de rapports plus fluides et moins d’accès disque/SQLite répétés.
