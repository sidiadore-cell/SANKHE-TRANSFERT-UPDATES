SANKHE TRANSFERT V237 — SAMA CAISSE : dates/heures et onglets harmonisés

- La liste ARGENT CONFIÉ conserve la colonne de dernière opération avec date et heure.
- La liste ARGENT PRÊTÉ affiche désormais la dernière opération avec date et heure, en plus de l'échéance.
- Les deux onglets de sélection sont dessinés avec des boutons de même taille, alignés, bordures lumineuses et couleurs distinctes bleu/orange.
- Les rapports imprimés/PDF reprennent les colonnes affichées, notamment date/heure.

La compilation doit être exécutée sur un PC disposant du SDK .NET 8.
