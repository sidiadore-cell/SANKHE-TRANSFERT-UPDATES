SANKHÉ TRANSFERT D’ARGENT — V35
CAISSE / COMPTABILITÉ GÉNÉRALE CORRIGÉE

- Le solde de départ est maintenant un constat de début de journée.
- Il n’est ajouté au solde de caisse que lors du tout premier démarrage de la caisse.
- Les jours suivants, saisir le solde de départ ne double plus la caisse précédente.
- Pour injecter de nouvelles liquidités, utiliser ENTRÉE.
- La caisse continue de recevoir les dépôts et remboursements de dettes en espèces.
- Les retraits et sorties manuelles diminuent la caisse.
- Ajout des totaux généraux des entrées et sorties.
- Conservation du journal et de l’impression.
