V143 — ALIGNEMENT ET VISIBILITÉ DES CAGES OPÉRATIONS

- Cages de saisie élargies et décalées légèrement vers la droite.
- Alignement uniforme des libellés Nom & Prénom, Téléphone, Montant, Commission et Référence avec leurs champs.
- Champs de saisie plus larges pour faciliter la lecture et la saisie.
- Cage Montant conservée en format renforcé avec police plus grande.
- Espacement vertical régulier entre toutes les cages.
- Zone Rééquilibrage adaptée à la nouvelle largeur.
- Bouton ENREGISTRER repositionné pour rester visible.
- Design Wave/Orange et fond de la maquette conservés.
