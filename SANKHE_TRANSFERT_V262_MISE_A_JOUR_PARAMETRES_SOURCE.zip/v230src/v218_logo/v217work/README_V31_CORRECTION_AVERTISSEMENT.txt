V31 - Correction du warning CS8602 dans MainForm.cs (impression des rapports).
La référence Graphics est vérifiée avant utilisation.
La recherche Nom & Prénom de V30 est conservée.
