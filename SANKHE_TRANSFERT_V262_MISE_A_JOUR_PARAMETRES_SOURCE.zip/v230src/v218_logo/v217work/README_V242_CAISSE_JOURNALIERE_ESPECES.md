V242 — Caisse journalière Espèces et affichage du menu Caisse

- Ajout de la caisse « Caisse » (Espèces) au suivi journalier, avec mouvements, entrées, sorties, solde théorique et clôture/vérification.
- Le suivi journalier inclut désormais Wave, Orange Money et Espèces.
- Dans le menu Caisse, le panneau « Synthèse générale des caisses » devient « Les caisses journalières » et présente trois cartes dans le style existant : Wave, Orange Money et Espèces.
- Le total général des soldes réels reste dans son bandeau supérieur; SAMA CAISSE reste exclue de ce total et ne dispose pas de compteur journalier.
- Le compteur journalier calcule les entrées moins les sorties du jour et repart de zéro au changement de date; les soldes réels et historiques ne sont pas remis à zéro.
