# V199 — Distribution totale : affichage simplifié

Dans « Mon Boutique » :
- Une seule cage « DISTRIBUTION TOTALE » est affichée.
- Le montant correspond à la somme de la distribution initiale et de tous les montants ajoutés avec « À AJOUTER ».
- Le titre affiche uniquement « DISTRIBUTION TOTALE ».
- La cage utilise exactement la même mise en page que les autres indicateurs (« RETOURS TOTAL », « ESPÈCES DISTRIBUÉES », etc.).
- Aucun montant n'est compté deux fois : les champs WaveDonne/OrangeDonne/EspecesDonne sont déjà cumulés lors des ajouts.
