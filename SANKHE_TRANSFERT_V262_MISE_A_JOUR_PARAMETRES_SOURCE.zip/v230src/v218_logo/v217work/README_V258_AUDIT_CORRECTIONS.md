SANKHÉ TRANSFERT — V258 Audit et optimisations ciblées

Modifications de cette version :
- Optimisation des requêtes de caisse journalière : une seule connexion SQLite est réutilisée pour calculer les trois résumés.
- Remplacement des filtres SQL substr(DateMouvement,1,10) par des intervalles de dates (>= début du jour et < début du lendemain), pour permettre l'utilisation de l'index DateMouvement et mieux traiter les dates avec ou sans heure.
- Même optimisation appliquée à la liste des mouvements journaliers et au résumé de caisse.
- Le filtrage des remboursements de dettes anciennes hors caisse journalière est conservé.
- Aucun changement volontaire aux règles de calcul financier ou aux données existantes.

Contrôles à faire sur Windows avant utilisation en production :
1. Compiler le projet avec le SDK .NET requis.
2. Tester Entrée, Sortie et Modifier solde sur Wave, Orange Money, Espèces et Seddo.
3. Tester remboursement d'une dette ancienne et d'une dette du jour, total et partiel.
4. Vérifier annulation, échange, rapports/PDF et cohérence des soldes après chaque opération.
5. Faire une sauvegarde de la base avant le premier lancement.

Limite : l'environnement de préparation ne dispose pas de dotnet/msbuild, donc aucune compilation ou exécution réelle de l'application n'a pu être effectuée ici. Cette version ne doit pas être considérée comme certifiée avant les tests ci-dessus.
