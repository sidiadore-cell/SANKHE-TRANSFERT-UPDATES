V26 - AFFICHAGE NOM & PRENOM DANS DERNIERES TRANSACTIONS

Modification : le tableau "Dernières transactions" affiche maintenant la colonne "Nom & Prénom" entre Service et Type.
La valeur provient du champ ClientNom déjà enregistré dans la base de données.
Aucune autre donnée ou fonctionnalité n'a été modifiée.
