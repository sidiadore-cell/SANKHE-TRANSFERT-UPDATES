# V144 — Bouton ENREGISTRER visible dans Rééquilibrage

Correction de l'affichage de la page **Nouvelle opération** :
- hauteur des cartes Wave / Orange Money augmentée pour éviter que le bas de la zone Rééquilibrage soit coupé ;
- zone des champs légèrement agrandie ;
- hauteur du conteneur principal augmentée pour permettre le défilement complet ;
- le bouton **✓ ENREGISTRER** du Rééquilibrage est maintenant entièrement visible.

La logique d'enregistrement n'a pas été modifiée.
