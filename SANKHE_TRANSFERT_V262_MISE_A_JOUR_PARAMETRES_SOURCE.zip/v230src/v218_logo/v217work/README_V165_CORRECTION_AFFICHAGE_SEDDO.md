# V165 — Correction affichage Seddo

- Augmentation de la hauteur de la carte « Nouvelle opération client » pour éviter le découpage du cadre du mode de paiement.
- Cadre du mode de paiement repositionné et agrandi afin que WAVE / ORANGE MONEY / ESPÈCES et le message de sélection soient entièrement visibles.
- Case « Paiement différé » déplacée sous le cadre de paiement, sans chevauchement.
- Bouton « VALIDER / ENREGISTRER L’OPÉRATION SEDDO » repositionné avec une marge inférieure suffisante afin qu’il ne soit plus collé ni coupé par la bordure.
- Carte « Mouvements de caisse » ajustée à la même hauteur pour conserver l’alignement visuel.
