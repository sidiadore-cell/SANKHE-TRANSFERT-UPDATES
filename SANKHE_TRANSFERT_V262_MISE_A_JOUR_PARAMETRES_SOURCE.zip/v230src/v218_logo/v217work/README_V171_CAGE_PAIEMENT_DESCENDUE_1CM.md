# V171 — Cage mode de paiement descendue de 1 cm

Correction ciblée basée sur V170 :
- la cage « Mode de paiement » est descendue uniquement d'environ 1 cm (38 px) ;
- largeur, hauteur, boutons et fonctionnement conservés ;
- aucune autre modification d'interface.
