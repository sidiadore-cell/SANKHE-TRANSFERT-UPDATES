# V200 — Correction compilation et Distribution totale

- Correction de l'erreur CS0103 dans `CreateMovementGlassCard` : `venteUVValue` et `achatUVValue` étaient utilisés sans être définis dans la portée de cette méthode.
- Les deux valeurs sont maintenant des paramètres optionnels à 0, sans modifier les appels existants.
- La fonctionnalité Accueil Vente UV / Achat UV de V195+ est conservée dans `CreateServiceDashboardCard`.
- `DISTRIBUTION TOTALE` reste une seule cage et utilise les champs `*Donne`, qui sont cumulés avec les ajouts par `AddBoutiqueFunds`.
