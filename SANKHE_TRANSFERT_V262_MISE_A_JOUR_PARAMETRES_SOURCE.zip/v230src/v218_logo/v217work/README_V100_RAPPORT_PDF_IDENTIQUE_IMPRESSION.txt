V100 - Le bouton RAPPORT PDF produit maintenant une image PDF A4 paysage rendue avec la même mise en page que le rapport d'impression : bandeau, colonnes, descriptions, totaux et pied de page.
