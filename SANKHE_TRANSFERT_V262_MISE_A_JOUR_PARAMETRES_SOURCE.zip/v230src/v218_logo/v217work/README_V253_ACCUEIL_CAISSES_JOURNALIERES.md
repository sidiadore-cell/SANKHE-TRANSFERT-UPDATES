# V253 — Montants des caisses journalières sur Accueil

Ajout sur Accueil d’une rangée « CAISSES JOURNALIÈRES » avec deux cages au même style que les cartes de synthèse : Wave — Journée et Orange Money — Journée.

Les montants sont calculés à partir des compteurs journaliers existants (mouvements nets depuis minuit), sans remplacer ni mélanger les soldes permanents des caisses. Les anciennes dettes encaissées aujourd’hui mais exclues du compteur journalier restent exclues grâce à la logique existante de `GetCaisseJournaliereSummaries`. La zone des opérations récentes est déplacée plus bas pour éviter le chevauchement.

Validation effectuée : archive ZIP vérifiée. Compilation et test visuel Windows/.NET à effectuer.
