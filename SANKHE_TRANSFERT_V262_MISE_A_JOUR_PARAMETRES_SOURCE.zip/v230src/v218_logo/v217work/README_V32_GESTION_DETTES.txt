SANKHÉ TRANSFERT D’ARGENT — V32 GESTION DES DETTES

- Tous les nouveaux Transferts et Envois créent automatiquement une dette à encaisser.
- La dette créée correspond au montant de l’opération + la commission.
- Ajout d’un menu « Dettes » pour suivre les comptes clients ouverts.
- Recherche par nom, prénom ou téléphone.
- Filtre Wave / Orange Money et dettes non soldées / toutes les dettes.
- Pour chaque dette : encaissement total ou partiel.
- Moyens d’encaissement : Caisse, Wave ou Orange Money.
- Une dette soldée est marquée « Soldée » ; un paiement partiel « Partiellement soldée ».
- Chaque règlement est enregistré dans l’historique avec sa référence et son moyen d’encaissement.
- Les soldes Caisse / Wave / Orange Money sont augmentés selon le moyen d’encaissement choisi.
- Les anciens Transferts / Envois présents dans la base sont importés automatiquement comme dettes ouvertes afin de ne pas les oublier. Ils peuvent être soldés depuis le menu Dettes.
- La carte Dette du tableau de bord affiche désormais uniquement le reste à encaisser.
