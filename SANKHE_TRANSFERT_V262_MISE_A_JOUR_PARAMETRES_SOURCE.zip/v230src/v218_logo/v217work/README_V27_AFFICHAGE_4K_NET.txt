SANKHÉ TRANSFERT — V27

Amélioration de la netteté et de la lisibilité de l’interface :
- rendu GDI+ haute qualité (anti-aliasing, interpolation bicubique, ClearType)
- panneaux plus opaques et contrastés pour éviter l’effet délavé
- arrière-plan statique et plus net
- téléphones Wave/Orange conservés en grand arrière-plan
- cartes Dépôt/Retrait, montants et icônes conservés au premier plan
- tableau Dernières transactions plus lisible (en-tête, lignes, hauteur, contraste)
- AutoScaleMode DPI pour un rendu plus stable sur écrans haute résolution

La V26 et ses données/fonctions sont conservées.
