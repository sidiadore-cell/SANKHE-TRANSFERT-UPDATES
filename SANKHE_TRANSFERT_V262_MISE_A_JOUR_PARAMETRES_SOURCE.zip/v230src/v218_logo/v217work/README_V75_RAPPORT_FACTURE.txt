V75 — RAPPORTS IMPRIMABLES AU FORMAT FACTURE

La fonction d'impression des rapports a été modernisée.

En-tête demandé :
Sankhe & Frères
RC : SN LGA 2015 - A - 568 // NINEA : 005597333/20
Tél : 77 519 57 75 - 70 811 04 04
DAHRA - SENEGAL
Email : sankhebaba@gmail.com

Le rapport imprimé conserve les filtres du rapport (service, type, période et recherche Nom & Prénom), avec tableau des opérations et totaux en bas de dernière page.
