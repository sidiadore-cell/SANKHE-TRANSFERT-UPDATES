SANKHÉ TRANSFERT D'ARGENT — V120

Navigation principale améliorée :
- barre des menus plus aérée et plus lisible ;
- boutons plus larges avec espace entre eux ;
- icônes agrandies et placées au-dessus du libellé ;
- texte des menus plus lisible ;
- navigation horizontale avec défilement si l'écran est trop petit ;
- ajout de l'icône Boutique fournie par le concepteur, intégrée en PNG transparent ;
- Mon Boutique conserve son accès entre Opérations et Ajout Seddo.
