V52 — LOGO OFFICIEL DANS L'ENTETE

Le logo fourni par le concepteur a ete integre dans l'entete de l'application.
Il remplace l'ancien symbole etoile + texte separes.
Le logo conserve le symbole SANKHE, le nom SANKHE et le sous-titre TRANSFERT D'ARGENT.
