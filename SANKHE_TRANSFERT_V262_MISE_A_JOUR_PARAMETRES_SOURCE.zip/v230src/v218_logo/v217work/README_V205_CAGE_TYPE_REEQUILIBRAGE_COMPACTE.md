# V205 — cage Type de Rééquilibrage compacte

La cage « TYPE DE RÉÉQUILIBRAGE » de l'écran Opérations a été réduite en largeur pour libérer de l'espace tout en conservant les choix Vente UV et Achat UV lisibles.
La logique de paiement Vente UV n'est pas modifiée : paiement immédiat uniquement Orange Money ou Espèces ; paiement différé = dette.
