# V178 — Vente UV : sortie de caisse puis dette

Nouvelle règle pour `Opérations > Rééquilibrage > Vente UV` :

- Si le service est **Wave**, le montant est immédiatement déduit de `Caisse Wave`.
- Si le service est **Orange Money**, le montant est immédiatement déduit de `Caisse Orange Money`.
- Le montant est simultanément enregistré comme **dette à recouvrer** dans `Dettes`.
- Aucun montant n'est versé dans la Caisse générale au moment de la Vente UV.
- Lors de la solvabilité depuis `Dettes`, le remboursement est ajouté à la caisse réellement choisie : Wave, Orange Money ou Caisse générale/espèces.
- Si la caisse concernée ne dispose pas du solde nécessaire, la Vente UV est refusée et la transaction est annulée.

L'ancienne règle d'Achat UV reste inchangée : Achat UV = sortie immédiate de la Caisse générale, sans dette.
