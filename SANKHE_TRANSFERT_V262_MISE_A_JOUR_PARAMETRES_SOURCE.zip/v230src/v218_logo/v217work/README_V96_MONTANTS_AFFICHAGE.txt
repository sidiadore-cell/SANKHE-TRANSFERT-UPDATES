V96 — Correction affichage des montants Seddo

Le solde Caisse Seddo est affiché avec une zone plus large et FCFA séparé. Le champ montant client est plus lisible, aligné à droite et normalisé à la sortie du champ.
