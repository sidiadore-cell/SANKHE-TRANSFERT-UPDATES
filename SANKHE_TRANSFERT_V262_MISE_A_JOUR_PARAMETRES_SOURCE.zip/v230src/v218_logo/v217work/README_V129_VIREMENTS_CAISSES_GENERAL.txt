SANKHÉ TRANSFERT D'ARGENT — V129

BASE: V124 (GÉRANT + RAPPORTS)

NOUVEAU MODULE CAISSE — VIREMENTS ENTRE CAISSES

- La Caisse générale est désormais une réserve indépendante.
- Ajout du bouton « ⇄ VIREMENT » dans le menu Caisse.
- Un virement permet de déplacer de l'argent entre :
  * Caisse générale
  * Caisse Wave
  * Caisse Orange Money
  * Caisse Seddo
- Le dialogue propose source, destination, montant, motif et référence.
- La Caisse générale est sélectionnée par défaut comme source.
- Le solde disponible de la caisse source est affiché avant validation.
- Un contrôle empêche un virement supérieur au solde disponible.
- Le virement crée automatiquement une sortie dans la caisse source et une entrée dans la caisse destinataire.
- Les deux mouvements partagent la même référence de virement.
- Les soldes sont modifiés dans une seule transaction SQLite : pas de sortie sans entrée correspondante.
- Les virements restent visibles dans les journaux et rapports de caisse.
- Les fonctionnalités de la V124, notamment le nom du gérant dans les rapports, sont conservées.

IMPORTANT : le SDK .NET 8 doit être installé sur le PC pour compiler l'EXE avec CONSTRUIRE_EXE.bat.
