V20 - Affichage central descendu de 9 mm.

Le bloc principal du tableau de bord est positionné à environ 102 px depuis le haut de la zone de contenu, soit environ 9 mm de décalage supplémentaire par rapport à la position de référence V18 à 96 DPI. Le décalage de 80 mm de la V19 est supprimé.
