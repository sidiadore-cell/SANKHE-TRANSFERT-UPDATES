# V226 — Restauration des virements et total des caisses

- Restaure le bouton « VIREMENTS ENTRE CAISSES » dans le menu Caisse.
- Le formulaire permet de choisir la caisse source, la caisse destinataire, le montant, un motif et une référence.
- Utilise Database.TransferCaisse, qui enregistre le virement atomiquement et vérifie le solde disponible.
- Le total général exclut SAMA CAISSE, tout en gardant sa carte et son solde visible dans la synthèse.
- SAMA CAISSE n'est pas proposée comme source ou destinataire des virements et reste indépendante.
