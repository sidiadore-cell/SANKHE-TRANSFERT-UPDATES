V152 — CORRECTION ERREUR PANEL + FLUIDITE

Correction principale : la V151 disposait les anciens contrôles avec Dispose() à chaque
changement de rubrique. Certains panneaux/labels du tableau de bord sont réutilisés
lorsque l'utilisateur revient sur Accueil ou Caisse. Ils pouvaient donc être réutilisés
après Dispose(), provoquant l'exception Windows Forms :
"Cannot access a disposed object. Object name: 'System.Windows.Forms.Panel'."

V152 retire les anciens contrôles de la collection visuelle sans disposer les contrôles
partagés. La navigation reste masquée pendant la reconstruction afin d'éviter le flash
blanc. Les calculs et données métier ne sont pas modifiés.
