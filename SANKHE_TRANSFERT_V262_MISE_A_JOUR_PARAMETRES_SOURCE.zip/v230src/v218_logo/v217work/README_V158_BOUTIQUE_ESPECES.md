V158 — MON BOUTIQUE : DOTATION ESPÈCES / CAISSE GÉNÉRALE

- La dotation d'un employé peut maintenant contenir trois montants : Wave, Orange Money et Espèces.
- La dotation Espèces du matin est automatiquement débitée de la Caisse générale.
- Un ajout d'espèces en cours de journée est également débité de la Caisse générale.
- Le retour d'espèces du soir est automatiquement crédité dans la Caisse générale.
- Wave continue d'utiliser la Caisse Wave et Orange Money la Caisse Orange Money.
- Les rapports Boutique affichent désormais une colonne ESPÈCES.
- L'historique Boutique affiche également les montants en espèces.
- La base existante est migrée automatiquement : les anciennes sessions ont 0 FCFA en espèces.
