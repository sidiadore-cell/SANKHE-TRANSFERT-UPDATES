SANKHÉ TRANSFERT D'ARGENT — V56

GESTION DES CAISSES SÉPARÉES

- Caisse Wave séparée avec son propre solde de départ.
- Caisse Orange Money séparée avec son propre solde de départ.
- Caisse générale conservée indépendamment.
- Les dépôts Wave augmentent uniquement la Caisse Wave.
- Les retraits Wave diminuent uniquement la Caisse Wave.
- Les dépôts Orange Money augmentent uniquement la Caisse Orange Money.
- Les retraits Orange Money diminuent uniquement la Caisse Orange Money.
- Les transferts/envois créent toujours la dette et ne retirent pas de liquidité avant le règlement.
- Le règlement d'une dette peut être encaissé dans la Caisse Wave ou la Caisse Orange Money selon le service.
- Le journal, le solde de départ, les entrées/sorties et l'impression sont séparés par caisse.
- Les anciennes bases sont migrées automatiquement : les anciens mouvements de caisse restent dans la caisse générale.
- L'effacement complet de la base remet à zéro les trois caisses ainsi que les portefeuilles.

IMPORTANT
La compilation n'a pas pu être exécutée dans cet environnement car le SDK .NET n'est pas installé ici. Le projet reste fourni avec les sources modifiées.
