V240 — Menu Caisse : boutons réintégrés

- Les cartes Caisse Wave, Orange Money, Caisse en espèces et Caisse Seddo retrouvent les boutons + Entrée, − Sortie et Modifier solde.
- Les boutons ouvrent les formulaires de mouvement/solde existants pour la caisse correspondante.
- Aucun bouton de mouvement manuel n’est ajouté à la carte SAMA CAISSE.
- La synthèse générale continue d’exclure SAMA CAISSE.
