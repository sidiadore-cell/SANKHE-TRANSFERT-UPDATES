SANKHE TRANSFERT V103 - CORRECTION RAPPORT PDF PAGE VIDE

Correction principale :
- Le rendu de la page PDF utilisait GraphicsUnit.Display alors que la bitmap était dimensionnée en pixels.
- Le rendu PDF utilise maintenant GraphicsUnit.Pixel, avec les dimensions A4 paysage 1169 x 827 pixels.
- Le PDF conserve la même composition visuelle que le rapport imprimable.
- Aucun changement au fonctionnement des caisses, Seddo, dettes ou rapports.

Le bouton RAPPORT PDF reste disponible dans Rapports.
