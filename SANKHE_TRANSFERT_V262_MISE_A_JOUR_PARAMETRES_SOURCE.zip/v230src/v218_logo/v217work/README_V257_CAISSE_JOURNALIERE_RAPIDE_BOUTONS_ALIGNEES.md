# V257 — Caisse journalière plus rapide et navigation simplifiée

- Suppression du bouton « CLÔTURER / VÉRIFIER » des trois caisses.
- Remplacement des onglets par trois boutons alignés : WAVE, ORANGE MONEY, ESPÈCES.
- Les boutons affichent clairement la caisse active avec sa couleur.
- Chargement paresseux : seul l’historique de la caisse sélectionnée est chargé, avec une limite de 250 mouvements, au lieu de charger les trois historiques à chaque actualisation.
- Les calculs financiers et les écritures en base ne sont pas modifiés.

La compilation et les tests de l’application Windows doivent être réalisés avec le SDK .NET sur Windows.
