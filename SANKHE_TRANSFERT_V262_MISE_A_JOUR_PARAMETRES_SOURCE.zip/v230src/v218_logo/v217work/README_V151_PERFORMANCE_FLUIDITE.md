# V151 — Performance, fluidité et suppression des pages blanches

- Navigation reconstruite hors écran pour éviter les flashes/pages blanches pendant le changement de rubrique.
- `SuspendLayout/ResumeLayout` utilisés pendant la reconstruction des pages afin de réduire les recalculs de layout.
- Les anciens contrôles de page sont explicitement libérés lors de la navigation pour limiter l'accumulation de handles/ressources.
- Double buffering conservé pour réduire le scintillement.
- Fond de la fenêtre principal passé en bleu sombre afin qu'aucune zone blanche ne soit affichée pendant une transition.
- Aucun calcul métier, aucune donnée, aucun format de saisie et aucune logique de caisse n'est modifié.
