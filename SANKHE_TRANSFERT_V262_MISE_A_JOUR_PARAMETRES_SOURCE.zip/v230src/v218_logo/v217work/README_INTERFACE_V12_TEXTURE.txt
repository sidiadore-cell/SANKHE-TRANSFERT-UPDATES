VERSION 12 - INTERFACE TEXTURE MAQUETTE

L'interface du tableau de bord a ete refondue pour reprendre la texture visuelle de la maquette validee :
- fond bleu nuit avec halos lumineux animes
- navigation horizontale en haut
- cage Wave independante avec depots et retraits
- cage Orange Money independante avec depots et retraits
- cages Caisse / Dette Wave / Dette Orange / Dette totale
- panneau Dernieres transactions en verre sombre
- bordures lumineuses, coins arrondis et transparence

Les donnees continuent d'etre lues depuis Database.cs.
