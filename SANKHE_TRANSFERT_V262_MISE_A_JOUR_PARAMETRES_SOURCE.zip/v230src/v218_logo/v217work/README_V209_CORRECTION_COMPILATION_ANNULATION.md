# V209 — Correction de compilation du module Annulation

Correction de l’erreur de compilation CS1003/CS1056/CS1026 provoquée par un retour à la ligne réel dans la chaîne interpolée de confirmation d’annulation.

La boîte de confirmation utilise maintenant `\n\n` dans une chaîne C# valide. Aucune règle métier du module Annulation n’a été modifiée.
