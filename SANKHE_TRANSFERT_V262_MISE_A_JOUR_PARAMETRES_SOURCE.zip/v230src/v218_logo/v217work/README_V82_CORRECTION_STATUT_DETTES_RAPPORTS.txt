SANKHÉ TRANSFERT – V82
Correction du statut des dettes dans les rapports.

Problème corrigé :
Lorsque plusieurs transferts/envois d'un même client utilisaient la même référence
(ou une référence vide), le rapport pouvait associer plusieurs opérations à la dette
du dernier transfert.

Correction :
- Chaque opération conserve maintenant son Id de base de données dans OperationRow.
- Le rapport recherche d'abord la dette par Dettes.OperationId.
- Les remboursements continuent d'utiliser l'identifiant de dette présent dans
  l'observation « Règlement dette ... ».
- Le statut Soldée / Non soldée affiché correspond ainsi à la dette réelle de
  chaque transfert.

Exemple :
Si 3 anciens transferts sont soldés et seul le dernier reste impayé, le rapport
affiche désormais les 3 premiers « Soldée » et uniquement le dernier « Non soldée ».
