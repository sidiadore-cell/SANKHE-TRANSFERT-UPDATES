V73 — DESIGN DES MONTANTS DANS CAISSE

Dans la page « Caisse », les quatre cartes de caisse conservent le design sombre/glassmorphism.
Le montant est désormais présenté comme dans la maquette demandée :
- montant très lisible et en gras ;
- « FCFA » immédiatement à droite du montant ;
- montant + FCFA toujours sur la même ligne ;
- taille du montant adaptée automatiquement si le nombre est long ;
- aucune indication supplémentaire sous le montant pour ne pas encombrer la carte.

La logique des caisses et les mouvements ne sont pas modifiés.
