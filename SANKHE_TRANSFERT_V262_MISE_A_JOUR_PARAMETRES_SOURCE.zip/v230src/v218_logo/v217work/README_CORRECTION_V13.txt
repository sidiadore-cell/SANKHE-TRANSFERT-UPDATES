V13 - CORRECTION AFFICHAGE

Correction du scintillement / saut des couleurs constaté à l'écran.
- Suppression de l'animation permanente du fond.
- Suppression du Timer qui provoquait des Invalidate toutes les 35 ms.
- Fond et halos désormais totalement statiques.
- Double buffering renforcé pour éviter le clignotement.
- Rendu graphique haute qualité pour les cages transparentes.
- Les couleurs Wave / Orange Money restent fixes et nettes.

Le design V12 est conservé.
