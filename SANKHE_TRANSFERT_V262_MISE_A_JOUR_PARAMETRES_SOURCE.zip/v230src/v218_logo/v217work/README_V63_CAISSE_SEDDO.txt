SANKHÉ TRANSFERT D'ARGENT — V63

AJOUT : CAISSE SEDDO

- Ajout d'une caisse indépendante « Caisse Seddo ».
- Ajout de l'icône Seddo fournie par l'utilisateur.
- La caisse Seddo possède son propre solde de départ, ses entrées, ses sorties et son journal.
- La page Caisse affiche maintenant 4 caisses : Wave, Orange Money, Seddo et Générale.
- Le bouton de sélection Seddo change de couleur lorsqu'il est actif.
- Le solde de la caisse générale inclut désormais Caisse générale + Caisse Wave + Caisse Orange Money + Caisse Seddo.
- L'effacement complet de la base remet également la Caisse Seddo à zéro.
- Les sauvegardes/restaurations SQLite conservent naturellement la caisse Seddo.

Remarque : la compilation n'a pas pu être exécutée dans l'environnement de génération car le SDK .NET n'y est pas installé. Le code a été modifié directement dans le projet V62.
