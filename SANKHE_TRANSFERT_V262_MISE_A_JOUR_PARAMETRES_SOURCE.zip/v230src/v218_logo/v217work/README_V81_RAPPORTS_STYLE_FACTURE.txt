V81 — RAPPORTS IMPRIMABLES STYLE FACTURE

Les rapports imprimables ont été entièrement remis en forme pour s'inspirer du modèle de facture fourni :
- bandeau supérieur bleu marine avec logo SANKHÉ et accent doré ;
- coordonnées de Sankhe & Frères ;
- titre centré et informations de période ;
- rapport individuel client en format portrait, avec bloc client ;
- tableau propre avec en-tête coloré, lignes alternées et statuts Soldée/Non soldée en couleur ;
- blocs de totaux mis en évidence ;
- pied de page avec numéro de page ;
- rapport général en format paysage avec la même identité visuelle ;
- aucune colonne de remboursement de dette par service dans les rapports imprimés.
