@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo SANKHE TRANSFERT D'ARGENT - V122
echo ================================================
if not exist "SankheTransfert.csproj" (
  echo ERREUR : SankheTransfert.csproj introuvable.
  pause
  exit /b 1
)
dotnet restore "SankheTransfert.csproj"
if errorlevel 1 goto :error
dotnet publish "SankheTransfert.csproj" -c Release -r win-x64 --self-contained false -o "publish"
if errorlevel 1 goto :error
echo.
echo BUILD TERMINE. EXE : %~dp0publish\Sankhe Transfert.exe
pause
exit /b 0
:error
echo.
echo ERREUR DE COMPILATION.
pause
exit /b 1
