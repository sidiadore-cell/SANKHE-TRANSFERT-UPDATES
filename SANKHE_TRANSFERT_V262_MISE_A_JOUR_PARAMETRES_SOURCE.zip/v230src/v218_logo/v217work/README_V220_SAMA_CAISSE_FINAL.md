# V220 — SAMA CAISSE dans le menu Caisse

- SAMA CAISSE est une caisse indépendante.
- Elle apparaît comme une carte dédiée dans le menu **Caisse**.
- Le logo officiel SAMA CAISSE est utilisé uniquement sur cette carte.
- La carte affiche : solde actuel, solde de départ, entrées, sorties et historique.
- Les boutons Entrée / Sortie / Modifier solde / Imprimer agissent sur SAMA CAISSE uniquement lorsque cette caisse est sélectionnée.
- SAMA CAISSE n'est pas automatiquement reliée à Wave, Orange Money, Seddo, caisse en espèces, dettes ou caisse journalière.
- Le solde de SAMA CAISSE est compté séparément dans le total des caisses.
- Le logo PNG a été nettoyé avec un fond transparent pour une meilleure intégration visuelle.
