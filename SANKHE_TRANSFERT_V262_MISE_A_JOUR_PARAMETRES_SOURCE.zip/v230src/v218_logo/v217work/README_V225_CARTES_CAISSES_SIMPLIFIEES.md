# V225 — Cartes des caisses simplifiées

Modifications du menu Caisse à partir de V224 :
- Suppression des lignes Solde de départ, Entrées et Sorties dans les cartes principales.
- Suppression du bouton DÉTAIL dans chacune des cartes principales.
- Conservation des boutons + ENTRÉE, − SORTIE et MODIFIER SOLDE.
- Conservation du bandeau de caisse journalière pour Wave et Orange Money.
- Correction du doublon « FCFA FCFA » dans les soldes des cartes et de la synthèse.
- Synthèse générale conservée et rapprochée des cartes pour libérer de l’espace.

Les données financières et les historiques ne sont pas supprimés.
Compilation .NET 8 à effectuer sur Windows.
