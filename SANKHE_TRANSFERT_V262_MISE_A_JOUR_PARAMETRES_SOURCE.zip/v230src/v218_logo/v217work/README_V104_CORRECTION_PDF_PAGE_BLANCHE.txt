V104 - CORRECTION PDF PAGE BLANCHE

Correction définitive de l'export PDF : les nombres PDF (MediaBox et matrice d'affichage) sont maintenant écrits avec CultureInfo.InvariantCulture.
Cela évite qu'un Windows configuré en français écrive des virgules décimales dans le PDF (ex: 841,89), ce qui rendait le fichier PDF invalide/affiché blanc dans Foxit.

Le PDF conserve le rendu image du rapport imprimable, en A4 paysage.
