V239 — SAMA CAISSE : filtres et impression par client

- Les listes actives Argent confié et Argent prêté masquent les soldes entièrement réglés.
- Les opérations réglées restent conservées dans les historiques.
- Recherche texte par client, motif, référence, type et date; filtres par date début/fin et type d’opération.
- Impression/PDF des résultats filtrés; impression de toutes les opérations du client sélectionné dans les résultats.
- Dates et heures enregistrées conservées dans les historiques.
