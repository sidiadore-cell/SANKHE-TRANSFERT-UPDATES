V51 — Icône officielle SANKHÉ TRANSFERT D’ARGENT

Le logo fourni a été adapté en icône Windows (Sankhe.ico) et appliqué à l’EXE et à la fenêtre principale.
