V21 - DESIGN MAQUETTE

- Ajout de téléphones Wave et Orange Money en arrière-plan des grandes cages.
- Ajout d'icônes de pièces empilées dans les cartes Dépôts / Retraits.
- Fond bleu nuit/orange statique.
- Logos Wave et Orange Money exacts conservés.
- Structure fonctionnelle de la V20 conservée.
