# V198 — Distribution totale Boutique

Ajout du total de dotation (distribution initiale + compléments) dans les indicateurs Mon Boutique. Le champ TOTAL DISTRIBUÉ des postes est renommé DISTRIBUTION TOTALE. Les champs *Donne* incluent déjà les compléments ; aucun double comptage.
