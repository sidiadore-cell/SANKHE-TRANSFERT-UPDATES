VERSION V238 — HISTORIQUES SAMA CAISSE AVEC DATES ET HEURES

Modifications :
- Ajout du bouton « HISTORIQUE DÉTAILLÉ » dans la rubrique Argent confié.
- L'historique affiche chaque dépôt client et chaque restitution séparément, avec date et heure (secondes incluses), client, montant, motif et référence.
- Ajout du bouton « HISTORIQUE DÉTAILLÉ » dans la rubrique Argent prêté.
- L'historique affiche chaque prêt accordé et chaque remboursement séparément, avec date et heure, client, montant, motif et référence.
- Les historiques détaillés proposent l'impression et l'export PDF.
- Les données utilisent la date/heure enregistrée dans SamaTransactions; aucune date ancienne n'est inventée.

Note de validation : l'archive source a été modifiée et contrôlée. La compilation .NET n'a pas pu être exécutée dans cet environnement, car le SDK dotnet n'est pas disponible. Compiler sur un PC équipé du .NET SDK 8 avant usage en production.
