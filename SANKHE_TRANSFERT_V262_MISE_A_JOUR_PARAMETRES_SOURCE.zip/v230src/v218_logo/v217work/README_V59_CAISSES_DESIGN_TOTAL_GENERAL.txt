SANKHE TRANSFERT D'ARGENT - V59

CAISSES : DESIGN + TOTAL GENERAL

- La page Caisse affiche trois gros boutons : CAISSE WAVE, CAISSE ORANGE MONEY, CAISSE GENERALE.
- Chaque caisse conserve son propre solde de depart, ses entrees, sorties et son journal.
- La CAISSE GENERALE affiche toujours le total : Caisse generale + Caisse Wave + Caisse Orange Money.
- Une variation de la caisse Wave ou Orange Money se repercute donc automatiquement dans le total general.
- Les soldes Wave et Orange Money restent geres separement.
- Le tableau de mouvements reste filtre par la caisse selectionnee.
