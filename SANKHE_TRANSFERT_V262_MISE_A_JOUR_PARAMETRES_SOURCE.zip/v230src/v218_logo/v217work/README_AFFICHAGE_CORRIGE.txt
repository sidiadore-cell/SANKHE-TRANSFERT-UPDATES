SANKHÉ TRANSFERT — CORRECTION AFFICHAGE V2

Corrections apportées :
- Tableau de bord responsive et centré dans la zone de contenu.
- Cartes Wave et Orange Money en deux colonnes, avec adaptation automatique de la largeur.
- Bloc Situation financière réorganisé en grille pour éviter les données coupées.
- Les métriques s'adaptent à la largeur de la fenêtre.
- Défilement activé si la fenêtre devient trop petite.
- Correction de l'accumulation de l'animation de fond lors des changements de page.

Projet : .NET 8 Windows Forms
