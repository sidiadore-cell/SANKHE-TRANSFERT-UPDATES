SANKHÉ TRANSFERT D’ARGENT — V34
GESTION DE CAISSE / COMPTABILITÉ GÉNÉRALE

Nouveautés :
- Menu Caisse fonctionnel.
- Saisie d’un solde de départ pour commencer la journée.
- Entrées et sorties manuelles de liquidités.
- Journal de caisse avec date, mouvement, montant, motif et référence.
- Solde actuel de caisse affiché.
- Résumé : solde de départ, entrées du jour, sorties du jour, caisse actuelle.
- Impression du journal de caisse.
- Dépôt Wave/Orange : le cash entre dans la caisse et le portefeuille est débité.
- Retrait Wave/Orange : le cash sort de la caisse et le portefeuille est crédité.
- Transfert/Envoi : le portefeuille est débité et la dette est conservée ; le cash n’entre qu’au règlement de la dette.
- Règlement d’une dette par Caisse : l’encaissement est ajouté au journal de caisse et au solde de caisse.
- Contrôle des sorties manuelles : impossible de sortir plus que le disponible.

Compilation :
lancer CONSTRUIRE_EXE.bat sous Windows avec le SDK .NET 8 installé.
