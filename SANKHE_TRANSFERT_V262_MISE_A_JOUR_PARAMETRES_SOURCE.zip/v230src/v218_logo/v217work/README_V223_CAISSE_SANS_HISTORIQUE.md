V223 — Menu Caisse épuré

- Retrait du tableau « Historique des mouvements » du menu Caisse pour libérer l’espace.
- Les cinq cartes de caisse et la synthèse générale restent affichées.
- Les mouvements et leurs données ne sont pas supprimés de la base.
- L’historique reste disponible dans les menus dédiés (Journalisation / Rapports).
- Les soldes, les entrées/sorties et la logique financière ne sont pas modifiés.

Compilation .NET 8 non exécutée dans l’environnement de préparation.
