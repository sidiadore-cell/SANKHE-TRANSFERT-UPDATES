V19 - Affichage central descendu de 80 mm supplémentaires.

Le bloc principal du tableau de bord est décalé vers le bas de 300 pixels environ (équivalent approximatif de 80 mm à 96 DPI). Le reste du design, les logos et les données sont conservés.
