V156 correction: tableWidth -> tableW
