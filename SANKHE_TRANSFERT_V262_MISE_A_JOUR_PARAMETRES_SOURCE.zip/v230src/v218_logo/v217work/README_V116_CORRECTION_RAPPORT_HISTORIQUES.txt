SANKHE TRANSFERT D'ARGENT — V116

Correction de la V115 :
- Rapport général « Tous les services » inclut Wave, Orange Money, Seddo et Mon Boutique.
- Les distributions Boutique, les compléments + AJOUTER et les retours du soir apparaissent avec leur date/heure.
- Historique ajoute Seddo, Mon Boutique et Caisses.
- Historique Caisses permet de choisir toutes les caisses, Wave, Orange Money, Seddo ou générale.
- Code réorganisé avec des méthodes classiques plutôt que certaines expressions locales complexes afin d'éviter les erreurs de compilation.
- Projet placé directement à la racine du ZIP pour éviter les problèmes de chemin lors de la compilation.
