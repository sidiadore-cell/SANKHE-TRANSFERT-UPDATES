SANKHÉ TRANSFERT D'ARGENT — V136

Modifications du menu Opérations :
- Suppression des cages Dette Wave, Dette Orange Money, Dette totale et Dette à encaisser.
- Remplacement par une seule cage : TOTAL CAISSES WAVE + ORANGE MONEY.
- Le total correspond à Caisse Wave + Caisse Orange Money.
- Lorsqu'on sélectionne Transfert, l'en-tête devient « TRANSFERT — DETTE À ENCAISSER ».
- Le champ Montant passe en rouge pour signaler clairement la dette.
- Un message rouge « DETTE À ENCAISSER » est affiché sous les champs.
- Le comportement comptable existant du transfert est conservé.
