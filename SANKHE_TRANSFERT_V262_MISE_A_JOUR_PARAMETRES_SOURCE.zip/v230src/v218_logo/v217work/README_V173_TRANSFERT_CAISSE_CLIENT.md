# V173 — Transfert caisse + sélection client uniforme

Modifications :
- Opération **Transfert** : le montant est directement déduit de la caisse du service sélectionné
  (**Caisse Wave** ou **Caisse Orange Money**).
- La dette du transfert reste créée pour être remboursée depuis le menu Dettes.
- Sélection client dans les écrans de saisie :
  - dès la première lettre, affichage des clients dont le nom ou un prénom commence par la saisie ;
  - sélection explicite du client ;
  - remplissage du téléphone uniquement après sélection ;
  - si aucun client ne correspond, la saisie libre reste possible.
- Cette sélection est appliquée aux saisies client de **Nouveau transfert/opération** et **Seddo**.
