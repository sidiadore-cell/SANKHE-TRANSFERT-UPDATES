SANKHÉ TRANSFERT – V10

Nouvelle interface du tableau de bord inspirée de la maquette validée.

- WAVE et ORANGE MONEY sont maintenant deux grandes cages totalement indépendantes.
- Chaque cage affiche son volume total ainsi que DÉPÔTS, RETRAITS et TRANSFERTS.
- CAISSE, DETTE WAVE, DETTE ORANGE et DETTE TOTALE sont dans quatre cages séparées.
- Ajout d'une zone « Dernières transactions » avec date, service, type, montant, référence et téléphone.
- Effet transparent/glassmorphism et couleurs dédiées Wave / Orange Money.
- Les données restent récupérées depuis la base SQLite existante.

Projet .NET 8 Windows Forms.
Lancer CONSTRUIRE_EXE.bat sur Windows avec le SDK .NET 8 installé.
