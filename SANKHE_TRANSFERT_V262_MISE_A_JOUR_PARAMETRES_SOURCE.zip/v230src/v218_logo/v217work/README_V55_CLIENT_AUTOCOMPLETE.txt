SANKHÉ TRANSFERT D’ARGENT — V54

Optimisations fluidité :
- cache des images pour éviter les relectures disque et décodages à chaque repaint ;
- rendu du fond allégé (AntiAlias/HighSpeed) ;
- recherche Dettes et Rapports légèrement temporisée (180 ms) pour éviter une requête SQLite à chaque frappe ;
- conservation du double buffering de l’interface.

Aucune modification de la logique métier, des calculs de caisse, dettes, rapports ou sauvegardes.


V55 - CLIENTS AUTOCOMPLÉTION
- Dans Opérations, les clients déjà enregistrés sont proposés automatiquement dès la saisie du nom/prénom.
- Après sélection/saisie exacte d’un client unique, son numéro de téléphone est rempli automatiquement.
- La liste des clients est chargée une seule fois à l’ouverture de la page pour conserver une interface fluide.
