# V167 — Cage de paiement au premier plan

Correction ciblée de l’affichage Seddo :
- la bande Commission / Montant total est placée derrière la cage du mode de paiement ;
- la cage Wave / Orange Money / Espèces est superposée au premier plan ;
- le message « Paiement sélectionné » reste dans la cage ;
- aucune nouvelle maquette ni changement de logique métier.
