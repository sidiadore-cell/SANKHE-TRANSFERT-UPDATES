V131 — EMPLOYÉS MON BOUTIQUE CONSERVÉS

La fonction « Effacer les données » ne supprime plus les employés enregistrés dans Mon Boutique.

Conservés :
- les 6 postes et leurs employés ;
- noms/prénoms ;
- téléphones ;
- notes et affectations de poste.

Effacés comme avant :
- clients ;
- opérations ;
- dettes et paiements ;
- historiques Boutique (sessions et opérations) ;
- mouvements de caisse ;
- soldes opérationnels.

Ainsi, après une réinitialisation, les employés restent disponibles dans « Mon Boutique » et peuvent immédiatement être réutilisés.
