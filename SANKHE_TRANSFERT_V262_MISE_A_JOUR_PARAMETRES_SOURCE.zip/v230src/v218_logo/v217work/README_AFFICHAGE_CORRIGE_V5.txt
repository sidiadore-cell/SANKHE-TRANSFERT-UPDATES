SANKHE TRANSFERT D'ARGENT - V5

Correction principale : mise en page du tableau de bord reduite et centree.
- largeur maximale du contenu : 980 px
- contenu centre automatiquement dans la zone disponible
- cartes Wave / Orange Money reduites et alignees
- situation financiere compacte
- meilleure adaptation aux grands ecrans et aux zooms Windows

Construction :
1. Ouvrir le dossier avec Visual Studio / .NET 8.
2. Executer CONSTRUIRE_EXE.bat.
