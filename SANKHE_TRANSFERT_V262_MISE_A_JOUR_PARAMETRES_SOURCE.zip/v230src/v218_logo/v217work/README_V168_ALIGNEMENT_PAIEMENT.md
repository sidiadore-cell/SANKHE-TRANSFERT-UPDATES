# V168 — Alignement paiement Seddo

Correction ciblée de l'affichage de la carte Seddo :
- la cage **MODE DE PAIEMENT** est alignée à droite de la carte ;
- la bande **Commission / Montant total** est alignée à gauche ;
- la cage de paiement reste au premier plan visuel ;
- les 3 boutons Wave / Orange Money / Espèces sont redimensionnés pour tenir proprement dans la cage ;
- aucun changement de logique métier.
