V147 — TYPE DE RÉÉQUILIBRAGE DANS LES RAPPORTS

Modification :
- Lorsqu’une opération est un « Rééquilibrage », la colonne Description indique maintenant le type réellement effectué.
- Affichage : « Rééquilibrage — Vente UV » ou « Rééquilibrage — Achat UV ».
- Fonctionne dans la liste des rapports, l’impression, le PDF, le rapport individuel client et l’export CSV car ces vues utilisent la même description.
- Les anciennes opérations sont également reconnues lorsque Observation contient « Vente UV » ou « Achat UV ».
- Aucun calcul de caisse ni aucune logique d’enregistrement n’a été modifié.
