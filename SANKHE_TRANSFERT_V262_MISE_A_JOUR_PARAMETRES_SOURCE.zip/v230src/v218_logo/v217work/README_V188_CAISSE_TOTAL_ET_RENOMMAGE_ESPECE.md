# V188 — Total des caisses + renommage Caisse en espèce

Modifications appliquées à partir de V187 :

- Ajout en haut de la page **Caisse** d'un bandeau **TOTAL DES CAISSES**.
- Le total additionne les soldes de :
  - Caisse Wave
  - Caisse Orange Money
  - Caisse Seddo
  - Caisse en espèce
- Le bandeau affiche également le détail de chaque caisse.
- Renommage visuel de **Caisse générale** en **Caisse en espèce** dans l'interface, les virements, les rapports et les filtres concernés.
- Le nom interne de la base de données reste **Caisse** afin de préserver les données existantes et la compatibilité avec les opérations historiques.
- Les calculs de virements continuent donc de fonctionner avec la caisse interne `Caisse`.
- La mise en page de la page Caisse a été décalée vers le bas pour laisser un espace propre au nouveau bandeau.

Remarque : le SDK .NET n'est pas disponible dans l'environnement de préparation, donc aucune compilation Windows réelle n'a pu être exécutée ici.
