# V187 — Boutique : remboursements partiels cumulables

- Un employé peut rembourser une partie de sa dotation pendant la journée.
- Les versements sont cumulés jusqu’au total distribué (distribution + ajouts).
- Le remboursement peut être réparti librement entre Wave, Orange Money et espèces.
- Un versement supérieur au reste est refusé.
- Chaque versement partiel est enregistré dans l’historique Boutique avec son service et son montant.
- La caisse correspondante est créditée à chaque versement.
- Le poste reste ouvert tant que le reste est supérieur à 0.
- Le poste se clôture automatiquement lorsque le total versé atteint exactement le total distribué.
- La carte affiche séparément les sommes versées en Wave, Orange Money et espèces, ainsi que le total versé et le reste.
- « Diadieuf » est affiché en grand, avec une police Georgia élégante, entre le numéro du poste et le point d’état après clôture complète.
