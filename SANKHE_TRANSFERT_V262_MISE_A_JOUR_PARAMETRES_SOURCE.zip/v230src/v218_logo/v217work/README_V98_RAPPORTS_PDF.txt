V98 - AJOUT RAPPORT PDF

Ajout du bouton RAPPORT PDF dans le menu Rapports. Le PDF est généré directement par l application, avec en-tête Sankhe & Frères, filtres, tableau des opérations, montants, commissions, dettes, statuts et totaux. Le CSV, l impression et le rapport individuel client sont conservés.
