SANKHÉ TRANSFERT V24

Correction de compilation de la V23.

La V23 utilisait ImageAttributes, ColorMatrix, ColorMatrixFlag et ColorAdjustType sans importer System.Drawing.Imaging.
Le fichier MainForm.cs inclut maintenant le namespace nécessaire.

Le design V23 est conservé : téléphones grands en arrière-plan, transparents, derrière les cartes.
