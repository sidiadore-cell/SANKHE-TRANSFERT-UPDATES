V25 - TELEPHONES EN ARRIERE-PLAN SUR TOUTE LA CAGE

Les images de téléphone Wave et Orange Money occupent désormais toute la grande cage de service.
Elles restent dessinées dans le Paint du panneau, donc derrière les textes, montants et cartes Dépôt/Retrait.
Le rendu conserve les proportions de l'image (mode cover) et une transparence de 24%.
