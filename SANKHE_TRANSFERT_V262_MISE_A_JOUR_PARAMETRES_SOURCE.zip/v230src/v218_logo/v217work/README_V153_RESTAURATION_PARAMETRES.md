V153 — Restauration des modifications Paramètres

- Deux options de suppression : garder les clients / supprimer aussi les clients.
- Les employés de Mon Boutique restent conservés car ils sont dans une table séparée.
- Paramètres en deux colonnes gauche/droite pour gagner de l’espace.
- Cartes centrées dans la zone disponible.
- Conservation des corrections V152 contre Cannot access a disposed object et du rafraîchissement blanc.
