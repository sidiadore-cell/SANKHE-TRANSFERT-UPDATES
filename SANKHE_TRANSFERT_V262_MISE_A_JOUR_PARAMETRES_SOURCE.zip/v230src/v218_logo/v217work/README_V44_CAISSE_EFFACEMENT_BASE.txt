SANKHÉ TRANSFERT D’ARGENT — V44

Correction Paramètres > Effacer toute la base de données.

L’effacement supprime désormais aussi tous les mouvements de caisse (CaisseMouvements), puis réinitialise les soldes Caisse, Wave et Orange Money à 0. Les dettes, paiements de dettes, opérations et clients sont également supprimés.

Les compteurs SQLite sont réinitialisés pour repartir sur une base propre.
