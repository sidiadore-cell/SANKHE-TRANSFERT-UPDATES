SANKHÉ TRANSFERT D'ARGENT — V69

Modification accueil/caisse demandée :
- Les cages des caisses sont plus larges : affichage en 2 colonnes / 2 lignes.
- Le montant est affiché sans répétition de FCFA.
- « FCFA » est placé sur la même ligne que le montant.
- Les quatre caisses restent disponibles : Wave, Orange Money, Seddo et Générale.
- Le fonctionnement et les soldes sont conservés.
