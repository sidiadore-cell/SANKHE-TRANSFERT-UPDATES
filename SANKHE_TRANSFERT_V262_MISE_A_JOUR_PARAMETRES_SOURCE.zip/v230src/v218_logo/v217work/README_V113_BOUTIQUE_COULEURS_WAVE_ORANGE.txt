V113 — Mon Boutique : montants Wave en bleu et montants Orange Money en orange, selon les couleurs des services. Les KPI distribution/retour utilisent également les couleurs correspondantes.
