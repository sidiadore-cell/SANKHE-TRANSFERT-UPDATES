SANKHÉ TRANSFERT D’ARGENT — V37

Correction du warning CS8604 signalé à Database.cs ligne 446 :
Normalize(clientSearch) pouvait recevoir null alors que Normalize attend une chaîne non nullable.
Correction : Normalize(clientSearch ?? "").

Aucune modification de la logique de caisse ou de l’affichage.
