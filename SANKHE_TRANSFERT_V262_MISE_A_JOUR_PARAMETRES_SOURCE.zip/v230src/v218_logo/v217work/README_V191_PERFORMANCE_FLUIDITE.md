# V191 — Performance et fluidité

Optimisations appliquées à partir de V190 :
- SQLite : WAL, cache mémoire, temp_store=MEMORY et mmap 256 Mo sur chaque connexion.
- Tableau de bord : remplacement de nombreuses sous-requêtes indépendantes par une agrégation unique des tables Soldes, Dettes et Operations.
- Comptage des opérations du jour borné entre aujourd'hui et demain.
- Aucun changement volontaire dans les règles métier, les montants ou la structure des données.

Objectif : accélérer l'ouverture du tableau de bord et les rafraîchissements fréquents, surtout quand la base contient beaucoup d'opérations.
