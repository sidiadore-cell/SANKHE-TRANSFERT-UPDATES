# V161 — Correction Transfert / Dette

- Dépôt : + caisse Wave/Orange, - caisse générale.
- Retrait : - caisse Wave/Orange, + caisse générale.
- Transfert / Envoi : le portefeuille Wave/Orange diminue et une dette est créée ; aucune caisse (Wave, Orange ou générale) ne bouge au moment de la création de la dette.
- Remboursement de dette : l'argent est encaissé dans la caisse choisie : Caisse Wave, Caisse Orange Money ou Caisse générale si le client paie en liquide.
- Rééquilibrage : logique inchangée.
