V213 - Ajustements menu Annulation

- Motif d'annulation désormais facultatif.
  Si laissé vide, la trace utilise automatiquement : "Annulation sans motif renseigné".
- Bloc des modes de recherche descendu d'environ 1 cm pour améliorer la mise en page.
- Les boutons Voir la fiche / Annuler et le tableau sont décalés de la même hauteur pour conserver l'alignement.
- Le filtre de statut par défaut est "Active" : les opérations annulées disparaissent de la liste principale.
- Après une annulation réussie, la liste est rechargée immédiatement : l'opération annulée disparaît directement de l'affichage courant.
- Les opérations annulées restent conservées en base pour la traçabilité et peuvent être retrouvées via le filtre "Toutes" ou "Annulée".
