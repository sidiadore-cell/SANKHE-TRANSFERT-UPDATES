V119 — BOUTIQUE + PDF + HISTORIQUE

- Mon Boutique : l'état du poste est indiqué uniquement par un grand point : vert si ouvert/actif, blanc sinon. Le libellé « POSTE » à côté du point a été supprimé.
- Rapport Boutique PDF : correction du générateur PDF avec CultureInfo.InvariantCulture pour empêcher les virgules décimales de Windows FR de rendre le PDF invalide/blanc. Le PDF reprend le même rendu graphique que RenderBoutiqueReport utilisé pour l'impression.
- Historique : onglets Wave, Orange Money, Seddo, Boutique et Caisse transformés en boutons/onglets visuels plus grands, arrondis, contrastés et colorés selon le service.
