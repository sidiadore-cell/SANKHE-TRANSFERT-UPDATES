SANKHÉ TRANSFERT D'ARGENT — V30

Modification : recherche dans Rapports par Nom & Prénom.

Fonctions ajoutées :
- champ « Nom & Prénom » dans Rapports ;
- recherche partielle : Mamadou, Diop ou Mamadou Diop ;
- recherche insensible aux majuscules/minuscules et aux accents ;
- recherche combinable avec service, type d'opération et période ;
- les totaux sont recalculés selon les résultats filtrés ;
- impression et export CSV utilisent les résultats actuellement filtrés ;
- bouton EFFACER pour revenir à tous les clients.

Remarque : l'environnement de génération actuel ne contient pas le SDK .NET, donc la compilation n'a pas pu être exécutée ici. Le projet source reste un projet .NET 8 tel que fourni dans V29.
