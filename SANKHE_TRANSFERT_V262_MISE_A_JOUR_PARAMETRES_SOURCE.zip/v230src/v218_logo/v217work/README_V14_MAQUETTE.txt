V14 - SANKHE TRANSFERT

Interface du tableau de bord reprise selon la maquette validee :
- Wave et Orange Money dans deux grandes cages independantes.
- Logos fournis par l'utilisateur utilises directement.
- Depots et retraits affiches dans deux sous-cages colorees.
- Nombre d'operations affiche.
- Transferts conserves en ligne secondaire.
- Caisse, Dette Wave, Dette Orange, Dette totale en cartes independantes.
- Dernieres transactions sous les cartes.
- Fond statique et rendu double-bufferise pour eviter le scintillement.

Compilation : executer CONSTRUIRE_EXE.bat avec le SDK .NET 8 installe.
