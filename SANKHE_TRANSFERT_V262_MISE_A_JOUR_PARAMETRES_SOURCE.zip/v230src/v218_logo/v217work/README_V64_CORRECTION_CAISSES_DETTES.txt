SANKHÉ TRANSFERT D'ARGENT — V64

Correction du moyen d'encaissement dans Dettes :
- Caisse Wave apparaît une seule fois.
- Caisse Orange Money apparaît une seule fois.
- Ajout de Caisse Seddo.
- Ajout de Caisse générale.
- Wave et Orange Money restent disponibles comme moyens de règlement mobile.

Le règlement via Caisse Wave / Caisse Orange Money / Caisse Seddo / Caisse générale augmente la caisse correspondante.
La caisse générale est calculée comme le total de sa propre caisse + Wave + Orange Money + Seddo.
