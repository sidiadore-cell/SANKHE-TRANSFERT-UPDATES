SANKHE TRANSFERT D'ARGENT - V101

Amélioration de la carte Caisse Seddo dans le menu Seddo.
- Présentation inspirée des cartes de caisse Wave/Orange : gradient, bordure lumineuse, icône, pièces, grand montant.
- Solde et FCFA plus lisibles.
- Commission et bouton Modifier le taux conservés.
- Historique et opérations Seddo conservés.
