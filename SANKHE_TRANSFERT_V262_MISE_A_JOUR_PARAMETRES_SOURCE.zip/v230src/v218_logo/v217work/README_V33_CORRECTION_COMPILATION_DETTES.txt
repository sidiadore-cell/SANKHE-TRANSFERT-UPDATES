SANKHÉ TRANSFERT D’ARGENT — V33
Correction compilation de la gestion des dettes.

Correction : le message de confirmation lors de la création automatique d’une dette utilisait une chaîne C# multi-ligne non valide. Les retours à la ligne sont maintenant encodés avec \\n.

Fonctionnalités V32 conservées :
- Transfert et Envoi créent automatiquement une dette.
- Menu Dettes.
- Encaissement total ou partiel.
- Moyens de règlement : Caisse, Wave, Orange Money.
- Recherche client.
