# V210 — Correction compilation Annulation

Correction de l'erreur CS9000/CS1003 signalée dans `Database.cs` lors de la compilation du module Annulation.

La chaîne SQL multi-ligne utilisait le délimiteur C# de chaîne brute `"""` sur la même ligne que la fin de la requête. En C#, le délimiteur fermant doit être seul sur sa ligne (hors indentation).

La requête a été corrigée sans modifier sa logique : recherche des opérations, filtres, fiche d'opération ou mécanisme d'annulation.
