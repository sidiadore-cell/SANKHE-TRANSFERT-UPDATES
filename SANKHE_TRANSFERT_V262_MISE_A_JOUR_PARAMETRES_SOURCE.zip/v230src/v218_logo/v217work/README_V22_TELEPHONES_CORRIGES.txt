SANKHÉ TRANSFERT D'ARGENT - V22

Correction demandée : téléphones décoratifs plus petits et en arrière-plan.
- Téléphone Wave et Orange Money réduits à environ 160x190 px.
- Positionnés en haut à droite de chaque grande cage.
- Transparence renforcée pour ne pas masquer les informations.
- Les cartes Dépôts/Retraits, montants et icônes restent lisibles devant les téléphones.
- Design et données de la V21 conservés.
