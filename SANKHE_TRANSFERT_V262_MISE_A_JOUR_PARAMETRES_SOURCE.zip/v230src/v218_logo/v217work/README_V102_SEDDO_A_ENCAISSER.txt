SANKHÉ TRANSFERT D'ARGENT — V102

SEDDo : PAIEMENTS DIFFÉRÉS / À ENCAISSER

Nouveauté :
- Dans Opérations Seddo, une case « Paiement différé — À ENCAISSER PLUS TARD » permet d'enregistrer une opération lorsque le client paiera plus tard.
- Une opération différée est débitée immédiatement de la Caisse Seddo comme une opération Seddo normale, puis le paiement du client est enregistré séparément lorsqu'il est reçu.
- Un bloc très visible « À ENCAISSER » affiche le nombre de clients et le montant restant à encaisser.
- Le bouton « VOIR / ENCAISSER » ouvre la liste des paiements en attente.
- L'encaissement peut être total ou partiel. Chaque encaissement crédite automatiquement la Caisse Seddo et crée un mouvement de caisse.
- Une opération entièrement encaissée disparaît de « À ENCAISSER » mais reste dans l'historique Seddo.
- L'historique affiche le statut et le montant restant.
- Ce système est indépendant des dettes Wave/Orange et n'utilise pas la Caisse Seddo pour solder les dettes.

IMPORTANT : le projet n'a pas pu être compilé dans l'environnement de génération car le SDK .NET n'y est pas installé. Les fichiers source ont été contrôlés pour l'équilibre des blocs et parenthèses.
