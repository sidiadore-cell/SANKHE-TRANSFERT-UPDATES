SANKHE TRANSFERT — V110

Améliorations Mon Boutique :
- Page Boutique centrée dans une largeur de 1320 px.
- Les 6 postes sont présentés sous forme de cartes glassmorphism inspirées du design Accueil/Vista.
- Cartes plus grandes, plus lisibles et avec halo, dégradé, bordure et accent par poste.
- Suppression du bouton « Modifier » directement sur chaque tableau/poste.
- La gestion des affectations reste accessible via « GÉRER LES POSTES ».
- Ajout du KPI « ORANGE RETOURNÉ » en haut, en plus de « WAVE RETOURNÉ ».
- Chaque carte affiche séparément Wave donné, Orange donné, Wave retour et Orange retour.
- Le fonctionnement par 6 postes et les retours matin/soir est conservé.
