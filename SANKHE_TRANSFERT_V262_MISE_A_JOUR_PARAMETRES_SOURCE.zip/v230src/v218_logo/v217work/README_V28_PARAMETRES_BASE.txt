SANKHÉ TRANSFERT D'ARGENT — V28

Nouveautés dans Paramètres :
1. ENREGISTRER LA BASE : ouvre une fenêtre pour choisir l'emplacement et le nom d'une copie complète du fichier SQLite.
2. EFFACER TOUTES LES DONNÉES : demande deux confirmations puis supprime Clients et Operations et remet Caisse/Wave/Orange Money à 0. La structure de la base est conservée.

IMPORTANT : la suppression est définitive. Il est recommandé d'enregistrer une copie de la base avant toute suppression.

Compilation :
lancer CONSTRUIRE_EXE.bat sur un PC Windows avec le SDK .NET 8 installé.
