V76 — RAPPORTS : SERVICES UTILISÉS POUR REMBOURSER LES DETTES

Le module Rapports affiche maintenant, pour chaque opération « Remboursement dette », le service/caisse utilisé pour encaisser le règlement :
- Caisse Wave
- Caisse Orange Money
- Caisse générale

Le champ « Service remboursement » apparaît dans le tableau et dans les rapports imprimés.
L'impression ajoute également un récapitulatif des montants remboursés par service.
L'export CSV contient aussi cette information.

La recherche Nom & Prénom, les filtres service/type/période et l'en-tête facture de Sankhe & Frères sont conservés.
