SANKHÉ TRANSFERT D’ARGENT — V68

Accueil :
- Suppression de la zone/icône dans les badges « CAISSE WAVE » et « CAISSE ORANGE MONEY ».
- Affichage épuré : nom de la caisse, montant principal très lisible et FCFA.
- Conservation des montants réels des caisses.
- Aucun changement aux autres caisses, opérations ou fonctionnalités.

Remarque : le SDK .NET n’est pas disponible dans l’environnement de préparation, donc la compilation n’a pas pu être exécutée ici.
