SANKHÉ TRANSFERT D'ARGENT — V138

Nouvelle maquette de référence pour le menu « Nouvelle opération ».

- Conservation du fond global bleu nuit avec halos bleu/orange/violet.
- Wave à gauche et Orange Money à droite.
- Caisse Wave et Caisse Orange Money affichées séparément.
- Logos officiels intégrés dans les cartes de caisse.
- Montants de caisse affichés en grand caractères.
- Couleur Wave bleue et couleur Orange Money orange.
- Boutons Dépôt, Retrait, Transfert et Rééquilibrage arrondis et plus visibles.
- Le bouton sélectionné prend la couleur du service.
- Transfert conserve l'indication « DETTE À ENCAISSER » avec montant rouge.
- Rééquilibrage conserve Vente UV / Achat UV et la logique de caisse existante.
- Mise en page centrée et compatible avec l'adaptation DPI/résolution existante.

Le reste des fonctionnalités de V137 est conservé.
