SANKHÉ TRANSFERT D'ARGENT — V136
MAQUETTE OPÉRATIONS — RÉFÉRENCE EXACTE

Cette version reprend la maquette de référence demandée :
- Wave à gauche, Orange Money à droite.
- Logos Wave et Orange Money intégrés.
- Couleurs bleu Wave et orange Orange Money.
- Cartes de caisse avec montant très visible.
- Boutons Dépôt / Retrait / Transfert / Rééquilibrage arrondis.
- Wave démarre sur Transfert avec l'alerte DETTE À ENCAISSER.
- Orange Money démarre sur Dépôt.
- Montant d'un transfert affiché en rouge.
- Rééquilibrage : Vente UV ou Achat UV.
- Boutons ENREGISTRER et ANNULER arrondis.
- Même fond et même style visuel général que la maquette fournie.
