V243 — Opérations et échanges de caisses

- Les montants en haut du menu Opérations montrent les soldes journaliers Wave et Orange Money, et non les soldes permanents.
- Les boutons du service Orange Money portent les libellés « Réservoir UV ⬇ », « Transfert UV ⬆ », « Dette » et « Échange » avec un style coloré.
- L’échange depuis Orange Money débite la caisse Orange Money et crédite directement la caisse Wave, sans passer par les espèces ni créer de dette.
- Le sous-type Échange dans Rééquilibrage (Wave) débite la caisse Wave et crédite directement la caisse Orange Money. Il est immédiat et ne crée pas de dette.
- Les échanges sont enregistrés dans l’historique et les mouvements des deux caisses.
