# V163 — Seddo : boutons de service et paiement différé

- Remplacement de la liste déroulante du mode de paiement client par 3 boutons : WAVE, ORANGE MONEY, ESPÈCES.
- Le service sélectionné est clairement mis en évidence.
- En activant « Paiement différé », le choix du service est désactivé et annulé.
- Le choix du mode de paiement se fait uniquement au moment de l’encaissement dans « À ENCAISSER ».
- Les opérations immédiates continuent d’alimenter la caisse correspondant au bouton choisi.
