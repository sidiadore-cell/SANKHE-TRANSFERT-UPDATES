# V259 — Confirmation WhatsApp automatique des dettes soldées

## Fonctionnement
- Lorsqu'un encaissement est enregistré dans le menu Dettes et qu'il couvre la totalité du montant restant, le logiciel tente d'envoyer une confirmation WhatsApp.
- Aucun message n'est déclenché pour un remboursement partiel.
- La notification est exécutée après l'enregistrement du remboursement ; un échec WhatsApp ne rétablit pas la dette et ne modifie aucune caisse.
- La notification utilise un modèle WhatsApp Business approuvé, nécessaire pour envoyer une confirmation proactive hors de la fenêtre de conversation.

## Configuration requise
Cette fonction n'envoie rien tant que WhatsApp Business Platform n'est pas configuré.
Créer/configurer une application Meta WhatsApp Business, un numéro WhatsApp Business, un jeton d'accès valide et un modèle approuvé avec 7 variables de corps, dans cet ordre :
1. Nom du client
2. Service concerné (Wave / Orange Money)
3. Montant initial de la dette
4. Montant du dernier remboursement
5. Moyen d'encaissement
6. Date et heure du solde
7. Référence du reçu (ou « Non renseignée »)

Définir les variables d'environnement Windows suivantes pour le compte utilisateur qui lance le logiciel :
- `SANKHE_WHATSAPP_PHONE_NUMBER_ID` : identifiant du numéro WhatsApp Cloud API (pas le numéro de téléphone visible).
- `SANKHE_WHATSAPP_ACCESS_TOKEN` : jeton d'accès Meta valide.
- `SANKHE_WHATSAPP_TEMPLATE_NAME` : nom exact du modèle approuvé.
- `SANKHE_WHATSAPP_LANGUAGE_CODE` : code langue du modèle, optionnel, défaut `fr`.

Après avoir ajouté ou modifié les variables, fermer puis relancer l'application. Le jeton doit rester privé et ne doit pas être intégré au ZIP ni communiqué à des tiers.

## Modèle de texte suggéré à faire approuver dans Meta
« Bonjour {{1}}, nous vous confirmons que votre dette liée à {{2}} chez SANKHÉ TRANSFERT D’ARGENT est intégralement soldée. Montant initial : {{3}}. Dernier paiement reçu : {{4}} par {{5}} le {{6}}. Référence : {{7}}. Reste à payer : 0 FCFA. Merci pour votre confiance. »

## Limites et sécurité
- Le téléphone du client doit être au format international, ou être un numéro sénégalais local à 9 chiffres (préfixe 221 ajouté automatiquement).
- Le modèle doit correspondre exactement aux 7 variables décrites ci-dessus.
- L'envoi peut échouer si le numéro n'est pas autorisé, le jeton a expiré, le modèle n'est pas approuvé ou le réseau est indisponible.
- Un échec affiche un avertissement mais n'annule jamais le remboursement déjà enregistré.
- L'application ne conserve pas le jeton dans la base de données et n'enregistre pas encore de journal détaillé des messages envoyés.
- Compilation et test réel sur Windows/.NET 8 à effectuer avant déploiement.


## Correction V260 — configuration visible dans Paramètres
- Ajout d'une carte WhatsApp dans Paramètres avec ID du numéro, jeton d'accès masqué, nom du modèle et langue.
- Les paramètres sont enregistrés dans la base locale et utilisés par le service de notification. Les variables d'environnement restent compatibles comme solution de repli.
- Le statut confirme uniquement que les champs sont renseignés ; l'envoi réel dépend encore des identifiants Meta et d'un modèle approuvé correspondant aux 7 paramètres du message.
- Aucun changement des règles comptables ou des mouvements de caisse.
