SANKHE TRANSFERT D’ARGENT — V121

Adaptation automatique de l’affichage
- Activation de HighDpiMode.PerMonitorV2 pour une meilleure adaptation entre PC et écrans différents.
- Conservation du AutoScaleMode.Dpi de l’application.
- Recalcul du layout lors d’un changement de moniteur/DPI.
- Les pages centrées recalculent leur largeur disponible à chaque redimensionnement.
- L’application reste en plein écran/maximisée et adapte les éléments selon l’espace disponible.

Objectif : pouvoir utiliser le logiciel sur plusieurs ordinateurs avec des résolutions et niveaux de zoom Windows différents sans avoir un affichage coupé ou disproportionné.
