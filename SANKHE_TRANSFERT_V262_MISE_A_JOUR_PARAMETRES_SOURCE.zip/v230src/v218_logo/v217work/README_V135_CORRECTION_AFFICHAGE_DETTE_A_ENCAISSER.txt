V135 — Correction du menu Opérations.
- Restauration de la cage « DETTE À ENCAISSER » qui avait disparu.
- Conservation des cages Dette Wave, Dette Orange Money et Dette totale.
- 4 cages alignées sur la largeur du menu pour éviter la disparition/clipping.
- « Dette à encaisser » inclut les dettes restantes et les paiements Seddo différés encore à encaisser.
- Aucun type d’opération ni fonctionnalité Rééquilibrage supprimé.
