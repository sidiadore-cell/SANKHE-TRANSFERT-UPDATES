SANKHÉ TRANSFERT — V85

Correction caisse générale :
- Caisse Wave, Caisse Orange Money et Caisse Seddo restent séparées.
- Caisse générale est indépendante.
- Le solde affiché de Caisse générale correspond uniquement au montant enregistré pour le service « Caisse ».
- Suppression du double comptage qui pouvait afficher 40 000 000 FCFA au lieu de 20 000 000 FCFA.
- Le journal de la caisse générale continue d'utiliser le service « Caisse ».
