# V202 — Accueil Wave : totaux UV visibles

- La ligne de synthèse en bas de la cage WAVE affiche sur une seule ligne :
  - TRANSFERTS
  - RÉÉQ. VENTE UV
  - RÉÉQ. ACHAT UV
- Les montants proviennent de GetReequilibrageSums().
- La cage Orange Money conserve uniquement TRANSFERTS sur cette ligne.
- Les autres calculs et flux ne sont pas modifiés.
