SANKHE TRANSFERT D'ARGENT - V93

Nouveau fonctionnement Seddo distributeur :
- La Caisse Seddo est indépendante.
- Dépôt/sortie manuels de la Caisse Seddo.
- Opération client Seddo avec nom, téléphone, montant et référence.
- Taux de commission Seddo configurable, 5,5 % par défaut.
- Le taux peut être modifié à tout moment avec le bouton « Modifier le taux ».
- Pour une opération, la commission est calculée automatiquement.
- Le total débité de la Caisse Seddo est le montant remis au client + la commission.
- L'opération est enregistrée dans l'historique comme service Seddo.
- Seddo ne crée aucune dette et n'intervient pas dans le règlement des dettes Wave/Orange.
