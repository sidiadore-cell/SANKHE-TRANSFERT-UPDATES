# V231 — SAMA CAISSE : argent confié et portefeuille personnel

## Règles appliquées
- Les boutons `+ Entrée`, `- Sortie` et `Modifier solde` sont retirés des cartes du menu Caisse.
- Un bouton dédié `SAMA CAISSE • CLIENTS & PRÊTS` ouvre la gestion des clients, dépôts confiés, restitutions, prêts et remboursements.
- L'argent confié par un client augmente le solde physique de SAMA CAISSE et crée une obligation de restitution au nom du client.
- La restitution diminue le solde SAMA CAISSE et est refusée si elle dépasse le montant confié encore détenu pour ce client.
- Les prêts sont financés par le portefeuille personnel, pas par SAMA CAISSE ni par les caisses SANKHÉ. Un prêt diminue le portefeuille personnel et augmente le montant à récupérer.
- Les remboursements de prêts augmentent le portefeuille personnel et réduisent le solde du prêt choisi.
- Le portefeuille personnel dispose d'actions séparées d'approvisionnement et de retrait, journalisées.
- Le total général des caisses SANKHÉ continue d'exclure SAMA CAISSE.
- Les opérations sont conservées dans des tables dédiées, séparées des dettes de transfert du logiciel.

## Important
Le solde du portefeuille personnel démarre à 0 FCFA. Utiliser `+ PORTEFEUILLE` pour enregistrer le montant personnel réellement disponible avant d'accorder le premier prêt. Le logiciel ne déplace jamais automatiquement cet argent vers les caisses Wave, Orange Money ou espèces.

## Compilation
Projet Windows Forms .NET 8. Compiler `SankheTransfert.csproj` sur un PC Windows équipé du SDK .NET 8. La compilation n'a pas été exécutée dans l'environnement de préparation si le SDK n'y est pas disponible.
