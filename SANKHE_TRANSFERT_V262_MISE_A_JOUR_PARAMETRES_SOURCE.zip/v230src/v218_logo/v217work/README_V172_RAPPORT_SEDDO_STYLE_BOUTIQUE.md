# V172 — Rapport Seddo même mise en page que Boutique

- Rapport Seddo imprimé en paysage avec la même structure visuelle que le rapport Boutique.
- Même en-tête Sankhe & Frères, coordonnées, titre centré, période et tableau quadrillé.
- Colonnes Seddo conservées : date/heure, client, montant, commission/taux, total débité, caisse de dépôt, statut, restant, référence, description.
- Totaux des caisses présentés dans quatre blocs en bas du rapport.
- Impression et PDF utilisent exactement le même rendu graphique, comme pour le rapport Boutique.
