SANKHÉ TRANSFERT — V15

Objectif : reproduire proprement la maquette validée.

- Wave et Orange Money sont deux grands panneaux indépendants.
- Chaque panneau contient ses propres Dépôts et Retraits dans des cartes colorées.
- Les montants et le nombre d'opérations sont issus de la base de données.
- Les transferts restent visibles sous les cartes de mouvements.
- Caisse, Dette Wave, Dette Orange et Dette totale restent séparées.
- Les dernières transactions restent en dessous.
- Fond statique, double-buffering et rendu net pour éviter le scintillement.
- Les logos wave_exact.png et orange_money_exact.png fournis par l'utilisateur sont utilisés.
