V72 — ACCUEIL : CAISSE WAVE / CAISSE ORANGE MONEY

La modification concerne UNIQUEMENT les deux cartes de caisse affichées sur la page ACCUEIL.

- Suppression de l'affichage « FCFA » sous le montant.
- Le montant et « FCFA » sont maintenant sur la même ligne.
- « FCFA » est placé immédiatement à droite du montant.
- Les cartes de caisse de l'accueil sont légèrement élargies pour améliorer la lisibilité.
- Le montant reste grand et lisible ; sa taille s'adapte légèrement si nécessaire.
- La page CAISSE et ses trois caisses ne sont pas modifiées par cette correction.
