SANKHE TRANSFERT — V179

Règle de solvabilité des dettes :
- Caisse Wave : autorisée
- Caisse Orange Money : autorisée
- Caisse générale : autorisée
- Caisse Seddo : INTERDITE

La règle est protégée à deux niveaux :
1. L'écran Dettes n'affiche pas Caisse Seddo.
2. Database.SettleDebt refuse également toute tentative de règlement avec Caisse Seddo.
