# V190 — Boutique : cages plus larges, libellés courts et boutons compacts

## Modifications
- Cartes des postes élargies à 500 px et espacement augmenté pour afficher correctement les montants.
- Zone de remboursement réorganisée avec les libellés courts : **WAVE**, **ORANGE M**, **ESPÈCE**.
- Les montants remboursés sont affichés directement après chaque libellé.
- Zone TOTAL VERSÉ / RESTE élargie.
- Boutons **DISTRIBUTION**, **＋ AJOUTER** et **REMBOURSER** réduits légèrement en largeur et hauteur.
- Fonctionnement des remboursements partiels conservé.
