V130 — RAPPORT DES VIREMENTS ENTRE CAISSES

Base: V124/V129 avec les fonctions de gérant et virements conservées.

Ajout dans le menu Rapports : « ⇄ RAPPORT VIREMENTS ».
Le rapport permet de filtrer par période, caisse source et caisse destination, puis d'afficher, imprimer ou exporter en PDF les virements entre Caisse générale, Wave, Orange Money et Seddo.
Chaque virement est présenté une seule fois (source -> destination), avec date/heure, montant, motif, référence et nom du gérant.
