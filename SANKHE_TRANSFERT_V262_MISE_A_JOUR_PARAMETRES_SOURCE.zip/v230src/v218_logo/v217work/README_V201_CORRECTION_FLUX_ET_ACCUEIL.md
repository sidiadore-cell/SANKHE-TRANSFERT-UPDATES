# V201 — Flux Dépôt/Retrait + totaux UV Accueil

- Retrait : augmente le portefeuille/caisse Wave ou Orange Money et diminue la Caisse générale.
- Dépôt : diminue le portefeuille/caisse Wave ou Orange Money et augmente la Caisse générale.
- Transfert/Envoi : conserve son traitement de dette et sa sortie de caisse dédiée.
- Les rapports utilisent les mêmes opérations et présentent donc les flux corrigés.
- Accueil Wave affiche sur une même ligne les indicateurs Dépôts, Retraits, Transferts, Rééquilibrage — Vente UV et Rééquilibrage — Achat UV.
- Les totaux UV proviennent directement de GetReequilibrageSums().
- Les libellés Vente UV / Achat UV sont uniformisés dans le menu Opérations.
