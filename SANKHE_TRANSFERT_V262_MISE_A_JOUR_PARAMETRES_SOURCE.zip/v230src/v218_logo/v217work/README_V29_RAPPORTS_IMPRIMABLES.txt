SANKHÉ TRANSFERT D'ARGENT — V29
RAPPORTS COMPLETS ET IMPRESSION

Ajouts :
- Menu Rapports fonctionnel.
- Rapports complets des transactions.
- Filtre Service : Tous les services / Wave / Orange Money.
- Filtre Type : Toutes les opérations / Dépôt / Retrait / Transfert / Rééquilibrage / Remboursement dette.
- Périodes rapides : Aujourd'hui / Cette semaine / Ce mois.
- Période personnalisée avec date de début et date de fin.
- Tableau complet avec Date & Heure, Service, Nom & Prénom, Type, Montant, Commission, Dette, Référence et Téléphone.
- Résumé du nombre d'opérations, montant total, commissions et dettes.
- Impression papier via l'imprimante Windows, en paysage.
- Export CSV pour conserver/imprimer le rapport dans Excel ou LibreOffice.

Le design V28 et les fonctions de sauvegarde/effacement de la base sont conservés.

Construction : lancer CONSTRUIRE_EXE.bat sur Windows avec .NET 8 SDK installé.
