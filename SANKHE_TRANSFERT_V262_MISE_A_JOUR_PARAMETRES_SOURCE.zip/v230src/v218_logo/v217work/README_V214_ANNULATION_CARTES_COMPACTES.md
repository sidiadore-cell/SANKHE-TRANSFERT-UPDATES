# V214 — Annulation : cartes statistiques compactes

- Réduction importante de la hauteur des cartes « Opérations actives », « Annulées », « À vérifier » et « Sécurité / Traçabilité ».
- Réduction de la taille des textes internes pour éviter tout rognage vertical.
- Repositionnement du bloc de recherche, des boutons et du tableau pour conserver un affichage normal et éviter les éléments coupés en bas.
- Fonctionnement du module Annulation conservé.
