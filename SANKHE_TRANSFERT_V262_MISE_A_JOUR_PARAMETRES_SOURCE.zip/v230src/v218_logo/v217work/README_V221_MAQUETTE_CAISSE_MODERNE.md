# V221 — Nouvelle maquette du menu Caisse

- Refonte complète du menu Caisse selon la maquette validée.
- 5 cartes principales : Wave, Orange Money, Espèces, Seddo et SAMA CAISSE.
- Actions Entrée / Sortie / Solde directement dans chaque carte.
- Caisse journalière visible dans Wave et Orange Money.
- Synthèse générale des 5 caisses.
- Historique global avec recherche.
- Les soldes restent indépendants et aucun montant n'est doublé.
- SAMA CAISSE utilise son logo et reste indépendante.
