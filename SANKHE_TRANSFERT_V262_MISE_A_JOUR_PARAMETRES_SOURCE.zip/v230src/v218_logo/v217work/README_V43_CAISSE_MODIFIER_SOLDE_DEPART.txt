SANKHÉ TRANSFERT D’ARGENT — V43

CAISSE : MODIFICATION DU SOLDE DE DÉPART
- Le bouton de caisse permet maintenant de modifier le solde de départ du jour.
- Si un solde de départ existe, son montant est prérempli.
- La modification applique uniquement la différence (nouveau - ancien) à la caisse.
- Le mouvement initial existant est mis à jour au lieu de créer un doublon.
- Une protection empêche de rendre la caisse négative.
- Si aucun solde de départ n’existe, le bouton crée celui du jour.
