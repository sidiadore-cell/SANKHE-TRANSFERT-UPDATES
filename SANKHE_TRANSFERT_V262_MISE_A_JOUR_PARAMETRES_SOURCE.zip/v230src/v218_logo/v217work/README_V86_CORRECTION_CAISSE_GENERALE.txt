SANKHÉ TRANSFERT — V86

Correction de la caisse générale :
- Caisse Wave, Caisse Orange Money et Caisse Seddo restent séparées.
- La Caisse générale affiche désormais le total de Caisse Wave + Caisse Orange Money + Caisse Seddo.
- Exemple : 10 000 000 Wave + 10 000 000 Orange + 0 Seddo = 20 000 000 FCFA.
- Le double comptage qui pouvait afficher 40 000 000 FCFA est supprimé.
- Le journal et les mouvements des caisses individuelles restent séparés.
