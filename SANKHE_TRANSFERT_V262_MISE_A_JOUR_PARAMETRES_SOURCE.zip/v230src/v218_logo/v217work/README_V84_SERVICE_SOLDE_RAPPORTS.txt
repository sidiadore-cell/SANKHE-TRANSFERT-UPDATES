SANKHÉ TRANSFERT D'ARGENT - V84

Correction rapports : service ayant soldé la dette

Pour chaque opération Transfert/Envoi :
- si la dette est non soldée, le rapport conserve le service d'origine (Wave / Orange Money) ;
- si la dette est soldée, la colonne SERVICE affiche le moyen de paiement du règlement final :
  Caisse Wave, Caisse Orange Money ou Caisse générale ;
- le même comportement est appliqué au rapport individuel client, au rapport imprimé général,
  à l'aperçu des rapports et à l'export CSV.

Le statut de dette continue d'être déterminé à partir de la dette liée à l'OperationId exacte.
