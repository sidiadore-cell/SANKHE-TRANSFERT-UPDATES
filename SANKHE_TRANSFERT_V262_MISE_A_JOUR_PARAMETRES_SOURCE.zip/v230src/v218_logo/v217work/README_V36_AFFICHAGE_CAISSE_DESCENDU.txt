SANKHÉ TRANSFERT D’ARGENT — V36

Correction d’affichage de la page Caisse.
La page Caisse est descendue de 60 px environ afin de ne plus être trop proche/masquée par la barre de navigation supérieure.
Aucune logique de caisse, dette ou comptabilité n’a été modifiée.
