# V218 — SAMA CAISSE indépendante

## Modification
Ajout d'une nouvelle caisse indépendante nommée **SAMA CAISSE** dans le menu **Caisse**.

### Règles
- SAMA CAISSE possède son propre solde dans `Soldes`.
- Elle possède son propre historique dans `CaisseMouvements` avec `ServiceCaisse = 'Sama caisse'`.
- Elle n'est reliée automatiquement à aucune opération Wave, Orange Money, Seddo, boutique ou dette.
- Les boutons **Solde de départ**, **Entrée** et **Sortie** permettent de la gérer manuellement.
- Elle apparaît séparément dans le total du menu Caisse.
- Elle n'est pas ajoutée au module de **Caisse journalière Wave/Orange Money**.
- Elle n'est pas proposée dans les virements internes afin de conserver son caractère indépendant.
- La remise à zéro de la base recrée SAMA CAISSE avec un solde de 0 FCFA.

## Affichage
- Carte dédiée **SAMA CAISSE** dans le menu Caisse.
- Bouton de sélection dédié.
- Couleur violette distincte.
- Le solde SAMA CAISSE est séparé des autres caisses et n'est jamais doublé dans les caisses Wave/Orange.
