V241 — Caisse journalière remise à zéro à minuit

- Les compteurs de caisse journalière Wave et Orange Money démarrent à 0 chaque jour.
- Les entrées et sorties sont calculées uniquement sur la date sélectionnée.
- Le solde journalier affiché correspond aux entrées du jour moins les sorties du jour.
- Le solde réel permanent des caisses n’est pas remis à zéro et reste inchangé.
- Les mouvements et les clôtures des jours précédents restent conservés dans l’historique.
