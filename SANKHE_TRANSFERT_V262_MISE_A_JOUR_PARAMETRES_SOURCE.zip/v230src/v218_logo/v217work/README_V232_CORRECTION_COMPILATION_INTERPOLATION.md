SANKHÉ TRANSFERT V232 — correction compilation

Correction du CS8361 dans MainForm.cs : l’expression conditionnelle utilisée pour afficher la date d’un prêt est maintenant entourée de parenthèses dans l’interpolation de chaîne.

Cette correction vise l’erreur affichée lors de la compilation de V231. Compiler le fichier SankheTransfert.csproj avec le SDK .NET 8 sous Windows pour vérifier le projet complet.
