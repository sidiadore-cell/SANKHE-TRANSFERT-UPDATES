﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SankheTransfert;

public class MainForm : Form
{
    readonly Panel content = new();
    readonly Label caisse = new(), wave = new(), orange = new(), total = new(), detteWave = new(), detteOrange = new(), dettes = new(), ops = new();
    readonly Label waveDepot = new(), waveRetrait = new(), waveTransfert = new(), orangeDepot = new(), orangeRetrait = new(), orangeTransfert = new();
    readonly Panel caisseWaveDashboard = new(), caisseOrangeDashboard = new();
    readonly Color dark = Color.FromArgb(12, 18, 32);
    readonly Color light = Color.FromArgb(246, 248, 252);
    static readonly System.Collections.Concurrent.ConcurrentDictionary<string, Image> AssetCache = new(StringComparer.OrdinalIgnoreCase);
    readonly System.Windows.Forms.Timer searchDebounce = new() { Interval = 180 };
    int pageBuildVersion = 0;

    public MainForm()
    {
        Text = "SANKHÉ TRANSFERT D'ARGENT";
        var iconPath = Path.Combine(AppContext.BaseDirectory, "Assets", "Sankhe.ico");
        if (File.Exists(iconPath))
        {
            try { Icon = new Icon(iconPath); } catch { }
        }
        Width = 1180;
        Height = 760;
        MinimumSize = new Size(900, 600);
        StartPosition = FormStartPosition.CenterScreen;
        WindowState = FormWindowState.Maximized;
        BackColor = Color.FromArgb(2, 12, 35);
        DoubleBuffered = true;
        // Le logiciel s'adapte à la résolution et au DPI du PC/moniteur utilisé.
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoScaleDimensions = new SizeF(96F, 96F);
        DpiChanged += (_, _) =>
        {
            // Recalcule immédiatement les zones centrées après un changement de moniteur/DPI.
            BeginInvoke(new Action(() =>
            {
                try { PerformLayout(); content.PerformLayout(); } catch { }
            }));
        };
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
        UpdateStyles();

        BuildHeader();
        BuildSidebar();
        content.Dock = DockStyle.Fill;
        content.Padding = new Padding(18, 12, 18, 18);
        content.BackColor = Color.Transparent;
        content.Paint += DrawAnimatedBackground;
        EnableDoubleBuffer(content);
        content.AutoScroll = true;
        Controls.Add(content);

        searchDebounce.Tick += (_, _) => searchDebounce.Stop();

        ShowDashboard();
    }

    void BuildHeader()
    {
        var header = new Panel { Dock = DockStyle.Top, Height = 92, BackColor = Color.FromArgb(7, 18, 38) };
        // Logo officiel SANKHÉ fourni par le concepteur : symbole + nom + sous-titre.
        var logoPath = Path.Combine(AppContext.BaseDirectory, "Assets", "sankhe_logo_header.png");
        if (File.Exists(logoPath))
        {
            try
            {
                var logoImage = new PictureBox
                {
                    Image = new Bitmap(logoPath),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Left = 18,
                    Top = 4,
                    Width = 250,
                    Height = 84,
                    BackColor = Color.Transparent
                };
                header.Controls.Add(logoImage);
            }
            catch { }
        }
        else
        {
            var logo = new Label
            { Text = "✦", AutoSize = true, Left = 24, Top = 14, Font = new Font("Segoe UI Symbol", 28, FontStyle.Bold), ForeColor = Color.FromArgb(37, 211, 255) };
            header.Controls.Add(logo);
            var title = new Label
            { Text = "SANKHÉ", AutoSize = true, Left = 64, Top = 12, Font = new Font("Segoe UI", 21, FontStyle.Bold), ForeColor = Color.White };
            header.Controls.Add(title);
            var sub = new Label
            { Text = "TRANSFERT D’ARGENT", AutoSize = true, Left = 66, Top = 48, Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = Color.FromArgb(255, 214, 0) };
            header.Controls.Add(sub);
        }

        // Barre de navigation aérée : les boutons ont davantage d'espace entre eux,
        // des icônes plus lisibles et un libellé centré sous l'icône.
        var menuBar = new FlowLayoutPanel
        {
            Left = 278,
            Top = 7,
            Height = 78,
            Width = Math.Max(0, header.ClientSize.Width - 278 - 185),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            BackColor = Color.Transparent,
            WrapContents = false,
            AutoScroll = true,
            FlowDirection = FlowDirection.LeftToRight,
            Padding = new Padding(2, 2, 2, 2),
            Margin = new Padding(0)
        };
        header.Controls.Add(menuBar);

        AddTopMenu(menuBar, "Accueil", ShowDashboard, true, "nav_accueil.png");
        AddTopMenu(menuBar, "Opérations", () => ShowOperation(), false, "nav_operation.png");
        AddTopMenu(menuBar, "Mon Boutique", ShowBoutique, false, "nav_boutique.png");
        AddTopMenu(menuBar, "Ajout Seddo", ShowSeddo, false, "nav_seddo.png");
        AddTopMenu(menuBar, "Historique", ShowHistory, false, "nav_historique.png");
        AddTopMenu(menuBar, "Caisse", ShowCaisse, false, "nav_caisse.png");
        AddTopMenu(menuBar, "Caisse journalière", ShowCaisseJournaliere, false, "nav_caisse.png");
        AddTopMenu(menuBar, "Dettes", ShowDettes, false, "nav_dettes.png");
        AddTopMenu(menuBar, "Annulation", ShowAnnulation, false, "nav_annulation.png");
        AddTopMenu(menuBar, "Rapports", ShowReports, false, "nav_rapports.png");
        AddTopMenu(menuBar, "Paramètres", ShowSettings, false, "nav_parametres.png");

        var admin = new Label { Text = BuildManagerHeaderText(), AutoSize = true, Left = 0, Top = 18, Anchor = AnchorStyles.Top | AnchorStyles.Right, Font = new Font("Segoe UI", 9, FontStyle.Bold), ForeColor = Color.White, TextAlign = ContentAlignment.MiddleLeft };
        header.Controls.Add(admin);
        header.Resize += (_, _) =>
        {
            admin.Left = header.ClientSize.Width - admin.PreferredWidth - 22;
            menuBar.Width = Math.Max(0, header.ClientSize.Width - menuBar.Left - 185);
        };
        Controls.Add(header);
    }

    string BuildManagerHeaderText()
    {
        var manager = Database.GetSetting("ManagerName", "").Trim();
        if (string.IsNullOrWhiteSpace(manager)) manager = "Gérant non défini";
        return "●  " + manager + "\n     " + DateTime.Now.ToString("dd MMM. yyyy HH:mm");
    }

    static string GetManagerName()
    {
        var manager = Database.GetSetting("ManagerName", "").Trim();
        return string.IsNullOrWhiteSpace(manager) ? "Gérant non défini" : manager;
    }

    void RefreshManagerHeader()
    {
        foreach (Control c in Controls)
        {
            if (c is Panel header)
            {
                foreach (Control child in header.Controls)
                {
                    if (child is Label label && label.Top >= 10 && label.Top <= 30 && label.Text.Contains("\n"))
                    {
                        label.Text = BuildManagerHeaderText();
                        label.Left = header.ClientSize.Width - label.PreferredWidth - 22;
                        return;
                    }
                }
            }
        }
    }

    void AddTopMenu(FlowLayoutPanel menuBar, string text, Action action, bool selected, string iconFile)
    {
        var b = new Button
        {
            Text = text,
            Width = 108,
            Height = 68,
            Margin = new Padding(4, 2, 4, 2),
            FlatStyle = FlatStyle.Flat,
            BackColor = selected ? Color.FromArgb(15, 122, 205) : Color.Transparent,
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 9.2f, FontStyle.Bold),
            Cursor = Cursors.Hand,
            TextImageRelation = TextImageRelation.ImageAboveText,
            ImageAlign = ContentAlignment.MiddleCenter,
            TextAlign = ContentAlignment.BottomCenter,
            Padding = new Padding(2, 1, 2, 4),
            UseCompatibleTextRendering = true
        };
        b.FlatAppearance.BorderSize = 0;
        b.FlatAppearance.MouseOverBackColor = Color.FromArgb(25, 95, 145);
        var iconPath = Path.Combine(AppContext.BaseDirectory, "Assets", "navicons", iconFile);
        if (File.Exists(iconPath))
        {
            try
            {
                using var source = new Bitmap(iconPath);
                var icon = new Bitmap(34, 34);
                using (var g = Graphics.FromImage(icon))
                {
                    g.Clear(Color.Transparent);
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.SmoothingMode = SmoothingMode.HighQuality;
                    g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    g.DrawImage(source, new Rectangle(2, 2, 30, 30));
                }
                b.Image = icon;
            }
            catch { }
        }
        b.Click += (_, _) => action();
        menuBar.Controls.Add(b);
    }

    void BuildSidebar()
    {
        // La nouvelle maquette utilise une navigation horizontale dans l’en-tête.
    }

    void AddMenu(Panel side, string text, int index, Action action)
    {
        var b = new Button
        {
            Text = text,
            Tag = index,
            Dock = DockStyle.Top,
            Height = 49,
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(22, 30, 48),
            ForeColor = Color.FromArgb(225, 231, 241),
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(22, 0, 0, 0),
            Font = new Font("Segoe UI", 9.3f, FontStyle.Bold)
        };
        b.FlatAppearance.BorderSize = 0;
        b.MouseEnter += (_, _) => b.BackColor = Color.FromArgb(38, 50, 75);
        b.MouseLeave += (_, _) => b.BackColor = Color.FromArgb(22, 30, 48);
        b.Click += (_, _) => action();
        side.Controls.Add(b);
        side.Controls.SetChildIndex(b, 0);
    }

    void ClearContent()
    {
        // V151 : construit chaque page hors écran pour supprimer les flashes blancs
        // visibles pendant Controls.Clear()/création de nombreux contrôles.
        // Les changements de layout sont suspendus jusqu'à ce que toute la page soit prête.
        int build = ++pageBuildVersion;
        bool canHide = IsHandleCreated && content.IsHandleCreated;

        if (canHide)
        {
            content.SuspendLayout();
            content.Visible = false;
        }

        // IMPORTANT V152 : ne pas appeler Dispose() ici. Plusieurs contrôles sont
        // réutilisés entre les pages (notamment les panneaux/labels du tableau de bord).
        // Les disposer pendant une navigation pouvait laisser un contrôle réutilisé
        // dans l'état "disposed" et provoquer :
        // "Cannot access a disposed object. Object name: System.Windows.Forms.Panel"
        // On retire simplement les anciens contrôles de l'arbre visuel. Le GC pourra
        // récupérer les pages qui ne sont plus référencées sans casser les contrôles
        // partagés/réutilisables.
        content.Controls.Clear();
        content.Paint -= DrawAnimatedBackground;
        content.Paint += DrawAnimatedBackground;

        if (canHide)
        {
            BeginInvoke(new Action(() =>
            {
                if (build != pageBuildVersion || IsDisposed) return;
                try
                {
                    content.ResumeLayout(true);
                    content.Visible = true;
                    content.Invalidate();
                    content.Update();
                }
                catch { }
            }));
        }
    }

    Label Heading(string text)
    {
        return new Label
        {
            Text = text,
            AutoSize = true,
            Font = new Font("Segoe UI", 25, FontStyle.Bold),
            ForeColor = Color.White,
            Location = new Point(22, 18)
        };
    }

    Panel CreatePageHost(int maxWidth = 980)
    {
        var host = new Panel
        {
            BackColor = Color.Transparent,
            Height = 560,
            Width = Math.Min(maxWidth, Math.Max(680, content.ClientSize.Width - 20)),
            Anchor = AnchorStyles.Top
        };

        void CenterHost()
        {
            int available = Math.Max(680, content.ClientSize.Width - 20);
            host.Width = Math.Min(maxWidth, available);
            host.Left = Math.Max(0, (content.ClientSize.Width - host.Width) / 2);
            host.Top = 102; // V20 : décalage de 9 mm environ (34 px) par rapport à la position V18
        }

        content.Resize += (_, _) => CenterHost();
        CenterHost();
        return host;
    }

    void ShowDashboard()
    {
        ClearContent();
        content.Paint -= DrawAnimatedBackground;
        content.Paint += DrawAnimatedBackground;
        content.AutoScroll = true;

        var host = CreatePageHost(1540);
        host.Height = 1120;
        content.Controls.Add(host);

        var ws = Database.GetOperationSums("Wave");
        var os = Database.GetOperationSums("Orange Money");
        // Les rééquilibrages sont accessibles depuis Wave uniquement.
        // Ils sont affichés sur la même ligne que Dépôts/Retraits/Transferts.
        var uv = Database.GetReequilibrageSums();

        // Maquette verrouillée : WAVE à gauche, ORANGE MONEY à droite.
        var services = new Panel
        {
            Left = 0, Top = 0, Width = host.Width, Height = 400,
            BackColor = Color.Transparent,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };
        host.Controls.Add(services);

        var waveBox = CreateServiceDashboardCard(
            "WAVE", "Mouvements et opérations Wave",
            ws.Depot, ws.Retrait, ws.Transfert,
            uv.VenteUV, uv.AchatUV,
            Color.FromArgb(0, 184, 255),
            LoadAsset("wave_exact.png"), true);

        var orangeBox = CreateServiceDashboardCard(
            "ORANGE MONEY", "Mouvements et opérations Orange Money",
            os.Depot, os.Retrait, os.Transfert,
            0, 0,
            Color.FromArgb(255, 132, 0),
            LoadAsset("orange_money_exact.png"), false);

        services.Controls.Add(waveBox);
        services.Controls.Add(orangeBox);

        void LayoutServices()
        {
            int gap = 18;
            int w = Math.Max(420, (services.ClientSize.Width - gap) / 2);
            waveBox.SetBounds(0, 0, w, services.ClientSize.Height);
            orangeBox.SetBounds(w + gap, 0, services.ClientSize.Width - w - gap, services.ClientSize.Height);
        }
        services.Resize += (_, _) => LayoutServices();
        LayoutServices();

        decimal caisseValue = Database.GetSolde("Caisse");
        decimal detteWaveValue = Database.GetDette("Wave");
        decimal detteOrangeValue = Database.GetDette("Orange Money");
        decimal detteTotalValue = detteWaveValue + detteOrangeValue;

        var globals = new TableLayoutPanel
        {
            Left = 0, Top = 418, Width = host.Width, Height = 138,
            ColumnCount = 4, RowCount = 1, BackColor = Color.Transparent,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            Margin = new Padding(0), Padding = new Padding(0)
        };
        for (int i = 0; i < 4; i++)
            globals.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));

        globals.Controls.Add(CreateGlassMetricCard("CAISSE EN ESPÈCES", Money(caisseValue), "Solde disponible",
            Color.FromArgb(0, 150, 255), "▣"), 0, 0);
        globals.Controls.Add(CreateGlassMetricCard("DETTE WAVE", Money(detteWaveValue), "Dette liée à Wave",
            Color.FromArgb(126, 76, 255), "$"), 1, 0);
        globals.Controls.Add(CreateGlassMetricCard("DETTE ORANGE", Money(detteOrangeValue), "Dette liée à Orange Money",
            Color.FromArgb(245, 130, 32), "$"), 2, 0);
        globals.Controls.Add(CreateGlassMetricCard("DETTE TOTALE", Money(detteTotalValue), "Total des dettes",
            Color.FromArgb(0, 210, 245), "↗"), 3, 0);
        host.Controls.Add(globals);

        // V253 : afficher les compteurs journaliers Wave et Orange Money sur l'accueil,
        // dans des cages identiques aux cartes de synthèse existantes. Ces montants
        // représentent les mouvements nets du jour, pas le solde permanent des caisses.
        var dailySummaries = Database.GetCaisseJournaliereSummaries(DateTime.Today);
        var dailyWave = dailySummaries.FirstOrDefault(x => x.ServiceCaisse == "Caisse Wave");
        var dailyOrange = dailySummaries.FirstOrDefault(x => x.ServiceCaisse == "Caisse Orange Money");
        var dailyTitle = new Label
        {
            Text = "CAISSES JOURNALIÈRES",
            Left = 2, Top = 568, Width = host.Width - 4, Height = 28,
            ForeColor = Color.White, Font = new Font("Segoe UI", 12, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };
        host.Controls.Add(dailyTitle);
        var dailyCards = new TableLayoutPanel
        {
            Left = 0, Top = 600, Width = host.Width, Height = 126,
            ColumnCount = 2, RowCount = 1, BackColor = Color.Transparent,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            Margin = new Padding(0), Padding = new Padding(0)
        };
        dailyCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
        dailyCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
        dailyCards.Controls.Add(CreateDailyCashMetricCard("WAVE — JOURNÉE", Money(dailyWave?.SoldeActuel ?? 0m),
            "Mouvements nets depuis minuit", Color.FromArgb(0, 184, 255), "wave_exact.png"), 0, 0);
        dailyCards.Controls.Add(CreateDailyCashMetricCard("ORANGE MONEY — JOURNÉE", Money(dailyOrange?.SoldeActuel ?? 0m),
            "Mouvements nets depuis minuit", Color.FromArgb(255, 132, 0), "orange_money_exact.png"), 1, 0);
        host.Controls.Add(dailyCards);

        // V254 : suppression du panneau « Dernières transactions » de la page Accueil.
        // Les opérations restent accessibles dans le menu Historique/Rapports.

        RefreshDashboard();
    }

    Panel CreateServiceDashboardCard(string service, string subtitle,
        decimal depotValue, decimal retraitValue, decimal transfertValue,
        decimal venteUVValue, decimal achatUVValue,
        Color accent, Image? logo, bool isWave)
    {
        var card = new Panel
        {
            BackColor = Color.Transparent,
            Padding = new Padding(0),
            Cursor = Cursors.Hand
        };
        EnableDoubleBuffer(card);

        card.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            e.Graphics.CompositingQuality = CompositingQuality.HighQuality;
            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            var baseFill = isWave
                ? Color.FromArgb(8, 47, 103)
                : Color.FromArgb(86, 45, 7);

            DrawGlassPanel(e.Graphics, card.ClientRectangle, baseFill, accent, 24, 235);

            // Téléphone décoratif : GRAND, mais réellement en arrière-plan.
            // Il est dessiné directement dans le Paint du panneau afin de rester
            // derrière tous les textes, montants, cartes Dépôt/Retrait et icônes.
            var bgPhone = LoadAsset(isWave ? "phone_wave_bg.png" : "phone_orange_bg.png");
            if (bgPhone != null)
            {
                using var ia = new ImageAttributes();
                var matrix = new ColorMatrix();
                matrix.Matrix33 = 0.24f; // transparence du décor
                ia.SetColorMatrix(matrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);

                // Le téléphone occupe maintenant toute la cage, comme dans la maquette.
                // On conserve ses proportions avec un rendu "cover" : l'image est agrandie
                // jusqu'à remplir toute la surface, puis légèrement recadrée si nécessaire.
                var bounds = new Rectangle(0, 0, card.ClientSize.Width, card.ClientSize.Height);
                float scale = Math.Max(
                    bounds.Width / (float)bgPhone.Width,
                    bounds.Height / (float)bgPhone.Height);
                int drawW = Math.Max(1, (int)Math.Ceiling(bgPhone.Width * scale));
                int drawH = Math.Max(1, (int)Math.Ceiling(bgPhone.Height * scale));
                int drawX = bounds.X + (bounds.Width - drawW) / 2;
                int drawY = bounds.Y + (bounds.Height - drawH) / 2;
                var phoneRect = new Rectangle(drawX, drawY, drawW, drawH);
                e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                e.Graphics.CompositingMode = CompositingMode.SourceOver;
                e.Graphics.DrawImage(bgPhone, phoneRect, 0, 0, bgPhone.Width, bgPhone.Height,
                    GraphicsUnit.Pixel, ia);
            }

            // Halo fixe, sans animation.
            using var glow = new SolidBrush(Color.FromArgb(24, accent));
            e.Graphics.FillEllipse(glow, card.Width - 245, -75, 330, 330);
        };

        // En-tête du service : logo + nom + sous-titre, toujours visible.
        var logoFrame = new Panel
        {
            BackColor = Color.FromArgb(35, accent),
            Padding = new Padding(6)
        };
        using (var _ = logoFrame.CreateGraphics()) { } // force handle before layout
        logoFrame.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var p = RoundedPath(new Rectangle(0, 0, logoFrame.Width - 1, logoFrame.Height - 1), 18);
            using var b = new SolidBrush(Color.FromArgb(48, accent));
            e.Graphics.FillPath(b, p);
            using var pen = new Pen(Color.FromArgb(130, accent), 1.2f);
            e.Graphics.DrawPath(pen, p);
        };

        if (logo != null)
        {
            var pic = new PictureBox
            {
                Dock = DockStyle.Fill,
                Image = logo,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent,
                Margin = Padding.Empty
            };
            logoFrame.Controls.Add(pic);
        }
        else
        {
            var fallback = new Label
            {
                Dock = DockStyle.Fill,
                Text = isWave ? "W" : "OM",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.Transparent
            };
            logoFrame.Controls.Add(fallback);
        }
        card.Controls.Add(logoFrame);

        var title = new Label
        {
            Text = service,
            AutoSize = true,
            Font = new Font("Segoe UI", 23, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = Color.Transparent
        };
        card.Controls.Add(title);

        var sub = new Label
        {
            Text = subtitle,
            AutoSize = true,
            Font = new Font("Segoe UI", 10.8f, FontStyle.Regular),
            ForeColor = Color.FromArgb(236, 245, 255),
            BackColor = Color.Transparent
        };
        card.Controls.Add(sub);

        // Solde de caisse propre au service : badge très lisible, avec un vrai
        // montant principal. On évite désormais le rectangle gris pâle qui
        // rendait le solde difficile à lire sur la maquette.
        var caisseService = isWave ? caisseWaveDashboard : caisseOrangeDashboard;
        ConfigureCaisseDashboardBadge(
            caisseService,
            isWave ? "CAISSE WAVE" : "CAISSE ORANGE MONEY",
            Database.GetSolde(isWave ? "Caisse Wave" : "Caisse Orange Money"),
            isWave ? Color.FromArgb(0, 190, 255) : Color.FromArgb(255, 145, 35),
            isWave ? "W" : "OM");
        card.Controls.Add(caisseService);

        var operations = Database.GetOperations(isWave ? "Wave" : "Orange Money");
        int depotCount = operations.Count(x => string.Equals(x.TypeOperation, "Dépôt", StringComparison.OrdinalIgnoreCase));
        int retraitCount = operations.Count(x => string.Equals(x.TypeOperation, "Retrait", StringComparison.OrdinalIgnoreCase));

        var metrics = new Panel { BackColor = Color.Transparent };
        card.Controls.Add(metrics);

        var depot = CreateMovementMetric(
            "DÉPÔTS " + service,
            depotValue, depotCount,
            Color.FromArgb(0, 225, 145), "↓");

        var retrait = CreateMovementMetric(
            "RETRAITS " + service,
            retraitValue, retraitCount,
            Color.FromArgb(255, 66, 66), "↑");

        metrics.Controls.Add(depot);
        metrics.Controls.Add(retrait);

        // Ligne récapitulative du bas : TRANSFERTS + les deux totaux de
        // rééquilibrage UV sur la même ligne, comme demandé pour l'accueil.
        // Les montants UV proviennent directement de GetReequilibrageSums().
        var bottomStats = new TableLayoutPanel
        {
            ColumnCount = isWave ? 3 : 1,
            RowCount = 1,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        int bottomCount = isWave ? 3 : 1;
        for (int i = 0; i < bottomCount; i++)
            bottomStats.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / bottomCount));

        Label MakeBottomStat(string text) => new Label
        {
            Text = text,
            Dock = DockStyle.Fill,
            AutoEllipsis = true,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 8.7f, FontStyle.Bold),
            ForeColor = Color.FromArgb(220, 237, 252),
            BackColor = Color.Transparent,
            Padding = new Padding(0, 0, 8, 0)
        };

        bottomStats.Controls.Add(MakeBottomStat($"TRANSFERTS  •  {Money(transfertValue)}"), 0, 0);
        if (isWave)
        {
            bottomStats.Controls.Add(MakeBottomStat($"RÉÉQ. VENTE UV  •  {Money(venteUVValue)}"), 1, 0);
            bottomStats.Controls.Add(MakeBottomStat($"RÉÉQ. ACHAT UV  •  {Money(achatUVValue)}"), 2, 0);
        }
        card.Controls.Add(bottomStats);

        void LayoutCard()
        {
            int pad = 22;
            // Le téléphone est maintenant dessiné dans le Paint du panneau,
            // donc aucun repositionnement de contrôle n'est nécessaire.
            logoFrame.SetBounds(pad, 18, 82, 82);

            title.Location = new Point(118, 21);
            sub.Location = new Point(120, 61);

            // La caisse est volontairement dans la partie supérieure droite,
            // sans recouvrir le logo, le titre ou les cartes Dépôt/Retrait.
            int caisseW = Math.Min(330, Math.Max(260, card.ClientSize.Width / 3));
            caisseService.SetBounds(Math.Max(430, card.ClientSize.Width - caisseW - 24), 18, caisseW, 78);

            int innerW = Math.Max(360, card.ClientSize.Width - (pad * 2));
            int metricGap = 16;
            int metricW = Math.Max(160, (innerW - metricGap) / 2);
            int metricTop = 120;
            int metricH = Math.Max(175, Math.Min(205, card.ClientSize.Height - 178));

            metrics.SetBounds(pad, metricTop, innerW, metricH);
            depot.SetBounds(0, 0, metricW, metricH);
            retrait.SetBounds(metricW + metricGap, 0, innerW - metricW - metricGap, metricH);

            bottomStats.SetBounds(pad + 2, card.ClientSize.Height - 44, Math.Max(300, card.ClientSize.Width - (pad * 2) - 4), 32);
        }

        card.Resize += (_, _) => LayoutCard();
        LayoutCard();

        card.Click += (_, _) => ShowOperation(isWave ? "Wave" : "Orange Money");
        return card;
    }

    void ConfigureCaisseDashboardBadge(Panel panel, string title, decimal value, Color accent, string symbol)
    {
        panel.Controls.Clear();
        panel.BackColor = Color.Transparent;
        panel.Padding = Padding.Empty;
        EnableDoubleBuffer(panel);

        panel.Paint += BadgePaint;

        var titleLabel = new Label
        {
            Text = title,
            AutoSize = false,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = Color.Transparent,
            TextAlign = ContentAlignment.MiddleLeft
        };
        panel.Controls.Add(titleLabel);

        // Accueil uniquement : montant + FCFA doivent rester sur UNE SEULE LIGNE.
        // Le montant est volontairement séparé de l'unité afin d'éviter que
        // « FCFA » passe en dessous lorsque le nombre devient long.
        var amountFlow = new FlowLayoutPanel
        {
            Name = "caisseAmountFlow",
            Left = 16,
            Top = 31,
            Width = Math.Max(160, panel.ClientSize.Width - 28),
            Height = 38,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            AutoSize = false,
            BackColor = Color.Transparent,
            Padding = Padding.Empty,
            Margin = Padding.Empty
        };

        var amountLabel = new Label
        {
            Name = "caisseAmount",
            Text = value.ToString("N0"),
            AutoSize = true,
            Font = new Font("Segoe UI", 18, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 0, 7, 0),
            TextAlign = ContentAlignment.MiddleLeft
        };

        var fcfaLabel = new Label
        {
            Name = "caisseFcfa",
            Text = "FCFA",
            AutoSize = true,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            ForeColor = Color.FromArgb(210, 238, 255),
            BackColor = Color.Transparent,
            Margin = new Padding(0, 8, 0, 0),
            TextAlign = ContentAlignment.MiddleLeft
        };

        amountFlow.Controls.Add(amountLabel);
        amountFlow.Controls.Add(fcfaLabel);
        panel.Controls.Add(amountFlow);

        void LayoutBadge()
        {
            int width = Math.Max(170, panel.ClientSize.Width - 28);
            titleLabel.SetBounds(18, 7, width, 23);
            amountFlow.SetBounds(16, 30, width, 40);

            // Réduit légèrement le nombre si nécessaire, mais ne descend jamais
            // FCFA à la ligne suivante.
            float amountSize = 18f;
            using var g = panel.CreateGraphics();
            while (amountSize > 14f)
            {
                using var af = new Font("Segoe UI", amountSize, FontStyle.Bold);
                using var ff = new Font("Segoe UI", 9.5f, FontStyle.Bold);
                float total = g.MeasureString(amountLabel.Text, af).Width + 7f + g.MeasureString("FCFA", ff).Width;
                if (total <= width) break;
                amountSize -= 0.5f;
            }
            amountLabel.Font = new Font("Segoe UI", amountSize, FontStyle.Bold);
            amountLabel.Margin = new Padding(0, 0, 7, 0);
            fcfaLabel.Margin = new Padding(0, Math.Max(4, (amountFlow.ClientSize.Height - fcfaLabel.PreferredHeight) / 2 - 1), 0, 0);
            amountFlow.PerformLayout();
        }
        panel.Resize += (_, _) => LayoutBadge();
        LayoutBadge();

        return;

        void BadgePaint(object? sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            e.Graphics.CompositingQuality = CompositingQuality.HighQuality;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            DrawGlassPanel(e.Graphics, panel.ClientRectangle, Color.FromArgb(8, 38, 72), accent, 16, 245);
            using var glow = new SolidBrush(Color.FromArgb(48, accent));
            e.Graphics.FillEllipse(glow, panel.Width - 72, -34, 105, 105);
            using var line = new Pen(Color.FromArgb(100, accent), 1.1f);
            e.Graphics.DrawLine(line, 18, panel.Height - 11, panel.Width - 12, panel.Height - 11);
        }
    }

    void UpdateCaisseDashboardBadge(Panel panel, decimal value)
    {
        var amount = panel.Controls.Find("caisseAmount", false).FirstOrDefault() as Label;
        if (amount != null) amount.Text = Money(value);
        panel.Invalidate();
    }

    Panel CreateMovementMetric(string title, decimal value, int count, Color accent, string symbol)
    {
        var p = new Panel { BackColor = Color.Transparent };
        EnableDoubleBuffer(p);
        p.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            DrawGlassPanel(e.Graphics, p.ClientRectangle, Color.FromArgb(5, 35, 52), accent, 18, 248);
            using var glow = new SolidBrush(Color.FromArgb(42, accent));
            e.Graphics.FillEllipse(glow, p.Width - 95, p.Height - 100, 125, 125);
            using var pen = new Pen(Color.FromArgb(100, accent), 1f);
            e.Graphics.DrawLine(pen, 18, p.Height - 46, p.Width - 18, p.Height - 46);
        };

        var icon = new Label
        {
            Text = symbol,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 27, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = Color.FromArgb(92, accent)
        };
        p.Controls.Add(icon);
        var t = new Label { Text = title, AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Color.White };
        var amount = new Label { Text = Money(value), AutoSize = true, Font = new Font("Segoe UI", 20, FontStyle.Bold), ForeColor = Color.White };
        var fcfa = new Label { Text = "FCFA", AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Color.FromArgb(210, 228, 245) };
        var countLabel = new Label { Text = $"▤  {count} opération{(count > 1 ? "s" : "")}", AutoSize = true, Font = new Font("Segoe UI", 9.5f), ForeColor = Color.FromArgb(235, 245, 255) };
        p.Controls.Add(t); p.Controls.Add(amount); p.Controls.Add(fcfa); p.Controls.Add(countLabel);

        // Icône de pièces empilées, comme sur la maquette.
        var coins = new PictureBox
        {
            Image = LoadAsset(accent.R > 180 && accent.G < 120 ? "coins_red.png" : "coins_green.png"),
            SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Transparent
        };
        p.Controls.Add(coins);

        void LayoutMetric()
        {
            icon.SetBounds(18, 18, 60, 60);
            t.Location = new Point(88, 18);
            amount.Location = new Point(88, 49);
            fcfa.Location = new Point(88, 83);
            countLabel.Location = new Point(18, Math.Max(95, p.ClientSize.Height - 34));
            coins.SetBounds(Math.Max(0, p.ClientSize.Width - 150), Math.Max(78, p.ClientSize.Height - 112), 135, 105);
        }
        p.Resize += (_, _) => LayoutMetric();
        LayoutMetric();
        return p;
    }

    void AddExactMovementMetric(TableLayoutPanel parent, string title, decimal value, int count,
        Color accent, string symbol, int column)
    {
        var p = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent, Margin = new Padding(5) };
        p.Paint += (_, e) =>
        {
            DrawGlassPanel(e.Graphics, p.ClientRectangle, Color.FromArgb(9, 35, 52), accent, 18, 220);
            using var glow = new SolidBrush(Color.FromArgb(25, accent));
            e.Graphics.FillEllipse(glow, p.Width - 105, p.Height - 105, 130, 130);
        };

        var icon = new Label
        {
            Text = symbol,
            TextAlign = ContentAlignment.MiddleCenter,
            Left = 16, Top = 18, Width = 58, Height = 58,
            Font = new Font("Segoe UI", 28, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = Color.FromArgb(75, accent)
        };
        p.Controls.Add(icon);
        p.Controls.Add(new Label
        {
            Text = title,
            AutoSize = true, Left = 88, Top = 18,
            Font = new Font("Segoe UI", 9.2f, FontStyle.Bold), ForeColor = Color.White
        });
        p.Controls.Add(new Label
        {
            Text = Money(value),
            AutoSize = true, Left = 88, Top = 49,
            Font = new Font("Segoe UI", 19, FontStyle.Bold), ForeColor = Color.White
        });
        p.Controls.Add(new Label
        {
            Text = $"{count} opération{(count > 1 ? "s" : "")}",
            AutoSize = true, Left = 88, Top = 91,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Regular), ForeColor = Color.FromArgb(226, 235, 247)
        });
        p.Controls.Add(new Label
        {
            Text = "FCFA",
            AutoSize = true, Left = 88, Top = 113,
            Font = new Font("Segoe UI", 9, FontStyle.Bold), ForeColor = Color.FromArgb(196, 214, 235)
        });
        parent.Controls.Add(p, column, 0);
    }

    Panel CreateRecentTransactionsPanel(int width)
    {
        var panel = new Panel { Width = width, Height = 340, BackColor = Color.Transparent, Padding = new Padding(16) };
        panel.Paint += (_, e) => {
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            DrawGlassPanel(e.Graphics, panel.ClientRectangle, Color.FromArgb(8, 24, 54), Color.FromArgb(0, 180, 255), 24, 248);
        };
        panel.Controls.Add(new Label { Text = "▣  Dernières transactions", AutoSize = true, Left = 20, Top = 12, Font = new Font("Segoe UI", 17, FontStyle.Bold), ForeColor = Color.White });
        var all = Database.GetRecentOperations(8);
        var grid = new DataGridView { Left = 12, Top = 52, Width = Math.Max(500, width - 24), Height = 270, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom, BackgroundColor = Color.FromArgb(5, 18, 42), BorderStyle = BorderStyle.None, AllowUserToAddRows = false, AllowUserToDeleteRows = false, ReadOnly = true, RowHeadersVisible = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, AutoGenerateColumns = false, EnableHeadersVisualStyles = false, AllowUserToResizeRows = false, CellBorderStyle = DataGridViewCellBorderStyle.Single, GridColor = Color.FromArgb(70, 100, 135) };
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(18, 91, 168); grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White; grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        grid.ColumnHeadersHeight = 34;
        grid.DefaultCellStyle.BackColor = Color.FromArgb(7, 24, 52); grid.DefaultCellStyle.ForeColor = Color.White; grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 116, 205); grid.DefaultCellStyle.SelectionForeColor = Color.White; grid.DefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
        grid.DefaultCellStyle.Padding = new Padding(6, 0, 6, 0);
        grid.RowTemplate.Height = 32;
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(10, 32, 67);
        AddGridColumn(grid, "Date & Heure", "Date", false); AddGridColumn(grid, "Service", "Service", false); AddGridColumn(grid, "Nom & Prénom", "ClientNom", false); AddGridColumn(grid, "Type", "Type", false); AddGridColumn(grid, "Montant", "Montant", true); AddGridColumn(grid, "Référence", "Reference", false); AddGridColumn(grid, "Téléphone", "Telephone", false);
        foreach (var op in all) grid.Rows.Add(op.DateOperation, op.Service, op.ClientNom, op.TypeOperation, Money(op.Montant), op.Reference, op.Telephone);
        panel.Controls.Add(grid); return panel;
    }

    Panel CreateMovementGlassCard(string title, string subtitle, decimal totalVolume,
        decimal depotValue, decimal retraitValue, decimal transfertValue, Color accent, Image? logo, bool isWave,
        decimal venteUVValue = 0, decimal achatUVValue = 0)
    {
        var card = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand,
            Padding = new Padding(16),
            Margin = new Padding(0)
        };
        card.Paint += (_, e) =>
        {
            DrawGlassPanel(e.Graphics, card.ClientRectangle, accent, accent, 22, 24);
            using var glow = new SolidBrush(Color.FromArgb(35, accent));
            e.Graphics.FillEllipse(glow, card.Width - 110, -40, 150, 150);
        };

        var logoCircle = new Panel
        {
            Left = 16, Top = 16, Width = 58, Height = 58,
            BackColor = Color.Transparent
        };
        logoCircle.Paint += (_, e) =>
        {
            using var b = new SolidBrush(Color.FromArgb(45, accent));
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.FillEllipse(b, 0, 0, logoCircle.Width - 1, logoCircle.Height - 1);
        };
        if (logo != null)
        {
            logoCircle.Controls.Add(new PictureBox
            {
                Dock = DockStyle.Fill,
                Image = logo,
                SizeMode = PictureBoxSizeMode.Zoom,
                Padding = new Padding(5),
                BackColor = Color.Transparent
            });
        }
        card.Controls.Add(logoCircle);

        var titleLabel = new Label
        {
            Text = title,
            AutoSize = true, Left = 88, Top = 16,
            Font = new Font("Segoe UI", 11, FontStyle.Bold),
            ForeColor = accent
        };
        card.Controls.Add(titleLabel);
        card.Controls.Add(new Label
        {
            Text = subtitle,
            AutoSize = true, Left = 88, Top = 40,
            Font = new Font("Segoe UI", 8.5f),
            ForeColor = Color.FromArgb(71,85,105)
        });

        var totalLabel = new Label
        {
            Text = Money(totalVolume),
            AutoSize = true, Left = 16, Top = 84,
            Font = new Font("Segoe UI", 18, FontStyle.Bold),
            ForeColor = Color.FromArgb(15,23,42)
        };
        card.Controls.Add(totalLabel);
        card.Controls.Add(new Label
        {
            Text = "VOLUME TOTAL DES MOUVEMENTS",
            AutoSize = true, Left = 18, Top = 114,
            Font = new Font("Segoe UI", 6.2f, FontStyle.Bold),
            ForeColor = Color.FromArgb(100,116,139)
        });

        var chips = new TableLayoutPanel
        {
            Left = 14, Top = 139, Width = 620, Height = 45,
            ColumnCount = isWave ? 5 : 3, RowCount = 1,
            BackColor = Color.Transparent,
            Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
        };
        int chipCount = isWave ? 5 : 3;
        for (int i = 0; i < chipCount; i++) chips.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / chipCount));
        AddGlassChip(chips, "DÉPÔTS", Money(depotValue), Color.FromArgb(16,185,129), 0);
        AddGlassChip(chips, "RETRAITS", Money(retraitValue), Color.FromArgb(239,68,68), 1);
        AddGlassChip(chips, "TRANSFERTS", Money(transfertValue), Color.FromArgb(59,130,246), 2);
        if (isWave)
        {
            AddGlassChip(chips, "RÉÉQ. VENTE UV", Money(venteUVValue), Color.FromArgb(168,85,247), 3);
            AddGlassChip(chips, "RÉÉQ. ACHAT UV", Money(achatUVValue), Color.FromArgb(20,184,166), 4);
        }
        card.Controls.Add(chips);

        card.Click += (_, _) => ShowOperation(isWave ? "Wave" : "Orange Money");
        card.MouseEnter += (_, _) => card.Invalidate();
        return card;
    }

    // V255 : cartes journalières avec les vrais logos et montants lisibles à gauche du logo.
    Panel CreateDailyCashMetricCard(string title, string value, string subtitle, Color accent, string logoFile)
    {
        var card = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent, Margin = new Padding(5) };
        card.Paint += (_, e) => DrawGlassPanel(e.Graphics, card.ClientRectangle, Color.FromArgb(10, 35, 72), accent, 20, 220);
        var logo = new PictureBox
        {
            Left =  card.Width - 86, Top = 26, Width = 64, Height = 64,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            Image = LoadAsset(logoFile), SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Transparent
        };
        var heading = new Label
        {
            Text = title, Left = 18, Top = 14, Width =  card.Width - 112, Height = 25,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Color.White,
            AutoEllipsis = true
        };
        var amount = new Label
        {
            Text = value, Left = 18, Top = 43, Width = card.Width - 116, Height = 36,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            Font = new Font("Segoe UI", 16f, FontStyle.Bold), ForeColor = accent,
            AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft
        };
        var caption = new Label
        {
            Text = subtitle, Left = 18, Top = 83, Width = card.Width - 36, Height = 20,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            Font = new Font("Segoe UI", 8f, FontStyle.Regular), ForeColor = Color.FromArgb(190, 210, 235),
            AutoEllipsis = true
        };
        card.Controls.Add(logo);
        card.Controls.Add(heading);
        card.Controls.Add(amount);
        card.Controls.Add(caption);
        card.Resize += (_, _) =>
        {
            logo.Left = Math.Max(18, card.ClientSize.Width - 82);
            heading.Width = Math.Max(80, card.ClientSize.Width - 112);
            amount.Width = Math.Max(80, card.ClientSize.Width - 116);
            caption.Width = Math.Max(80, card.ClientSize.Width - 36);
        };
        return card;
    }

    Panel CreateGlassMetricCard(string title, string value, string subtitle, Color accent, string symbol)
    {
        var card = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent, Margin = new Padding(5) };
        card.Paint += (_, e) => DrawGlassPanel(e.Graphics, card.ClientRectangle, Color.FromArgb(10, 35, 72), accent, 20, 220);
        var badge = new Label { Text = symbol, TextAlign = ContentAlignment.MiddleCenter, Left = 16, Top = 18, Width = 58, Height = 58, Font = new Font("Segoe UI", 18, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.FromArgb(55, accent) };
        card.Controls.Add(badge);
        card.Controls.Add(new Label { Text = title, AutoSize = true, Left = 88, Top = 19, Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = Color.White });
        card.Controls.Add(new Label { Text = value, AutoSize = true, Left = 16, Top = 78, Font = new Font("Segoe UI", 17, FontStyle.Bold), ForeColor = accent });
        card.Controls.Add(new Label { Text = subtitle, AutoSize = true, Left = 18, Top = 108, Font = new Font("Segoe UI", 8, FontStyle.Bold), ForeColor = Color.FromArgb(170, 196, 225) });
        return card;
    }

    void AddGlassChip(TableLayoutPanel parent, string title, string value, Color accent, int column)
    {
        var chip = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent, Margin = new Padding(3) };
        chip.Paint += (_, e) => DrawGlassPanel(e.Graphics, chip.ClientRectangle, accent, accent, 12, 24);
        chip.Controls.Add(new Label
        {
            Text = title, AutoSize = true, Left = 8, Top = 5,
            Font = new Font("Segoe UI", 6.8f, FontStyle.Bold),
            ForeColor = Color.FromArgb(100,116,139)
        });
        chip.Controls.Add(new Label
        {
            Text = value, AutoSize = true, Left = 8, Top = 20,
            Font = new Font("Segoe UI", 8.3f, FontStyle.Bold),
            ForeColor = accent
        });
        parent.Controls.Add(chip, column, 0);
    }

    static void DrawGlassPanel(Graphics g, Rectangle rect, Color fill, Color border, int radius, int alpha)
    {
        if (rect.Width <= 2 || rect.Height <= 2) return;
        rect.Width--; rect.Height--;
        using var path = RoundedPath(rect, radius);
        g.SmoothingMode = SmoothingMode.HighQuality;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.CompositingQuality = CompositingQuality.HighQuality;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        using var brush = new SolidBrush(Color.FromArgb(Math.Max(238, Math.Min(alpha, 252)), fill));
        using var pen = new Pen(Color.FromArgb(235, border), 1.7f);
        g.FillPath(brush, path);
        g.DrawPath(pen, path);
    }

    static GraphicsPath RoundedPath(Rectangle rect, int radius)
    {
        int r = Math.Max(2, Math.Min(radius, Math.Min(rect.Width, rect.Height)));
        var path = new GraphicsPath();
        path.AddArc(rect.X, rect.Y, r, r, 180, 90);
        path.AddArc(rect.Right - r, rect.Y, r, r, 270, 90);
        path.AddArc(rect.Right - r, rect.Bottom - r, r, r, 0, 90);
        path.AddArc(rect.X, rect.Bottom - r, r, r, 90, 90);
        path.CloseFigure();
        return path;
    }

    void RefreshDashboard()
    {
        var d = Database.GetDashboardSnapshot();
        caisse.Text = Money(d.Caisse); wave.Text = Money(d.Wave); orange.Text = Money(d.Orange);
        UpdateCaisseDashboardBadge(caisseWaveDashboard, d.CaisseWave);
        UpdateCaisseDashboardBadge(caisseOrangeDashboard, d.CaisseOrange);
        total.Text = Money(d.Caisse + d.Wave + d.Orange);
        detteWave.Text = Money(d.DetteWave); detteOrange.Text = Money(d.DetteOrange); dettes.Text = Money(d.DetteWave + d.DetteOrange);
        waveDepot.Text = Money(d.WaveDepot); waveRetrait.Text = Money(d.WaveRetrait); waveTransfert.Text = Money(d.WaveTransfert);
        orangeDepot.Text = Money(d.OrangeDepot); orangeRetrait.Text = Money(d.OrangeRetrait); orangeTransfert.Text = Money(d.OrangeTransfert);
        ops.Text = d.TodayOperations.ToString("0");
    }


    void ShowBoutique()
    {
        ClearContent();
        content.Paint -= DrawAnimatedBackground; content.Paint += DrawAnimatedBackground;
        content.AutoScroll = true; content.Padding = new Padding(24, 18, 24, 30);
        var host = CreatePageHost(1580); host.Height = Math.Max(1220, content.ClientSize.Height - 10); content.Controls.Add(host);

        var title = Heading("Mon Boutique");
        title.Font = new Font("Segoe UI", 24, FontStyle.Bold);
        title.Location = new Point(0, 0);
        host.Controls.Add(title);
        host.Controls.Add(new Label { Text = "6 postes indépendants • dotation Wave, Orange Money et espèces • retour le soir", AutoSize = true, Left = 2, Top = 42, ForeColor = Color.FromArgb(205,225,245), Font = new Font("Segoe UI", 10) });

        var employees = Database.GetBoutiqueEmployees(false).ToDictionary(x => x.Poste);
        var sessions = Database.GetBoutiqueSessions(DateTime.Today, DateTime.Today.AddDays(1));

        AddBoutiqueKpi(host, "POSTES UTILISÉS", employees.Values.Count(x => x.Actif).ToString() + " / 6", Color.FromArgb(37,99,235), 0);
        AddBoutiqueKpi(host, "POSTES OUVERTS", sessions.Count(x => x.Statut == "Ouverte").ToString(), Color.FromArgb(0,190,130), 220);
        AddBoutiqueKpi(host, "WAVE DISTRIBUÉ", Money(sessions.Sum(x => x.WaveDonne)), Color.FromArgb(0,145,255), 440);
        AddBoutiqueKpi(host, "ORANGE DISTRIBUÉ", Money(sessions.Sum(x => x.OrangeDonne)), Color.FromArgb(255,121,0), 660);
        AddBoutiqueKpi(host, "ESPÈCES DISTRIBUÉES", Money(sessions.Sum(x => x.EspecesDonne)), Color.FromArgb(80,190,120), 880);
        AddBoutiqueKpi(host, "RETOURS TOTAL", Money(sessions.Sum(x => x.WaveRetour + x.OrangeRetour + x.EspecesRetour)), Color.FromArgb(0,190,130), 1100);
        // DISTRIBUTION TOTALE = distribution initiale + tous les montants « À AJOUTER ».
        // Les champs *Donne sont cumulés par AddBoutiqueFunds, donc ils représentent déjà cette somme.
        // Une seule cage est affichée, avec exactement la même mise en page que les autres indicateurs.
        AddBoutiqueKpi(host, "DISTRIBUTION TOTALE", Money(sessions.Sum(x => x.WaveDonne + x.OrangeDonne + x.EspecesDonne)), Color.FromArgb(0,190,220), 1320);

        var manage = CreateBoutiqueRoundButton("⚙  GÉRER LES POSTES", 1120, 142, 190, 42, Color.FromArgb(25,105,210));
        manage.Click += (_, _) => ShowBoutiquePostesManager();
        host.Controls.Add(manage);

        // Cartes volontairement plus grandes et plus sobres : un seul fond sombre,
        // texte blanc très contrasté et une petite touche cyan pour éviter les fonds colorés.
        for (int poste = 1; poste <= 6; poste++)
        {
            int col = (poste - 1) % 3, row = (poste - 1) / 3;
            employees.TryGetValue(poste, out var emp);
            var session = emp is null ? null : sessions.FirstOrDefault(x => x.EmployeId == emp.Id);
            bool posteOuvert = session is not null && session.Statut == "Ouverte";
            var card = new Panel { Left = 5 + col * 515, Top = 195 + row * 365, Width = 500, Height = 350, BackColor = Color.FromArgb(7, 23, 45) };
            card.Paint += (_, e) =>
            {
                var r = card.ClientRectangle;
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                var accent = posteOuvert ? Color.FromArgb(0,220,150) : Color.FromArgb(0,190,220);
                DrawGlassPanel(e.Graphics, r, Color.FromArgb(7,23,45), accent, 20, 245);
                using var line = new Pen(Color.FromArgb(150, accent.R, accent.G, accent.B), 2);
                e.Graphics.DrawLine(line, 22, 54, r.Width - 22, 54);
                using var halo = new SolidBrush(posteOuvert ? Color.FromArgb(20,0,220,150) : Color.FromArgb(15,0,190,220));
                e.Graphics.FillEllipse(halo, r.Width - 120, -45, 150, 150);
            };
            host.Controls.Add(card);
            var head = new Label { Text = $"POSTE {poste}", Left = 22, Top = 14, AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 17, FontStyle.Bold) };
            card.Controls.Add(head);
            // Après un remboursement complet, afficher « Diadieuf » entre le numéro du poste
            // et le point d'état, comme confirmation visuelle de la clôture.
            bool posteCloture = session is not null && session.Statut == "Clôturée";
            if (posteCloture)
            {
                var thank = new Label
                {
                    Text = "Diadieuf", Left = 180, Top = 10, Width = 165, Height = 40,
                    ForeColor = Color.FromArgb(120, 255, 205), Font = new Font("Georgia", 18, FontStyle.Bold | FontStyle.Italic),
                    TextAlign = ContentAlignment.MiddleCenter
                };
                card.Controls.Add(thank);
            }
            // Vert = poste ouvert ; blanc = poste clôturé/non ouvert.
            var statusDot = new Label
            {
                Text = "●", Left = 350, Top = 2, Width = 52, Height = 48,
                ForeColor = posteOuvert ? Color.FromArgb(0, 235, 150) : Color.White,
                Font = new Font("Segoe UI", 34, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter
            };
            card.Controls.Add(statusDot);

            var identity = new Label { Text = emp is null ? "Aucun employé affecté" : emp.Nom, Left = 22, Top = 66, Width = 455, Height = 42, ForeColor = Color.White, Font = new Font("Segoe UI", 19, FontStyle.Bold), AutoEllipsis = true };
            card.Controls.Add(identity);
            var phone = new Label { Text = emp is null || string.IsNullOrWhiteSpace(emp.Telephone) ? "Téléphone non renseigné" : emp.Telephone, Left = 22, Top = 107, Width = 455, ForeColor = Color.FromArgb(175,200,225), Font = new Font("Segoe UI", 10.5f) };
            card.Controls.Add(phone);

            var waveCaption = new Label { Text = "WAVE DISPONIBLE", Left = 22, Top = 137, AutoSize = true, ForeColor = Color.FromArgb(0,145,255), Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            var wave = new Label { Text = Money(session?.WaveDonne ?? 0), Left = 22, Top = 154, Width = 205, Height = 38, ForeColor = Color.FromArgb(80,185,255), Font = new Font("Segoe UI", 21, FontStyle.Bold) };
            var orangeCaption = new Label { Text = "ORANGE M DISPONIBLE", Left = 250, Top = 137, AutoSize = true, ForeColor = Color.FromArgb(255,121,0), Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            var orange = new Label { Text = Money(session?.OrangeDonne ?? 0), Left = 250, Top = 154, Width = 225, Height = 38, ForeColor = Color.FromArgb(255,165,70), Font = new Font("Segoe UI", 21, FontStyle.Bold) };
            var cashCaption = new Label { Text = "ESPÈCES DISPONIBLES", Left = 22, Top = 193, AutoSize = true, ForeColor = Color.FromArgb(80,190,120), Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            var cash = new Label { Text = Money(session?.EspecesDonne ?? 0), Left = 22, Top = 210, Width = 180, Height = 30, ForeColor = Color.FromArgb(120,220,150), Font = new Font("Segoe UI", 17, FontStyle.Bold) };
            card.Controls.AddRange(new Control[] { waveCaption, wave, orangeCaption, orange, cashCaption, cash });

            var totalDistribueLabel = new Label { Text = $"DISTRIBUTION TOTALE : {Money((session?.WaveDonne ?? 0) + (session?.OrangeDonne ?? 0) + (session?.EspecesDonne ?? 0))}", Left = 250, Top = 212, Width = 225, Height = 22, ForeColor = Color.FromArgb(220,235,250), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), TextAlign = ContentAlignment.MiddleRight };
            card.Controls.Add(totalDistribueLabel);
            var verseWave = new Label { Text = $"WAVE : {Money(session?.WaveRetour ?? 0)}", Left = 22, Top = 239, Width = 145, Height = 24, ForeColor = Color.FromArgb(80,185,255), Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
            var verseOrange = new Label { Text = $"ORANGE M : {Money(session?.OrangeRetour ?? 0)}", Left = 177, Top = 239, Width = 155, Height = 24, ForeColor = Color.FromArgb(255,165,70), Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
            var verseCash = new Label { Text = $"ESPÈCE : {Money(session?.EspecesRetour ?? 0)}", Left = 342, Top = 239, Width = 135, Height = 24, ForeColor = Color.FromArgb(120,220,150), Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
            card.Controls.AddRange(new Control[] { verseWave, verseOrange, verseCash });
            var totalVerse = (session?.WaveRetour ?? 0) + (session?.OrangeRetour ?? 0) + (session?.EspecesRetour ?? 0);
            var totalDistribueCarte = (session?.WaveDonne ?? 0) + (session?.OrangeDonne ?? 0) + (session?.EspecesDonne ?? 0);
            var resteCarte = Math.Max(0, totalDistribueCarte - totalVerse);
            var returned = new Label { Text = $"TOTAL VERSÉ : {Money(totalVerse)}   |   RESTE : {Money(resteCarte)}", Left = 22, Top = 262, Width = 455, Height = 22, ForeColor = resteCarte == 0 && session is not null ? Color.FromArgb(120,255,205) : Color.FromArgb(225,235,245), Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter };
            card.Controls.Add(returned);
            var status = new Label { Text = session is null ? "● Pas encore ouvert" : session.Statut == "Ouverte" ? "● JOURNÉE OUVERTE — REMBOURSEMENTS POSSIBLES" : "● JOURNÉE CLÔTURÉE — Diadieuf", Left = 22, Top = 284, Width = 455, Height = 20, ForeColor = session is null ? Color.FromArgb(160,180,200) : session.Statut == "Ouverte" ? Color.FromArgb(0,235,165) : Color.FromArgb(125,190,255), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter };
            card.Controls.Add(status);

            var give = CreateBoutiqueRoundButton("💰 DISTRIBUTION", 20, 308, 105, 36, Color.FromArgb(0,150,105));
            var addFunds = CreateBoutiqueRoundButton("＋ AJOUTER", 137, 308, 105, 36, Color.FromArgb(37,99,235));
            var close = CreateBoutiqueRoundButton("↩ REMBOURSER", 254, 308, 105, 36, Color.FromArgb(180,48,55));
            give.Enabled = emp is not null && (session is null || session.Statut != "Ouverte");
            addFunds.Enabled = session is not null && session.Statut == "Ouverte";
            close.Enabled = session is not null && session.Statut == "Ouverte";
            card.Controls.AddRange(new Control[] { give, addFunds, close });

            give.Click += (_, _) =>
            {
                if (emp is null) return;
                using var d = CreateBoutiqueMoneyDialog($"Distribution — Poste {poste}", "Montant Wave donné", "Montant Orange Money donné", "Montant espèces donné");
                if (d.ShowDialog(this) == DialogResult.OK)
                {
                    try { Database.OpenBoutiqueSession(emp.Id, d.Wave, d.Orange, d.Cash); ShowBoutique(); }
                    catch (Exception ex) { MessageBox.Show(ex.Message, "Boutique", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                }
            };
            close.Click += (_, _) =>
            {
                if (session is null) return;
                using var d = CreateBoutiqueMoneyDialog($"Versement employé — Poste {poste}", "Montant Wave versé", "Montant Orange Money versé", "Montant espèces versé");
                if (d.ShowDialog(this) == DialogResult.OK)
                {
                    try { Database.CloseBoutiqueSession(session.Id, d.Wave, d.Orange, d.Cash, "Retour du soir"); ShowBoutique(); }
                    catch (Exception ex) { MessageBox.Show(ex.Message, "Boutique", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                }
            };
            addFunds.Click += (_, _) =>
            {
                if (session is null) return;
                using var d = CreateBoutiqueMoneyDialog($"Augmenter la dotation — Poste {poste}", "Montant Wave à ajouter", "Montant Orange Money à ajouter", "Montant espèces à ajouter");
                if (d.ShowDialog(this) == DialogResult.OK)
                {
                    try { Database.AddBoutiqueFunds(session.Id, d.Wave, d.Orange, d.Cash, "Complément en cours de journée"); ShowBoutique(); }
                    catch (Exception ex) { MessageBox.Show(ex.Message, "Boutique", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                }
            };
        }
    }

    Button CreateBoutiqueRoundButton(string text, int left, int top, int width, int height, Color backColor)
    {
        var b = new Button { Text = text, Left = left, Top = top, Width = width, Height = height, BackColor = backColor, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8f, FontStyle.Bold), UseVisualStyleBackColor = false };
        b.FlatAppearance.BorderSize = 0;
        b.Region = new Region(RoundedPath(new Rectangle(0, 0, width, height), 14));
        b.MouseEnter += (_, _) => { if (b.Enabled) b.BackColor = ControlPaint.Light(backColor, .12f); };
        b.MouseLeave += (_, _) => b.BackColor = backColor;
        return b;
    }

    sealed class BoutiqueMoneyDialog : Form
    {
        public decimal Wave { get; private set; }
        public decimal Orange { get; private set; }
        public decimal Cash { get; private set; }
        public BoutiqueMoneyDialog(string title, string waveLabel, string orangeLabel, string cashLabel)
        {
            Text = title;
            Width = 680;
            Height = 345;
            MinimumSize = new Size(620, 320);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.FromArgb(14,24,43);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96F, 96F);

            // Zone des libellés : largeur fixe et texte aligné à droite pour éviter
            // que les intitulés longs ne passent sous les champs de saisie.
            var waveCaption = new Label
            {
                Text = waveLabel, Left = 25, Top = 39, Width = 285, Height = 30,
                ForeColor = Color.White, BackColor = Color.Transparent,
                TextAlign = ContentAlignment.MiddleRight, AutoEllipsis = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Regular)
            };
            var orangeCaption = new Label
            {
                Text = orangeLabel, Left = 25, Top = 99, Width = 285, Height = 30,
                ForeColor = Color.White, BackColor = Color.Transparent,
                TextAlign = ContentAlignment.MiddleRight, AutoEllipsis = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Regular)
            };

            var w = new TextBox
            {
                Left = 330, Top = 35, Width = 285, Height = 32,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                Font = new Font("Segoe UI", 11F),
                Margin = new Padding(0)
            };
            var o = new TextBox
            {
                Left = 330, Top = 95, Width = 285, Height = 32,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                Font = new Font("Segoe UI", 11F),
                Margin = new Padding(0)
            };
            ApplyMoneyInputFormat(w); ApplyMoneyInputFormat(o);
            var cashCaption = new Label { Text = cashLabel, Left = 25, Top = 159, Width = 285, Height = 30, ForeColor = Color.White, BackColor = Color.Transparent, TextAlign = ContentAlignment.MiddleRight, AutoEllipsis = true, Font = new Font("Segoe UI", 10F) };
            var cash = new TextBox { Left = 330, Top = 155, Width = 285, Height = 32, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right, Font = new Font("Segoe UI", 11F), Margin = new Padding(0) };
            ApplyMoneyInputFormat(cash);

            var ok = new Button
            {
                Text = "VALIDER", Left = 330, Top = 215, Width = 150, Height = 42,
                BackColor = Color.FromArgb(0,190,130), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
            ok.FlatAppearance.BorderSize = 0;
            ok.Region = new Region(RoundedPath(new Rectangle(0, 0, ok.Width, ok.Height), 10));

            Controls.AddRange(new Control[] { waveCaption, w, orangeCaption, o, cashCaption, cash, ok });
            AcceptButton = ok;
            Shown += (_, _) => w.Focus();
            ok.Click += (_, _) =>
            {
                // Une cage vide signifie 0 FCFA dans Boutique.
                var ww = string.IsNullOrWhiteSpace(w.Text) ? 0m : (TryMoney(w.Text, out var wv) ? wv : -1m);
                var oo = string.IsNullOrWhiteSpace(o.Text) ? 0m : (TryMoney(o.Text, out var ov) ? ov : -1m);
                var cc = string.IsNullOrWhiteSpace(cash.Text) ? 0m : (TryMoney(cash.Text, out var cv) ? cv : -1m);
                if (ww < 0 || oo < 0 || cc < 0)
                {
                    MessageBox.Show("Montants invalides.", "Boutique", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                Wave = ww;
                Orange = oo;
                Cash = cc;
                DialogResult = DialogResult.OK;
                Close();
            };
        }
    }
    static BoutiqueMoneyDialog CreateBoutiqueMoneyDialog(string title, string waveLabel, string orangeLabel, string cashLabel) => new(title, waveLabel, orangeLabel, cashLabel);

    void ShowBoutiquePostesManager()
    {
        using var d = new Form { Text = "Gestion des 6 postes", Width = 780, Height = 560, StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(7,18,38) };
        var grid = new DataGridView { Left = 20, Top = 20, Width = 720, Height = 380, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false, AutoGenerateColumns = false, BackgroundColor = Color.FromArgb(5,18,42), BorderStyle = BorderStyle.None, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Id", Visible = false });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Poste", HeaderText = "Poste" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Nom", HeaderText = "Employé" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Tel", HeaderText = "Téléphone" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Etat", HeaderText = "État" });
        d.Controls.Add(grid);
        void LoadRows()
        {
            grid.Rows.Clear();
            var all = Database.GetBoutiqueEmployees(false).ToDictionary(x => x.Poste);
            for (int poste = 1; poste <= 6; poste++)
            {
                all.TryGetValue(poste, out var e);
                grid.Rows.Add(e?.Id ?? 0, $"Poste {poste}", e?.Nom ?? "Aucun employé affecté", e?.Telephone ?? "", e is null ? "Libre" : (e.Actif ? "Actif" : "Inactif"));
            }
        }
        LoadRows();
        var add = CreateBoutiqueRoundButton("＋ AFFECTER LE POSTE", 20, 420, 220, 42, Color.FromArgb(0,190,130));
        var edit = CreateBoutiqueRoundButton("✎ MODIFIER L'EMPLOYÉ", 255, 420, 220, 42, Color.FromArgb(37,99,235));
        var close = CreateBoutiqueRoundButton("FERMER", 490, 420, 150, 42, Color.FromArgb(70,85,105));
        d.Controls.AddRange(new Control[] { add, edit, close });
        void EditSelected(bool forceNew)
        {
            if (grid.SelectedRows.Count == 0) { MessageBox.Show("Sélectionnez un poste.", "Boutique"); return; }
            var row = grid.SelectedRows[0];
            var poste = row.Index + 1;
            var id = Convert.ToInt64(row.Cells["Id"].Value ?? 0);
            var e = id > 0 ? Database.GetBoutiqueEmployee(id) : null;
            ShowBoutiquePosteDialog(e, poste);
            LoadRows();
        }
        add.Click += (_, _) => EditSelected(true);
        edit.Click += (_, _) => EditSelected(false);
        close.Click += (_, _) => d.Close();
        d.AcceptButton = add;
        d.ShowDialog(this);
    }

    void ShowBoutiquePosteDialog(Database.BoutiqueEmployeeRow? row, int posteForce = 0)
    {
        using var d = new Form { Text = row is null ? "Affecter un poste" : "Modifier le poste", Width = 500, Height = 360, StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(14,24,43), FormBorderStyle = FormBorderStyle.FixedDialog };
        var poste = new ComboBox { Left = 190, Top = 28, Width = 220, DropDownStyle = ComboBoxStyle.DropDownList }; for (int i = 1; i <= 6; i++) poste.Items.Add($"Poste {i}"); poste.SelectedIndex = Math.Max(0, ((posteForce > 0 ? posteForce : (row?.Poste ?? 1)) - 1));
        var n = new TextBox { Left = 190, Top = 80, Width = 220, Text = row?.Nom ?? "" }; var t = new TextBox { Left = 190, Top = 132, Width = 220, Text = row?.Telephone ?? "" }; ApplyPhoneInputFormat(t); var note = new TextBox { Left = 190, Top = 184, Width = 220, Text = row?.Note ?? "" }; var active = new CheckBox { Left = 190, Top = 230, Width = 220, Text = "Poste actif", Checked = row?.Actif ?? true, ForeColor = Color.White };
        d.Controls.AddRange(new Control[] { new Label { Text = "Poste", Left = 30, Top = 32, ForeColor = Color.White }, poste, new Label { Text = "Nom & Prénom", Left = 30, Top = 84, ForeColor = Color.White }, n, new Label { Text = "Téléphone", Left = 30, Top = 136, ForeColor = Color.White }, t, new Label { Text = "Observation", Left = 30, Top = 188, ForeColor = Color.White }, note, active });
        var ok = new Button { Text = "ENREGISTRER", Left = 190, Top = 270, Width = 125, Height = 38, BackColor = Color.FromArgb(0,190,130), ForeColor = Color.White, FlatStyle = FlatStyle.Flat }; ok.FlatAppearance.BorderSize = 0; d.Controls.Add(ok); d.AcceptButton = ok;
        ok.Click += (_, _) => { try { Database.SaveBoutiqueEmployee(row?.Id ?? 0, poste.SelectedIndex + 1, n.Text.Trim(), t.Text.Trim(), note.Text.Trim(), active.Checked); d.DialogResult = DialogResult.OK; d.Close(); } catch (Exception ex) { MessageBox.Show(ex.Message, "Boutique", MessageBoxButtons.OK, MessageBoxIcon.Warning); } };
        d.ShowDialog(this);
    }

    sealed class BoutiqueEmployeeChoice { public long Id; public int Poste; public string Nom; public BoutiqueEmployeeChoice(Database.BoutiqueEmployeeRow e){Id=e.Id;Poste=e.Poste;Nom=e.Nom;} public override string ToString()=>string.IsNullOrWhiteSpace(Nom)?$"Poste {Poste}" : $"Poste {Poste} — {Nom}"; }
    sealed class BoutiqueSessionChoice { public long Id; public string Label; public BoutiqueSessionChoice(Database.BoutiqueSessionRow s){Id=s.Id;Label=$"{s.Employe} — Wave {Money(s.WaveDonne)} / Orange {Money(s.OrangeDonne)}";} public override string ToString()=>Label; }
    static bool TryMoney(string text,out decimal value)=>decimal.TryParse((text??"").Replace(" ","").Replace(".","").Replace(",","."),System.Globalization.NumberStyles.Any,System.Globalization.CultureInfo.InvariantCulture,out value)&&value>=0;

    void AddBoutiqueKpi(Control host,string label,string value,Color accent,int left)
    { var p=new Panel{Left=left,Top=78,Width=210,Height=55,BackColor=Color.FromArgb(8,31,53)};p.Paint+=(_,e)=>DrawGlassPanel(e.Graphics,p.ClientRectangle,Color.FromArgb(8,31,53),accent,14,230);p.Controls.Add(new Label{Text=label,Left=12,Top=7,Width=186,AutoEllipsis=true,ForeColor=Color.FromArgb(185,210,235),Font=new Font("Segoe UI",7.5f,FontStyle.Bold)});p.Controls.Add(new Label{Text=value,Left=12,Top=25,Width=186,AutoEllipsis=true,ForeColor=Color.White,Font=new Font("Segoe UI",11,FontStyle.Bold)});host.Controls.Add(p); }

    sealed record BoutiqueReportLine(string Date, string Heure, string Poste, string Employe, string Operation, decimal Wave, decimal Orange, decimal Cash, string Statut);

    List<BoutiqueReportLine> BuildBoutiqueReportLines(DateTime start, DateTime endExclusive, int posteFilter)
    {
        var employees = Database.GetBoutiqueEmployees(false).ToDictionary(x => x.Id);
        var sessions = Database.GetBoutiqueSessions(start.Date, endExclusive.Date);
        if (posteFilter > 0)
            sessions = sessions.Where(s => employees.TryGetValue(s.EmployeId, out var e) && e.Poste == posteFilter).ToList();

        var lines = new List<BoutiqueReportLine>();
        foreach (var session in sessions.OrderBy(s => s.DateJour).ThenBy(s => s.Ouverture).ThenBy(s => s.Id))
        {
            employees.TryGetValue(session.EmployeId, out var emp);
            int poste = emp?.Poste ?? 0;
            var additions = Database.GetBoutiqueOperations(start.Date, endExclusive.Date, session.EmployeId)
                .Where(o => o.SessionId == session.Id && string.Equals(o.TypeOperation, "Complément dotation", StringComparison.OrdinalIgnoreCase))
                .OrderBy(o => o.DateOperation).ToList();
            decimal addedWave = additions.Where(o => string.Equals(o.Service, "Wave", StringComparison.OrdinalIgnoreCase)).Sum(o => o.Montant);
            decimal addedOrange = additions.Where(o => string.Equals(o.Service, "Orange Money", StringComparison.OrdinalIgnoreCase)).Sum(o => o.Montant);
            decimal initialWave = Math.Max(0, session.WaveDonne - addedWave);
            decimal initialOrange = Math.Max(0, session.OrangeDonne - addedOrange);
            lines.Add(new BoutiqueReportLine(session.DateJour, ParseHour(session.Ouverture), $"Poste {poste}", session.Employe, "Distribution matin", initialWave, initialOrange, Math.Max(0, session.EspecesDonne - additions.Where(o => string.Equals(o.Service, "Espèces", StringComparison.OrdinalIgnoreCase)).Sum(o => o.Montant)), session.Statut));
            foreach (var a in additions)
            {
                decimal aw = string.Equals(a.Service, "Wave", StringComparison.OrdinalIgnoreCase) ? a.Montant : 0;
                decimal ao = string.Equals(a.Service, "Orange Money", StringComparison.OrdinalIgnoreCase) ? a.Montant : 0;
                lines.Add(new BoutiqueReportLine(session.DateJour, ParseHour(a.DateOperation), $"Poste {poste}", session.Employe, "+ Ajout dotation", aw, ao, string.Equals(a.Service, "Espèces", StringComparison.OrdinalIgnoreCase) ? a.Montant : 0, session.Statut));
            }
            if (!string.IsNullOrWhiteSpace(session.Fermeture) || session.WaveRetour > 0 || session.OrangeRetour > 0 || session.EspecesRetour > 0)
                lines.Add(new BoutiqueReportLine(session.DateJour, ParseHour(session.Fermeture), $"Poste {poste}", session.Employe, "Retour soir", session.WaveRetour, session.OrangeRetour, session.EspecesRetour, session.Statut));
        }
        return lines;
    }

    static string ParseHour(string value)
    {
        if (DateTime.TryParse(value, out var dt)) return dt.ToString("HH:mm:ss");
        return string.IsNullOrWhiteSpace(value) ? "—" : value.Length >= 8 ? value.Substring(Math.Max(0, value.Length - 8)) : value;
    }

    static string ReportDayKey(string value)
    {
        if (DateTime.TryParse(value, out var dt)) return dt.Date.ToString("yyyy-MM-dd");
        if (!string.IsNullOrWhiteSpace(value) && value.Length >= 10) return value.Substring(0, 10);
        return value ?? "";
    }

    void ShowBoutiqueReportDialog()
    {
        using var d = new Form { Text = "Rapport Boutique", Width = 1240, Height = 760, StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(7,18,38) };
        var title = new Label { Text = "RAPPORT BOUTIQUE — POSTES", Left = 20, Top = 16, AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 20, FontStyle.Bold) }; d.Controls.Add(title);
        var start = new DateTimePicker { Left = 20, Top = 60, Width = 150, Format = DateTimePickerFormat.Short, Value = DateTime.Today };
        var end = new DateTimePicker { Left = 180, Top = 60, Width = 150, Format = DateTimePickerFormat.Short, Value = DateTime.Today };
        var poste = new ComboBox { Left = 350, Top = 60, Width = 190, DropDownStyle = ComboBoxStyle.DropDownList };
        poste.Items.Add("Tous les postes");
        for (int i = 1; i <= 6; i++) poste.Items.Add($"Poste {i}");
        poste.SelectedIndex = 0;
        var load = CreateBoutiqueRoundButton("AFFICHER", 555, 58, 110, 34, Color.FromArgb(0,155,225));
        var print = CreateBoutiqueRoundButton("🖨 IMPRIMER", 675, 58, 135, 34, Color.FromArgb(0,170,120));
        var pdf = CreateBoutiqueRoundButton("📄 PDF", 820, 58, 105, 34, Color.FromArgb(220,145,25));
        var close = CreateBoutiqueRoundButton("FERMER", 1080, 58, 120, 34, Color.FromArgb(55,72,100));
        d.Controls.AddRange(new Control[] { start, end, poste, load, print, pdf, close });

        var grid = new DataGridView { Left = 20, Top = 110, Width = 1180, Height = 520, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, BackgroundColor = Color.FromArgb(5,18,42), BorderStyle = BorderStyle.None, EnableHeadersVisualStyles = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect };
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(18,91,168); grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White; grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        grid.Columns.Add("Date", "DATE"); grid.Columns.Add("Heure", "HEURE"); grid.Columns.Add("Poste", "POSTE"); grid.Columns.Add("Employe", "EMPLOYÉ"); grid.Columns.Add("Operation", "OPÉRATION"); grid.Columns.Add("Wave", "WAVE"); grid.Columns.Add("Orange", "ORANGE MONEY"); grid.Columns.Add("Cash", "ESPÈCES"); grid.Columns.Add("Statut", "STATUT"); d.Controls.Add(grid);
        var summary = new Label { Left = 20, Top = 642, Width = 1180, Height = 34, ForeColor = Color.FromArgb(210,225,240), Font = new Font("Segoe UI", 9, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter }; d.Controls.Add(summary);

        List<BoutiqueReportLine> current = new();
        void Load()
        {
            int pf = poste.SelectedIndex;
            current = BuildBoutiqueReportLines(start.Value.Date, end.Value.Date.AddDays(1), pf);
            grid.Rows.Clear();
            foreach (var r in current)
            {
                int idx = grid.Rows.Add(r.Date, r.Heure, r.Poste, r.Employe, r.Operation, r.Wave > 0 ? Money(r.Wave) : "—", r.Orange > 0 ? Money(r.Orange) : "—", r.Cash > 0 ? Money(r.Cash) : "—", r.Statut);
                var row = grid.Rows[idx];
                row.DefaultCellStyle.ForeColor = Color.White;
                row.DefaultCellStyle.BackColor = r.Operation.StartsWith("+") ? Color.FromArgb(18,55,50) : Color.FromArgb(5,18,42);
                row.DefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Regular);
            }
            decimal w = current.Sum(x => x.Wave), o = current.Sum(x => x.Orange), c = current.Sum(x => x.Cash), adds = current.Where(x => x.Operation.StartsWith("+")).Sum(x => x.Wave + x.Orange + x.Cash);
            summary.Text = $"{current.Count} mouvement(s)   •   Wave : {Money(w)}   •   Orange Money : {Money(o)}   •   Espèces : {Money(c)}   •   Compléments (+ Ajouter) : {Money(adds)}";
        }
        load.Click += (_, _) => Load();
        print.Click += (_, _) => { if (current.Count == 0) Load(); PrintBoutiqueReport(current, start.Value.Date, end.Value.Date.AddDays(1), poste.SelectedIndex); };
        pdf.Click += (_, _) => { if (current.Count == 0) Load(); SaveBoutiqueReportAsPdf(current, start.Value.Date, end.Value.Date.AddDays(1), poste.SelectedIndex); };
        close.Click += (_, _) => d.Close();
        Load();
        d.ShowDialog(this);
    }

    void PrintBoutiqueReport(List<BoutiqueReportLine> lines, DateTime start, DateTime endExclusive, int posteFilter)
    {
        using var dialog = new PrintDialog();
        using var doc = new PrintDocument();
        doc.DocumentName = $"Rapport Boutique {(posteFilter > 0 ? "Poste " + posteFilter : "Tous les postes")}";
        doc.DefaultPageSettings.Landscape = true;
        doc.DefaultPageSettings.Margins = new Margins(35, 35, 35, 35);
        int page = 0; const int perPage = 18;
        doc.PrintPage += (_, e) =>
        {
            RenderBoutiqueReport(e.Graphics!, e.MarginBounds, lines, start, endExclusive, posteFilter, page, perPage);
            page++; e.HasMorePages = page * perPage < lines.Count;
        };
        if (dialog.ShowDialog(this) == DialogResult.OK) doc.Print();
    }

    Bitmap RenderBoutiqueReportPage(List<BoutiqueReportLine> lines, DateTime start, DateTime endExclusive, int posteFilter, int pageIndex, int perPage)
    {
        var bmp = new Bitmap(1600, 1100, PixelFormat.Format24bppRgb);
        using var g = Graphics.FromImage(bmp); g.Clear(Color.White);
        RenderBoutiqueReport(g, new Rectangle(55, 45, 1490, 1010), lines, start, endExclusive, posteFilter, pageIndex, perPage);
        return bmp;
    }

    void RenderBoutiqueReport(Graphics g, Rectangle b, List<BoutiqueReportLine> lines, DateTime start, DateTime endExclusive, int posteFilter, int pageIndex, int perPage)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        Color navy = Color.FromArgb(16,43,79), blue = Color.FromArgb(28,83,145), gold = Color.FromArgb(236,174,45), line = Color.FromArgb(205,213,223), pale = Color.FromArgb(246,248,251);
        using var white = new SolidBrush(Color.White); using var navyBrush = new SolidBrush(navy); using var blueBrush = new SolidBrush(blue); using var goldBrush = new SolidBrush(gold); using var paleBrush = new SolidBrush(pale); using var gray = new SolidBrush(Color.FromArgb(90,100,115)); using var pen = new Pen(line, .8f);
        using var company = new Font("Segoe UI", 18, FontStyle.Bold); using var title = new Font("Segoe UI", 16, FontStyle.Bold); using var sub = new Font("Segoe UI", 8.5f); using var head = new Font("Segoe UI", 8, FontStyle.Bold); using var body = new Font("Segoe UI", 8); using var totalFont = new Font("Segoe UI", 9, FontStyle.Bold);
        float left=b.Left, top=b.Top, width=b.Width;
        g.FillRectangle(navyBrush,left,top,width,68); g.DrawString("Sankhe & Frères",company,white,left+16,top+8); g.DrawString("TRANSFERT D’ARGENT • RAPPORT BOUTIQUE",sub,goldBrush,left+17,top+40);
        g.DrawString($"Gérant : {GetManagerName()}", sub, white, left + 250, top + 42);
        top += 78; g.DrawString("RC : SN LGA 2015 - A - 568   •   NINEA : 005597333/20",sub,gray,left,top); top+=13; g.DrawString("Tél : 77 519 57 75 - 70 811 04 04   •   DAHRA - SENEGAL   •   Email : sankhebaba@gmail.com",sub,gray,left,top); top+=24;
        string t = posteFilter>0 ? $"RAPPORT BOUTIQUE — POSTE {posteFilter}" : "RAPPORT BOUTIQUE — TOUS LES POSTES"; var ts=g.MeasureString(t,title); g.DrawString(t,title,navyBrush,left+(width-ts.Width)/2,top); top+=27;
        string f=$"Période : {start:dd/MM/yyyy} au {endExclusive.AddDays(-1):dd/MM/yyyy}   •   Heure incluse : Oui"; var fs=g.MeasureString(f,sub); g.DrawString(f,sub,gray,left+(width-fs.Width)/2,top); top+=22;
        string[] heads={"DATE","HEURE","POSTE","EMPLOYÉ","OPÉRATION","WAVE","ORANGE MONEY","ESPÈCES","STATUT"}; float[] ws={82,72,95,170,190,115,135,115,90}; float scale=Math.Min(1f,width/ws.Sum()); for(int i=0;i<ws.Length;i++)ws[i]*=scale; float tw=ws.Sum(), x0=left+(width-tw)/2; g.FillRectangle(blueBrush,x0,top,tw,28); float x=x0; foreach(var i in Enumerable.Range(0,heads.Length)){g.DrawRectangle(Pens.White,x,top,ws[i],28); using var sf=new StringFormat{Alignment=StringAlignment.Center,LineAlignment=StringAlignment.Center};g.DrawString(heads[i],head,white,new RectangleF(x+2,top+2,ws[i]-4,24),sf);x+=ws[i];} top+=28;
        int si=pageIndex*perPage, ei=Math.Min(lines.Count,si+perPage); for(int i=si;i<ei;i++){var r=lines[i];float rh=36;if((i-si)%2==1)g.FillRectangle(paleBrush,x0,top,tw,rh);string[] vals={r.Date,r.Heure,r.Poste,r.Employe,r.Operation,r.Wave>0?Money(r.Wave):"—",r.Orange>0?Money(r.Orange):"—",r.Cash>0?Money(r.Cash):"—",r.Statut};x=x0;for(int j=0;j<vals.Length;j++){g.DrawRectangle(pen,x,top,ws[j],rh);using var sf=new StringFormat{Alignment=(j==5||j==6||j==7)?StringAlignment.Far:StringAlignment.Near,LineAlignment=StringAlignment.Center,Trimming=StringTrimming.EllipsisCharacter};Brush br=(j==4&&r.Operation.StartsWith("+"))?new SolidBrush(Color.FromArgb(0,145,105)):(j==5?new SolidBrush(Color.FromArgb(0,105,190)):(j==6?new SolidBrush(Color.FromArgb(225,105,0)):(j==7?new SolidBrush(Color.FromArgb(40,140,80)):Brushes.Black)));g.DrawString(vals[j],body,br,new RectangleF(x+4,top+2,ws[j]-8,rh-4),sf);if(br!=Brushes.Black)br.Dispose();x+=ws[j];}top+=rh;}
        if(pageIndex==Math.Max(0,(int)Math.Ceiling(lines.Count/(double)perPage)-1)){top+=12;decimal w=lines.Sum(r=>r.Wave),o=lines.Sum(r=>r.Orange),c=lines.Sum(r=>r.Cash),a=lines.Where(r=>r.Operation.StartsWith("+")).Sum(r=>r.Wave+r.Orange+r.Cash);float bw=(tw-30)/4f;string[] labs={"WAVE TOTAL","ORANGE MONEY TOTAL","ESPÈCES TOTAL","COMPLÉMENTS (+ AJOUTER)"};string[] vs={Money(w),Money(o),Money(c),Money(a)};for(int i=0;i<4;i++){float bx=x0+i*(bw+10);g.FillRectangle(i==2?goldBrush:paleBrush,bx,top,bw,50);g.DrawRectangle(pen,bx,top,bw,50);g.DrawString(labs[i],head,i==2?white:blueBrush,bx+8,top+7);g.DrawString(vs[i],totalFont,i==2?white:navyBrush,bx+8,top+25);}}
        }

    void SaveBoutiqueReportAsPdf(List<BoutiqueReportLine> lines, DateTime start, DateTime endExclusive, int posteFilter)
    {
        using var dialog = new SaveFileDialog { Title="Enregistrer le rapport Boutique PDF", Filter="Document PDF (*.pdf)|*.pdf", FileName=$"Rapport_Boutique_{(posteFilter>0?"Poste"+posteFilter:"Tous")}_{start:yyyyMMdd}_{endExclusive.AddDays(-1):yyyyMMdd}.pdf", AddExtension=true, DefaultExt="pdf" };
        if(dialog.ShowDialog(this)!=DialogResult.OK)return;
        const int perPage=18; int totalPages=Math.Max(1,(int)Math.Ceiling(lines.Count/(double)perPage)); var pages=new List<byte[]>(); for(int p=0;p<totalPages;p++){using var bmp=RenderBoutiqueReportPage(lines,start,endExclusive,posteFilter,p,perPage);pages.Add(BitmapToJpeg(bmp));}
        WriteJpegPagesPdf(dialog.FileName,pages); MessageBox.Show("Rapport Boutique PDF créé avec la même mise en page que l’impression.","SANKHÉ — Rapport Boutique",MessageBoxButtons.OK,MessageBoxIcon.Information);
    }

    void WriteJpegPagesPdf(string fileName, List<byte[]> jpegPages)
    {
        // Générateur PDF volontairement simple et robuste : chaque page contient
        // directement l'image JPEG correspondant exactement à la page imprimée.
        const double pageW = 841.8898, pageH = 595.2756;
        // Les nombres PDF doivent toujours utiliser le point décimal, même sur Windows FR.
        var inv = System.Globalization.CultureInfo.InvariantCulture;
        using var fs = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None);
        using var bw = new BinaryWriter(fs, Encoding.ASCII, leaveOpen: true);

        var objects = new List<byte[]>();
        // 1 Catalog, 2 Pages
        objects.Add(Encoding.ASCII.GetBytes("<< /Type /Catalog /Pages 2 0 R >>"));
        objects.Add(Array.Empty<byte>()); // remplacé après création des pages

        var pageObjectNumbers = new List<int>();
        var pageObjects = new List<byte[]>();
        var contentObjects = new List<byte[]>();
        var imageObjects = new List<byte[]>();

        foreach (var jpg in jpegPages)
        {
            using var ms = new MemoryStream(jpg, false);
            using var img = Image.FromStream(ms, useEmbeddedColorManagement: false, validateImageData: true);
            imageObjects.Add(jpg);
        }

        int nextObject = 3;
        for (int i = 0; i < jpegPages.Count; i++)
        {
            int pageObj = nextObject++;
            int contentObj = nextObject++;
            int imageObj = nextObject++;
            pageObjectNumbers.Add(pageObj);

            string page = $"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {pageW.ToString("0.##", inv)} {pageH.ToString("0.##", inv)}] " +
                          $"/Resources << /ProcSet [/PDF /ImageC] /XObject << /Im0 {imageObj} 0 R >> >> " +
                          $"/Contents {contentObj} 0 R >>";
            string stream = $"q {pageW.ToString("0.##", inv)} 0 0 {pageH.ToString("0.##", inv)} 0 0 cm /Im0 Do Q";
            pageObjects.Add(Encoding.ASCII.GetBytes(page));
            contentObjects.Add(Encoding.ASCII.GetBytes($"<< /Length {Encoding.ASCII.GetByteCount(stream)} >>\nstream\n{stream}\nendstream"));
        }

        int pageCount = jpegPages.Count;
        var kids = string.Join(" ", pageObjectNumbers.Select(n => $"{n} 0 R"));
        objects[1] = Encoding.ASCII.GetBytes($"<< /Type /Pages /Count {pageCount} /Kids [{kids}] >>");
        for (int i = 0; i < pageCount; i++)
        {
            objects.Add(pageObjects[i]);
            objects.Add(contentObjects[i]);
            // image object bytes are wrapped specially below; keep a marker in objects.
            objects.Add(imageObjects[i]);
        }

        var offsets = new List<long> { 0 };
        bw.Write(Encoding.ASCII.GetBytes("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n"));
        for (int i = 0; i < objects.Count; i++)
        {
            int objNo = i + 1;
            offsets.Add(fs.Position);
            bool isImage = i >= 2 && ((i - 2) % 3 == 2);
            if (isImage)
            {
                byte[] jpg = objects[i];
                using var ms = new MemoryStream(jpg, false);
                using var img = Image.FromStream(ms, false, true);
                string header = $"{objNo} 0 obj\n" +
                    $"<< /Type /XObject /Subtype /Image /Width {img.Width} /Height {img.Height} " +
                    $"/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length {jpg.Length} >>\nstream\n";
                bw.Write(Encoding.ASCII.GetBytes(header));
                bw.Write(jpg);
                bw.Write(Encoding.ASCII.GetBytes("\nendstream\nendobj\n"));
            }
            else
            {
                bw.Write(Encoding.ASCII.GetBytes($"{objNo} 0 obj\n"));
                bw.Write(objects[i]);
                bw.Write(Encoding.ASCII.GetBytes("\nendobj\n"));
            }
        }

        long xref = fs.Position;
        bw.Write(Encoding.ASCII.GetBytes($"xref\n0 {objects.Count + 1}\n0000000000 65535 f \n"));
        for (int i = 1; i < offsets.Count; i++)
            bw.Write(Encoding.ASCII.GetBytes($"{offsets[i]:D10} 00000 n \n"));
        bw.Write(Encoding.ASCII.GetBytes($"trailer\n<< /Size {objects.Count + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF"));
    }

    void ShowSeddo()
    {
        ClearContent();
        content.AutoScroll = true;
        content.Padding = new Padding(10, 10, 10, 30);

        // Page Seddo centrée dans la zone principale.
        var host = new Panel
        {
            BackColor = Color.Transparent,
            Width = 1040,
            Height = 1190,
            Anchor = AnchorStyles.Top
        };
        void CenterSeddoHost()
        {
            host.Left = Math.Max(0, (content.ClientSize.Width - host.Width) / 2);
            host.Top = 20;
        }
        content.Resize += (_, _) => CenterSeddoHost();
        CenterSeddoHost();
        content.Controls.Add(host);

        var title = Heading("Opérations Seddo");
        title.Location = new Point(0, 0);
        title.Font = new Font("Segoe UI", 25, FontStyle.Bold);
        host.Controls.Add(title);

        var rate = Database.GetSettingDecimal("SeddoCommissionPercent", 5.5m);
        var info = new Label
        {
            Text = "Caisse Seddo indépendante • Déposez vos liquidités puis effectuez les opérations clients. Le taux de commission est modifiable à tout moment.",
            Left = 0, Top = 52, Width = 1040, Height = 40,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 10, FontStyle.Regular),
            ForeColor = Color.FromArgb(205, 220, 238)
        };
        host.Controls.Add(info);

        // Carte Caisse Seddo : présentation inspirée des cartes de caisse du tableau de bord.
        var caisseCard = new Panel { Left = 0, Top = 105, Width = 1040, Height = 160, BackColor = Color.Transparent };
        EnableDoubleBuffer(caisseCard);
        caisseCard.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            var rect = new Rectangle(0, 0, caisseCard.Width - 1, caisseCard.Height - 1);
            using var path = RoundedPath(rect, 20);
            using var bg = new LinearGradientBrush(rect, Color.FromArgb(5, 105, 82), Color.FromArgb(8, 48, 67), 0f);
            e.Graphics.FillPath(bg, path);
            using var border = new Pen(Color.FromArgb(0, 232, 170), 2f);
            e.Graphics.DrawPath(border, path);
            using var glow = new SolidBrush(Color.FromArgb(38, 0, 235, 175));
            e.Graphics.FillEllipse(glow, caisseCard.Width - 190, 18, 150, 150);
            using var accent = new Pen(Color.FromArgb(255, 211, 70), 4);
            e.Graphics.DrawLine(accent, 24, 20, 205, 20);
        };
        host.Controls.Add(caisseCard);

        var solde = Database.GetSolde("Caisse Seddo");
        var seddoIcon = new PictureBox
        {
            Image = LoadAsset("caisse_seddo_icon.png"),
            SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Transparent,
            Left = 24, Top = 34, Width = 66, Height = 66
        };
        caisseCard.Controls.Add(seddoIcon);

        caisseCard.Controls.Add(new Label
        {
            Text = "CAISSE SEDDO", Left = 105, Top = 23, Width = 300,
            ForeColor = Color.FromArgb(255, 225, 90), Font = new Font("Segoe UI", 15, FontStyle.Bold)
        });
        caisseCard.Controls.Add(new Label
        {
            Text = "SOLDE DISPONIBLE", Left = 105, Top = 52, Width = 260,
            ForeColor = Color.FromArgb(205, 235, 235), Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
        });
        var soldeLabel = new Label
        {
            Text = Money(solde), Left = 105, Top = 69, Width = 420, Height = 58,
            ForeColor = Color.White, Font = new Font("Segoe UI", 31, FontStyle.Bold), AutoEllipsis = false
        };
        caisseCard.Controls.Add(soldeLabel);
        caisseCard.Controls.Add(new Label
        {
            Text = "FCFA", Left = 530, Top = 82, Width = 90, Height = 38,
            ForeColor = Color.FromArgb(0, 245, 180), Font = new Font("Segoe UI", 17, FontStyle.Bold)
        });

        var coinsSeddo = new PictureBox
        {
            Image = LoadAsset("coins_green.png"), SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Transparent, Left = 705, Top = 34, Width = 120, Height = 105
        };
        caisseCard.Controls.Add(coinsSeddo);

        var rateLabel = new Label
        {
            Text = $"COMMISSION\r\n{rate:0.##}%", Left = 825, Top = 24, Width = 92, Height = 64,
            TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.White,
            BackColor = Color.FromArgb(45, 0, 190, 140), Font = new Font("Segoe UI", 10, FontStyle.Bold)
        };
        caisseCard.Controls.Add(rateLabel);
        var rateBtn = new Button
        {
            Text = "⚙  MODIFIER LE TAUX", Left = 825, Top = 96, Width = 190, Height = 43,
            BackColor = Color.FromArgb(255, 196, 45), ForeColor = Color.FromArgb(20, 28, 45),
            FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };
        rateBtn.FlatAppearance.BorderSize = 0;
        caisseCard.Controls.Add(rateBtn);
        rateBtn.Click += (_, _) =>
        {
            using var dlg = new Form { Text = "Commission Seddo", Width = 390, Height = 210, StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(15, 27, 48), FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false };
            dlg.Controls.Add(new Label { Text = "Taux de commission (%)", Left = 25, Top = 22, Width = 300, ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) });
            var tb = new TextBox { Left = 25, Top = 52, Width = 300, Text = rate.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture), Font = new Font("Segoe UI", 13, FontStyle.Bold) };
            dlg.Controls.Add(tb);
            var save = new Button { Text = "ENREGISTRER", Left = 210, Top = 105, Width = 115, Height = 38, BackColor = Color.FromArgb(0, 190, 130), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            save.FlatAppearance.BorderSize = 0;
            dlg.Controls.Add(save);
            save.Click += (_, _) =>
            {
                if (!decimal.TryParse(tb.Text.Replace(',', '.'), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var v) || v < 0 || v > 100)
                { MessageBox.Show("Entrez un taux compris entre 0 et 100 %.", "Seddo", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                Database.SetSetting("SeddoCommissionPercent", v.ToString("0.####", System.Globalization.CultureInfo.InvariantCulture));
                dlg.DialogResult = DialogResult.OK;
                dlg.Close();
            };
            dlg.ShowDialog(this);
            ShowSeddo();
        };

        var opCard = new Panel { Left = 0, Top = 270, Width = 650, Height = 440, BackColor = Color.FromArgb(12, 27, 52) };
        opCard.Paint += (_, e) => { using var pen = new Pen(Color.FromArgb(0, 190, 255), 2); e.Graphics.DrawRectangle(pen, 0, 0, opCard.Width - 1, opCard.Height - 1); };
        host.Controls.Add(opCard);
        opCard.Controls.Add(new Label { Text = "NOUVELLE OPÉRATION CLIENT", Left = 24, Top = 18, Width = 400, ForeColor = Color.White, Font = new Font("Segoe UI", 13, FontStyle.Bold) });
        var nom = new TextBox
        {
            Left = 24, Top = 65, Width = 280, Font = new Font("Segoe UI", 11),
            AutoCompleteMode = AutoCompleteMode.SuggestAppend,
            AutoCompleteSource = AutoCompleteSource.CustomSource
        };
        var tel = new TextBox { Left = 330, Top = 65, Width = 290, Font = new Font("Segoe UI", 11) }; ApplyPhoneInputFormat(tel);
        opCard.Controls.Add(new Label { Text = "Nom & Prénom", Left = 24, Top = 42, Width = 280, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        opCard.Controls.Add(nom);
        opCard.Controls.Add(new Label { Text = "Téléphone", Left = 330, Top = 42, Width = 290, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        opCard.Controls.Add(tel);

        // V173 : même sélecteur client dans Seddo.
        // La liste apparaît dès la première lettre et le téléphone est rempli
        // seulement après le choix du client.
        ConfigureClientPicker(opCard, nom, tel);

        var montant = new TextBox { Left = 24, Top = 135, Width = 280, Font = new Font("Segoe UI", 12, FontStyle.Bold) }; ApplyMoneyInputFormat(montant);
        var reference = new TextBox { Left = 330, Top = 135, Width = 290, Font = new Font("Segoe UI", 11) };
        opCard.Controls.Add(new Label { Text = "Montant remis au client (FCFA)", Left = 24, Top = 112, Width = 280, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        opCard.Controls.Add(montant);
        opCard.Controls.Add(new Label { Text = "Référence (facultatif)", Left = 330, Top = 112, Width = 290, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        opCard.Controls.Add(reference);
        // Bande de commission / total : volontairement placée derrière la cage de paiement.
        // Elle reste lisible autour de la cage, tandis que la cage de paiement passe au premier plan.
        var calc = new Label
        {
            Left = 24, Top = 184, Width = 290, Height = 112,
            ForeColor = Color.FromArgb(255, 220, 100),
            BackColor = Color.FromArgb(10, 27, 50),
            Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleCenter,
            Padding = new Padding(6)
        };
        opCard.Controls.Add(calc);
        // Mode de paiement du client : 3 boutons explicites au lieu d'une liste déroulante.
        // Le bouton sélectionné reste visuellement actif pour éviter toute confusion.
        opCard.Controls.Add(new Label { Text = "Mode de paiement du client", Left = 365, Top = 184, Width = 255, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        // La cage de paiement est volontairement superposée à la bande commission/total.
        // Elle doit être visuellement prioritaire et ne doit jamais être cachée par le texte.
        var servicePanel = new Panel { Left = 365, Top = 240, Width = 255, Height = 78, BackColor = Color.Transparent };
        servicePanel.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            using var path = RoundedPath(new Rectangle(0, 0, servicePanel.Width - 1, servicePanel.Height - 1), 10);
            using var bg = new LinearGradientBrush(new Rectangle(0, 0, servicePanel.Width, servicePanel.Height), Color.FromArgb(18, 43, 70), Color.FromArgb(10, 28, 50), 0f);
            e.Graphics.FillPath(bg, path);
            using var pen = new Pen(Color.FromArgb(60, 105, 145), 1.5f);
            e.Graphics.DrawPath(pen, path);
        };
        var btnWave = new Button { Text = "WAVE", Left = 5, Top = 5, Width = 65, Height = 25, BackColor = Color.FromArgb(0, 177, 255), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), Cursor = Cursors.Hand };
        var btnOrange = new Button { Text = "ORANGE MONEY", Left = 75, Top = 5, Width = 92, Height = 25, BackColor = Color.FromArgb(245, 145, 20), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.2f, FontStyle.Bold), Cursor = Cursors.Hand };
        var btnEspeces = new Button { Text = "ESPÈCES", Left = 172, Top = 5, Width = 65, Height = 25, BackColor = Color.FromArgb(55, 150, 95), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.2f, FontStyle.Bold), Cursor = Cursors.Hand };
        foreach (var b in new[] { btnWave, btnOrange, btnEspeces }) { b.FlatAppearance.BorderSize = 1; b.FlatAppearance.BorderColor = Color.FromArgb(115, 145, 175); servicePanel.Controls.Add(b); }
        var selectedServiceBox = new Panel { Left = 5, Top = 35, Width = 245, Height = 35, BackColor = Color.FromArgb(18, 105, 88) };
        selectedServiceBox.Paint += (_, e) =>
        {
            using var path = RoundedPath(new Rectangle(0, 0, selectedServiceBox.Width - 1, selectedServiceBox.Height - 1), 7);
            using var pen = new Pen(Color.FromArgb(0, 225, 170), 1);
            e.Graphics.DrawPath(pen, path);
        };
        var selectedServiceLabel = new Label { Text = "✓  PAIEMENT SÉLECTIONNÉ : WAVE", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.White, Font = new Font("Segoe UI", 6.6f, FontStyle.Bold), BackColor = Color.Transparent, AutoEllipsis = true };
        selectedServiceBox.Controls.Add(selectedServiceLabel);
        servicePanel.Controls.Add(selectedServiceBox);
        opCard.Controls.Add(servicePanel);
        string? selectedService = "Wave";
        void SelectService(string service)
        {
            selectedService = service;
            btnWave.BackColor = service == "Wave" ? Color.FromArgb(0, 125, 210) : Color.FromArgb(0, 177, 255);
            btnOrange.BackColor = service == "Orange Money" ? Color.FromArgb(210, 105, 10) : Color.FromArgb(245, 145, 20);
            btnEspeces.BackColor = service == "Espèces" ? Color.FromArgb(35, 105, 65) : Color.FromArgb(55, 150, 95);
            selectedServiceLabel.Text = $"✓  PAIEMENT SÉLECTIONNÉ : {service.ToUpperInvariant()}";
            selectedServiceBox.BackColor = service == "Wave" ? Color.FromArgb(0, 92, 135) : service == "Orange Money" ? Color.FromArgb(130, 72, 10) : Color.FromArgb(25, 100, 60);
        }
        btnWave.Click += (_, _) => SelectService("Wave");
        btnOrange.Click += (_, _) => SelectService("Orange Money");
        btnEspeces.Click += (_, _) => SelectService("Espèces");
        SelectService("Wave");
        void RefreshCalc()
        {
            if (decimal.TryParse(montant.Text.Replace(" ", "").Replace(".", ""), out var m) && m > 0)
            {
                var com = Math.Round(m * rate / 100m, 0, MidpointRounding.AwayFromZero);
                calc.Text = $"Commission : {Money(com)} FCFA\r\nMontant total : {Money(m + com)} FCFA";
            }
            else calc.Text = $"Commission actuelle : {rate:0.##}%";
        }
        montant.TextChanged += (_, _) => RefreshCalc();
        RefreshCalc();
        var paiementDiffere = new CheckBox
        {
            Text = "Paiement différé — À ENCAISSER PLUS TARD",
            Left = 24, Top = 325, Width = 596, Height = 25,
            ForeColor = Color.FromArgb(255, 210, 90), BackColor = Color.Transparent,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            AutoSize = false
        };
        opCard.Controls.Add(paiementDiffere);
        paiementDiffere.CheckedChanged += (_, _) =>
        {
            // En paiement différé, aucun service d'encaissement n'est choisi à la création.
            // Le choix sera obligatoirement effectué au moment du règlement dans « À ENCAISSER ».
            var actif = !paiementDiffere.Checked;
            btnWave.Enabled = actif; btnOrange.Enabled = actif; btnEspeces.Enabled = actif;
            servicePanel.BackColor = paiementDiffere.Checked ? Color.FromArgb(35, 42, 55) : Color.Transparent;
            if (!actif)
            {
                selectedService = null;
                btnWave.BackColor = Color.FromArgb(70, 78, 92);
                btnOrange.BackColor = Color.FromArgb(70, 78, 92);
                btnEspeces.BackColor = Color.FromArgb(70, 78, 92);
                selectedServiceLabel.Text = "✓  PAIEMENT : À CHOISIR AU RÈGLEMENT";
                selectedServiceBox.BackColor = Color.FromArgb(78, 68, 38);
            }
            else SelectService("Wave");
        };
        var saveOp = new Button { Text = "✓  VALIDER / ENREGISTRER L’OPÉRATION SEDDO", Left = 24, Top = 365, Width = 596, Height = 48, BackColor = Color.FromArgb(0, 190, 130), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10.5f, FontStyle.Bold), Cursor = Cursors.Hand };
        saveOp.FlatAppearance.BorderSize = 0;
        opCard.Controls.Add(saveOp);
        saveOp.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(nom.Text)) { MessageBox.Show("Veuillez saisir le nom du client.", "Seddo", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (string.IsNullOrWhiteSpace(tel.Text)) { MessageBox.Show("Veuillez saisir le téléphone du client.", "Seddo", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!decimal.TryParse(montant.Text.Replace(" ", "").Replace(".", ""), out var m) || m <= 0) { MessageBox.Show("Veuillez saisir un montant valide.", "Seddo", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            try
            {
                var service = paiementDiffere.Checked ? null : selectedService;
                var com = Database.AddSeddoOperation(nom.Text.Trim(), tel.Text.Trim(), m, rate, reference.Text.Trim(), "", paiementDiffere.Checked, service ?? "");
                var msg = paiementDiffere.Checked
                    ? $"Opération Seddo enregistrée en paiement différé.\r\nCommission : {Money(com)} FCFA\r\nMontant à encaisser plus tard : {Money(m + com)} FCFA.\r\n\r\nLe client est maintenant visible dans « À ENCAISSER »."
                    : $"Opération Seddo enregistrée.\r\nCommission : {Money(com)} FCFA\r\nPaiement client versé sur : {service}.";
                MessageBox.Show(msg, "SANKHÉ — Seddo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDashboard();
                ShowSeddo();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "SANKHÉ — Seddo", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        };

        // Entrée = validation rapide de l'opération Seddo.
        void ValidateSeddoOnEnter(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;
            saveOp.PerformClick();
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
        nom.KeyDown += ValidateSeddoOnEnter;
        tel.KeyDown += ValidateSeddoOnEnter;
        montant.KeyDown += ValidateSeddoOnEnter;
        reference.KeyDown += ValidateSeddoOnEnter;
        btnWave.KeyDown += ValidateSeddoOnEnter;
        btnOrange.KeyDown += ValidateSeddoOnEnter;
        btnEspeces.KeyDown += ValidateSeddoOnEnter;
        servicePanel.KeyDown += ValidateSeddoOnEnter;

        var moveCard = new Panel { Left = 670, Top = 270, Width = 370, Height = 440, BackColor = Color.FromArgb(18, 32, 58) };
        moveCard.Paint += (_, e) => { using var pen = new Pen(Color.FromArgb(220, 85, 105), 2); e.Graphics.DrawRectangle(pen, 0, 0, moveCard.Width - 1, moveCard.Height - 1); };
        host.Controls.Add(moveCard);
        moveCard.Controls.Add(new Label { Text = "MOUVEMENTS DE CAISSE", Left = 20, Top = 18, Width = 320, ForeColor = Color.White, Font = new Font("Segoe UI", 12, FontStyle.Bold) });
        var moveAmount = new TextBox { Left = 20, Top = 70, Width = 330, Font = new Font("Segoe UI", 11) }; ApplyMoneyInputFormat(moveAmount);
        var moveMotif = new TextBox { Left = 20, Top = 135, Width = 330, Font = new Font("Segoe UI", 10) };
        var moveRef = new TextBox { Left = 20, Top = 200, Width = 330, Font = new Font("Segoe UI", 10) };
        moveCard.Controls.Add(new Label { Text = "Montant (FCFA)", Left = 20, Top = 48, Width = 330, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        moveCard.Controls.Add(moveAmount);
        moveCard.Controls.Add(new Label { Text = "Motif", Left = 20, Top = 113, Width = 330, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        moveCard.Controls.Add(moveMotif);
        moveCard.Controls.Add(new Label { Text = "Référence", Left = 20, Top = 178, Width = 330, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        moveCard.Controls.Add(moveRef);
        var inBtn = new Button { Text = "➕ DÉPÔT", Left = 20, Top = 255, Width = 150, Height = 42, BackColor = Color.FromArgb(0, 166, 81), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var outBtn = new Button { Text = "➖ SORTIE", Left = 200, Top = 255, Width = 150, Height = 42, BackColor = Color.FromArgb(220, 38, 38), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        inBtn.FlatAppearance.BorderSize = 0; outBtn.FlatAppearance.BorderSize = 0;
        moveCard.Controls.Add(inBtn); moveCard.Controls.Add(outBtn);
        void SaveMove(bool entree)
        {
            if (!decimal.TryParse(moveAmount.Text.Replace(" ", "").Replace(".", ""), out var m) || m <= 0) { MessageBox.Show("Veuillez saisir un montant valide.", "Seddo", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            try { Database.AddCaisseMovement(m, entree, string.IsNullOrWhiteSpace(moveMotif.Text) ? (entree ? "Dépôt Seddo" : "Sortie Seddo") : moveMotif.Text.Trim(), moveRef.Text.Trim(), "Caisse Seddo"); ShowSeddo(); RefreshDashboard(); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "SANKHÉ — Seddo", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }
        inBtn.Click += (_, _) => SaveMove(true);
        outBtn.Click += (_, _) => SaveMove(false);

        // Bloc très visible pour les paiements Seddo différés.
        var pending = Database.GetSeddoPending(500);
        var pendingTotal = pending.Sum(x => x.Reste);
        var pendingCard = new Panel { Left = 0, Top = 725, Width = 1040, Height = 62, BackColor = Color.Transparent };
        pendingCard.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            using var path = RoundedPath(new Rectangle(0, 0, pendingCard.Width - 1, pendingCard.Height - 1), 14);
            using var bg = new LinearGradientBrush(new Rectangle(0, 0, pendingCard.Width, pendingCard.Height), Color.FromArgb(112, 58, 18), Color.FromArgb(70, 31, 25), 0f);
            e.Graphics.FillPath(bg, path);
            using var pen = new Pen(Color.FromArgb(255, 185, 55), 2f);
            e.Graphics.DrawPath(pen, path);
        };
        host.Controls.Add(pendingCard);
        pendingCard.Controls.Add(new Label { Text = "🔔  À ENCAISSER", Left = 22, Top = 9, Width = 250, Height = 24, ForeColor = Color.FromArgb(255, 224, 115), Font = new Font("Segoe UI", 13, FontStyle.Bold) });
        pendingCard.Controls.Add(new Label { Text = $"{pending.Count} client(s)  •  {Money(pendingTotal)} FCFA restant(s)", Left = 22, Top = 33, Width = 500, Height = 22, ForeColor = Color.White, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) });
        var viewPending = new Button { Text = "VOIR / ENCAISSER", Left = 830, Top = 10, Width = 185, Height = 42, BackColor = Color.FromArgb(255, 193, 52), ForeColor = Color.FromArgb(22, 30, 45), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        viewPending.FlatAppearance.BorderSize = 0;
        pendingCard.Controls.Add(viewPending);

        void OpenPendingDialog()
        {
            using var dlg = new Form { Text = "Seddo — À encaisser", Width = 920, Height = 560, StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(10, 22, 42), FormBorderStyle = FormBorderStyle.Sizable, MinimumSize = new Size(760, 450) };
            dlg.Controls.Add(new Label { Text = "PAIEMENTS SEDDO EN ATTENTE", Left = 24, Top = 18, Width = 800, Height = 34, ForeColor = Color.FromArgb(255, 220, 95), Font = new Font("Segoe UI", 16, FontStyle.Bold) });
            var rows = Database.GetSeddoPending(500);
            var g = new DataGridView { Left = 20, Top = 62, Width = 860, Height = 390, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right, BackgroundColor = Color.FromArgb(5, 18, 42), BorderStyle = BorderStyle.None, AllowUserToAddRows = false, ReadOnly = true, RowHeadersVisible = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect, EnableHeadersVisualStyles = false, AutoGenerateColumns = false };
            g.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 52, 90); g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White; g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            g.DefaultCellStyle.BackColor = Color.FromArgb(8, 24, 47); g.DefaultCellStyle.ForeColor = Color.White; g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(35, 90, 130); g.DefaultCellStyle.SelectionForeColor = Color.White;
            g.Columns.Add(new DataGridViewTextBoxColumn { Name = "Id", Visible = false });
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "DATE", FillWeight = 95 });
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "CLIENT", FillWeight = 150 });
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "TÉLÉPHONE", FillWeight = 100 });
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "TOTAL", FillWeight = 90 });
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "ENCAISSÉ", FillWeight = 90 });
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "RESTANT", FillWeight = 90 });
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "RÉFÉRENCE", FillWeight = 90 });
            g.Columns.Add(new DataGridViewButtonColumn { Name = "Encaisser", HeaderText = "ACTION", Text = "ENCAISSER", UseColumnTextForButtonValue = true, FillWeight = 105 });
            foreach (var r in rows) g.Rows.Add(r.Id, r.DateOperation, r.ClientNom, r.Telephone, Money(r.Total) + " FCFA", Money(r.Encaisse) + " FCFA", Money(r.Reste) + " FCFA", r.Reference);
            g.CellContentClick += (_, e) =>
            {
                if (e.RowIndex < 0 || g.Columns[e.ColumnIndex].Name != "Encaisser") return;
                var row = rows[e.RowIndex];
                using var pay = new Form { Text = "Encaisser Seddo", Width = 430, Height = 330, StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(15, 27, 48), FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false };
                pay.Controls.Add(new Label { Text = $"Client : {row.ClientNom}\r\nReste à encaisser : {Money(row.Reste)} FCFA", Left = 24, Top = 18, Width = 360, Height = 55, ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) });
                var amount = new TextBox { Left = 24, Top = 85, Width = 360, Text = row.Reste.ToString("0", System.Globalization.CultureInfo.InvariantCulture), Font = new Font("Segoe UI", 12, FontStyle.Bold) }; ApplyMoneyInputFormat(amount);
                pay.Controls.Add(new Label { Text = "Montant encaissé (FCFA)", Left = 24, Top = 64, Width = 360, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) }); pay.Controls.Add(amount);
                var modePay = new ComboBox { Left = 24, Top = 145, Width = 360, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
                modePay.Items.AddRange(new object[] { "Wave", "Orange Money", "Espèces" });
                modePay.SelectedIndex = 0;
                pay.Controls.Add(new Label { Text = "Caisse d'encaissement", Left = 24, Top = 123, Width = 360, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) }); pay.Controls.Add(modePay);
                var referencePay = new TextBox { Left = 24, Top = 205, Width = 360, Font = new Font("Segoe UI", 10) };
                pay.Controls.Add(new Label { Text = "Référence (facultatif)", Left = 24, Top = 183, Width = 360, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) }); pay.Controls.Add(referencePay);
                var ok = new Button { Text = "ENCAISSER", Left = 250, Top = 245, Width = 134, Height = 38, BackColor = Color.FromArgb(0, 190, 130), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) }; ok.FlatAppearance.BorderSize = 0; pay.Controls.Add(ok);
                ok.Click += (_, _) => { if (!decimal.TryParse(amount.Text.Replace(" ", "").Replace(".", ""), out var a) || a <= 0) { MessageBox.Show("Montant invalide.", "Seddo", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; } try { Database.AddSeddoPayment(row.Id, a, modePay.SelectedItem?.ToString() ?? "Wave", referencePay.Text.Trim()); pay.DialogResult = DialogResult.OK; pay.Close(); } catch (Exception ex) { MessageBox.Show(ex.Message, "Seddo", MessageBoxButtons.OK, MessageBoxIcon.Warning); } };
                if (pay.ShowDialog(dlg) == DialogResult.OK) { dlg.Close(); RefreshDashboard(); ShowSeddo(); }
            };
            dlg.Controls.Add(g);
            var close = new Button { Text = "FERMER", Left = 770, Top = 465, Width = 110, Height = 38, Anchor = AnchorStyles.Bottom | AnchorStyles.Right, BackColor = Color.FromArgb(45, 75, 110), ForeColor = Color.White, FlatStyle = FlatStyle.Flat }; close.FlatAppearance.BorderSize = 0; close.Click += (_, _) => dlg.Close(); dlg.Controls.Add(close);
            dlg.ShowDialog(this);
        }
        viewPending.Click += (_, _) => OpenPendingDialog();

        // Historique Seddo en bas de la page.
        var histTitle = new Label { Text = "HISTORIQUE DES OPÉRATIONS SEDDO", Left = 0, Top = 805, Width = 1040, Height = 38, TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.White, Font = new Font("Segoe UI", 16, FontStyle.Bold) };
        host.Controls.Add(histTitle);
        var histPanel = new Panel { Left = 0, Top = 850, Width = 1040, Height = 320, BackColor = Color.FromArgb(12, 27, 52) };
        histPanel.Paint += (_, e) => { using var pen = new Pen(Color.FromArgb(0, 190, 255), 2); e.Graphics.DrawRectangle(pen, 0, 0, histPanel.Width - 1, histPanel.Height - 1); };
        host.Controls.Add(histPanel);
        var grid = new DataGridView
        {
            Left = 12, Top = 12, Width = 1016, Height = 295,
            BackgroundColor = Color.FromArgb(5, 18, 42), BorderStyle = BorderStyle.None,
            AllowUserToAddRows = false, AllowUserToDeleteRows = false, ReadOnly = true,
            RowHeadersVisible = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, AutoGenerateColumns = false,
            EnableHeadersVisualStyles = false, AllowUserToResizeRows = false,
            CellBorderStyle = DataGridViewCellBorderStyle.Single, GridColor = Color.FromArgb(70, 100, 135)
        };
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 52, 90);
        grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        grid.DefaultCellStyle.BackColor = Color.FromArgb(8, 24, 47);
        grid.DefaultCellStyle.ForeColor = Color.White;
        grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(35, 90, 130);
        grid.DefaultCellStyle.SelectionForeColor = Color.White;
        void AddSeddoCol(string header, string name, float weight)
        {
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = header, Name = name, FillWeight = weight });
        }
        AddSeddoCol("DATE / HEURE", "Date", 105);
        AddSeddoCol("CLIENT", "Client", 150);
        AddSeddoCol("TÉLÉPHONE", "Telephone", 100);
        AddSeddoCol("MONTANT", "Montant", 90);
        AddSeddoCol("COMM. / TAUX", "Commission", 105);
        AddSeddoCol("TOTAL DÉBITÉ", "Total", 105);
        AddSeddoCol("RÉFÉRENCE", "Reference", 90);
        AddSeddoCol("STATUT", "Statut", 85);
        AddSeddoCol("RESTANT", "Restant", 90);
        AddSeddoCol("DESCRIPTION", "Description", 150);
        foreach (var row in Database.GetSeddoOperations(100))
        {
            var statut = row.PaiementDiffere ? (row.Reste > 0 ? "À encaisser" : "Payé") : "Payé";
            var caisseDesc = Database.GetSeddoCaisseDescription(row.Id);
            var description = row.PaiementDiffere ? row.Observation + (row.Reste > 0 ? " — paiement en attente" : " — paiement encaissé") + " — " + caisseDesc : row.Observation + " — " + caisseDesc;
            grid.Rows.Add(row.DateOperation, row.ClientNom, row.Telephone, Money(row.Montant) + " FCFA", Money(row.Commission) + " FCFA / " + row.TauxCommission.ToString("0.##") + "%", Money(row.Montant + row.Commission) + " FCFA", row.Reference, statut, Money(row.Reste) + " FCFA", description);
        }
        histPanel.Controls.Add(grid);
    }

    void ShowSamaManagement()
    {
        using var form = new Form
        {
            Text = "SAMA CAISSE — Argent confié et prêts personnels",
            Width = 1320, Height = 850, MinimumSize = new Size(1080, 720),
            StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(5, 19, 43), ForeColor = Color.White
        };
        var title = new Label { Text = "SAMA CAISSE", Left = 22, Top = 14, Width = 500, Height = 38, Font = new Font("Segoe UI", 21, FontStyle.Bold), ForeColor = Color.White };
        var subtitle = new Label { Text = "Deux listes séparées : argent confié à restituer et argent prêté à récupérer", Left = 24, Top = 53, Width = 950, Height = 24, Font = new Font("Segoe UI", 10), ForeColor = Color.FromArgb(190, 220, 245) };
        form.Controls.Add(title); form.Controls.Add(subtitle);

        Label Metric(string text, int left, int width, Color accent)
        {
            var panel = new Panel { Left = left, Top = 84, Width = width, Height = 70, BackColor = Color.FromArgb(10, 38, 70), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
            panel.Paint += (_, e) => { using var pen = new Pen(accent, 2); e.Graphics.DrawRectangle(pen, 1, 1, panel.Width - 3, panel.Height - 3); };
            var lab = new Label { Text = text, Dock = DockStyle.Fill, Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = Color.White, TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent, AutoEllipsis = true };
            panel.Controls.Add(lab); form.Controls.Add(panel); return lab;
        }
        var heldMetric = Metric("ARGENT CONFIÉ — RESTANT À RESTITUER\n0 FCFA", 22, 620, Color.FromArgb(0, 165, 255));
        var loanMetric = Metric("ARGENT PRÊTÉ — RESTANT À RÉCUPÉRER\n0 FCFA", 654, 620, Color.FromArgb(235, 145, 30));

        DataGridView MakeGrid()
        {
            var g = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Color.FromArgb(5, 19, 43), ForeColor = Color.White, BorderStyle = BorderStyle.None, ReadOnly = true,
                AllowUserToAddRows = false, AllowUserToDeleteRows = false, RowHeadersVisible = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, EnableHeadersVisualStyles = false, GridColor = Color.FromArgb(35, 75, 115), RowTemplate = { Height = 32 } };
            g.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 90, 155); g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White; g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            g.DefaultCellStyle.BackColor = Color.FromArgb(7, 28, 55); g.DefaultCellStyle.ForeColor = Color.White; g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 105, 180); g.DefaultCellStyle.SelectionForeColor = Color.White;
            return g;
        }
        var tabs = new TabControl { Left = 22, Top = 168, Width = 1258, Height = 620, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right, Font = new Font("Segoe UI", 10, FontStyle.Bold), DrawMode = TabDrawMode.OwnerDrawFixed, ItemSize = new Size(300, 44), SizeMode = TabSizeMode.Fixed };
        tabs.DrawItem += (_, e) =>
        {
            bool selected = e.Index == tabs.SelectedIndex;
            var isHeld = e.Index == 0;
            var bg = selected ? (isHeld ? Color.FromArgb(0, 125, 220) : Color.FromArgb(205, 125, 20)) : Color.FromArgb(10, 38, 70);
            var border = isHeld ? Color.FromArgb(0, 190, 255) : Color.FromArgb(255, 175, 55);
            using var brush = new SolidBrush(bg); using var pen = new Pen(border, selected ? 2.5f : 1.2f);
            var rect = e.Bounds; rect.Inflate(-3, -3); e.Graphics.FillRectangle(brush, rect); e.Graphics.DrawRectangle(pen, rect);
            var label = isHeld ? "ARGENT CONFIÉ PAR LES CLIENTS" : "ARGENT PRÊTÉ AUX CLIENTS";
            TextRenderer.DrawText(e.Graphics, label, new Font("Segoe UI", 10, FontStyle.Bold), rect, Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        };
        var heldTab = new TabPage("") { BackColor = Color.FromArgb(5, 19, 43), ForeColor = Color.White };
        var loansTab = new TabPage("") { BackColor = Color.FromArgb(5, 19, 43), ForeColor = Color.White };
        var heldGrid = MakeGrid(); var loansGrid = MakeGrid();
        heldGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "ClientId", Visible = false });
        foreach (var c in new[] { ("Nom", "Client"), ("Telephone", "Téléphone"), ("Confie", "Total confié"), ("Restitue", "Total restitué"), ("Reste", "Reste à restituer"), ("Dernier", "Dernière opération") }) heldGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = c.Item1, HeaderText = c.Item2 });
        loansGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "ClientId", Visible = false });
        foreach (var c in new[] { ("Nom", "Client"), ("Telephone", "Téléphone"), ("Prete", "Total prêté"), ("Rembourse", "Total remboursé"), ("Reste", "Reste à récupérer"), ("Dernier", "Dernière opération (date/heure)"), ("Echeance", "Échéance") }) loansGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = c.Item1, HeaderText = c.Item2 });

        Button Act(string text, int left, int top, int width, Color color, Action callback)
        {
            var b = new Button { Text = text, Left = left, Top = top, Width = width, Height = 36, BackColor = color, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), Cursor = Cursors.Hand };
            b.FlatAppearance.BorderSize = 0; b.Click += (_, _) => callback(); return b;
        }
        var heldTools = new Panel { Dock = DockStyle.Top, Height = 46, BackColor = Color.FromArgb(5, 19, 43) };
        var loanTools = new Panel { Dock = DockStyle.Top, Height = 46, BackColor = Color.FromArgb(5, 19, 43) };
        heldTools.Controls.Add(Act("+ DÉPÔT CLIENT", 6, 5, 150, Color.FromArgb(0,145,85), () => Entrusted(true)));
        heldTools.Controls.Add(Act("RESTITUER LE CLIENT SÉLECTIONNÉ", 164, 5, 245, Color.FromArgb(205,55,55), () => SelectedHeldAction()));
        heldTools.Controls.Add(Act("HISTORIQUE DÉTAILLÉ", 420, 5, 175, Color.FromArgb(95,75,150), () => ShowSamaHistory(true)));
        heldTools.Controls.Add(Act("IMPRIMER", 830, 5, 120, Color.FromArgb(30,105,175), () => PrintSamaGrid(heldGrid, "Rapport — Argent confié")));
        heldTools.Controls.Add(Act("PDF", 958, 5, 100, Color.FromArgb(220,145,25), () => SaveSamaGridPdf(heldGrid, "Rapport — Argent confié")));
        heldTools.Controls.Add(Act("ACTUALISER", 1066, 5, 130, Color.FromArgb(75,95,120), Refresh));
        loanTools.Controls.Add(Act("+ ACCORDER UN PRÊT", 6, 5, 165, Color.FromArgb(205,125,20), () => Loan()));
        loanTools.Controls.Add(Act("REMBOURSEMENT DU CLIENT SÉLECTIONNÉ", 179, 5, 275, Color.FromArgb(0,135,105), () => SelectedLoanAction()));
        loanTools.Controls.Add(Act("HISTORIQUE DÉTAILLÉ", 465, 5, 175, Color.FromArgb(95,75,150), () => ShowSamaHistory(false)));
        loanTools.Controls.Add(Act("IMPRIMER", 830, 5, 120, Color.FromArgb(30,105,175), () => PrintSamaGrid(loansGrid, "Rapport — Argent prêté")));
        loanTools.Controls.Add(Act("PDF", 958, 5, 100, Color.FromArgb(220,145,25), () => SaveSamaGridPdf(loansGrid, "Rapport — Argent prêté")));
        loanTools.Controls.Add(Act("ACTUALISER", 1066, 5, 130, Color.FromArgb(75,95,120), Refresh));
        heldTab.Controls.Add(heldGrid); heldTab.Controls.Add(heldTools); loansTab.Controls.Add(loansGrid); loansTab.Controls.Add(loanTools);
        tabs.TabPages.Add(heldTab); tabs.TabPages.Add(loansTab); form.Controls.Add(tabs);

        void Refresh()
        {
            var sums = Database.GetSamaSummary();
            heldMetric.Text = $"ARGENT CONFIÉ — RESTANT À RESTITUER\n{Money(sums.ArgentConfie)} FCFA";
            loanMetric.Text = $"ARGENT PRÊTÉ — RESTANT À RÉCUPÉRER\n{Money(sums.PretsRestants)} FCFA";
            heldGrid.Rows.Clear();
            foreach (var r in Database.GetSamaEntrustedBalances().Where(x => x.Reste > 0.0001m))
            {
                var idx = heldGrid.Rows.Add(r.ClientId, r.Nom, r.Telephone, Money(r.MontantInitial) + " FCFA", Money(r.MontantRembourse) + " FCFA", Money(r.Reste) + " FCFA", r.DerniereOperation);
                heldGrid.Rows[idx].DefaultCellStyle.ForeColor = r.Reste > 0 ? Color.White : Color.FromArgb(155,175,195);
            }
            loansGrid.Rows.Clear();
            foreach (var r in Database.GetSamaLoanBalances().Where(x => x.Reste > 0.0001m))
            {
                var idx = loansGrid.Rows.Add(r.ClientId, r.Nom, r.Telephone, Money(r.MontantInitial) + " FCFA", Money(r.MontantRembourse) + " FCFA", Money(r.Reste) + " FCFA", r.DerniereOperation, r.ProchaineEcheance);
                loansGrid.Rows[idx].DefaultCellStyle.ForeColor = r.Reste > 0 ? Color.White : Color.FromArgb(155,175,195);
            }
        }
        void SelectedHeldAction()
        {
            if (heldGrid.CurrentRow == null) { MessageBox.Show("Sélectionne d'abord le client dans la liste.", "SAMA CAISSE"); return; }
            var id = Convert.ToInt64(heldGrid.CurrentRow.Cells["ClientId"].Value);
            var client = Database.GetSamaClientById(id);
            if (client == null) return;
            if (Convert.ToDecimal(heldGrid.CurrentRow.Cells["Reste"].Value.ToString()!.Replace(" FCFA", "").Replace(" ", "")) <= 0) { MessageBox.Show("Ce client n'a plus d'argent à restituer.", "SAMA CAISSE"); return; }
            Entrusted(false, client.Nom, client.Telephone);
        }
        void SelectedLoanAction()
        {
            if (loansGrid.CurrentRow == null) { MessageBox.Show("Sélectionne d'abord le client dans la liste.", "SAMA CAISSE"); return; }
            var id = Convert.ToInt64(loansGrid.CurrentRow.Cells["ClientId"].Value);
            if (Convert.ToDecimal(loansGrid.CurrentRow.Cells["Reste"].Value.ToString()!.Replace(" FCFA", "").Replace(" ", "")) <= 0) { MessageBox.Show("Ce client n'a plus de prêt à rembourser.", "SAMA CAISSE"); return; }
            Repayment(id);
        }

        void Entrusted(bool depot, string presetName = "", string presetPhone = "")
        {
            using var d = new Form { Text = depot ? "Dépôt — argent confié" : "Restitution — argent client", Width = 590, Height = 470, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, BackColor = Color.White };
            var name = new TextBox { Left = 190, Top = 28, Width = 330, PlaceholderText = "Nom complet du client", Text = presetName, ReadOnly = !depot && !string.IsNullOrWhiteSpace(presetName) };
            var phone = new TextBox { Left = 190, Top = 78, Width = 330, PlaceholderText = "Téléphone (facultatif)", Text = presetPhone, ReadOnly = !depot && !string.IsNullOrWhiteSpace(presetName) };
            var amount = new TextBox { Left = 190, Top = 128, Width = 330, PlaceholderText = "Montant en FCFA" }; ApplyMoneyInputFormat(amount);
            var motif = new TextBox { Left = 190, Top = 178, Width = 330, PlaceholderText = "Motif (facultatif)" };
            var reference = new TextBox { Left = 190, Top = 228, Width = 330, PlaceholderText = "Référence (facultative)" };
            d.Controls.Add(new Label { Text = "Nom complet *", Left = 28, Top = 32, Width = 150 }); d.Controls.Add(name); d.Controls.Add(new Label { Text = "Téléphone", Left = 28, Top = 82, Width = 150 }); d.Controls.Add(phone); d.Controls.Add(new Label { Text = "Montant", Left = 28, Top = 132, Width = 150 }); d.Controls.Add(amount); d.Controls.Add(new Label { Text = "Motif", Left = 28, Top = 182, Width = 150 }); d.Controls.Add(motif); d.Controls.Add(new Label { Text = "Référence", Left = 28, Top = 232, Width = 150 }); d.Controls.Add(reference);
            var save = new Button { Text = depot ? "ENREGISTRER LE DÉPÔT" : "ENREGISTRER LA RESTITUTION", Left = 190, Top = 292, Width = 270, Height = 42, BackColor = depot ? Color.FromArgb(0, 150, 85) : Color.FromArgb(210, 55, 55), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            save.Click += (_, _) => { if (string.IsNullOrWhiteSpace(name.Text) || !TryMoney(amount.Text, out var m) || m <= 0) { MessageBox.Show("Saisis le nom du client et un montant valide.", "SAMA CAISSE"); return; } try { long clientId; if (depot) clientId = Database.FindOrCreateSamaClient(name.Text, phone.Text); else { clientId = Database.FindSamaClient(name.Text, phone.Text); if (clientId == 0) { MessageBox.Show("Client introuvable dans la liste.", "SAMA CAISSE"); return; } } Database.RecordSamaEntrustedMovement(clientId, m, depot, motif.Text, reference.Text); d.DialogResult = DialogResult.OK; d.Close(); } catch (Exception ex) { MessageBox.Show(ex.Message, "SAMA CAISSE"); } };
            d.Controls.Add(save); d.ShowDialog(form); Refresh();
        }
        void Loan()
        {
            using var d = new Form { Text = "Accorder un prêt personnel", Width = 610, Height = 500, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, BackColor = Color.White };
            var name = new TextBox { Left = 205, Top = 28, Width = 340, PlaceholderText = "Nom complet du client" }; var phone = new TextBox { Left = 205, Top = 78, Width = 340, PlaceholderText = "Téléphone (facultatif)" }; var amount = new TextBox { Left = 205, Top = 128, Width = 340, PlaceholderText = "Montant en FCFA" }; ApplyMoneyInputFormat(amount);
            var due = new DateTimePicker { Left = 205, Top = 178, Width = 220, Format = DateTimePickerFormat.Short, ShowCheckBox = true, Checked = false }; var motif = new TextBox { Left = 205, Top = 228, Width = 340, PlaceholderText = "Motif (facultatif)" }; var reference = new TextBox { Left = 205, Top = 278, Width = 340, PlaceholderText = "Référence (facultative)" };
            d.Controls.Add(new Label { Text = "Nom complet *", Left = 28, Top = 32, Width = 165 }); d.Controls.Add(name); d.Controls.Add(new Label { Text = "Téléphone", Left = 28, Top = 82, Width = 165 }); d.Controls.Add(phone); d.Controls.Add(new Label { Text = "Montant", Left = 28, Top = 132, Width = 165 }); d.Controls.Add(amount); d.Controls.Add(new Label { Text = "Échéance (facultative)", Left = 28, Top = 182, Width = 165 }); d.Controls.Add(due); d.Controls.Add(new Label { Text = "Motif", Left = 28, Top = 232, Width = 165 }); d.Controls.Add(motif); d.Controls.Add(new Label { Text = "Référence", Left = 28, Top = 282, Width = 165 }); d.Controls.Add(reference);
            var save = new Button { Text = "CONFIRMER LE PRÊT", Left = 205, Top = 338, Width = 230, Height = 40, BackColor = Color.FromArgb(210, 125, 20), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            save.Click += (_, _) => { if (string.IsNullOrWhiteSpace(name.Text) || !TryMoney(amount.Text, out var m) || m <= 0) { MessageBox.Show("Saisis le nom du client et un montant valide.", "SAMA CAISSE"); return; } try { var clientId = Database.FindOrCreateSamaClient(name.Text, phone.Text); Database.RecordSamaLoan(clientId, m, due.Checked ? due.Value.Date : null, motif.Text, reference.Text); d.DialogResult = DialogResult.OK; d.Close(); } catch (Exception ex) { MessageBox.Show(ex.Message, "SAMA CAISSE"); } };
            d.Controls.Add(save); d.ShowDialog(form); Refresh();
        }
        void Repayment(long clientId = 0)
        {
            var loans = Database.GetSamaOpenLoans(clientId); if (loans.Count == 0) { MessageBox.Show("Aucun prêt en attente de remboursement pour ce client.", "SAMA CAISSE"); return; }
            using var d = new Form { Text = "Encaisser un remboursement de prêt", Width = 650, Height = 410, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, BackColor = Color.White };
            var options = loans.Select(l => new { l.Id, Label = $"{l.ClientNom} — reste {Money(l.MontantRestant)} FCFA — prêt du {(DateTime.TryParse(l.DateOperation, out var dt) ? dt.ToString("dd/MM/yyyy") : l.DateOperation)}" }).ToList();
            var loan = new ComboBox { Left = 210, Top = 32, Width = 390, DropDownStyle = ComboBoxStyle.DropDownList, DataSource = options, DisplayMember = "Label", ValueMember = "Id" }; var amount = new TextBox { Left = 210, Top = 88, Width = 390, PlaceholderText = "Montant remboursé en FCFA" }; ApplyMoneyInputFormat(amount); var motif = new TextBox { Left = 210, Top = 140, Width = 390 }; var reference = new TextBox { Left = 210, Top = 192, Width = 390 };
            d.Controls.Add(new Label { Text = "Prêt concerné", Left = 28, Top = 36, Width = 170 }); d.Controls.Add(loan); d.Controls.Add(new Label { Text = "Montant reçu", Left = 28, Top = 92, Width = 170 }); d.Controls.Add(amount); d.Controls.Add(new Label { Text = "Motif", Left = 28, Top = 144, Width = 170 }); d.Controls.Add(motif); d.Controls.Add(new Label { Text = "Référence", Left = 28, Top = 196, Width = 170 }); d.Controls.Add(reference);
            var save = new Button { Text = "ENREGISTRER LE REMBOURSEMENT", Left = 210, Top = 250, Width = 280, Height = 40, BackColor = Color.FromArgb(0, 145, 105), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            save.Click += (_, _) => { if (loan.SelectedValue == null || !TryMoney(amount.Text, out var m) || m <= 0) { MessageBox.Show("Choisis un prêt et saisis un montant valide.", "SAMA CAISSE"); return; } try { Database.RecordSamaRepayment(Convert.ToInt64(loan.SelectedValue), m, motif.Text, reference.Text); d.DialogResult = DialogResult.OK; d.Close(); } catch (Exception ex) { MessageBox.Show(ex.Message, "SAMA CAISSE"); } }; d.Controls.Add(save); d.ShowDialog(form); Refresh();
        }
        heldGrid.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) SelectedHeldAction(); };
        loansGrid.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) SelectedLoanAction(); };

        void ShowSamaHistory(bool entrusted)
        {
            var historyForm = new Form { Text = entrusted ? "Historique — argent confié et restitué" : "Historique — prêts et remboursements", Width = 1280, Height = 740, MinimumSize = new Size(980, 600), StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(5, 19, 43), ForeColor = Color.White };
            var filterPanel = new Panel { Dock = DockStyle.Top, Height = 100, BackColor = Color.FromArgb(8, 32, 60), Padding = new Padding(10) };
            var search = new TextBox { Left = 12, Top = 27, Width = 260, PlaceholderText = "Rechercher prénom, nom, téléphone, référence…" };
            var dateFrom = new DateTimePicker { Left = 285, Top = 27, Width = 145, Format = DateTimePickerFormat.Short, ShowCheckBox = true, Checked = false };
            var dateTo = new DateTimePicker { Left = 440, Top = 27, Width = 145, Format = DateTimePickerFormat.Short, ShowCheckBox = true, Checked = false };
            var operation = new ComboBox { Left = 595, Top = 27, Width = 190, DropDownStyle = ComboBoxStyle.DropDownList };
            operation.Items.Add("Toutes les opérations");
            if (entrusted) operation.Items.AddRange(new object[] { "Dépôt client", "Restitution client" }); else operation.Items.AddRange(new object[] { "Prêt accordé", "Remboursement prêt" });
            operation.SelectedIndex = 0;
            var apply = new Button { Text = "RECHERCHER", Left = 795, Top = 24, Width = 125, Height = 32, BackColor = Color.FromArgb(0, 130, 180), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            var clear = new Button { Text = "EFFACER FILTRES", Left = 928, Top = 24, Width = 135, Height = 32, BackColor = Color.FromArgb(80, 95, 115), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            filterPanel.Controls.AddRange(new Control[] { search, dateFrom, dateTo, operation, apply, clear });
            foreach (var item in new[] { ("Recherche client / référence", 12, 260), ("Date début", 285, 145), ("Date fin", 440, 145), ("Type", 595, 190) }) filterPanel.Controls.Add(new Label { Text = item.Item1, Left = item.Item2, Top = 7, Width = item.Item3, ForeColor = Color.White });
            filterPanel.Controls.Add(new Label { Text = "L’impression et le PDF reprennent les résultats filtrés. Pour imprimer un seul client, sélectionne une de ses lignes.", Left = 14, Top = 66, Width = 1160, Height = 22, ForeColor = Color.FromArgb(190, 220, 245), Font = new Font("Segoe UI", 8.5f) });

            var history = MakeGrid(); history.Dock = DockStyle.Fill;
            history.Columns.Add(new DataGridViewTextBoxColumn { Name = "DateHeure", HeaderText = "Date et heure" });
            history.Columns.Add(new DataGridViewTextBoxColumn { Name = "Client", HeaderText = "Client" });
            history.Columns.Add(new DataGridViewTextBoxColumn { Name = "Operation", HeaderText = "Opération" });
            history.Columns.Add(new DataGridViewTextBoxColumn { Name = "Montant", HeaderText = "Montant (FCFA)" });
            history.Columns.Add(new DataGridViewTextBoxColumn { Name = "Motif", HeaderText = "Description / motif" });
            history.Columns.Add(new DataGridViewTextBoxColumn { Name = "Reference", HeaderText = "Référence" });
            var allRows = Database.GetSamaTransactions(2000).Where(t => entrusted ? (t.TypeOperation == "Dépôt client" || t.TypeOperation == "Restitution client") : (t.TypeOperation == "Prêt accordé" || t.TypeOperation == "Remboursement prêt")).ToList();
            void ApplyFilters()
            {
                history.Rows.Clear(); var term = search.Text.Trim();
                foreach (var t in allRows)
                {
                    if (operation.SelectedIndex > 0 && t.TypeOperation != Convert.ToString(operation.SelectedItem)) continue;
                    if (DateTime.TryParse(t.DateOperation, out var dt)) { if (dateFrom.Checked && dt.Date < dateFrom.Value.Date) continue; if (dateTo.Checked && dt.Date > dateTo.Value.Date) continue; }
                    else if (dateFrom.Checked || dateTo.Checked) continue;
                    var searchable = $"{t.ClientNom} {t.TypeOperation} {t.Motif} {t.Reference} {t.DateOperation}";
                    if (!string.IsNullOrWhiteSpace(term) && !searchable.Contains(term, StringComparison.CurrentCultureIgnoreCase)) continue;
                    var date = DateTime.TryParse(t.DateOperation, out var parsed) ? parsed.ToString("dd/MM/yyyy HH:mm:ss") : t.DateOperation;
                    var idx = history.Rows.Add(date, t.ClientNom, t.TypeOperation, Money(t.Montant), t.Motif, t.Reference);
                    history.Rows[idx].DefaultCellStyle.ForeColor = t.TypeOperation == "Restitution client" || t.TypeOperation == "Remboursement prêt" ? Color.FromArgb(120, 225, 175) : Color.White;
                }
            }
            apply.Click += (_, _) => ApplyFilters(); search.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { ApplyFilters(); e.SuppressKeyPress = true; } };
            clear.Click += (_, _) => { search.Clear(); dateFrom.Checked = false; dateTo.Checked = false; operation.SelectedIndex = 0; ApplyFilters(); };
            var bar = new Panel { Dock = DockStyle.Bottom, Height = 52, BackColor = Color.FromArgb(8, 32, 60) };
            var print = new Button { Text = "IMPRIMER", Left = 12, Top = 8, Width = 130, Height = 36, BackColor = Color.FromArgb(30,105,175), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            var pdf = new Button { Text = "EXPORTER PDF", Left = 152, Top = 8, Width = 150, Height = 36, BackColor = Color.FromArgb(220,145,25), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            var clientPrint = new Button { Text = "IMPRIMER PAR CLIENT", Left = 312, Top = 8, Width = 205, Height = 36, BackColor = Color.FromArgb(0, 135, 105), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            print.Click += (_, _) => PrintSamaGrid(history, entrusted ? "Historique détaillé — argent confié et restitué" : "Historique détaillé — prêts et remboursements");
            pdf.Click += (_, _) => SaveSamaGridPdf(history, entrusted ? "Historique détaillé — argent confié et restitué" : "Historique détaillé — prêts et remboursements");
            clientPrint.Click += (_, _) =>
            {
                var name = history.CurrentRow?.Cells["Client"].Value?.ToString();
                if (string.IsNullOrWhiteSpace(name)) { MessageBox.Show("Sélectionne une ligne du client à imprimer.", "Impression par client"); return; }
                using var filtered = MakeGrid(); foreach (DataGridViewColumn col in history.Columns) filtered.Columns.Add(new DataGridViewTextBoxColumn { Name = col.Name, HeaderText = col.HeaderText, Width = col.Width });
                foreach (DataGridViewRow row in history.Rows) if (!row.IsNewRow && string.Equals(Convert.ToString(row.Cells["Client"].Value), name, StringComparison.CurrentCultureIgnoreCase)) filtered.Rows.Add(row.Cells.Cast<DataGridViewCell>().Select(c => c.Value).ToArray());
                PrintSamaGrid(filtered, (entrusted ? "Historique client — argent confié/restitué — " : "Historique client — prêts/remboursements — ") + name);
            };
            bar.Controls.AddRange(new Control[] { print, pdf, clientPrint }); historyForm.Controls.Add(history); historyForm.Controls.Add(bar); historyForm.Controls.Add(filterPanel); ApplyFilters(); historyForm.ShowDialog(form);
        }

        void PrintSamaGrid(DataGridView g, string reportTitle)
        {
            using var doc = new PrintDocument(); doc.DocumentName = reportTitle; doc.DefaultPageSettings.Landscape = true; doc.DefaultPageSettings.Margins = new Margins(35,35,45,45);
            int page = 0; const int perPage = 20;
            doc.PrintPage += (_, e) => { RenderSamaGridReport(e.Graphics!, e.MarginBounds, g, reportTitle, page, perPage); page++; e.HasMorePages = page * perPage < g.Rows.Cast<DataGridViewRow>().Count(r => !r.IsNewRow); };
            using var pd = new PrintDialog { Document = doc, UseEXDialog = true }; if (pd.ShowDialog(form) == DialogResult.OK) doc.Print();
        }
        void SaveSamaGridPdf(DataGridView g, string reportTitle)
        {
            using var dlg = new SaveFileDialog { Title = "Enregistrer le rapport PDF", Filter = "Document PDF (*.pdf)|*.pdf", FileName = (reportTitle.Replace(" ", "_").Replace("—", "-") + "_" + DateTime.Now.ToString("yyyyMMdd") + ".pdf"), AddExtension = true, DefaultExt = "pdf" };
            if (dlg.ShowDialog(form) != DialogResult.OK) return;
            const int perPage = 20; int count = g.Rows.Cast<DataGridViewRow>().Count(r => !r.IsNewRow); int pages = Math.Max(1, (int)Math.Ceiling(count / (double)perPage)); var images = new List<byte[]>();
            for (int page = 0; page < pages; page++) { using var bmp = new Bitmap(1600, 1100); using (var gr = Graphics.FromImage(bmp)) RenderSamaGridReport(gr, new Rectangle(55,45,1490,1010), g, reportTitle, page, perPage); images.Add(BitmapToJpeg(bmp)); }
            WriteJpegPagesPdf(dlg.FileName, images);
        }
        Refresh(); form.ShowDialog(this);
    }

    void RenderSamaGridReport(Graphics g, Rectangle bounds, DataGridView grid, string reportTitle, int pageIndex = 0, int perPage = 20)
    {
        g.Clear(Color.White); using var navy = new SolidBrush(Color.FromArgb(16,43,79)); using var blue = new SolidBrush(Color.FromArgb(28,83,145)); using var gray = new SolidBrush(Color.FromArgb(90,100,115)); using var pen = new Pen(Color.FromArgb(205,213,223));
        using var company = new Font("Segoe UI", 20, FontStyle.Bold); using var title = new Font("Segoe UI", 16, FontStyle.Bold); using var header = new Font("Segoe UI", 9, FontStyle.Bold); using var body = new Font("Segoe UI", 9);
        g.FillRectangle(navy,bounds.Left,bounds.Top,bounds.Width,66); g.DrawString("Sankhe & Frères",company,Brushes.White,bounds.Left+16,bounds.Top+8); g.DrawString("SAMA CAISSE • RAPPORT DE SUIVI",body,Brushes.White,bounds.Left+18,bounds.Top+42);
        float y=bounds.Top+82; g.DrawString(reportTitle,title,navy,bounds.Left,y); y+=34; g.DrawString("Édité le : "+DateTime.Now.ToString("dd/MM/yyyy HH:mm"),body,gray,bounds.Left,y); y+=30;
        var cols=grid.Columns.Cast<DataGridViewColumn>().Where(c=>c.Visible).ToList(); float totalW=bounds.Width; float cw=totalW/Math.Max(1,cols.Count); float x=bounds.Left; float rh=34;
        foreach(var col in cols){g.FillRectangle(blue,x,y,cw,rh);g.DrawRectangle(Pens.White,x,y,cw,rh);g.DrawString(col.HeaderText,header,Brushes.White,new RectangleF(x+4,y+2,cw-8,rh-4),new StringFormat{Alignment=StringAlignment.Center,LineAlignment=StringAlignment.Center,Trimming=StringTrimming.EllipsisCharacter});x+=cw;} y+=rh;
        var visibleRows = grid.Rows.Cast<DataGridViewRow>().Where(r => !r.IsNewRow).Skip(pageIndex * perPage).Take(perPage).ToList();
        foreach(DataGridViewRow row in visibleRows){x=bounds.Left;foreach(var col in cols){g.DrawRectangle(pen,x,y,cw,rh);var value=Convert.ToString(row.Cells[col.Index].FormattedValue)??"";g.DrawString(value,body,Brushes.Black,new RectangleF(x+5,y+2,cw-10,rh-4),new StringFormat{LineAlignment=StringAlignment.Center,Trimming=StringTrimming.EllipsisCharacter});x+=cw;}y+=rh;}
        y=Math.Min(y+18,bounds.Bottom-28);g.DrawString("Nombre de clients : "+grid.Rows.Cast<DataGridViewRow>().Count(r=>!r.IsNewRow)+$"    •    Page {pageIndex+1}",header,navy,bounds.Left,y);
    }

    void ShowCaisse()
    {
        // V223 : menu Caisse épuré — cartes et synthèse conservées, historique global retiré de cette page.
        ClearContent();
        // V229 : désactive le fond animé sur la page Caisse pour éviter les flashs/sursauts.
        content.Paint -= DrawAnimatedBackground;
        content.BackColor = Color.FromArgb(2, 12, 35);
        EnableDoubleBuffer(content);
        content.AutoScroll = true;
        content.Padding = new Padding(24, 78, 24, 24);

        var host = CreatePageHost(1580);
        EnableDoubleBuffer(host);
        host.Height = Math.Max(900, content.ClientSize.Height - 18);
        content.Controls.Add(host);

        var title = Heading("Caisse");
        title.Font = new Font("Segoe UI", 25, FontStyle.Bold);
        title.Location = new Point(0, 0);
        host.Controls.Add(title);

        host.Controls.Add(new Label
        {
            Text = "Gérez les différentes caisses de votre service • les soldes sont indépendants et clairement séparés.",
            AutoSize = true, Left = 2, Top = 43,
            ForeColor = Color.FromArgb(205, 225, 245), Font = new Font("Segoe UI", 10)
        });

        var virementsButton = new Button
        {
            Text = "⇄  VIREMENTS ENTRE CAISSES", Width = 245, Height = 38,
            Left = host.Width - 520, Top = 34, Anchor = AnchorStyles.Top | AnchorStyles.Right,
            BackColor = Color.FromArgb(124, 58, 237), ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold), Cursor = Cursors.Hand
        };
        virementsButton.FlatAppearance.BorderSize = 0;
        host.Controls.Add(virementsButton);
        var samaManagerButton = new Button
        {
            Text = "SAMA CAISSE • CLIENTS & PRÊTS", Width = 255, Height = 38,
            Left = host.Width - 265, Top = 34, Anchor = AnchorStyles.Top | AnchorStyles.Right,
            BackColor = Color.FromArgb(0, 145, 160), ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), Cursor = Cursors.Hand
        };
        samaManagerButton.FlatAppearance.BorderSize = 0;
        samaManagerButton.Click += (_, _) => ShowSamaManagement();
        host.Controls.Add(samaManagerButton);

        string selectedCaisse = "Caisse Wave";
        // V228 : bandeau Total général restauré en haut, dans le style d'origine.
        var totalBanner = new Panel
        {
            Left = 0, Top = 70, Width = host.Width, Height = 52,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            BackColor = Color.Transparent
        };
        totalBanner.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var path = RoundedPath(new Rectangle(0, 0, totalBanner.Width - 1, totalBanner.Height - 1), 12);
            using var bg = new System.Drawing.Drawing2D.LinearGradientBrush(totalBanner.ClientRectangle,
                Color.FromArgb(20, 22, 112, 215), Color.FromArgb(20, 0, 65, 145), 0f);
            using var pen = new Pen(Color.FromArgb(210, 0, 170, 255), 1.5f);
            e.Graphics.FillPath(bg, path); e.Graphics.DrawPath(pen, path);
        };
        host.Controls.Add(totalBanner);
        EnableDoubleBuffer(totalBanner);
        var globalTotalsLabel = new Label
        {
            Name = "globalTotalsLabel", Text = "TOTAL DES CAISSES : calcul en cours…",
            Left = 18, Top = 3, Width = host.Width - 36, Height = 27,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            ForeColor = Color.White, Font = new Font("Segoe UI", 16, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.Transparent, AutoEllipsis = true
        };
        totalBanner.Controls.Add(globalTotalsLabel);
        var globalBreakdownLabel = new Label
        {
            Name = "globalBreakdownLabel", Text = "Wave : 0 FCFA  •  Orange Money : 0 FCFA  •  Seddo : 0 FCFA  •  Espèces : 0 FCFA",
            Left = 20, Top = 29, Width = host.Width - 40, Height = 20,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            ForeColor = Color.FromArgb(205, 230, 255), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.Transparent, AutoEllipsis = true
        };
        totalBanner.Controls.Add(globalBreakdownLabel);

        var cardArea = new TableLayoutPanel
        {
            Left = 0, Top = 132, Width = host.Width, Height = 365,
            ColumnCount = 5, RowCount = 1, BackColor = Color.Transparent,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            Padding = new Padding(0)
        };
        for (int i = 0; i < 5; i++) cardArea.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20f));
        host.Controls.Add(cardArea);
        EnableDoubleBuffer(cardArea);

        var synthesisPanel = new Panel
        {
            Left = 0, Top = 510, Width = host.Width, Height = 205,
            BackColor = Color.Transparent, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };
        synthesisPanel.Paint += (_, e) => DrawGlassPanel(e.Graphics, synthesisPanel.ClientRectangle, Color.FromArgb(7, 31, 59), Color.FromArgb(0, 165, 240), 20, 235);
        host.Controls.Add(synthesisPanel);
        EnableDoubleBuffer(synthesisPanel);

        var synthTitle = new Label
        {
            Text = "▥  Les caisses journalières", Left = 20, Top = 12, Width = 500, Height = 30,
            ForeColor = Color.White, Font = new Font("Segoe UI", 13, FontStyle.Bold), BackColor = Color.Transparent
        };
        synthesisPanel.Controls.Add(synthTitle);

        var dayBadge = new Label
        {
            Text = $"Aujourd'hui • {DateTime.Now:dd/MM/yyyy}", Left = Math.Max(800, synthesisPanel.Width - 260), Top = 11,
            Width = 235, Height = 30, TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.White, BackColor = Color.FromArgb(20, 65, 105),
            Font = new Font("Segoe UI", 9, FontStyle.Bold), Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        synthesisPanel.Controls.Add(dayBadge);

        // V222 : synthèse visuelle horizontale conforme à la maquette demandée.
        var synthCards = new TableLayoutPanel
        {
            // Trois cartes journalières : Wave, Orange Money et Espèces.
            Left = 12, Top = 50, Width = synthesisPanel.Width - 24, Height = 112,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            ColumnCount = 3, RowCount = 1, BackColor = Color.Transparent,
            Margin = new Padding(0), Padding = new Padding(0),
            GrowStyle = TableLayoutPanelGrowStyle.FixedSize
        };
        for (int i = 0; i < 3; i++) synthCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333f));
        synthesisPanel.Controls.Add(synthCards);
        EnableDoubleBuffer(synthCards);

        // Le total général est affiché dans le bandeau supérieur, comme dans la mise en page d'origine.

        // V223 : l'historique global est retiré de l'écran Caisse pour libérer l'espace.
        // Les mouvements restent conservés dans la base et consultables via Journalisation / Rapports.
        // Les contrôles d'historique ci-dessous restent non affichés pour ne pas toucher à la logique existante.
        var historyPanel = new Panel
        {
            Left = 0, Top = 485, Width = host.Width, Height = Math.Max(420, host.Height - 495),
            BackColor = Color.Transparent, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
        };
        historyPanel.Paint += (_, e) => DrawGlassPanel(e.Graphics, historyPanel.ClientRectangle, Color.FromArgb(6, 24, 48), Color.FromArgb(0, 135, 220), 20, 225);
        // Ne pas ajouter historyPanel à host : la synthèse reste visible sans le tableau encombrant.

        historyPanel.Controls.Add(new Label
        {
            Text = "▤  Historique des mouvements", Left = 20, Top = 12, Width = 330, Height = 30,
            ForeColor = Color.White, Font = new Font("Segoe UI", 13, FontStyle.Bold), BackColor = Color.Transparent
        });

        var search = new TextBox
        {
            Left = Math.Max(650, historyPanel.Width - 740), Top = 9, Width = 260, Height = 32,
            PlaceholderText = "Rechercher caisse, motif, référence...",
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            Font = new Font("Segoe UI", 9.5f)
        };
        historyPanel.Controls.Add(search);

        var print = new Button
        {
            Text = "🖨  IMPRIMER", Left = Math.Max(930, historyPanel.Width - 205), Top = 8, Width = 180, Height = 34,
            BackColor = Color.FromArgb(18, 91, 168), ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 9, FontStyle.Bold), Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        print.FlatAppearance.BorderSize = 0;
        historyPanel.Controls.Add(print);

        var historyGrid = new DataGridView
        {
            Left = 16, Top = 52, Width = historyPanel.Width - 32, Height = Math.Max(290, historyPanel.Height - 105),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
            BackgroundColor = Color.FromArgb(5, 18, 42), BorderStyle = BorderStyle.None,
            AllowUserToAddRows = false, ReadOnly = true, RowHeadersVisible = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            AutoGenerateColumns = false, EnableHeadersVisualStyles = false,
            CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
            GridColor = Color.FromArgb(35, 74, 120), AllowUserToResizeRows = false,
            RowTemplate = { Height = 31 }
        };
        historyGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(18, 91, 168);
        historyGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        historyGrid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        historyGrid.ColumnHeadersHeight = 34;
        historyGrid.DefaultCellStyle.BackColor = Color.FromArgb(7, 24, 52);
        historyGrid.DefaultCellStyle.ForeColor = Color.White;
        historyGrid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 116, 205);
        historyGrid.DefaultCellStyle.SelectionForeColor = Color.White;
        AddGridColumn(historyGrid, "Date", "Date");
        AddGridColumn(historyGrid, "Heure", "Heure");
        AddGridColumn(historyGrid, "Caisse", "Caisse");
        AddGridColumn(historyGrid, "Type", "Type");
        AddGridColumn(historyGrid, "Montant", "Montant", true);
        AddGridColumn(historyGrid, "Description", "Description");
        AddGridColumn(historyGrid, "Référence", "Reference");
        historyPanel.Controls.Add(historyGrid);

        var totals = new Label
        {
            Left = 20, Top = Math.Max(350, historyPanel.Height - 48), Width = historyPanel.Width - 40, Height = 35,
            Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
            ForeColor = Color.FromArgb(220, 235, 250), Font = new Font("Segoe UI", 10, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.Transparent
        };
        historyPanel.Controls.Add(totals);

        string DbName(string display) => display switch
        {
            "Caisse en espèces" or "Caisse en espèce" or "Espèces" => "Caisse",
            "Wave" => "Caisse Wave",
            "Orange Money" => "Caisse Orange Money",
            "Seddo" => "Caisse Seddo",
            "SAMA CAISSE" => "Sama caisse",
            _ => display
        };

        void AddModernCard(string displayName, string dbName, Color accent, string iconFile, bool hasDaily)
        {
            var card = new Panel { Dock = DockStyle.Fill, Margin = new Padding(5), BackColor = Color.Transparent, Cursor = Cursors.Hand };
            card.Paint += (_, e) =>
            {
                var selected = selectedCaisse == displayName;
                var borderColor = selected ? Color.FromArgb(245, accent) : Color.FromArgb(150, accent);
                var fill1 = Color.FromArgb(20, Math.Min(255, accent.R / 2 + 8), Math.Min(255, accent.G / 2 + 18), Math.Min(255, accent.B / 2 + 35));
                var fill2 = Color.FromArgb(8, 19, 38);
                using var path = RoundedPath(new Rectangle(1, 1, card.Width - 3, card.Height - 3), 20);
                using var bg = new System.Drawing.Drawing2D.LinearGradientBrush(card.ClientRectangle, fill1, fill2, 25f);
                using var pen = new Pen(borderColor, selected ? 2.8f : 1.5f);
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.FillPath(bg, path);
                e.Graphics.DrawPath(pen, path);
                using var glow = new SolidBrush(Color.FromArgb(35, accent));
                e.Graphics.FillEllipse(glow, card.Width - 100, -28, 120, 120);
            };

            var icon = new PictureBox
            {
                Left = 14, Top = 14, Width = 76, Height = 76,
                Image = LoadAsset(iconFile), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent
            };
            card.Controls.Add(icon);

            var name = new Label
            {
                Text = displayName, Left = 100, Top = 20, Width = card.Width - 112, Height = 42,
                Font = new Font("Segoe UI", 11.5f, FontStyle.Bold), ForeColor = Color.White,
                BackColor = Color.Transparent, TextAlign = ContentAlignment.MiddleLeft,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            card.Controls.Add(name);

            var currentCaption = new Label
            {
                Text = "Solde actuel", Left = 18, Top = 101, Width = card.Width - 36, Height = 24,
                Font = new Font("Segoe UI", 10, FontStyle.Regular), ForeColor = Color.White,
                BackColor = Color.Transparent, TextAlign = ContentAlignment.MiddleCenter,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            card.Controls.Add(currentCaption);

            var current = new Label
            {
                Name = "current", Text = "0 FCFA", Left = 14, Top = 123, Width = card.Width - 28, Height = 48,
                Font = new Font("Segoe UI", 20, FontStyle.Bold), ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.FromArgb(45, 8, 28, 55),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            card.Controls.Add(current);

            var daily = new Label
            {
                Name = "daily", Text = hasDaily ? "CAISSE JOURNALIÈRE  •  0 FCFA" : "CAISSE INDÉPENDANTE",
                Left = 12, Top = 185, Width = card.Width - 24, Height = 48,
                Font = new Font("Segoe UI", 9.2f, FontStyle.Bold), ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.FromArgb(38, accent),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            card.Controls.Add(daily);

            // V240 : réintégration des actions de caisse sur toutes les cartes sauf SAMA CAISSE.
            // Chaque action sélectionne explicitement la caisse concernée avant d'ouvrir le formulaire.
            if (!string.Equals(dbName, "Sama caisse", StringComparison.OrdinalIgnoreCase))
            {
                Button MakeActionButton(string text, int left, int top, int width, Color color, Action action)
                {
                    var b = new Button
                    {
                        Text = text, Left = left, Top = top, Width = width, Height = 31,
                        BackColor = color, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                        Font = new Font("Segoe UI", 8f, FontStyle.Bold), Cursor = Cursors.Hand,
                        Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
                    };
                    b.FlatAppearance.BorderSize = 0;
                    b.Click += (_, _) => { selectedCaisse = displayName; action(); };
                    card.Controls.Add(b);
                    return b;
                }
                var actionWidth = Math.Max(78, (card.Width - 36) / 3);
                var actionLeft = 12;
                var actionTop = 244;
                var enterButton = MakeActionButton("＋ ENTRÉE", actionLeft, actionTop, actionWidth, Color.FromArgb(0, 145, 85), () => AskMovement(false, true));
                enterButton.Anchor = AnchorStyles.Top | AnchorStyles.Left;
                var outButton = MakeActionButton("− SORTIE", actionLeft + actionWidth + 4, actionTop, actionWidth, Color.FromArgb(190, 45, 55), () => AskMovement(false, false));
                outButton.Anchor = AnchorStyles.Top | AnchorStyles.Left;
                var balanceButton = MakeActionButton("MODIFIER SOLDE", actionLeft, actionTop + 39, card.Width - 24, Color.FromArgb(45, 95, 165), () => AskMovement(true, true));
                balanceButton.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            }

            void SelectCard()
            {
                selectedCaisse = displayName;
                RebuildData();
                cardArea.Invalidate(true);
            }
            card.Click += (_, _) => SelectCard();
            icon.Click += (_, _) => SelectCard();
            name.Click += (_, _) => SelectCard();

            cardArea.Controls.Add(card);
            card.Tag = dbName;

            void RefreshCard()
            {
                var sum = Database.GetCaisseSummary(DateTime.Now, dbName);
                current.Text = Money(sum.Solde);

                if (string.Equals(dbName, "Sama caisse", StringComparison.OrdinalIgnoreCase))
                {
                    // La miniature SAMA CAISSE présente les deux soldes de suivi, séparément.
                    // Ils ne remplacent pas le solde physique et ne sont pas ajoutés au total général.
                    var sama = Database.GetSamaSummary();
                    currentCaption.Text = "ARGENT CONFIÉ  •  ARGENT PRÊTÉ";
                    currentCaption.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
                    current.Text = $"CONFIÉ : {Money(sama.ArgentConfie)} FCFA\nPRÊTÉ : {Money(sama.PretsRestants)} FCFA";
                    current.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold);
                    current.Height = 52;
                    daily.Text = "SUIVI INDÉPENDANT";
                }
                else if (hasDaily)
                {
                    currentCaption.Text = "Solde actuel";
                    currentCaption.Font = new Font("Segoe UI", 10, FontStyle.Regular);
                    current.Font = new Font("Segoe UI", 20, FontStyle.Bold);
                    current.Height = 48;
                    var dailyRows = Database.GetCaisseJournaliereSummaries(DateTime.Now);
                    var ds = dailyRows.FirstOrDefault(x => x.ServiceCaisse == dbName);
                    daily.Text = $"CAISSE JOURNALIÈRE  •  {Money(ds?.SoldeActuel ?? 0)}";
                }
                else
                {
                    currentCaption.Text = "Solde actuel";
                    currentCaption.Font = new Font("Segoe UI", 10, FontStyle.Regular);
                    current.Font = new Font("Segoe UI", 20, FontStyle.Bold);
                    current.Height = 48;
                    daily.Text = "SUIVI DE LA CAISSE";
                }
            }

            RefreshCard();
            card.Tag = (Action)RefreshCard;
        }

        void RebuildCards()
        {
            cardArea.Controls.Clear();
            AddModernCard("Caisse Wave", "Caisse Wave", Color.FromArgb(0, 190, 255), "caisse_wave_icon.png", true);
            AddModernCard("Orange Money", "Caisse Orange Money", Color.FromArgb(255, 145, 35), "caisse_orange_icon.png", true);
            AddModernCard("Caisse en espèces", "Caisse", Color.FromArgb(35, 195, 95), "caisse_generale_icon.png", false);
            AddModernCard("Caisse Seddo", "Caisse Seddo", Color.FromArgb(165, 85, 230), "caisse_seddo_icon.png", false);
            AddModernCard("SAMA CAISSE", "Sama caisse", Color.FromArgb(40, 195, 200), "sama_caisse_logo.png", false);
        }

        void RebuildData()
        {
            var services = new[]
            {
                (Display:"Caisse Wave", Db:"Caisse Wave"),
                (Display:"Orange Money", Db:"Caisse Orange Money"),
                (Display:"Caisse en espèces", Db:"Caisse"),
                (Display:"Caisse Seddo", Db:"Caisse Seddo"),
                (Display:"SAMA CAISSE", Db:"Sama caisse")
            };

            synthCards.Controls.Clear();
            var summaryStyles = new[]
            {
                (Color.FromArgb(0, 125, 255), "caisse_wave_icon.png"),
                (Color.FromArgb(245, 112, 0), "caisse_orange_icon.png"),
                (Color.FromArgb(0, 165, 76), "caisse_generale_icon.png"),
                (Color.FromArgb(130, 35, 225), "caisse_seddo_icon.png"),
                (Color.FromArgb(0, 155, 170), "sama_caisse_logo.png")
            };
            decimal global = 0, totalIn = 0, totalOut = 0;
            for (int si = 0; si < services.Length; si++)
            {
                var s = services[si];
                var sum = Database.GetCaisseSummary(DateTime.Now, s.Db);
                var accent = summaryStyles[si].Item1;
                bool isDaily = s.Db == "Caisse Wave" || s.Db == "Caisse Orange Money" || s.Db == "Caisse";
                if (isDaily)
                {
                var dailySummary = Database.GetCaisseJournaliereSummaries(DateTime.Now).First(x => x.ServiceCaisse == s.Db);
                var dailyName = s.Db == "Caisse" ? "Espèces" : s.Db == "Caisse Wave" ? "Wave" : "Orange Money";
                var mini = new Panel { Dock = DockStyle.Fill, Margin = new Padding(5, 0, 5, 0), BackColor = Color.Transparent, Cursor = Cursors.Hand };
                EnableDoubleBuffer(mini);
                mini.Paint += (_, e) =>
                {
                    e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    using var path = RoundedPath(new Rectangle(1, 1, mini.Width - 3, mini.Height - 3), 12);
                    using var bg = new System.Drawing.Drawing2D.LinearGradientBrush(mini.ClientRectangle,
                        Color.FromArgb(245, Math.Min(255, accent.R + 25), Math.Min(255, accent.G + 15), Math.Min(255, accent.B + 10)),
                        Color.FromArgb(235, Math.Max(0, accent.R / 2), Math.Max(0, accent.G / 2), Math.Max(0, accent.B / 2)), 25f);
                    using var pen = new Pen(Color.FromArgb(235, accent), 1.5f);
                    e.Graphics.FillPath(bg, path); e.Graphics.DrawPath(pen, path);
                };
                var pic = new PictureBox { Left = 10, Top = 22, Width = 48, Height = 58, Image = LoadAsset(summaryStyles[si].Item2), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent };
                var nm = new Label { Text = dailyName, Left = 64, Top = 12, Width = 180, Height = 24, Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.Transparent, AutoEllipsis = true };
                var dailyCaption = new Label { Text = "TOTAL JOURNALIER", Left = 64, Top = 35, Width = 180, Height = 18, Font = new Font("Segoe UI", 7.5f, FontStyle.Bold), ForeColor = Color.FromArgb(210, 230, 250), BackColor = Color.Transparent };
                var amount = new Label { Text = Money(dailySummary.SoldeActuel) + " FCFA", Left = 64, Top = 53, Width = Math.Max(80, mini.Width - 72), Height = 35, Font = new Font("Segoe UI", 14, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.Transparent, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
                mini.Controls.Add(pic); mini.Controls.Add(nm); mini.Controls.Add(dailyCaption); mini.Controls.Add(amount); synthCards.Controls.Add(mini);
                mini.Click += (_, _) => { selectedCaisse = s.Display; ShowCaisseJournaliere(); };
                pic.Click += (_, _) => { selectedCaisse = s.Display; ShowCaisseJournaliere(); };
                nm.Click += (_, _) => { selectedCaisse = s.Display; ShowCaisseJournaliere(); };
                }
                // SAMA CAISSE reste indépendante et n'entre pas dans le total général.
                if (!string.Equals(s.Db, "Sama caisse", StringComparison.OrdinalIgnoreCase))
                {
                    global += sum.Solde;
                    totalIn += sum.Entrees;
                    totalOut += sum.Sorties;
                }
            }

            var all = new List<Database.CaisseRow>();
            foreach (var s in services) all.AddRange(Database.GetCaisseJournal(s.Db, 150));
            var q = search.Text.Trim();
            var filtered = all.OrderByDescending(x => x.DateMouvement).Where(x => string.IsNullOrWhiteSpace(q) ||
                x.ServiceCaisse.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                x.TypeMouvement.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                x.Motif.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                x.Reference.Contains(q, StringComparison.OrdinalIgnoreCase)).Take(250).ToList();

            historyGrid.Rows.Clear();
            foreach (var r in filtered)
            {
                var dt = DateTime.TryParse(r.DateMouvement, out var parsed) ? parsed : DateTime.MinValue;
                var displayCaisse = r.ServiceCaisse == "Caisse" ? "Espèces" : r.ServiceCaisse.Replace("Caisse ", "");
                var idx = historyGrid.Rows.Add(dt == DateTime.MinValue ? r.DateMouvement : dt.ToString("dd/MM/yyyy"), dt == DateTime.MinValue ? "" : dt.ToString("HH:mm:ss"), displayCaisse, r.TypeMouvement, Money(r.Montant) + " FCFA", r.Motif, r.Reference);
                var typeCell = historyGrid.Rows[idx].Cells[3];
                if (r.TypeMouvement.Contains("Entr", StringComparison.OrdinalIgnoreCase)) typeCell.Style.ForeColor = Color.FromArgb(70, 225, 130);
                else if (r.TypeMouvement.Contains("Sort", StringComparison.OrdinalIgnoreCase)) typeCell.Style.ForeColor = Color.FromArgb(255, 90, 90);
            }
            totals.Text = $"Total entrées : {Money(totalIn)} FCFA      •      Total sorties : {Money(totalOut)} FCFA      •      Solde global : {Money(global)} FCFA";
            globalTotalsLabel.Text = $"TOTAL DES CAISSES : {Money(global)} FCFA";
            var breakdown = services.Where(s => !string.Equals(s.Db, "Sama caisse", StringComparison.OrdinalIgnoreCase))
                .Select(s => (s.Display, Summary: Database.GetCaisseSummary(DateTime.Now, s.Db)))
                .ToList();
            globalBreakdownLabel.Text = string.Join("   •   ", breakdown.Select(x =>
                $"{(x.Display == "Caisse Wave" ? "Wave" : x.Display == "Orange Money" ? "Orange Money" : x.Display == "Caisse en espèces" ? "Espèces" : "Seddo")} : {Money(x.Summary.Solde)} FCFA"));
            RebuildCardsVisuals();
        }

        void RebuildCardsVisuals()
        {
            foreach (Control c in cardArea.Controls)
            {
                if (c.Tag is Action refresh) refresh();
                c.Invalidate(true);
            }
        }

        void AskMovement(bool openingMode, bool entreeMode)
        {
            var serviceCaisse = DbName(selectedCaisse);
            using var d = new Form
            {
                Text = openingMode ? $"Solde de départ — {selectedCaisse}" : entreeMode ? $"Entrée — {selectedCaisse}" : $"Sortie — {selectedCaisse}",
                Width = 540, Height = 330, StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, BackColor = Color.White
            };
            var amount = new TextBox { Left = 200, Top = 34, Width = 250, PlaceholderText = "Montant FCFA" }; ApplyMoneyInputFormat(amount);
            if (openingMode)
            {
                var actuel = Database.GetCaisseOpeningToday(serviceCaisse);
                if (actuel > 0) amount.Text = actuel.ToString("0.##");
            }
            var motif = new TextBox { Left = 200, Top = 84, Width = 250, PlaceholderText = openingMode ? "Ex. argent disponible au début de journée" : "Motif" };
            var reference = new TextBox { Left = 200, Top = 134, Width = 250, PlaceholderText = "Référence (facultatif)" };
            d.Controls.Add(new Label { Text = "Montant", Left = 30, Top = 38, Width = 160 }); d.Controls.Add(amount);
            d.Controls.Add(new Label { Text = "Motif", Left = 30, Top = 88, Width = 160 }); d.Controls.Add(motif);
            d.Controls.Add(new Label { Text = "Référence", Left = 30, Top = 138, Width = 160 }); d.Controls.Add(reference);
            var ok = new Button { Text = openingMode ? "ENREGISTRER" : "VALIDER", Left = 200, Top = 195, Width = 120, Height = 38, BackColor = openingMode ? Color.FromArgb(37,99,235) : entreeMode ? Color.FromArgb(0,166,81) : Color.FromArgb(220,38,38), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            ok.FlatAppearance.BorderSize = 0;
            ok.Click += (_, _) =>
            {
                if (!TryMoney(amount.Text, out var m) || m <= 0) { MessageBox.Show("Saisissez un montant valide.", "SANKHÉ"); return; }
                try
                {
                    if (openingMode) Database.SetCaisseOpening(m, motif.Text, serviceCaisse);
                    else Database.AddCaisseMovement(m, entreeMode, motif.Text, reference.Text, serviceCaisse);
                    d.DialogResult = DialogResult.OK; d.Close();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "SANKHÉ — Caisse", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            };
            d.Controls.Add(ok);
            d.ShowDialog(this);
            RebuildData();
        }

        void OpenCaisseTransferDialog()
        {
            var caisses = new[]
            {
                (Display: "Caisse Wave", Db: "Caisse Wave"),
                (Display: "Orange Money", Db: "Caisse Orange Money"),
                (Display: "Caisse en espèces", Db: "Caisse"),
                (Display: "Caisse Seddo", Db: "Caisse Seddo")
            };
            using var d = new Form
            {
                Text = "Virement entre caisses", Width = 560, Height = 390,
                StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false, MinimizeBox = false, BackColor = Color.White
            };
            var source = new ComboBox { Left = 205, Top = 35, Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            var destination = new ComboBox { Left = 205, Top = 88, Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            source.Items.AddRange(caisses.Select(x => x.Display).Cast<object>().ToArray());
            destination.Items.AddRange(caisses.Select(x => x.Display).Cast<object>().ToArray());
            source.SelectedIndex = 0; destination.SelectedIndex = 1;
            var amount = new TextBox { Left = 205, Top = 141, Width = 300, PlaceholderText = "Montant en FCFA" }; ApplyMoneyInputFormat(amount);
            var motif = new TextBox { Left = 205, Top = 194, Width = 300, PlaceholderText = "Motif (facultatif)" };
            var reference = new TextBox { Left = 205, Top = 247, Width = 300, PlaceholderText = "Référence (facultative)" };
            d.Controls.Add(new Label { Text = "Caisse source", Left = 30, Top = 39, Width = 160 }); d.Controls.Add(source);
            d.Controls.Add(new Label { Text = "Caisse destinataire", Left = 30, Top = 92, Width = 160 }); d.Controls.Add(destination);
            d.Controls.Add(new Label { Text = "Montant", Left = 30, Top = 145, Width = 160 }); d.Controls.Add(amount);
            d.Controls.Add(new Label { Text = "Motif", Left = 30, Top = 198, Width = 160 }); d.Controls.Add(motif);
            d.Controls.Add(new Label { Text = "Référence", Left = 30, Top = 251, Width = 160 }); d.Controls.Add(reference);
            var save = new Button { Text = "VALIDER LE VIREMENT", Left = 205, Top = 298, Width = 190, Height = 38, BackColor = Color.FromArgb(124, 58, 237), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
            save.FlatAppearance.BorderSize = 0;
            save.Click += (_, _) =>
            {
                if (source.SelectedIndex < 0 || destination.SelectedIndex < 0) { MessageBox.Show("Choisissez les deux caisses.", "SANKHÉ"); return; }
                if (source.SelectedIndex == destination.SelectedIndex) { MessageBox.Show("La caisse source et la caisse destinataire doivent être différentes.", "SANKHÉ"); return; }
                if (!TryMoney(amount.Text, out var m) || m <= 0) { MessageBox.Show("Saisissez un montant valide.", "SANKHÉ"); return; }
                try
                {
                    var src = caisses[source.SelectedIndex]; var dst = caisses[destination.SelectedIndex];
                    Database.TransferCaisse(m, src.Db, dst.Db, motif.Text, reference.Text);
                    d.DialogResult = DialogResult.OK; d.Close();
                    MessageBox.Show("Virement enregistré. Les deux caisses ont été mises à jour.", "SANKHÉ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "SANKHÉ — Virement", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            };
            d.Controls.Add(save);
            d.ShowDialog(this);
            RebuildData();
        }

        virementsButton.Click += (_, _) => OpenCaisseTransferDialog();
        print.Click += (_, _) => PrintCaisseJournal(DbName(selectedCaisse));
        search.TextChanged += (_, _) => RebuildData();

        RebuildCards();
        RebuildData();
    }

    void PrintCaisseJournal(string serviceCaisse = "Caisse")
    {
        var rows = Database.GetCaisseJournal(serviceCaisse, 500);
        if (rows.Count == 0) { MessageBox.Show("Aucun mouvement de caisse à imprimer.", "SANKHÉ"); return; }
        using var doc = new System.Drawing.Printing.PrintDocument();
        doc.PrintPage += (_, e) =>
        {
            using var titleFont = new Font("Segoe UI", 15, FontStyle.Bold);
            using var font = new Font("Segoe UI", 9);
            var graphics = e.Graphics ?? throw new InvalidOperationException("Le contexte graphique d'impression est indisponible.");
            graphics.DrawString($"SANKHÉ TRANSFERT D’ARGENT — {serviceCaisse.ToUpperInvariant()}", titleFont, Brushes.Black, 40, 35);
            graphics.DrawString($"Gérant : {GetManagerName()}", font, Brushes.Black, 40, 58);
            var y = 90;
            graphics.DrawString($"Imprimé le {DateTime.Now:dd/MM/yyyy HH:mm}    Solde actuel : {Money(Database.GetCaisseSolde(serviceCaisse))}", font, Brushes.Black, 40, y);
            y += 30;
            foreach (var r in rows)
            {
                graphics.DrawString($"{r.DateMouvement}   {r.TypeMouvement,-14}   {Money(r.Montant),15}   {r.Motif}   {r.Reference}", font, Brushes.Black, 40, y);
                y += 20;
                if (y > e.PageBounds.Height - 40) { e.HasMorePages = true; break; }
            }
        };
        using var dlg = new PrintDialog { Document = doc, UseEXDialog = true };
        if (dlg.ShowDialog(this) == DialogResult.OK) doc.Print();
    }

    // V136 : maquette Opérations de référence — deux caisses séparées, fidèle au modèle Wave / Orange Money.
    void ShowOperation(string selectedService = "Wave")
    {
        ClearContent();
        content.AutoScroll = true;

        var host = CreatePageHost(1160);
        host.Height = 930;
        content.Controls.Add(host);

        var title = Heading("Nouvelle opération");
        title.Font = new Font("Segoe UI", 23, FontStyle.Bold);
        title.ForeColor = Color.White;
        title.Location = new Point(0, 0);
        host.Controls.Add(title);

        var subtitle = new Label
        {
            Text = "Choisissez directement le service et le type d’opération. Le bouton sélectionné est mis en évidence.",
            AutoSize = true, Left = 2, Top = 38,
            Font = new Font("Segoe UI", 9.5f), ForeColor = Color.FromArgb(215, 225, 240),
            BackColor = Color.Transparent
        };
        host.Controls.Add(subtitle);

        var dailyAtOperation = Database.GetCaisseJournaliereSummaries(DateTime.Now);
        BuildBalanceCard("WAVE", "Caisse journalière Wave", dailyAtOperation.First(x => x.ServiceCaisse == "Caisse Wave").SoldeActuel, Color.FromArgb(0, 145, 255), 10);
        BuildBalanceCard("ORANGE MONEY", "Caisse journalière Orange Money", dailyAtOperation.First(x => x.ServiceCaisse == "Caisse Orange Money").SoldeActuel, Color.FromArgb(255, 145, 20), 590);

        BuildServiceCard("Wave", Color.FromArgb(0, 145, 255), 10);
        BuildServiceCard("Orange Money", Color.FromArgb(255, 145, 20), 590);

        void BuildBalanceCard(string brand, string caisseName, decimal amount, Color accent, int left)
        {
            // Maquette de référence : logo intégré à gauche, montant très lisible à droite,
            // couleurs officielles Wave / Orange Money et angles arrondis.
            var card = new Panel
            {
                Left = left, Top = 66, Width = 560, Height = 105,
                BackColor = Color.Transparent
            };
            card.Paint += (_, e) =>
            {
                using var path = RoundedPath(new Rectangle(1, 1, card.Width - 3, card.Height - 3), 22);
                using var fill = new LinearGradientBrush(card.ClientRectangle,
                    Color.FromArgb(170, Math.Min(255, accent.R / 2 + 12), Math.Min(255, accent.G / 2 + 12), Math.Min(255, accent.B / 2 + 12)),
                    Color.FromArgb(145, 5, 24, 52), 0f);
                using var pen = new Pen(Color.FromArgb(245, accent), 2.5f);
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.FillPath(fill, path);
                e.Graphics.DrawPath(pen, path);
            };

            var logoFrame = new Panel
            {
                Left = 16, Top = 13, Width = 118, Height = 78,
                BackColor = Color.FromArgb(115, 0, 0, 0)
            };
            logoFrame.Paint += (_, e) =>
            {
                using var path = RoundedPath(new Rectangle(0, 0, logoFrame.Width - 1, logoFrame.Height - 1), 18);
                using var b = new SolidBrush(Color.FromArgb(125, 0, 0, 0));
                using var pen = new Pen(Color.FromArgb(90, accent), 1.3f);
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.FillPath(b, path);
                e.Graphics.DrawPath(pen, path);
            };

            var logoFile = brand.Equals("WAVE", StringComparison.OrdinalIgnoreCase)
                ? "wave_exact.png"
                : "orange_money_exact.png";
            var logo = new PictureBox
            {
                Image = LoadAsset(logoFile),
                Left = 8, Top = 8, Width = 102, Height = 62,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent
            };
            logoFrame.Controls.Add(logo);

            var lbl = new Label
            {
                Text = caisseName.ToUpperInvariant(), Left = 150, Top = 13, Width = 390, Height = 22,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Color.White,
                BackColor = Color.Transparent
            };
            var amountLabel = new Label
            {
                Text = Money(amount), Left = 148, Top = 34, Width = 390, Height = 55,
                Font = new Font("Segoe UI", 26, FontStyle.Bold),
                ForeColor = amount < 0 ? Color.FromArgb(255, 65, 75) : accent,
                TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.Transparent
            };
            card.Controls.Add(logoFrame);
            card.Controls.Add(lbl);
            card.Controls.Add(amountLabel);
            host.Controls.Add(card);
        }

        void BuildServiceCard(string serviceName, Color accent, int left)
        {
            var panel = new Panel
            {
                Left = left, Top = 185, Width = 560, Height = 720,
                BackColor = Color.FromArgb(130, 5, 24, 52)
            };
            panel.Paint += (_, e) =>
            {
                using var path = RoundedPath(new Rectangle(1, 1, panel.Width - 3, panel.Height - 3), 24);
                using var fill = new LinearGradientBrush(panel.ClientRectangle,
                    Color.FromArgb(145, 5, 28, 62), Color.FromArgb(125, 3, 18, 40), 35f);
                using var pen = new Pen(Color.FromArgb(240, accent), 2.2f);
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.FillPath(fill, path); e.Graphics.DrawPath(pen, path);
                using var glow = new SolidBrush(Color.FromArgb(24, accent));
                e.Graphics.FillEllipse(glow, panel.Width - 180, panel.Height - 170, 250, 220);
            };
            host.Controls.Add(panel);

            var header = new Label { Text = serviceName.ToUpperInvariant(), Left = 22, Top = 14, Width = 516, Height = 42, Font = new Font("Segoe UI", 20, FontStyle.Bold), ForeColor = accent, TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            panel.Controls.Add(header);

            var choiceBox = new Panel { Left = 22, Top = 60, Width = 516, Height = 50, BackColor = Color.FromArgb(115, 8, 36, 70) };
            choiceBox.Paint += (_, e) => DrawRoundedBorder(e.Graphics, choiceBox.ClientRectangle, 14, Color.FromArgb(90, accent));
            var choice = new Label { Text = "OPÉRATION CHOISIE : ", Left = 12, Top = 0, Width = 310, Height = 50, Font = new Font("Segoe UI", 10.5f, FontStyle.Bold), ForeColor = Color.FromArgb(226,232,240), TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.Transparent };
            var debtBadge = new Label { Text = "⚠  DETTE À ENCAISSER", Left = 350, Top = 8, Width = 150, Height = 34, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.FromArgb(220, 225, 35, 55), TextAlign = ContentAlignment.MiddleCenter, Visible = false };
            debtBadge.Region = new Region(RoundedPath(new Rectangle(0, 0, debtBadge.Width, debtBadge.Height), 16));
            choiceBox.Controls.Add(choice); choiceBox.Controls.Add(debtBadge); panel.Controls.Add(choiceBox);

            var typesPanel = new FlowLayoutPanel { Left = 12, Top = 120, Width = 536, Height = 58, WrapContents = false, FlowDirection = FlowDirection.LeftToRight, BackColor = Color.Transparent, Padding = new Padding(0, 0, 4, 0), AutoScroll = false };
            panel.Controls.Add(typesPanel);
            string[] types = serviceName.Equals("Wave", StringComparison.OrdinalIgnoreCase)
                ? new[] { "Dépôt", "Retrait", "Transfert", "Rééquilibrage" }
                : new[] { "Dépôt", "Retrait", "Transfert", "Échange" };
            var typeButtons = new Dictionary<string, Button>();
            foreach (var t in types)
            {
                var displayText = serviceName.Equals("Orange Money", StringComparison.OrdinalIgnoreCase)
                    ? (t == "Retrait" ? "⬇  RÉSERVOIR UV" : t == "Dépôt" ? "⬆  TRANSFERT UV" : t == "Transfert" ? "Dette" : t)
                    : (t == "Transfert" ? "Dette" : t);
                var btn = new Button { Text = displayText, Width = (t == "Rééquilibrage" ? 132 : t == "Échange" ? 118 : (displayText.Contains("UV") ? 132 : (displayText.Length > 11 ? 112 : 92))), Height = 50, Margin = new Padding(2), FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", displayText.Contains("UV") ? 9.5f : 9f, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.FromArgb(18,45,78), Cursor = Cursors.Hand, UseVisualStyleBackColor = false };
                btn.FlatAppearance.BorderSize = 1; btn.FlatAppearance.BorderColor = Color.FromArgb(80,110,145);
                btn.Region = new Region(RoundedPath(new Rectangle(0, 0, btn.Width, btn.Height), 10));
                btn.MouseEnter += (_, _) => { if (btn.Enabled) btn.BackColor = ControlPaint.Light(btn.BackColor, .12f); };
                btn.MouseLeave += (_, _) => { if (!typeButtons.TryGetValue(t, out var current) || current.BackColor == Color.FromArgb(18,45,78)) btn.BackColor = Color.FromArgb(18,45,78); };
                typeButtons[t] = btn; typesPanel.Controls.Add(btn);
            }

            // Zone des champs : chaque élément est désormais clairement délimité par sa propre cage.
            var fields = new Panel { Left = 18, Top = 188, Width = 524, Height = 560, BackColor = Color.Transparent };
            panel.Controls.Add(fields);

            var client = new TextBox { Width = 308, Height = 32, BorderStyle = BorderStyle.None, BackColor = Color.White, ForeColor = Color.FromArgb(25,35,50), Font = new Font("Segoe UI", 10.5f, FontStyle.Bold) };
            var tel = new TextBox { Width = 308, Height = 32, BorderStyle = BorderStyle.None, BackColor = Color.White, ForeColor = Color.FromArgb(25,35,50), Font = new Font("Segoe UI", 10.5f, FontStyle.Bold) }; ApplyPhoneInputFormat(tel);
            var montant = new TextBox { Width = 308, Height = 32, BorderStyle = BorderStyle.None, BackColor = Color.White, ForeColor = Color.FromArgb(25,35,50), Font = new Font("Segoe UI", 10.5f, FontStyle.Bold) }; ApplyMoneyInputFormat(montant);
            var commission = new TextBox { Width = 308, Height = 32, BorderStyle = BorderStyle.None, BackColor = Color.White, ForeColor = Color.FromArgb(25,35,50), Font = new Font("Segoe UI", 10.5f, FontStyle.Bold), Text = "0" }; ApplyMoneyInputFormat(commission);
            var reference = new TextBox { Width = 308, Height = 32, BorderStyle = BorderStyle.None, BackColor = Color.White, ForeColor = Color.FromArgb(25,35,50), Font = new Font("Segoe UI", 10.5f, FontStyle.Bold) };

            Panel FieldCage(string label, Control input, int top)
            {
                var row = new Panel { Left = 0, Top = top, Width = 524, Height = 50, BackColor = Color.FromArgb(70, 7, 35, 68) };
                row.Paint += (_, e) =>
                {
                    e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    using var path = RoundedPath(new Rectangle(1, 1, row.Width - 3, row.Height - 3), 13);
                    using var fill = new SolidBrush(Color.FromArgb(65, 9, 43, 80));
                    using var pen = new Pen(Color.FromArgb(115, accent), 1.25f);
                    e.Graphics.FillPath(fill, path);
                    e.Graphics.DrawPath(pen, path);
                };
                var lab = new Label { Text = label, Left = 14, Top = 0, Width = 174, Height = 50, Font = new Font("Segoe UI", 10.5f, FontStyle.Bold), ForeColor = Color.FromArgb(235, 242, 250), BackColor = Color.Transparent, TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true };
                input.Left = 196; input.Width = 312; input.Height = 36;
                input.Top = Math.Max(7, (row.Height - input.Height) / 2);
                lab.Left = 14; lab.Top = 0; lab.Width = 168; lab.Height = row.Height;
                lab.TextAlign = ContentAlignment.MiddleLeft;
                row.Controls.Add(lab); row.Controls.Add(input);
                fields.Controls.Add(row);
                return row;
            }

            var rowClient = FieldCage("Nom & Prénom", client, 0);
            var rowTel = FieldCage("Téléphone", tel, 58);
            var rowMontant = FieldCage("Montant (FCFA)", montant, 116);
            var rowCommission = FieldCage("Commission", commission, 184);
            // Montant : cage plus haute et police plus grande pour une lecture immédiate.
            rowMontant.Height = 64;
            montant.Top = (rowMontant.Height - 48) / 2; montant.Height = 48; montant.Left = 196; montant.Width = 312; montant.Font = new Font("Segoe UI", 14.5f, FontStyle.Bold);
            var amountLabel = rowMontant.Controls.OfType<Label>().FirstOrDefault();
            if (amountLabel != null) { amountLabel.Height = 64; amountLabel.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold); }

            var rowReference = FieldCage("Référence", reference, 242);
            var rebalancePanel = new Panel { Left = 16, Top = 188, Width = 492, Height = 118, Visible = false, BackColor = Color.Transparent };
            rebalancePanel.Paint += (_, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundedPath(new Rectangle(1, 1, rebalancePanel.Width - 3, rebalancePanel.Height - 3), 14);
                using var fill = new LinearGradientBrush(rebalancePanel.ClientRectangle, Color.FromArgb(95, accent), Color.FromArgb(45, 8, 30, 65), 0f);
                using var pen = new Pen(Color.FromArgb(190, accent), 1.6f);
                e.Graphics.FillPath(fill, path); e.Graphics.DrawPath(pen, path);
            };
            var rebTitle = new Label { Text = "TYPE DE RÉÉQUILIBRAGE", Left = 10, Top = 8, Width = 472, Height = 22, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Color.White, TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            var vente = new RadioButton { Text = "VENTE UV\nPAIEMENT CLIENT", Left = 8, Top = 38, Width = 150, Height = 68, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.FromArgb(35, 12, 45, 80), Appearance = Appearance.Button, FlatStyle = FlatStyle.Flat, TextAlign = ContentAlignment.MiddleCenter, Cursor = Cursors.Hand, UseVisualStyleBackColor = false };
            var achat = new RadioButton { Text = "ACHAT UV\nSORTIE CAISSE EN ESPÈCE", Left = 170, Top = 38, Width = 150, Height = 68, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.FromArgb(35, 12, 45, 80), Appearance = Appearance.Button, FlatStyle = FlatStyle.Flat, TextAlign = ContentAlignment.MiddleCenter, Cursor = Cursors.Hand, UseVisualStyleBackColor = false };
            var echangeReb = new RadioButton { Text = "ÉCHANGE ⇄\nPAYÉ MAINTENANT", Left = 332, Top = 38, Width = 150, Height = 68, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.FromArgb(35, 12, 45, 80), Appearance = Appearance.Button, FlatStyle = FlatStyle.Flat, TextAlign = ContentAlignment.MiddleCenter, Cursor = Cursors.Hand, UseVisualStyleBackColor = false };
            vente.FlatAppearance.BorderSize = 1; achat.FlatAppearance.BorderSize = 1; echangeReb.FlatAppearance.BorderSize = 1;
            vente.Region = new Region(RoundedPath(new Rectangle(0, 0, vente.Width, vente.Height), 12));
            achat.Region = new Region(RoundedPath(new Rectangle(0, 0, achat.Width, achat.Height), 12));
            echangeReb.Region = new Region(RoundedPath(new Rectangle(0, 0, echangeReb.Width, echangeReb.Height), 12));
            vente.Checked = true;

            // Achat UV est désormais réservé à Wave : aucune cage « Destination Achat UV ».
            // La destination est fixe : Caisse Wave.
            rebalancePanel.Controls.Add(rebTitle); rebalancePanel.Controls.Add(vente); rebalancePanel.Controls.Add(achat); rebalancePanel.Controls.Add(echangeReb); fields.Controls.Add(rebalancePanel);

            // Vente UV : paiement immédiat uniquement par Orange Money ou espèces.
            // Sinon, le paiement est différé et crée une dette.
            var paymentPanel = new Panel { Left = 0, Top = 314, Width = 524, Height = 86, Visible = false, BackColor = Color.Transparent };
            paymentPanel.Paint += (_, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var path = RoundedPath(new Rectangle(1, 1, paymentPanel.Width - 3, paymentPanel.Height - 3), 14);
                using var fill = new SolidBrush(Color.FromArgb(55, 9, 43, 80));
                using var pen = new Pen(Color.FromArgb(105, accent), 1.2f);
                e.Graphics.FillPath(fill, path); e.Graphics.DrawPath(pen, path);
            };
            var paymentTitle = new Label { Text = "RÈGLEMENT DE LA VENTE UV", Left = 12, Top = 6, Width = 500, Height = 22, Font = new Font("Segoe UI", 8.8f, FontStyle.Bold), ForeColor = Color.White, TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            var immediate = new RadioButton { Text = "Payé maintenant", Left = 16, Top = 34, Width = 130, Height = 34, Font = new Font("Segoe UI", 9f, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.Transparent, Checked = true };
            var deferred = new RadioButton { Text = "Paiement différé (dette)", Left = 145, Top = 34, Width = 160, Height = 34, Font = new Font("Segoe UI", 9f, FontStyle.Bold), ForeColor = Color.White, BackColor = Color.Transparent };
            var paymentMethod = new ComboBox { Left = 318, Top = 32, Width = 190, Height = 32, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            paymentMethod.Items.AddRange(new object[] { "Orange Money", "Espèces" });
            paymentMethod.SelectedIndex = 0;
            paymentPanel.Controls.AddRange(new Control[] { paymentTitle, immediate, deferred, paymentMethod });
            fields.Controls.Add(paymentPanel);

            var info = new Label { Left = 14, Top = 360, Width = 496, Height = 42, Font = new Font("Segoe UI", 9, FontStyle.Bold), ForeColor = Color.FromArgb(148,163,184), Text = "", BackColor = Color.Transparent, TextAlign = ContentAlignment.MiddleCenter };
            fields.Controls.Add(info);

            // V173 : recherche client par première lettre / début du nom ou prénom.
            // Le téléphone est rempli uniquement après sélection explicite dans la liste.
            ConfigureClientPicker(fields, client, tel);

            var save = new Button { Text = "✓  ENREGISTRER", Left = 167, Top = 362, Width = 180, Height = 50, BackColor = accent, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), Cursor = Cursors.Hand };
            save.FlatAppearance.BorderSize = 0;
            save.Region = new Region(RoundedPath(new Rectangle(0, 0, save.Width, save.Height), 12));
            fields.Controls.Add(save);

            string selectedType = "";
            void SelectType(string t)
            {
                selectedType = t;
                foreach (var kv in typeButtons)
                {
                    kv.Value.BackColor = kv.Key == t ? accent : Color.FromArgb(18,45,78);
                    kv.Value.FlatAppearance.BorderColor = kv.Key == t ? accent : Color.FromArgb(80,110,145);
                }
                bool reb = t == "Rééquilibrage"; bool dette = t == "Transfert";
                rebalancePanel.Visible = reb;
                // Pour un rééquilibrage, le nom/prénom et le numéro restent obligatoires pour tracer l'opération.
                rowClient.Visible = true; rowTel.Visible = true; rowCommission.Visible = !reb && t != "Échange";
                client.Visible = true; tel.Visible = true; commission.Visible = !reb && t != "Échange"; reference.Visible = !reb;
                rowClient.Top = 0;
                rowTel.Top = 58;
                paymentPanel.Visible = reb && vente.Checked;
                rowMontant.Top = 116;
                rowReference.Visible = !reb;
                rowReference.Top = 242;
                info.Top = reb ? 414 : 318;
                save.Top = reb ? 468 : 362;
                choice.Text = "OPÉRATION CHOISIE : " + t.ToUpperInvariant();
                choice.ForeColor = accent;
                debtBadge.Visible = dette;
                montant.ForeColor = dette ? Color.FromArgb(220, 35, 55) : Color.FromArgb(20, 30, 45);
                montant.BackColor = dette ? Color.FromArgb(255, 238, 238) : Color.White;
                info.Text = reb ? (echangeReb.Checked
                    ? "ÉCHANGE PAYÉ MAINTENANT • Caisse Wave − montant / Caisse Orange Money + montant. Aucune dette créée."
                    : vente.Checked
                        ? (immediate.Checked ? "VENTE UV • PAIEMENT IMMÉDIAT\nLe montant sort de la caisse Wave puis est encaissé dans la caisse choisie." : "VENTE UV • PAIEMENT DIFFÉRÉ\nLe montant est déduit de la caisse Wave et enregistré en dette.")
                        : "ACHAT UV • TRANSFERT INTERNE\nLe montant sort de la Caisse en espèce et entre uniquement dans la Caisse Wave.")
                    : (dette ? "⚠ DETTE À ENCAISSER — le montant avancé au client sera enregistré en dette." : (t == "Échange" ? "ÉCHANGE IMMÉDIAT • Orange Money − montant / Wave + montant. Aucune dette créée." : ""));
                info.ForeColor = reb ? (echangeReb.Checked ? Color.FromArgb(90, 235, 190) : vente.Checked ? Color.FromArgb(255, 210, 90) : Color.FromArgb(80, 235, 165)) : (dette ? Color.FromArgb(255, 85, 85) : Color.FromArgb(148,163,184));
                foreach (var kv in typeButtons)
                {
                    var selected = kv.Key == t;
                    var selectedColor = kv.Key switch
                    {
                        "Dépôt" => Color.FromArgb(18, 205, 125),
                        "Retrait" => Color.FromArgb(20, 105, 245),
                        "Transfert" => Color.FromArgb(15, 125, 245),
                        "Échange" => Color.FromArgb(0, 155, 135),
                        _ => Color.FromArgb(25, 105, 220)
                    };
                    kv.Value.BackColor = selected ? selectedColor : Color.FromArgb(18,45,78);
                    kv.Value.FlatAppearance.BorderColor = selected && kv.Key == "Transfert" ? Color.FromArgb(255, 65, 75) : (selected ? selectedColor : Color.FromArgb(80,110,145));
                    kv.Value.FlatAppearance.BorderSize = selected && kv.Key == "Transfert" ? 2 : 1;
                }
            }
            foreach (var kv in typeButtons) kv.Value.Click += (_, _) => SelectType(kv.Key);
            void RefreshRebalanceChoice()
            {
                var active = Color.FromArgb(70, Math.Min(255, accent.R + 10), Math.Min(255, accent.G + 10), Math.Min(255, accent.B + 10));
                vente.BackColor = vente.Checked ? active : Color.FromArgb(35, 12, 45, 80);
                achat.BackColor = achat.Checked ? active : Color.FromArgb(35, 12, 45, 80);
                echangeReb.BackColor = echangeReb.Checked ? Color.FromArgb(30, 125, 100) : Color.FromArgb(35, 12, 45, 80);
                echangeReb.FlatAppearance.BorderColor = echangeReb.Checked ? Color.FromArgb(80, 235, 190) : Color.FromArgb(90, 120, 155);
                echangeReb.FlatAppearance.BorderSize = echangeReb.Checked ? 2 : 1;
                vente.FlatAppearance.BorderColor = vente.Checked ? accent : Color.FromArgb(90, 120, 155);
                achat.FlatAppearance.BorderColor = achat.Checked ? accent : Color.FromArgb(90, 120, 155);
                vente.FlatAppearance.BorderSize = vente.Checked ? 2 : 1;
                achat.FlatAppearance.BorderSize = achat.Checked ? 2 : 1;
                paymentPanel.Visible = selectedType == "Rééquilibrage" && vente.Checked;
                if (selectedType == "Rééquilibrage")
                {
                    info.Text = echangeReb.Checked
                        ? "ÉCHANGE PAYÉ MAINTENANT • Caisse Wave − montant / Caisse Orange Money + montant. Aucune dette créée."
                        : vente.Checked
                            ? (immediate.Checked ? "VENTE UV • PAIEMENT IMMÉDIAT\nLe montant sort de la caisse Wave puis est encaissé dans la caisse choisie." : "VENTE UV • PAIEMENT DIFFÉRÉ\nLe montant est déduit de la caisse Wave et enregistré en dette.")
                            : "ACHAT UV • TRANSFERT INTERNE\nLe montant sort de la Caisse en espèce et entre uniquement dans la Caisse Wave.";
                    info.ForeColor = echangeReb.Checked ? Color.FromArgb(90,235,190) : vente.Checked ? Color.FromArgb(255, 210, 90) : Color.FromArgb(80, 235, 165);
                }
            }
            vente.CheckedChanged += (_, _) => RefreshRebalanceChoice();
            achat.CheckedChanged += (_, _) => RefreshRebalanceChoice();
            echangeReb.CheckedChanged += (_, _) => RefreshRebalanceChoice();

            immediate.CheckedChanged += (_, _) =>
            {
                paymentMethod.Enabled = immediate.Checked;
                if (selectedType == "Rééquilibrage")
                {
                    info.Text = immediate.Checked ? "VENTE UV • PAIEMENT IMMÉDIAT\nLe montant sort de la caisse Wave puis est encaissé dans la caisse choisie." : "VENTE UV • PAIEMENT DIFFÉRÉ\nLe montant est déduit de la caisse Wave et enregistré en dette.";
                    info.ForeColor = immediate.Checked ? Color.FromArgb(80, 235, 165) : Color.FromArgb(255, 210, 90);
                }
            };
            deferred.CheckedChanged += (_, _) => immediate.Checked = !deferred.Checked;
            save.Click += (_, _) =>
            {
                if (string.IsNullOrWhiteSpace(selectedType)) { MessageBox.Show("Sélectionnez d'abord un type d'opération.", "SANKHÉ"); return; }
                if (!TryMoney(montant.Text, out var m) || m <= 0) { MessageBox.Show("Veuillez saisir un montant valide.", "SANKHÉ"); return; }
                try
                {
                    if (selectedType == "Échange")
                    {
                        Database.AddExchangeOperation("Orange Money", client.Text.Trim(), tel.Text.Trim(), m, reference.Text.Trim());
                        MessageBox.Show($"Échange enregistré et payé immédiatement.\n\nCaisse Orange Money : −{Money(m)} FCFA\nCaisse Wave : +{Money(m)} FCFA\nAucune dette créée.", "SANKHÉ");
                    }
                    else if (selectedType == "Rééquilibrage" && echangeReb.Checked)
                    {
                        Database.AddExchangeOperation("Wave", client.Text.Trim(), tel.Text.Trim(), m, reference.Text.Trim());
                        MessageBox.Show($"Échange enregistré et payé immédiatement.\n\nCaisse Wave : −{Money(m)} FCFA\nCaisse Orange Money : +{Money(m)} FCFA\nAucune dette créée.", "SANKHÉ");
                    }
                    else if (selectedType == "Rééquilibrage")
                    {
                        var typeReequilibrage = vente.Checked ? "Vente UV" : "Achat UV";
                        if (vente.Checked && (string.IsNullOrWhiteSpace(client.Text) || string.IsNullOrWhiteSpace(tel.Text)))
                        {
                            MessageBox.Show("Pour une Vente UV, veuillez renseigner le Nom & Prénom et le Numéro du client.", "SANKHÉ");
                            return;
                        }
                        var payment = (vente.Checked && immediate.Checked) ? paymentMethod.SelectedItem?.ToString() ?? "Orange Money" : "";
                        var descriptionReequilibrage = typeReequilibrage == "Vente UV"
                            ? (string.IsNullOrWhiteSpace(payment)
                                ? "Vente UV — paiement différé (dette)"
                                : $"Vente UV — réglée par {payment}")
                            : "Achat UV — réglé en espèces";
                        Database.AddReequilibrage(serviceName, typeReequilibrage, m,
                            "", descriptionReequilibrage, client.Text.Trim(), tel.Text.Trim(), "Wave", payment);
                        MessageBox.Show(typeReequilibrage == "Vente UV"
                            ? (immediate.Checked
                                ? $"Vente UV enregistrée et payée immédiatement.\n\nMontant : {Money(m)} FCFA\nMoyen : {payment}\nAucune dette créée."
                                : $"Vente UV enregistrée.\n\nAvance débitée de la caisse {serviceName} : {Money(m)}.\nDette créée : {Money(m)}.\nElle sera réglée dans le menu Dettes.")
                            : $"Achat UV enregistré.\n\nCaisse en espèce : −{Money(m)}\nCaisse Wave : +{Money(m)}.", "SANKHÉ");
                    }
                    else
                    {
                        TryMoney(commission.Text, out var co); var de = selectedType == "Transfert" ? m + co : 0;
                        Database.AddOperation(serviceName, selectedType, client.Text.Trim(), tel.Text.Trim(), m, co, de, reference.Text.Trim(), "");
                        MessageBox.Show(selectedType == "Transfert" ? $"Opération enregistrée.\n\nDette créée : {Money(de)}." : "Opération enregistrée.", "SANKHÉ");
                    }
                    ShowOperation(serviceName);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "SANKHÉ — Opération refusée", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            };

            // Entrée = validation rapide de l'opération.
            void ValidateOperationOnEnter(object? sender, KeyEventArgs e)
            {
                if (e.KeyCode != Keys.Enter) return;
                save.PerformClick();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
            client.KeyDown += ValidateOperationOnEnter;
            tel.KeyDown += ValidateOperationOnEnter;
            montant.KeyDown += ValidateOperationOnEnter;
            commission.KeyDown += ValidateOperationOnEnter;
            reference.KeyDown += ValidateOperationOnEnter;
            vente.KeyDown += ValidateOperationOnEnter;
            achat.KeyDown += ValidateOperationOnEnter;

            // Maquette de référence : Wave démarre sur Transfert et Orange Money sur Dépôt.
            // L'utilisateur peut ensuite changer le choix à tout moment.
            SelectType(serviceName.Equals("Wave", StringComparison.OrdinalIgnoreCase) ? "Transfert" : "Dépôt");
            RefreshRebalanceChoice();
        }
    }


    // V176 : recherche client généralisée et robuste.
    // Utilisée par les saisies client d'Opérations ET de Seddo.
    // - Recherche dès la première lettre.
    // - La lettre peut correspondre au début du nom OU de n'importe quel prénom/nom.
    // - Le téléphone reste vide tant qu'un client n'a pas été sélectionné.
    // - Si aucun client ne correspond, la saisie libre reste possible.
    void ConfigureClientPicker(Control host, TextBox clientBox, TextBox phoneBox)
    {
        var picker = new ListBox
        {
            Visible = false,
            IntegralHeight = false,
            Height = 180,
            Width = Math.Max(220, clientBox.Width),
            Font = clientBox.Font,
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.White,
            ForeColor = Color.FromArgb(25, 35, 50),
            DisplayMember = nameof(Database.ClientRow.Nom)
        };

        bool applyingSelection = false;

        void PositionPicker()
        {
            if (clientBox.IsDisposed || host.IsDisposed || picker.IsDisposed) return;
            var screenPoint = clientBox.PointToScreen(new Point(0, clientBox.Height + 2));
            var hostPoint = host.PointToClient(screenPoint);
            picker.Left = Math.Max(0, hostPoint.X);
            picker.Top = Math.Max(0, hostPoint.Y);
            picker.Width = Math.Max(clientBox.Width, 260);
            if (picker.Right > host.ClientSize.Width)
                picker.Left = Math.Max(0, host.ClientSize.Width - picker.Width);
        }

        bool StartsWithWord(string fullName, string query)
        {
            if (string.IsNullOrWhiteSpace(fullName) || string.IsNullOrWhiteSpace(query)) return false;
            var q = NormalizeSearch(query);
            var normalized = NormalizeSearch(fullName);
            if (normalized.StartsWith(q, StringComparison.OrdinalIgnoreCase)) return true;
            return normalized.Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Any(part => part.StartsWith(q, StringComparison.OrdinalIgnoreCase));
        }

        void HidePicker()
        {
            picker.Visible = false;
            picker.SelectedIndex = -1;
        }

        void SelectCurrent()
        {
            if (picker.SelectedIndex < 0 || picker.SelectedIndex >= picker.Items.Count) return;
            if (picker.Items[picker.SelectedIndex] is not Database.ClientRow selected) return;

            applyingSelection = true;
            clientBox.Text = selected.Nom;
            clientBox.SelectionStart = clientBox.TextLength;
            clientBox.SelectionLength = 0;
            phoneBox.Text = selected.Telephone ?? "";
            applyingSelection = false;
            HidePicker();
            clientBox.Focus();
            clientBox.SelectionStart = clientBox.TextLength;
        }

        void RefreshPicker()
        {
            if (applyingSelection) return;

            // Dès que l'utilisateur modifie le nom/prénom après une sélection,
            // l'ancien téléphone ne doit jamais rester associé au nouveau texte.
            phoneBox.Clear();

            var typed = clientBox.Text.Trim();
            if (typed.Length == 0)
            {
                HidePicker();
                return;
            }

            // Relecture de la base à chaque recherche : les nouveaux clients
            // ajoutés lors d'une opération précédente sont immédiatement disponibles.
            List<Database.ClientRow> clients;
            try
            {
                clients = Database.GetClients();
            }
            catch
            {
                HidePicker();
                return;
            }

            var matches = clients
                .Where(c => StartsWithWord(c.Nom, typed))
                .Take(30)
                .ToList();

            picker.BeginUpdate();
            picker.Items.Clear();
            foreach (var c in matches) picker.Items.Add(c);
            picker.EndUpdate();

            if (matches.Count == 0)
            {
                HidePicker();
                return;
            }

            PositionPicker();
            picker.Height = Math.Min(220, Math.Max(34, matches.Count * 27));
            picker.Visible = true;
            picker.BringToFront();
            picker.SelectedIndex = -1;
        }

        host.Controls.Add(picker);
        PositionPicker();
        picker.BringToFront();

        clientBox.AutoCompleteMode = AutoCompleteMode.None;
        clientBox.AutoCompleteSource = AutoCompleteSource.None;

        clientBox.TextChanged += (_, _) => RefreshPicker();
        clientBox.KeyDown += (_, e) =>
        {
            if (!picker.Visible) return;

            if (e.KeyCode == Keys.Down)
            {
                picker.Focus();
                picker.SelectedIndex = picker.Items.Count == 0 ? -1 : 0;
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
            else if (e.KeyCode == Keys.Enter)
            {
                SelectCurrent();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                HidePicker();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        };

        picker.MouseDown += (_, _) => SelectCurrent();
        picker.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                SelectCurrent();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                HidePicker();
                clientBox.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        };

        host.Resize += (_, _) => PositionPicker();
        clientBox.ParentChanged += (_, _) => PositionPicker();
        clientBox.LocationChanged += (_, _) => PositionPicker();
        clientBox.SizeChanged += (_, _) => PositionPicker();
    }

    // V217: caisse journalière visible directement dans les cartes du menu Caisse.
    void AddCaisseSummaryCard(TableLayoutPanel parent, string name, decimal value, Color accent, string imageFile, int column, bool selected = false, decimal? dailyValue = null)
    {
        var activeAccent = selected ? accent : Color.FromArgb(90, 115, 145);
        var p = new Panel { Dock = DockStyle.Fill, Margin = new Padding(5), BackColor = Color.FromArgb(7, 25, 52), Cursor = Cursors.Hand, MinimumSize = new Size(0, 160) };
        p.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using var path = RoundedPath(new Rectangle(1, 1, p.Width - 3, p.Height - 3), 20);
            var c1 = selected ? Color.FromArgb(8, 55, 78) : Color.FromArgb(8, 31, 53);
            var c2 = selected ? Color.FromArgb(5, 24, 48) : Color.FromArgb(6, 18, 35);
            using var bg = new System.Drawing.Drawing2D.LinearGradientBrush(p.ClientRectangle, c1, c2, 25f);
            using var border = new Pen(Color.FromArgb(selected ? 235 : 120, activeAccent), selected ? 3f : 1.5f);
            g.FillPath(bg, path);
            g.DrawPath(border, path);
            using var glow = new SolidBrush(Color.FromArgb(selected ? 48 : 18, activeAccent));
            g.FillEllipse(glow, p.Width - 145, 65, 155, 155);
            g.FillEllipse(glow, p.Width - 80, -35, 90, 90);
            if (selected)
            {
                using var top = new SolidBrush(Color.FromArgb(235, activeAccent));
                g.FillRectangle(top, 18, 14, 5, p.Height - 28);
            }
        };

        // Maquette demandée : LOGO À GAUCHE + MONTANT À DROITE, sur la même ligne.
        var icon = LoadAsset(imageFile);
        if (icon != null)
        {
            var iconBox = new PictureBox
            {
                Left = 18, Top = 30, Width = 82, Height = 82,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent,
                Image = icon
            };
            p.Controls.Add(iconBox);
        }

        var title = new Label
        {
            Text = name,
            AutoSize = true,
            Left = 116,
            Top = 20,
            Font = new Font("Segoe UI", 12, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = Color.Transparent
        };
        p.Controls.Add(title);

        var status = new Label
        {
            Text = selected ? "CAISSE SÉLECTIONNÉE" : "SOLDE ACTUEL",
            AutoSize = true,
            Left = 116,
            Top = 48,
            Font = new Font("Segoe UI", 8, FontStyle.Bold),
            ForeColor = selected ? accent : Color.FromArgb(165, 190, 215),
            BackColor = Color.Transparent
        };
        p.Controls.Add(status);

        // Le montant est placé À DROITE DU LOGO et centré verticalement avec celui-ci.
        // FCFA reste immédiatement à droite du nombre, sur la même ligne.
        var amountFlow = new FlowLayoutPanel
        {
            Name = "caisseSummaryAmountFlow",
            Left = 116,
            Top = 67,
            Width = Math.Max(220, p.Width - 132),
            Height = 48,
            Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top,
            AutoSize = false,
            WrapContents = false,
            FlowDirection = FlowDirection.LeftToRight,
            BackColor = Color.Transparent,
            Padding = new Padding(0),
            Margin = new Padding(0)
        };

        var amountText = new Label
        {
            Name = "caisseSummaryAmount",
            Text = value.ToString("N0"),
            AutoSize = true,
            Font = new Font("Segoe UI", 28, FontStyle.Bold),
            ForeColor = selected ? Color.White : Color.FromArgb(235, 245, 255),
            BackColor = Color.Transparent,
            Margin = new Padding(0, 0, 9, 0),
            TextAlign = ContentAlignment.MiddleLeft
        };

        var fcfaText = new Label
        {
            Name = "caisseSummaryFcfa",
            Text = "FCFA",
            AutoSize = true,
            Font = new Font("Segoe UI", 15, FontStyle.Bold),
            ForeColor = selected ? accent : Color.FromArgb(205, 225, 242),
            BackColor = Color.Transparent,
            Margin = new Padding(0, 6, 0, 0),
            TextAlign = ContentAlignment.MiddleLeft
        };

        amountFlow.Controls.Add(amountText);
        amountFlow.Controls.Add(fcfaText);
        p.Controls.Add(amountFlow);

        if (dailyValue.HasValue)
        {
            var dailyBox = new Panel
            {
                Name = "caisseDailyBox",
                Left = 18, Top = 118, Width = Math.Max(260, p.ClientSize.Width - 36), Height = 48,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
                BackColor = Color.FromArgb(18, 43, 70)
            };
            dailyBox.Paint += (_, e) =>
            {
                using var pen = new Pen(Color.FromArgb(110, accent), 1.5f);
                e.Graphics.DrawRectangle(pen, 0, 0, dailyBox.Width - 1, dailyBox.Height - 1);
            };
            var dailyLabel = new Label
            {
                Name = "caisseDailyAmount",
                Text = $"CAISSE JOURNALIÈRE  •  {dailyValue.Value:N0} FCFA",
                Left = 12, Top = 6, Width = Math.Max(200, dailyBox.Width - 105), Height = 35,
                Anchor = AnchorStyles.Left | AnchorStyles.Right,
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold), ForeColor = accent, BackColor = Color.Transparent,
                TextAlign = ContentAlignment.MiddleLeft
            };
            var detail = new Button
            {
                Text = "DÉTAIL", Left = Math.Max(200, dailyBox.Width - 90), Top = 8, Width = 78, Height = 32,
                Anchor = AnchorStyles.Right, BackColor = Color.FromArgb(25, 55, 82), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8, FontStyle.Bold)
            };
            detail.FlatAppearance.BorderColor = accent; detail.FlatAppearance.BorderSize = 1;
            detail.Click += (_, _) => ShowCaisseJournaliere();
            dailyBox.Controls.Add(dailyLabel); dailyBox.Controls.Add(detail);
            p.Controls.Add(dailyBox);
            p.SizeChanged += (_, _) => { dailyBox.Width = Math.Max(240, p.ClientSize.Width - 36); dailyLabel.Width = Math.Max(170, dailyBox.ClientSize.Width - 105); detail.Left = Math.Max(180, dailyBox.ClientSize.Width - 90); };
        }

        void LayoutCaisseCard()
        {
            // Logo à gauche, montant à droite sur la même ligne.
            amountFlow.Left = 116;
            amountFlow.Width = Math.Max(220, p.ClientSize.Width - 132);
            amountFlow.Top = 67;
            amountFlow.Height = 48;

            float amountSize = 28f;
            const float fcfaSize = 15f;
            const int gap = 9;
            int available = Math.Max(220, amountFlow.ClientSize.Width);

            using (var g = p.CreateGraphics())
            {
                while (amountSize > 19f)
                {
                    using var af = new Font("Segoe UI", amountSize, FontStyle.Bold);
                    using var ff = new Font("Segoe UI", fcfaSize, FontStyle.Bold);
                    float total = g.MeasureString(amountText.Text, af).Width
                                + gap
                                + g.MeasureString("FCFA", ff).Width;
                    if (total <= available) break;
                    amountSize -= 1f;
                }
            }

            amountText.Font = new Font("Segoe UI", amountSize, FontStyle.Bold);
            amountText.Margin = new Padding(0, 0, gap, 0);
            fcfaText.Font = new Font("Segoe UI", fcfaSize, FontStyle.Bold);
            fcfaText.Margin = new Padding(0, 5, 0, 0);
            amountFlow.PerformLayout();
        }

        p.Resize += (_, _) => LayoutCaisseCard();
        LayoutCaisseCard();
        parent.Controls.Add(p, column % parent.ColumnCount, column / parent.ColumnCount);
    }

    void AddDebtMiniCard(TableLayoutPanel parent, string name, decimal value, Color accent, int column)
    {
        var p = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Margin = new Padding(4) };
        p.Paint += (_, e) => DrawRoundedBorder(e.Graphics, p.ClientRectangle, 12, Color.FromArgb(226,232,240));
        p.Controls.Add(new Label { Text = name, AutoSize = true, Left = 10, Top = 8, Font = new Font("Segoe UI", 7.5f, FontStyle.Bold), ForeColor = Color.FromArgb(100,116,139) });
        p.Controls.Add(new Label { Text = Money(value), AutoSize = true, Left = 10, Top = 28, Font = new Font("Segoe UI", 10f, FontStyle.Bold), ForeColor = accent });
        parent.Controls.Add(p, column, 0);
    }

    void AddField(Control p, string label, Control input, int top)
    {
        p.Controls.Add(new Label { Text = label, Left = 25, Top = top + 5, Width = 175, Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = Color.FromArgb(55,65,81) });
        p.Controls.Add(input);
    }

    void ShowCaisseJournaliere()
    {
        ClearContent();
        content.AutoScroll = true;
        content.Padding = new Padding(24, 18, 24, 24);
        var host = CreatePageHost(1580);
        host.Height = Math.Max(720, content.ClientSize.Height - 20);
        content.Controls.Add(host);

        var title = Heading("Caisse journalière");
        title.Font = new Font("Segoe UI", 24, FontStyle.Bold);
        title.Location = new Point(0, 0);
        host.Controls.Add(title);
        host.Controls.Add(new Label
        {
            Text = "Suivi quotidien des caisses Wave, Orange Money et Espèces • compteur indépendant pour chaque journée",
            AutoSize = true, Left = 2, Top = 42,
            ForeColor = Color.FromArgb(205, 225, 245), Font = new Font("Segoe UI", 10)
        });

        var datePicker = new DateTimePicker { Left = 0, Top = 76, Width = 170, Format = DateTimePickerFormat.Short };
        host.Controls.Add(datePicker);
        var refresh = new Button { Text = "ACTUALISER", Left = 184, Top = 73, Width = 120, Height = 36, BackColor = Color.FromArgb(0, 145, 225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
        refresh.FlatAppearance.BorderSize = 0;
        host.Controls.Add(refresh);

        var nav = new Panel { Left = 0, Top = 122, Width = host.Width, Height = 48, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right, BackColor = Color.Transparent };
        host.Controls.Add(nav);
        var area = new Panel { Left = 0, Top = 178, Width = host.Width, Height = host.Height - 188, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right, BackColor = Color.FromArgb(5, 18, 42) };
        host.Controls.Add(area);

        var configs = new[]
        {
            (Service: "Caisse Wave", Label: "WAVE", Color: Color.FromArgb(0, 166, 81)),
            (Service: "Caisse Orange Money", Label: "ORANGE MONEY", Color: Color.FromArgb(245, 130, 32)),
            (Service: "Caisse", Label: "ESPÈCES", Color: Color.FromArgb(35, 145, 95))
        };
        var pages = new Dictionary<string, (Panel panel, DataGridView grid, Label info, Button button)>();
        string activeService = configs[0].Service;

        foreach (var cfg in configs)
        {
            var button = new Button
            {
                Text = cfg.Label, Left = cfg.Label == "WAVE" ? 0 : cfg.Label == "ORANGE MONEY" ? 170 : 380,
                Top = 0, Width = cfg.Label == "ORANGE MONEY" ? 200 : 160, Height = 42,
                BackColor = cfg.Color, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), Cursor = Cursors.Hand
            };
            button.FlatAppearance.BorderSize = 0;
            nav.Controls.Add(button);

            var page = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(5, 18, 42), Visible = false };
            var info = new Label { Left = 18, Top = 14, Width = 1400, Height = 58, ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
            page.Controls.Add(info);
            var grid = new DataGridView
            {
                Left = 18, Top = 80, Width = Math.Max(500, area.ClientSize.Width - 36), Height = Math.Max(250, area.ClientSize.Height - 96),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                BackgroundColor = Color.FromArgb(5, 18, 42), BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false, ReadOnly = true, RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, EnableHeadersVisualStyles = false,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal, GridColor = Color.FromArgb(35, 74, 120)
            };
            grid.ColumnHeadersDefaultCellStyle.BackColor = cfg.Color;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            grid.ColumnHeadersHeight = 34;
            grid.DefaultCellStyle.BackColor = Color.FromArgb(7, 24, 52);
            grid.DefaultCellStyle.ForeColor = Color.White;
            grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 116, 205);
            grid.RowTemplate.Height = 32;
            foreach (var col in new[] { ("Heure", "Heure"), ("Mouvement", "Type"), ("Montant", "Montant"), ("Motif", "Motif"), ("Référence", "Reference"), ("Opération", "Operation") })
                AddGridColumn(grid, col.Item1, col.Item2, col.Item2 == "Montant");
            page.Controls.Add(grid);
            area.Controls.Add(page);
            pages[cfg.Service] = (page, grid, info, button);
            button.Click += (_, _) => { activeService = cfg.Service; ShowActivePage(); LoadActive(); };
        }

        void ShowActivePage()
        {
            foreach (var cfg in configs)
            {
                var entry = pages[cfg.Service];
                entry.panel.Visible = cfg.Service == activeService;
                entry.button.BackColor = cfg.Service == activeService ? ControlPaint.Dark(cfg.Color, 0.12f) : cfg.Color;
                entry.button.Height = cfg.Service == activeService ? 44 : 40;
            }
        }

        void LoadActive()
        {
            // Charge uniquement la caisse visible : évite de relire les trois historiques à chaque actualisation.
            var x = pages[activeService];
            var sum = Database.GetCaisseJournaliereSummaries(datePicker.Value).First(a => a.ServiceCaisse == activeService);
            x.info.Text = $"Début : {Money(sum.SoldeDebut)}   •   Entrées : {Money(sum.Entrees)}   •   Sorties : {Money(sum.Sorties)}   •   Solde théorique : {Money(sum.SoldeTheorique)}   •   Solde actuel : {Money(sum.SoldeActuel)}";
            x.grid.Rows.Clear();
            foreach (var m in Database.GetCaisseJournaliereMouvements(datePicker.Value, activeService, 250))
            {
                var type = m.OperationType == "Remboursement dette" ? "Remboursement dette antérieure" : m.Type;
                x.grid.Rows.Add(m.Heure, type, Money(m.Montant), m.Motif, m.Reference, m.OperationType);
            }
        }

        refresh.Click += (_, _) => LoadActive();
        datePicker.ValueChanged += (_, _) => LoadActive();
        ShowActivePage();
        LoadActive();
    }

    async System.Threading.Tasks.Task SendWhatsAppDebtSettledNotice(string phone, string clientName, string serviceName,
        decimal initialAmount, decimal lastPayment, string paymentMethod, DateTime paidAt, string reference)
    {
        var result = await WhatsAppDebtNotifier.SendDebtSettledAsync(phone, clientName, serviceName,
            initialAmount, lastPayment, paymentMethod, paidAt, reference);
        if (!result.Success)
        {
            MessageBox.Show(result.Message + "\\nLa dette reste bien enregistrée comme soldée. Aucun montant ni mouvement de caisse n'a été modifié par l'envoi du message.",
                "Notification WhatsApp", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    void ShowDettes()
    {
        ClearContent();
        content.Paint -= DrawAnimatedBackground;
        content.Paint += DrawAnimatedBackground;
        content.AutoScroll = true;
        content.Padding = new Padding(24, 18, 24, 24);

        var host = CreatePageHost(1580);
        host.Height = Math.Max(650, content.ClientSize.Height - 20);
        content.Controls.Add(host);

        var title = Heading("Gestion des dettes clients");
        title.Font = new Font("Segoe UI", 24, FontStyle.Bold);
        title.Location = new Point(0, 0);
        host.Controls.Add(title);
        host.Controls.Add(new Label
        {
            Text = "Chaque Transfert / Envoi crée automatiquement une dette à encaisser. Vous pouvez solder le compte totalement ou partiellement et choisir le moyen d'encaissement.",
            AutoSize = true, Left = 2, Top = 42, ForeColor = Color.FromArgb(205, 225, 245), Font = new Font("Segoe UI", 10)
        });

        var summary = new TableLayoutPanel
        {
            Left = 0, Top = 78, Width = host.Width, Height = 86, ColumnCount = 4, RowCount = 1,
            BackColor = Color.Transparent, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };
        for (int i = 0; i < 4; i++) summary.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        AddDebtMiniCard(summary, "DETTE TOTALE", Database.GetTotalDettes(), Color.FromArgb(220,38,38), 0);
        AddDebtMiniCard(summary, "DETTE WAVE", Database.GetDette("Wave"), Color.FromArgb(0,166,81), 1);
        AddDebtMiniCard(summary, "DETTE ORANGE", Database.GetDette("Orange Money"), Color.FromArgb(245,130,32), 2);
        AddDebtMiniCard(summary, "COMPTES OUVERTS", Database.GetDettes(null, null, true).Count, Color.FromArgb(37,99,235), 3);
        host.Controls.Add(summary);

        var filters = new Panel { Left = 0, Top = 178, Width = host.Width, Height = 92, BackColor = Color.Transparent, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
        filters.Paint += (_, e) => DrawGlassPanel(e.Graphics, filters.ClientRectangle, Color.FromArgb(8,27,52), Color.FromArgb(0,190,255), 18, 245);
        host.Controls.Add(filters);
        var service = new ComboBox { Left = 18, Top = 18, Width = 190, DropDownStyle = ComboBoxStyle.DropDownList };
        service.Items.AddRange(new object[] { "Tous les services", "Wave", "Orange Money" }); service.SelectedIndex = 0;
        var status = new ComboBox { Left = 220, Top = 18, Width = 190, DropDownStyle = ComboBoxStyle.DropDownList };
        status.Items.AddRange(new object[] { "Dettes non soldées", "Toutes les dettes" }); status.SelectedIndex = 0;
        var dateFilter = new ComboBox { Left = 422, Top = 18, Width = 195, DropDownStyle = ComboBoxStyle.DropDownList };
        dateFilter.Items.AddRange(new object[] { "Toutes les dates", "Dettes d'aujourd'hui", "Dettes des jours passés" });
        dateFilter.SelectedIndex = 0;
        var search = new TextBox { Left = 630, Top = 18, Width = 245, PlaceholderText = "Nom, prénom ou téléphone" };
        var refresh = new Button { Text = "ACTUALISER", Left = 890, Top = 17, Width = 120, Height = 34, BackColor = Color.FromArgb(0,155,225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var settle = new Button { Text = "💰 SOLDER / ENCAISSER", Left = 1020, Top = 17, Width = 190, Height = 34, BackColor = Color.FromArgb(0,166,81), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var history = new Button { Text = "HISTORIQUE", Left = 1220, Top = 17, Width = 125, Height = 34, BackColor = Color.FromArgb(75,85,99), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        foreach (var b in new[] { refresh, settle, history }) b.FlatAppearance.BorderSize = 0;
        filters.Controls.AddRange(new Control[] { service, status, dateFilter, search, refresh, settle, history });

        var grid = new DataGridView
        {
            Left = 0, Top = 286, Width = host.Width, Height = Math.Max(300, host.Height - 292),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
            BackgroundColor = Color.FromArgb(5,18,42), BorderStyle = BorderStyle.None,
            AllowUserToAddRows = false, ReadOnly = true, RowHeadersVisible = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            AutoGenerateColumns = false, EnableHeadersVisualStyles = false, AllowUserToResizeRows = false,
            CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal, GridColor = Color.FromArgb(35,74,120)
        };
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(18,91,168);
        grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        grid.ColumnHeadersHeight = 38;
        grid.DefaultCellStyle.BackColor = Color.FromArgb(7,24,52);
        grid.DefaultCellStyle.ForeColor = Color.White;
        grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0,116,205);
        grid.DefaultCellStyle.SelectionForeColor = Color.White;
        grid.RowTemplate.Height = 34;
        AddGridColumn(grid, "Date", "Date");
        AddGridColumn(grid, "Service", "Service");
        AddGridColumn(grid, "Client", "Client");
        AddGridColumn(grid, "Téléphone", "Telephone");
        AddGridColumn(grid, "Montant initial", "Initial", true);
        AddGridColumn(grid, "Reste à encaisser", "Restant", true);
        AddGridColumn(grid, "Origine", "Origine");
        AddGridColumn(grid, "Statut", "Statut");
        AddGridColumn(grid, "Référence", "Reference");
        host.Controls.Add(grid);

        List<Database.DetteRow> current = new();
        void LoadDebts()
        {
            var s = service.SelectedIndex == 0 ? null : service.Text;
            current = Database.GetDettes(s, search.Text, status.SelectedIndex == 0);
            var today = DateTime.Today;
            current = current.Where(d =>
            {
                if (dateFilter.SelectedIndex == 0) return true;
                DateTime created;
                var parsed = DateTime.TryParse(d.DateCreation, out created);
                if (!parsed) parsed = DateTime.TryParseExact(d.DateCreation, new[] { "yyyy-MM-dd HH:mm:ss", "yyyy-MM-ddTHH:mm:ss", "yyyy-MM-dd" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out created);
                if (!parsed) return dateFilter.SelectedIndex == 2;
                return dateFilter.SelectedIndex == 1 ? created.Date == today : created.Date < today;
            }).ToList();
            grid.Rows.Clear();
            foreach (var d in current)
                grid.Rows.Add(d.DateCreation, d.Service, d.ClientNom, d.Telephone, Money(d.MontantInitial), Money(d.MontantRestant), d.Origine, d.Statut, d.Reference);
            title.Text = $"Gestion des dettes clients  •  {current.Count} compte(s)";
        }

        void SettleSelected()
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Index < 0 || grid.CurrentRow.Index >= current.Count)
            {
                MessageBox.Show("Sélectionnez d'abord une dette.", "SANKHÉ"); return;
            }
            var d = current[grid.CurrentRow.Index];
            if (d.MontantRestant <= 0) { MessageBox.Show("Cette dette est déjà soldée.", "SANKHÉ"); return; }

            using var dialog = new Form { Text = "Encaisser / solder la dette", Width = 500, Height = 390, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, BackColor = Color.White };
            var info = new Label { Left = 24, Top = 20, Width = 430, Height = 72, Text = $"Client : {d.ClientNom}\nOrigine : {d.Origine}\nDette restante : {Money(d.MontantRestant)}", Font = new Font("Segoe UI", 11, FontStyle.Bold), ForeColor = Color.FromArgb(30,41,59) };
            var amount = new TextBox { Left = 190, Top = 92, Width = 230, Text = d.MontantRestant.ToString("0.##") }; ApplyMoneyInputFormat(amount);
            var method = new ComboBox { Left = 190, Top = 137, Width = 230, DropDownStyle = ComboBoxStyle.DropDownList };
            // Moyens autorisés pour la solvabilité d'une dette.
            // IMPORTANT : Caisse Seddo est exclue.
            method.Items.AddRange(new object[]
            {
                "Caisse Wave",
                "Caisse Orange Money",
                "Caisse en espèce"
            });
            method.SelectedItem = d.Service == "Orange Money" ? "Caisse Orange Money" : "Caisse Wave";
            if (method.SelectedIndex < 0) method.SelectedIndex = 0;
            var reference = new TextBox { Left = 190, Top = 182, Width = 230, PlaceholderText = "Référence / reçu (facultatif)" };
            var obs = new TextBox { Left = 190, Top = 227, Width = 230, PlaceholderText = "Observation (facultatif)" };
            dialog.Controls.Add(info);
            dialog.Controls.Add(new Label { Text = "Montant encaissé", Left = 24, Top = 96, Width = 155 }); dialog.Controls.Add(amount);
            dialog.Controls.Add(new Label { Text = "Moyen d'encaissement", Left = 24, Top = 141, Width = 155 }); dialog.Controls.Add(method);
            dialog.Controls.Add(new Label { Text = "Référence", Left = 24, Top = 186, Width = 155 }); dialog.Controls.Add(reference);
            dialog.Controls.Add(new Label { Text = "Observation", Left = 24, Top = 231, Width = 155 }); dialog.Controls.Add(obs);
            var ok = new Button { Text = "ENCAISSER", Left = 190, Top = 280, Width = 110, Height = 38, BackColor = Color.FromArgb(0,166,81), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            var cancel = new Button { Text = "ANNULER", Left = 310, Top = 280, Width = 110, Height = 38, DialogResult = DialogResult.Cancel, FlatStyle = FlatStyle.Flat };
            ok.FlatAppearance.BorderSize = 0; dialog.Controls.Add(ok); dialog.Controls.Add(cancel); dialog.AcceptButton = ok; dialog.CancelButton = cancel;
            ok.Click += (_, _) =>
            {
                if (!TryMoney(amount.Text, out var m) || m <= 0) { MessageBox.Show("Montant invalide.", "SANKHÉ"); return; }
                try
                {
                    bool fullySettled = m >= d.MontantRestant;
                    string phone = d.Telephone;
                    string clientName = d.ClientNom;
                    string debtService = d.Service;
                    decimal initialAmount = d.MontantInitial;
                    string paymentMethod = method.Text;
                    string paymentReference = reference.Text;
                    DateTime paymentDate = DateTime.Now;
                    Database.SettleDebt(d.Id, m, method.Text, reference.Text, obs.Text);
                    dialog.DialogResult = DialogResult.OK;
                    dialog.Close();
                    if (fullySettled)
                    {
                        _ = SendWhatsAppDebtSettledNotice(phone, clientName, debtService, initialAmount, m, paymentMethod, paymentDate, paymentReference);
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "SANKHÉ — Encaissement", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            };
            if (dialog.ShowDialog(this) == DialogResult.OK) { LoadDebts(); RefreshDashboard(); MessageBox.Show("Encaissement enregistré. Le solde de la dette a été mis à jour.", "SANKHÉ", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        }

        refresh.Click += (_, _) => LoadDebts();
        search.TextChanged += (_, _) => Debounce(LoadDebts);
        service.SelectedIndexChanged += (_, _) => LoadDebts();
        status.SelectedIndexChanged += (_, _) => LoadDebts();
        dateFilter.SelectedIndexChanged += (_, _) => LoadDebts();
        settle.Click += (_, _) => SettleSelected();
        grid.CellDoubleClick += (_, _) => SettleSelected();
        history.Click += (_, _) => { status.SelectedIndex = 1; LoadDebts(); };
        LoadDebts();
    }

    // V208 : centre de contrôle des annulations. Une opération n'est jamais supprimée :
    // elle est marquée "Annulée" et toutes les conséquences de caisse sont neutralisées
    // par des mouvements inverses, dans la même transaction SQLite.
    void ShowAnnulation()
    {
        ClearContent();
        content.AutoScroll = true;
        content.Padding = new Padding(24, 18, 24, 24);

        var host = CreatePageHost(1580);
        host.Height = Math.Max(720, content.ClientSize.Height - 20);
        content.Controls.Add(host);

        var title = Heading("Annulation des opérations");
        title.Font = new Font("Segoe UI", 24, FontStyle.Bold);
        title.Location = new Point(0, 0);
        host.Controls.Add(title);
        host.Controls.Add(new Label
        {
            Text = "Rechercher • vérifier la fiche complète • voir l'impact • annuler en toute sécurité",
            AutoSize = true, Left = 2, Top = 42, ForeColor = Color.FromArgb(205,225,245), Font = new Font("Segoe UI", 10)
        });

        var summary = new TableLayoutPanel
        { Left = 0, Top = 104, Width = host.Width, Height = 58, ColumnCount = 4, RowCount = 1, BackColor = Color.Transparent, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
        for (int i = 0; i < 4; i++) summary.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        var allOps = Database.SearchAnnulationOperations("", "Tous les types", "Toutes les caisses / services", "Toutes", null, null, null);
        var activeCount = allOps.Count(x => string.Equals(x.Statut, "Active", StringComparison.OrdinalIgnoreCase));
        var cancelledCount = allOps.Count - activeCount;
        AddAnnCard(summary, "OPÉRATIONS ACTIVES", activeCount, Color.FromArgb(18,180,120), 0);
        AddAnnCard(summary, "ANNULÉES", cancelledCount, Color.FromArgb(220,70,70), 1);
        AddAnnCard(summary, "À VÉRIFIER", allOps.Count, Color.FromArgb(35,125,225), 2);
        AddAnnCard(summary, "SÉCURITÉ", "TRAÇABILITÉ", Color.FromArgb(245,165,45), 3);
        host.Controls.Add(summary);

        var filters = new Panel { Left = 0, Top = 180, Width = host.Width, Height = 142, BackColor = Color.Transparent, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
        filters.Paint += (_, e) => DrawGlassPanel(e.Graphics, filters.ClientRectangle, Color.FromArgb(7,27,52), Color.FromArgb(0,190,255), 18, 245);
        host.Controls.Add(filters);

        var search = new TextBox { Left = 18, Top = 17, Width = 285, Height = 34, PlaceholderText = "N° opération / téléphone / référence" };
        var personSearch = new TextBox { Left = 311, Top = 17, Width = 250, Height = 34, PlaceholderText = "Nom & Prénom" };
        var type = new ComboBox { Left = 569, Top = 17, Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
        type.Items.AddRange(new object[] { "Tous les types", "Dépôt", "Retrait", "Transfert", "Envoi", "Rééquilibrage", "Remboursement dette", "Seddo" }); type.SelectedIndex = 0;
        var service = new ComboBox { Left = 757, Top = 17, Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
        service.Items.AddRange(new object[] { "Toutes les caisses / services", "Wave", "Orange Money", "Seddo" }); service.SelectedIndex = 0;
        var status = new ComboBox { Left = 945, Top = 17, Width = 135, DropDownStyle = ComboBoxStyle.DropDownList };
        status.Items.AddRange(new object[] { "Active", "Toutes", "Annulée" }); status.SelectedIndex = 0;
        var amount = new TextBox { Left = 1088, Top = 17, Width = 120, PlaceholderText = "Montant" };
        var btnSearch = new Button { Text = "🔎 RECHERCHER", Left = 1216, Top = 15, Width = 135, Height = 36, BackColor = Color.FromArgb(0,145,225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var btnReset = new Button { Text = "↻ RÉINITIALISER", Left = 1359, Top = 15, Width = 145, Height = 36, BackColor = Color.FromArgb(70,85,105), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        foreach (var b in new[] { btnSearch, btnReset }) b.FlatAppearance.BorderSize = 0;

        var useDates = new CheckBox { Text = "Filtrer par date", Left = 20, Top = 72, Width = 120, Height = 28, ForeColor = Color.White, BackColor = Color.Transparent };
        var dateStart = new DateTimePicker { Left = 150, Top = 69, Width = 150, Format = DateTimePickerFormat.Short, Enabled = false };
        var dateEnd = new DateTimePicker { Left = 310, Top = 69, Width = 150, Format = DateTimePickerFormat.Short, Enabled = false };
        var hint = new Label { Text = "Sélectionnez une ligne : vérifiez la fiche complète avant toute annulation.", Left = 485, Top = 72, Width = 760, Height = 26, ForeColor = Color.FromArgb(190,210,230), Font = new Font("Segoe UI", 9, FontStyle.Italic), BackColor = Color.Transparent };
        filters.Controls.AddRange(new Control[] { search,personSearch,type,service,status,amount,btnSearch,btnReset,useDates,dateStart,dateEnd,hint });
        useDates.CheckedChanged += (_, _) => { dateStart.Enabled = dateEnd.Enabled = useDates.Checked; };

        var viewButton = new Button { Text = "👁 VOIR LA FICHE", Left = 0, Top = 332, Width = 190, Height = 38, BackColor = Color.FromArgb(0,145,225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var cancelButton = new Button { Text = "✖ ANNULER L’OPÉRATION", Left = 200, Top = 332, Width = 220, Height = 38, BackColor = Color.FromArgb(220,55,65), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        foreach (var b in new[] { viewButton, cancelButton }) b.FlatAppearance.BorderSize = 0;
        host.Controls.Add(viewButton); host.Controls.Add(cancelButton);

        var grid = new DataGridView
        { Left = 0, Top = 382, Width = host.Width, Height = Math.Max(250, host.Height - 374), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
          BackgroundColor = Color.FromArgb(5,18,42), BorderStyle = BorderStyle.None, AllowUserToAddRows = false, ReadOnly = true, RowHeadersVisible = false,
          SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false, AutoGenerateColumns = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
          EnableHeadersVisualStyles = false, CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal, GridColor = Color.FromArgb(35,74,120) };
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(18,91,168); grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White; grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold); grid.ColumnHeadersHeight = 38;
        grid.DefaultCellStyle.BackColor = Color.FromArgb(7,24,52); grid.DefaultCellStyle.ForeColor = Color.White; grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0,116,205); grid.DefaultCellStyle.SelectionForeColor = Color.White; grid.RowTemplate.Height = 35;
        AddGridColumn(grid, "N°", "Id"); AddGridColumn(grid, "Date / Heure", "Date"); AddGridColumn(grid, "Client", "Client"); AddGridColumn(grid, "Type", "Type"); AddGridColumn(grid, "Service", "Service"); AddGridColumn(grid, "Montant", "Montant", true); AddGridColumn(grid, "Statut", "Statut");
        host.Controls.Add(grid);

        List<Database.AnnulationOperationRow> current = new();
        void Load()
        {
            decimal? m = null; if (!string.IsNullOrWhiteSpace(amount.Text)) { if (!TryMoney(amount.Text, out var mv)) { MessageBox.Show("Montant invalide.", "SANKHÉ"); return; } m = mv; }
            current = Database.SearchAnnulationOperations(search.Text, type.Text, service.Text, status.Text, useDates.Checked ? dateStart.Value.Date : null, useDates.Checked ? dateEnd.Value.Date : null, m);
            var personQ = personSearch.Text.Trim();
            if (!string.IsNullOrWhiteSpace(personQ))
            {
                var normalized = NormalizeSearch(personQ);
                current = current.Where(x => NormalizeSearch(x.ClientNom).Contains(normalized, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            grid.Rows.Clear();
            foreach (var o in current) grid.Rows.Add(o.Id, o.DateOperation, o.ClientNom, o.TypeOperation, o.Service, Money(o.Montant), o.Statut);
            title.Text = $"Annulation des opérations  •  {current.Count} résultat(s)";
        }
        btnSearch.Click += (_, _) => Load();
        btnReset.Click += (_, _) => { search.Clear(); personSearch.Clear(); amount.Clear(); type.SelectedIndex=0; service.SelectedIndex=0; status.SelectedIndex=0; useDates.Checked=false; Load(); };
        foreach (var box in new[] { search, personSearch, amount }) box.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { Load(); e.SuppressKeyPress=true; } };
        Load();

        void OpenSelected()
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Index < 0 || grid.CurrentRow.Index >= current.Count) { MessageBox.Show("Sélectionnez d'abord une opération.", "SANKHÉ"); return; }
            if (ShowAnnulationDetail(current[grid.CurrentRow.Index])) Load();
        }
        viewButton.Click += (_, _) => OpenSelected();
        cancelButton.Click += (_, _) => OpenSelected();
        grid.DoubleClick += (_, _) => OpenSelected();
    }

    void AddAnnCard(TableLayoutPanel table, string label, object value, Color accent, int col)
    {
        var p = new Panel { Dock = DockStyle.Fill, Margin = new Padding(3), BackColor = Color.Transparent };
        p.Paint += (_, e) => DrawGlassPanel(e.Graphics, p.ClientRectangle, Color.FromArgb(8,25,50), accent, 12, 220);
        p.Controls.Add(new Label { Text = label, Left = 10, Top = 5, Width = 280, Height = 16, Font = new Font("Segoe UI", 7.6f, FontStyle.Bold), ForeColor = Color.FromArgb(185,205,225), BackColor = Color.Transparent, AutoEllipsis = true });
        p.Controls.Add(new Label { Text = value is decimal d ? d.ToString("N0") : Convert.ToString(value) ?? "", Left = 10, Top = 22, Width = 300, Height = 24, Font = new Font("Segoe UI", 11.5f, FontStyle.Bold), ForeColor = accent, BackColor = Color.Transparent, AutoEllipsis = true });
        table.Controls.Add(p, col, 0);
    }

    bool ShowAnnulationDetail(Database.AnnulationOperationRow op)
    {
        var movements = Database.GetOperationMovements(op.Id);
        using var dlg = new Form { Text = $"Fiche opération #{op.Id}", Width = 980, Height = 720, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, BackColor = Color.FromArgb(244,247,251) };
        var top = new Panel { Dock = DockStyle.Top, Height = 105, BackColor = Color.FromArgb(6,25,52) }; dlg.Controls.Add(top);
        top.Controls.Add(new Label { Text = $"FICHE DE L’OPÉRATION  #{op.Id}", Left=22,Top=18,Width=840,Height=34,Font=new Font("Segoe UI",18,FontStyle.Bold),ForeColor=Color.White,BackColor=Color.Transparent });
        top.Controls.Add(new Label { Text = $"{op.TypeOperation}  •  {op.Statut}", Left=24,Top=56,Width=840,Height=26,Font=new Font("Segoe UI",10,FontStyle.Bold),ForeColor=op.Statut=="Active"?Color.FromArgb(80,235,165):Color.FromArgb(255,100,100),BackColor=Color.Transparent });

        var detail = new Panel { Left=20,Top=120,Width=920,Height=220,Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right,BackColor=Color.White };
        detail.Paint += (_,e)=>DrawRoundedBorder(e.Graphics,detail.ClientRectangle,14,Color.FromArgb(205,215,228)); dlg.Controls.Add(detail);
        var values = new (string,string)[] { ("Date / heure",op.DateOperation),("Client",string.IsNullOrWhiteSpace(op.ClientNom)?"—":op.ClientNom),("Téléphone",string.IsNullOrWhiteSpace(op.Telephone)?"—":op.Telephone),("Type d’opération",op.TypeOperation),("Service",op.Service),("Montant",Money(op.Montant)+" FCFA"),("Commission",Money(op.Commission)+" FCFA"),("Dette",Money(op.Dette)+" FCFA"),("Référence",string.IsNullOrWhiteSpace(op.Reference)?"—":op.Reference),("Description",string.IsNullOrWhiteSpace(op.Observation)?"—":op.Observation) };
        for(int i=0;i<values.Length;i++){ int col=i%2,row=i/2; int x=20+col*450,y=12+row*40; detail.Controls.Add(new Label{Text=values[i].Item1.ToUpperInvariant(),Left=x,Top=y,Width=150,Height=20,Font=new Font("Segoe UI",8,FontStyle.Bold),ForeColor=Color.FromArgb(100,116,139)}); detail.Controls.Add(new Label{Text=values[i].Item2,Left=x+150,Top=y-1,Width=275,Height=28,Font=new Font("Segoe UI",9.5f,FontStyle.Bold),ForeColor=Color.FromArgb(30,41,59),AutoEllipsis=true});}

        var movTitle = new Label { Text="MOUVEMENTS DE CAISSE LIÉS", Left=20,Top=355,Width=450,Height=28,Font=new Font("Segoe UI",11,FontStyle.Bold),ForeColor=Color.FromArgb(30,41,59) }; dlg.Controls.Add(movTitle);
        var movGrid = new DataGridView { Left=20,Top=388,Width=920,Height=145,Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right,BackgroundColor=Color.White,BorderStyle=BorderStyle.FixedSingle,AllowUserToAddRows=false,ReadOnly=true,RowHeadersVisible=false,AutoGenerateColumns=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,SelectionMode=DataGridViewSelectionMode.FullRowSelect,EnableHeadersVisualStyles=false };
        movGrid.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(18,91,168); movGrid.ColumnHeadersDefaultCellStyle.ForeColor=Color.White; movGrid.ColumnHeadersDefaultCellStyle.Font=new Font("Segoe UI",8.5f,FontStyle.Bold);
        AddGridColumn(movGrid,"Caisse","Caisse"); AddGridColumn(movGrid,"Mouvement","Mouvement"); AddGridColumn(movGrid,"Montant","Montant",true); AddGridColumn(movGrid,"Motif","Motif");
        foreach(var m in movements) movGrid.Rows.Add(m.ServiceCaisse,m.TypeMouvement,Money(m.Montant),m.Motif);
        dlg.Controls.Add(movGrid);

        var impact = new Panel { Left=20,Top=545,Width=920,Height=72,Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right,BackColor=Color.FromArgb(255,248,235) };
        impact.Paint += (_,e)=>DrawRoundedBorder(e.Graphics,impact.ClientRectangle,12,Color.FromArgb(240,170,50));
        var impactText = new StringBuilder();
        if (movements.Count==0) impactText.Append("Aucun mouvement de caisse lié n’a été trouvé. L’annulation modifiera uniquement le statut et les éléments associés.");
        else { impactText.Append("IMPACT AVANT ANNULATION : "); foreach(var m in movements){ var direction=string.Equals(m.TypeMouvement,"Entrée",StringComparison.OrdinalIgnoreCase)||string.Equals(m.TypeMouvement,"Solde initial",StringComparison.OrdinalIgnoreCase)?"SORTIE":"ENTRÉE"; impactText.Append($"{m.ServiceCaisse} → {direction} {Money(m.Montant)} FCFA   "); } }
        impact.Controls.Add(new Label{Text=impactText.ToString(),Left=14,Top=10,Width=890,Height=52,Font=new Font("Segoe UI",9,FontStyle.Bold),ForeColor=Color.FromArgb(130,82,10),AutoEllipsis=true}); dlg.Controls.Add(impact);

        var close = new Button { Text="FERMER", Left=610,Top=632,Width=135,Height=42,Anchor=AnchorStyles.Bottom|AnchorStyles.Right,BackColor=Color.FromArgb(75,85,99),ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",9,FontStyle.Bold) };
        bool cancelledSuccessfully = false;
        var cancel = new Button { Text="✖ ANNULER L’OPÉRATION", Left=755,Top=632,Width=185,Height=42,Anchor=AnchorStyles.Bottom|AnchorStyles.Right,BackColor=Color.FromArgb(205,45,55),ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",8.5f,FontStyle.Bold),Enabled=string.Equals(op.Statut,"Active",StringComparison.OrdinalIgnoreCase) };
        close.FlatAppearance.BorderSize=0; cancel.FlatAppearance.BorderSize=0; close.Click+=(_,_)=>dlg.Close();
        cancel.Click += (_,_) =>
        {
            using var reason = new Form { Text="Motif de l’annulation", Width=520, Height=230, StartPosition=FormStartPosition.CenterParent, FormBorderStyle=FormBorderStyle.FixedDialog, MaximizeBox=false,MinimizeBox=false };
            reason.Controls.Add(new Label{Text="Indiquez pourquoi cette opération doit être annulée :",Left=18,Top=18,Width=460,Height=28,Font=new Font("Segoe UI",9.5f,FontStyle.Bold)});
            var box=new TextBox{Left=18,Top=52,Width=465,Height=70,Multiline=true,ScrollBars=ScrollBars.Vertical,PlaceholderText="Ex. montant saisi incorrect, mauvais client…"}; reason.Controls.Add(box);
            var ok=new Button{Text="CONFIRMER",Left=300,Top=135,Width=180,Height=36,DialogResult=DialogResult.OK,BackColor=Color.FromArgb(205,45,55),ForeColor=Color.White,FlatStyle=FlatStyle.Flat}; ok.FlatAppearance.BorderSize=0; reason.Controls.Add(ok); reason.AcceptButton=ok;
            // Le motif est facultatif : l'utilisateur peut confirmer sans renseigner de texte.
            if(reason.ShowDialog(dlg)!=DialogResult.OK) return;
            var cancellationReason = string.IsNullOrWhiteSpace(box.Text) ? "Annulation sans motif renseigné" : box.Text.Trim();
            var confirm=MessageBox.Show($"Confirmer l’annulation de l’opération #{op.Id} ?\n\nLe logiciel va neutraliser les mouvements de caisse liés et conserver une trace de l’opération.","Confirmation d’annulation",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
            if(confirm!=DialogResult.Yes) return;
            try { Database.CancelOperation(op.Id,cancellationReason,GetManagerName()); cancelledSuccessfully = true; MessageBox.Show("Opération annulée avec succès. Les mouvements de caisse ont été neutralisés et l’opération reste traçable.","SANKHÉ",MessageBoxButtons.OK,MessageBoxIcon.Information); dlg.DialogResult=DialogResult.OK; dlg.Close(); }
            catch(Exception ex){ MessageBox.Show(ex.Message,"Annulation impossible",MessageBoxButtons.OK,MessageBoxIcon.Warning); }
        };
        dlg.Controls.Add(close); dlg.Controls.Add(cancel);
        dlg.ShowDialog(this);
        return cancelledSuccessfully;
    }

    void ShowReports()
    {
        ClearContent();
        content.Paint -= DrawAnimatedBackground;
        content.Paint += DrawAnimatedBackground;
        content.AutoScroll = true;
        content.Padding = new Padding(24, 18, 24, 24);

        var host = CreatePageHost(1500);
        host.Height = Math.Max(700, content.ClientSize.Height - 20);
        content.Controls.Add(host);

        var title = Heading("Rapports imprimables");
        title.Font = new Font("Segoe UI", 24, FontStyle.Bold);
        title.Location = new Point(0, 0);
        host.Controls.Add(title);
        host.Controls.Add(new Label
        {
            Text = "Rapports complets des transactions — Wave, Orange Money et Seddo séparés, avec les opérations détaillées.",
            AutoSize = true, Left = 2, Top = 42, ForeColor = Color.FromArgb(205, 225, 245), Font = new Font("Segoe UI", 10)
        });

        var filters = new Panel { Left = 0, Top = 78, Width = host.Width, Height = 250, BackColor = Color.Transparent, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
        filters.Paint += (_, e) => DrawGlassPanel(e.Graphics, filters.ClientRectangle, Color.FromArgb(8, 27, 52), Color.FromArgb(0, 190, 255), 18, 245);
        host.Controls.Add(filters);

        var period = new ComboBox { Left = 18, Top = 20, Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
        period.Items.AddRange(new object[] { "Aujourd’hui", "Cette semaine", "Ce mois", "Période personnalisée" });
        period.SelectedIndex = 0;
        var service = new ComboBox { Left = 220, Top = 20, Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
        service.Items.AddRange(new object[] { "Tous les services", "Wave", "Orange Money", "Seddo", "Boutique" });
        service.SelectedIndex = 0;
        var type = new ComboBox { Left = 420, Top = 20, Width = 190, DropDownStyle = ComboBoxStyle.DropDownList };
        type.Items.AddRange(new object[] { "Toutes les opérations", "Dépôt", "Retrait", "Transfert", "Envoi", "Rééquilibrage", "Remboursement dette" });
        type.SelectedIndex = 0;
        var start = new DateTimePicker { Left = 18, Top = 68, Width = 180, Format = DateTimePickerFormat.Short };
        var end = new DateTimePicker { Left = 220, Top = 68, Width = 180, Format = DateTimePickerFormat.Short };
        var refresh = new Button { Text = "AFFICHER", Left = 420, Top = 67, Width = 130, Height = 34, BackColor = Color.FromArgb(0, 155, 225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var print = new Button { Text = "🖨  IMPRIMER", Left = 565, Top = 67, Width = 145, Height = 34, BackColor = Color.FromArgb(0, 190, 110), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var savePdf = new Button { Text = "EXPORTER EN CSV", Left = 725, Top = 67, Width = 160, Height = 34, BackColor = Color.FromArgb(126, 76, 255), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var exportPdf = new Button { Text = "📄 RAPPORT PDF", Left = 895, Top = 67, Width = 160, Height = 34, BackColor = Color.FromArgb(220, 145, 25), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var clientReport = new Button { Text = "👤 RAPPORT CLIENT", Left = 1065, Top = 67, Width = 165, Height = 34, BackColor = Color.FromArgb(245, 158, 11), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var boutiqueReport = new Button { Text = "🏪 RAPPORT BOUTIQUE", Left = 1235, Top = 67, Width = 170, Height = 34, BackColor = Color.FromArgb(37, 99, 235), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var transferReport = new Button { Text = "⇄ RAPPORT VIREMENTS", Left = 18, Top = 145, Width = 190, Height = 34, BackColor = Color.FromArgb(124, 58, 237), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var seddoReport = new Button { Text = "💳 RAPPORT SEDDO", Left = 220, Top = 145, Width = 180, Height = 34, BackColor = Color.FromArgb(0, 166, 120), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold), Cursor = Cursors.Hand };
        foreach (var b in new[] { refresh, print, savePdf, exportPdf, clientReport, boutiqueReport, transferReport, seddoReport }) b.FlatAppearance.BorderSize = 0;

        var searchLabel = new Label
        {
            Text = "🔎  Nom & Prénom", Left = 18, Top = 112, Width = 125, Height = 28,
            ForeColor = Color.FromArgb(215, 232, 250), Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        };
        var clientSearch = new TextBox
        {
            Left = 145, Top = 110, Width = 330, Height = 30,
            BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 10.5f),
            PlaceholderText = "Ex. Mamadou Diop, Mamadou ou Diop"
        };
        var clearSearch = new Button
        {
            Text = "EFFACER", Left = 485, Top = 109, Width = 105, Height = 32,
            BackColor = Color.FromArgb(55, 72, 100), ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), Cursor = Cursors.Hand
        };
        clearSearch.FlatAppearance.BorderSize = 0;
        filters.Controls.AddRange(new Control[] { period, service, type, start, end, refresh, print, savePdf, exportPdf, clientReport, boutiqueReport, transferReport, seddoReport, searchLabel, clientSearch, clearSearch });

        var grid = new DataGridView
        {
            Left = 0, Top = 322, Width = host.Width, Height = Math.Max(300, host.Height - 327),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
            BackgroundColor = Color.FromArgb(5, 18, 42), BorderStyle = BorderStyle.None,
            AllowUserToAddRows = false, AllowUserToDeleteRows = false, ReadOnly = true, RowHeadersVisible = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            AutoGenerateColumns = false, EnableHeadersVisualStyles = false, AllowUserToResizeRows = false,
            CellBorderStyle = DataGridViewCellBorderStyle.Single, GridColor = Color.FromArgb(70, 100, 135)
        };
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(18, 91, 168);
        grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        grid.ColumnHeadersHeight = 38;
        grid.DefaultCellStyle.BackColor = Color.FromArgb(7, 24, 52);
        grid.DefaultCellStyle.ForeColor = Color.White;
        grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 116, 205);
        grid.DefaultCellStyle.SelectionForeColor = Color.White;
        grid.DefaultCellStyle.Font = new Font("Segoe UI", 9.2f);
        grid.RowTemplate.Height = 32;
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(10, 32, 67);
        AddGridColumn(grid, "Date & Heure", "Date");
        AddGridColumn(grid, "Service", "Service");
        AddGridColumn(grid, "Nom & Prénom", "ClientNom");
        AddGridColumn(grid, "Description", "Description");
        // V154 : la description doit rester large et lisible dans le rapport.
        grid.Columns["Description"].FillWeight = 280;
        AddGridColumn(grid, "Montant", "Montant", true);
        AddGridColumn(grid, "Commission", "Commission", true);
        AddGridColumn(grid, "Dette", "Dette", true);
        AddGridColumn(grid, "Statut dette", "StatutDette");
        AddGridColumn(grid, "Référence", "Reference");
        AddGridColumn(grid, "Téléphone", "Telephone");
        host.Controls.Add(grid);

        var summary = new Label { Left = 4, Top = 290, Width = host.Width - 8, Height = 28, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right, ForeColor = Color.FromArgb(205, 225, 245), Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
        host.Controls.Add(summary);

        List<Database.OperationRow> current = new();
        DateTime rangeStart = DateTime.Today;
        DateTime rangeEnd = DateTime.Today.AddDays(1);

        void SetRangeFromPeriod()
        {
            var today = DateTime.Today;
            switch (period.SelectedIndex)
            {
                case 0: rangeStart = today; rangeEnd = today.AddDays(1); break;
                case 1:
                    int delta = ((int)today.DayOfWeek + 6) % 7;
                    rangeStart = today.AddDays(-delta); rangeEnd = rangeStart.AddDays(7); break;
                case 2: rangeStart = new DateTime(today.Year, today.Month, 1); rangeEnd = rangeStart.AddMonths(1); break;
                default: rangeStart = start.Value.Date; rangeEnd = end.Value.Date.AddDays(1); break;
            }
            start.Value = rangeStart; end.Value = rangeEnd.AddDays(-1);
        }

        void LoadReport()
        {
            SetRangeFromPeriod();
            var s = service.SelectedIndex == 0 ? "" : service.Text;
            var t = type.SelectedIndex == 0 ? "" : type.Text;
            if (string.Equals(s, "Boutique", StringComparison.OrdinalIgnoreCase) || string.IsNullOrWhiteSpace(s))
            {
                current = string.IsNullOrWhiteSpace(s)
                    ? Database.GetOperationsReport("", t, rangeStart, rangeEnd)
                    : new List<Database.OperationRow>();

                var boutiqueSessions = Database.GetBoutiqueSessions(rangeStart.Date, rangeEnd.Date.AddDays(1));
                foreach (var bs in boutiqueSessions)
                {
                    var empRow = Database.GetBoutiqueEmployee(bs.EmployeId);
                    var posteLabel = empRow is null ? "Boutique" : $"Poste {empRow.Poste}";
                    var clientLabel = $"{posteLabel} — {bs.Employe}";

                    AddBoutiqueReportRow(current, t, "Mise à disposition Wave", bs.Ouverture, bs.WaveDonne, clientLabel, bs, "Distribution du matin");
                    AddBoutiqueReportRow(current, t, "Mise à disposition Orange Money", bs.Ouverture, bs.OrangeDonne, clientLabel, bs, "Distribution du matin");
                    AddBoutiqueReportRow(current, t, "Mise à disposition Espèces", bs.Ouverture, bs.EspecesDonne, clientLabel, bs, "Distribution du matin");

                    var additions = Database.GetBoutiqueOperations(rangeStart.Date, rangeEnd.Date.AddDays(1), bs.EmployeId)
                        .Where(o => o.SessionId == bs.Id && string.Equals(o.TypeOperation, "Complément dotation", StringComparison.OrdinalIgnoreCase))
                        .OrderBy(o => o.DateOperation).ToList();
                    foreach (var a in additions)
                    {
                        var wanted = string.Equals(a.Service, "Wave", StringComparison.OrdinalIgnoreCase)
                            ? "Ajout dotation Wave" : string.Equals(a.Service, "Orange Money", StringComparison.OrdinalIgnoreCase) ? "Ajout dotation Orange Money" : "Ajout dotation Espèces";
                        AddBoutiqueReportRow(current, t, wanted, a.DateOperation, a.Montant, clientLabel, bs, "Complément en cours de journée");
                    }

                    var retourDate = string.IsNullOrWhiteSpace(bs.Fermeture) ? bs.DateJour : bs.Fermeture;
                    AddBoutiqueReportRow(current, t, "Retour Wave", retourDate, bs.WaveRetour, clientLabel, bs, "Retour du soir");
                    AddBoutiqueReportRow(current, t, "Retour Orange Money", retourDate, bs.OrangeRetour, clientLabel, bs, "Retour du soir");
                    AddBoutiqueReportRow(current, t, "Retour Espèces", retourDate, bs.EspecesRetour, clientLabel, bs, "Retour du soir");
                }
            }
            else
            {
                current = Database.GetOperationsReport(s, t, rangeStart, rangeEnd);
            }

            // Recherche souple sur le Nom & Prénom : insensible aux majuscules, accents et espaces.
            var query = NormalizeSearch(clientSearch.Text);
            if (!string.IsNullOrWhiteSpace(query))
            {
                current = current.Where(op =>
                {
                    var fullName = NormalizeSearch(op.ClientNom);
                    var parts = query.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    return parts.Length == 0 || parts.All(part => fullName.Contains(part, StringComparison.OrdinalIgnoreCase));
                }).ToList();
            }

            grid.Rows.Clear();
            decimal total = 0, commission = 0, dette = 0;
            var debtInfoByKey = new Dictionary<string, Database.DebtReportStatus?>();
            var debtInfos = new List<Database.DebtReportStatus>();
            foreach (var op in current)
            {
                var debtInfo = GetReportDebtStatus(op, debtInfoByKey);
                if (debtInfo is not null && !debtInfos.Any(x => x.Id == debtInfo.Id)) debtInfos.Add(debtInfo);
                var status = debtInfo?.Statut ?? "";
                var reportService = GetReportService(op, debtInfo);
                grid.Rows.Add(op.DateOperation, reportService, op.ClientNom, GetReportDescription(op), Money(op.Montant), Money(op.Commission), Money(op.Dette), status, op.Reference, op.Telephone);
                total += op.Montant; commission += op.Commission; dette += op.Dette;
            }
            var soldes = debtInfos.Count(x => x.Statut == "Soldée");
            var nonSoldes = debtInfos.Count(x => x.Statut == "Non soldée");
            var montantInitialDettes = debtInfos.Sum(x => x.MontantInitial);
            var montantRestantNonSoldes = debtInfos.Where(x => x.Statut == "Non soldée").Sum(x => x.MontantRestant);
            var montantSolde = debtInfos.Where(x => x.Statut == "Soldée").Sum(x => x.MontantInitial);
            string serviceLabel = service.SelectedIndex == 0 ? "Tous les services" : service.Text;
            string typeLabel = type.SelectedIndex == 0 ? "Toutes les opérations" : type.Text;
            var searchLabelText = string.IsNullOrWhiteSpace(clientSearch.Text) ? "Tous les clients" : $"Client : {clientSearch.Text.Trim()}";
            summary.Text = $"{serviceLabel}  •  {typeLabel}  •  {searchLabelText}  •  {rangeStart:dd/MM/yyyy} au {rangeEnd.AddDays(-1):dd/MM/yyyy}  |  {current.Count} opérations  |  Montant : {Money(total)}  |  Commission : {Money(commission)}  |  Dette : {Money(dette)}  |  Soldées : {soldes} ({Money(montantSolde)})  |  Non soldées : {nonSoldes} ({Money(montantRestantNonSoldes)} restant)";
        }

        period.SelectedIndexChanged += (_, _) => LoadReport();
        refresh.Click += (_, _) => LoadReport();
        clientSearch.TextChanged += (_, _) => Debounce(LoadReport);
        clientSearch.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { LoadReport(); e.SuppressKeyPress = true; } };
        clearSearch.Click += (_, _) => { clientSearch.Clear(); clientSearch.Focus(); };
        LoadReport();

        print.Click += (_, _) => PrintReport(current, service.Text, type.Text, rangeStart, rangeEnd);
        savePdf.Click += (_, _) => SaveReportAsText(current, service.Text, type.Text, rangeStart, rangeEnd);
        exportPdf.Click += (_, _) => SaveReportAsPdf(current, service.Text, type.Text, rangeStart, rangeEnd);
        boutiqueReport.Click += (_, _) => ShowBoutiqueReportDialog();
        clientReport.Click += (_, _) => ShowIndividualClientReport(rangeStart, rangeEnd);
        transferReport.Click += (_, _) => ShowTransferReportDialog(rangeStart, rangeEnd);
        seddoReport.Click += (_, _) => ShowSeddoReportDialog(rangeStart, rangeEnd);
    }

    void ShowSeddoReportDialog(DateTime defaultStart, DateTime defaultEndExclusive)
    {
        using var d = new Form
        {
            Text = "Rapport des opérations Seddo",
            Width = 1320, Height = 780, StartPosition = FormStartPosition.CenterParent,
            BackColor = Color.FromArgb(8, 20, 39), FormBorderStyle = FormBorderStyle.Sizable,
            MinimumSize = new Size(1050, 650)
        };

        var title = new Label { Text = "💳 RAPPORT DES OPÉRATIONS SEDDO", Left = 24, Top = 18, Width = 800, Height = 34, ForeColor = Color.White, Font = new Font("Segoe UI", 18, FontStyle.Bold) };
        var start = new DateTimePicker { Left = 24, Top = 66, Width = 170, Format = DateTimePickerFormat.Short, Value = defaultStart.Date };
        var end = new DateTimePicker { Left = 210, Top = 66, Width = 170, Format = DateTimePickerFormat.Short, Value = defaultEndExclusive.AddDays(-1).Date };
        var refresh = new Button { Text = "AFFICHER", Left = 395, Top = 65, Width = 110, Height = 34, BackColor = Color.FromArgb(0, 155, 225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var print = new Button { Text = "🖨 IMPRIMER", Left = 520, Top = 65, Width = 125, Height = 34, BackColor = Color.FromArgb(0, 190, 110), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var pdf = new Button { Text = "📄 PDF", Left = 660, Top = 65, Width = 105, Height = 34, BackColor = Color.FromArgb(220, 145, 25), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var close = new Button { Text = "FERMER", Left = 1170, Top = 65, Width = 110, Height = 34, BackColor = Color.FromArgb(55, 72, 100), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold), Anchor = AnchorStyles.Top | AnchorStyles.Right };
        foreach (var b in new[] { refresh, print, pdf, close }) b.FlatAppearance.BorderSize = 0;
        d.Controls.AddRange(new Control[] { title, start, end, refresh, print, pdf, close });
        d.Controls.Add(new Label { Text = "Du", Left = 24, Top = 48, Width = 170, ForeColor = Color.FromArgb(190, 210, 235), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold) });
        d.Controls.Add(new Label { Text = "Au", Left = 210, Top = 48, Width = 170, ForeColor = Color.FromArgb(190, 210, 235), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold) });

        var grid = new DataGridView
        {
            Left = 24, Top = 118, Width = 1256, Height = 430, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
            BackgroundColor = Color.FromArgb(5, 18, 42), BorderStyle = BorderStyle.None, AllowUserToAddRows = false,
            ReadOnly = true, RowHeadersVisible = false, AutoGenerateColumns = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect, EnableHeadersVisualStyles = false, AllowUserToResizeRows = false,
            CellBorderStyle = DataGridViewCellBorderStyle.Single, GridColor = Color.FromArgb(70, 100, 135)
        };
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 91, 120); grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold); grid.ColumnHeadersHeight = 38;
        grid.DefaultCellStyle.BackColor = Color.FromArgb(8, 24, 47); grid.DefaultCellStyle.ForeColor = Color.White;
        grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 116, 130); grid.DefaultCellStyle.SelectionForeColor = Color.White;
        grid.RowTemplate.Height = 34;
        void Col(string h, float w) => grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = h, FillWeight = w });
        Col("DATE", 80); Col("CLIENT", 130); Col("MONTANT", 75); Col("COMM.", 65); Col("TOTAL", 75); Col("CAISSE DE DÉPÔT", 230); Col("STATUT", 75); Col("RESTANT", 75); Col("RÉFÉRENCE", 90); Col("DESCRIPTION", 160);
        d.Controls.Add(grid);

        var summary = new Label
        {
            Left = 24, Top = 560, Width = 1256, Height = 92, Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
            ForeColor = Color.White, BackColor = Color.FromArgb(14, 36, 62), Font = new Font("Segoe UI", 10, FontStyle.Bold), Padding = new Padding(12), AutoEllipsis = true
        };
        d.Controls.Add(summary);

        List<Database.SeddoReportRow> rows = new();
        void LoadRows()
        {
            var s = start.Value.Date; var e = end.Value.Date.AddDays(1);
            rows = Database.GetSeddoReport(s, e);
            grid.Rows.Clear();
            foreach (var r in rows)
                grid.Rows.Add(r.DateOperation, r.ClientNom, Money(r.Montant), Money(r.Commission), Money(r.Total), r.CaissesDescription, r.Statut, Money(r.Restant), r.Reference, r.Description);
            var wave = rows.Sum(x => x.CaisseWave); var orange = rows.Sum(x => x.CaisseOrange); var general = rows.Sum(x => x.CaisseGenerale); var seddo = rows.Sum(x => x.CaisseSeddoSortie);
            var total = rows.Sum(x => x.Total); var comm = rows.Sum(x => x.Commission); var reste = rows.Sum(x => x.Restant);
            summary.Text = $"{s:dd/MM/yyyy} au {end.Value:dd/MM/yyyy}  •  {rows.Count} opération(s)\r\n" +
                           $"Dépôts : Caisse Wave = {Money(wave)} FCFA   |   Caisse Orange Money = {Money(orange)} FCFA   |   Caisse en espèce = {Money(general)} FCFA\r\n" +
                           $"Sorties Caisse Seddo = {Money(seddo)} FCFA   |   Total des opérations = {Money(total)} FCFA   |   Commissions = {Money(comm)} FCFA   |   Restant à encaisser = {Money(reste)} FCFA";
        }

        void PrintSeddo()
        {
            if (rows.Count == 0) { MessageBox.Show("Aucune opération Seddo sur cette période.", "SANKHÉ — Rapport Seddo", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            using var doc = new PrintDocument();
            doc.DocumentName = "Rapport des opérations Seddo";
            doc.DefaultPageSettings.Landscape = true;
            doc.DefaultPageSettings.Margins = new Margins(35, 35, 35, 35);
            int page = 0; const int perPage = 18;
            doc.PrintPage += (_, e) =>
            {
                RenderSeddoReport(e.Graphics!, e.MarginBounds, rows, start.Value.Date, end.Value.Date.AddDays(1), page, perPage);
                page++; e.HasMorePages = page * perPage < rows.Count;
            };
            using var pd = new PrintDialog { Document = doc, UseEXDialog = true };
            if (pd.ShowDialog(d) == DialogResult.OK) doc.Print();
        }

        void SaveSeddoPdf()
        {
            if (rows.Count == 0) { MessageBox.Show("Aucune opération Seddo sur cette période.", "SANKHÉ — Rapport Seddo", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            using var dlg = new SaveFileDialog { Title = "Enregistrer le rapport Seddo PDF", Filter = "Document PDF (*.pdf)|*.pdf", FileName = $"Rapport_Seddo_{start.Value:yyyyMMdd}_{end.Value:yyyyMMdd}.pdf", AddExtension = true, DefaultExt = "pdf" };
            if (dlg.ShowDialog(d) != DialogResult.OK) return;
            const int perPage = 16; int pages = Math.Max(1, (int)Math.Ceiling(rows.Count / (double)perPage)); var jpegPages = new List<byte[]>();
            for (int p = 0; p < pages; p++) using (var bmp = RenderSeddoReportPage(rows, start.Value.Date, end.Value.Date.AddDays(1), p, perPage)) jpegPages.Add(BitmapToJpeg(bmp));
            WriteJpegPagesPdf(dlg.FileName, jpegPages);
            MessageBox.Show("Rapport Seddo PDF créé avec la même mise en page que l’impression.", "SANKHÉ — Rapport Seddo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        refresh.Click += (_, _) => LoadRows(); print.Click += (_, _) => PrintSeddo(); pdf.Click += (_, _) => SaveSeddoPdf(); close.Click += (_, _) => d.Close();
        LoadRows(); d.ShowDialog(this);
    }

    Bitmap RenderSeddoReportPage(List<Database.SeddoReportRow> rows, DateTime start, DateTime endExclusive, int pageIndex, int rowsPerPage)
    {
        var bmp = new Bitmap(1600, 1100, PixelFormat.Format24bppRgb);
        using var g = Graphics.FromImage(bmp); g.Clear(Color.White);
        RenderSeddoReport(g, new Rectangle(55, 45, 1490, 1010), rows, start, endExclusive, pageIndex, rowsPerPage);
        return bmp;
    }

    void RenderSeddoReport(Graphics g, Rectangle b, List<Database.SeddoReportRow> rows, DateTime start, DateTime endExclusive, int pageIndex, int rowsPerPage)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        Color navy = Color.FromArgb(16,43,79), blue = Color.FromArgb(28,83,145), gold = Color.FromArgb(236,174,45), line = Color.FromArgb(205,213,223), pale = Color.FromArgb(246,248,251);
        using var white = new SolidBrush(Color.White); using var navyBrush = new SolidBrush(navy); using var blueBrush = new SolidBrush(blue); using var goldBrush = new SolidBrush(gold); using var paleBrush = new SolidBrush(pale); using var gray = new SolidBrush(Color.FromArgb(90,100,115)); using var pen = new Pen(line, .8f);
        using var company = new Font("Segoe UI", 18, FontStyle.Bold); using var title = new Font("Segoe UI", 16, FontStyle.Bold); using var sub = new Font("Segoe UI", 8.5f); using var head = new Font("Segoe UI", 8, FontStyle.Bold); using var body = new Font("Segoe UI", 8); using var totalFont = new Font("Segoe UI", 9, FontStyle.Bold);
        float left=b.Left, top=b.Top, width=b.Width;
        g.FillRectangle(navyBrush,left,top,width,68);
        g.DrawString("Sankhe & Frères",company,white,left+16,top+8);
        g.DrawString("TRANSFERT D’ARGENT • RAPPORT SEDDO",sub,goldBrush,left+17,top+40);
        g.DrawString($"Gérant : {GetManagerName()}", sub, white, left + 250, top + 42);
        top += 78;
        g.DrawString("RC : SN LGA 2015 - A - 568   •   NINEA : 005597333/20",sub,gray,left,top); top+=13;
        g.DrawString("Tél : 77 519 57 75 - 70 811 04 04   •   DAHRA - SENEGAL   •   Email : sankhebaba@gmail.com",sub,gray,left,top); top+=24;
        string t="RAPPORT DES OPÉRATIONS SEDDO"; var ts=g.MeasureString(t,title); g.DrawString(t,title,navyBrush,left+(width-ts.Width)/2,top); top+=27;
        string f=$"Période : {start:dd/MM/yyyy} au {endExclusive.AddDays(-1):dd/MM/yyyy}   •   Heure incluse : Oui"; var fs=g.MeasureString(f,sub); g.DrawString(f,sub,gray,left+(width-fs.Width)/2,top); top+=22;

        string[] heads={"DATE / HEURE","CLIENT","MONTANT","COMM. / TAUX","TOTAL DÉBITÉ","CAISSE DE DÉPÔT","STATUT","RESTANT","RÉFÉRENCE","DESCRIPTION"};
        float[] ws={115,155,105,110,120,235,90,105,115,235};
        float scale=Math.Min(1f,width/ws.Sum()); for(int i=0;i<ws.Length;i++) ws[i]*=scale;
        float tw=ws.Sum(), x0=left+(width-tw)/2;
        g.FillRectangle(blueBrush,x0,top,tw,28); float x=x0;
        for(int i=0;i<heads.Length;i++){ g.DrawRectangle(Pens.White,x,top,ws[i],28); using var sf=new StringFormat{Alignment=StringAlignment.Center,LineAlignment=StringAlignment.Center,Trimming=StringTrimming.EllipsisCharacter}; g.DrawString(heads[i],head,white,new RectangleF(x+2,top+2,ws[i]-4,24),sf); x+=ws[i]; }
        top+=28;

        int si=pageIndex*rowsPerPage, ei=Math.Min(rows.Count,si+rowsPerPage);
        for(int i=si;i<ei;i++)
        {
            var r=rows[i]; float rh=36;
            if((i-si)%2==1) g.FillRectangle(paleBrush,x0,top,tw,rh);
            string[] vals={r.DateOperation,r.ClientNom,Money(r.Montant),Money(r.Commission),Money(r.Total),r.CaissesDescription,r.Statut,Money(r.Restant),r.Reference,r.Description};
            x=x0;
            for(int j=0;j<vals.Length;j++)
            {
                g.DrawRectangle(pen,x,top,ws[j],rh);
                using var sf=new StringFormat{Alignment=(j>=2&&j<=4)||j==7?StringAlignment.Far:StringAlignment.Near,LineAlignment=StringAlignment.Center,Trimming=StringTrimming.EllipsisCharacter};
                Brush br = j==5 ? new SolidBrush(Color.FromArgb(0,105,190)) : (j==6 && r.Statut.Contains("Pay",StringComparison.OrdinalIgnoreCase) ? new SolidBrush(Color.FromArgb(0,145,105)) : Brushes.Black);
                g.DrawString(TruncateText(vals[j], j==5?38:j==9?42:24), body, br, new RectangleF(x+4,top+2,ws[j]-8,rh-4), sf);
                if(br!=Brushes.Black) br.Dispose(); x+=ws[j];
            }
            top+=rh;
        }

        if(pageIndex==Math.Max(0,(int)Math.Ceiling(rows.Count/(double)rowsPerPage)-1))
        {
            top+=12;
            decimal wave=rows.Sum(r=>r.CaisseWave), orange=rows.Sum(r=>r.CaisseOrange), general=rows.Sum(r=>r.CaisseGenerale), seddo=rows.Sum(r=>r.CaisseSeddoSortie);
            decimal total=rows.Sum(r=>r.Total), comm=rows.Sum(r=>r.Commission), reste=rows.Sum(r=>r.Restant);
            float bw=(tw-30)/4f;
            string[] labs={"WAVE TOTAL","ORANGE MONEY TOTAL","CAISSE EN ESPÈCE","SORTIES CAISSE SEDDO"};
            string[] vs={Money(wave),Money(orange),Money(general),Money(seddo)};
            for(int i=0;i<4;i++){float bx=x0+i*(bw+10);g.FillRectangle(i==2?goldBrush:paleBrush,bx,top,bw,50);g.DrawRectangle(pen,bx,top,bw,50);g.DrawString(labs[i],head,i==2?white:blueBrush,bx+8,top+7);g.DrawString(vs[i]+" FCFA",totalFont,i==2?white:navyBrush,bx+8,top+25);}
            top+=62;
            g.DrawString($"TOTAL OPÉRATIONS : {Money(total)} FCFA   •   COMMISSIONS : {Money(comm)} FCFA   •   RESTANT À ENCAISSER : {Money(reste)} FCFA",totalFont,navyBrush,x0,top);
        }
        g.DrawString("SANKHÉ TRANSFERT D’ARGENT  •  Rapport Seddo imprimable",sub,gray,left,b.Bottom-18);
    }

    void ShowTransferReportDialog(DateTime defaultStart, DateTime defaultEndExclusive)
    {
        var rows = Database.GetCaisseTransfers(defaultStart, defaultEndExclusive);
        using var d = new Form
        {
            Text = "Rapport des virements entre caisses", Width = 1160, Height = 700,
            StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(8, 20, 39),
            FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false
        };
        var title = new Label { Text = "⇄ RAPPORT DES VIREMENTS ENTRE CAISSES", Left = 24, Top = 18, AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 18, FontStyle.Bold) };
        var start = new DateTimePicker { Left = 24, Top = 64, Width = 145, Value = defaultStart.Date, Format = DateTimePickerFormat.Short };
        var end = new DateTimePicker { Left = 180, Top = 64, Width = 145, Value = defaultEndExclusive.AddDays(-1).Date, Format = DateTimePickerFormat.Short };
        var source = new ComboBox { Left = 340, Top = 64, Width = 190, DropDownStyle = ComboBoxStyle.DropDownList };
        source.Items.AddRange(new object[] { "Toutes les sources", "Caisse en espèce", "Caisse Wave", "Caisse Orange Money", "Caisse Seddo" }); source.SelectedIndex = 0;
        var destination = new ComboBox { Left = 545, Top = 64, Width = 210, DropDownStyle = ComboBoxStyle.DropDownList };
        destination.Items.AddRange(new object[] { "Toutes les destinations", "Caisse en espèce", "Caisse Wave", "Caisse Orange Money", "Caisse Seddo" }); destination.SelectedIndex = 0;
        var refresh = new Button { Text = "AFFICHER", Left = 770, Top = 62, Width = 110, Height = 34, BackColor = Color.FromArgb(0,155,225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI",9,FontStyle.Bold) };
        var print = new Button { Text = "🖨 IMPRIMER", Left = 890, Top = 62, Width = 115, Height = 34, BackColor = Color.FromArgb(0,190,110), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI",9,FontStyle.Bold) };
        var pdf = new Button { Text = "📄 PDF", Left = 1015, Top = 62, Width = 90, Height = 34, BackColor = Color.FromArgb(220,145,25), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI",9,FontStyle.Bold) };
        foreach(var b in new[]{refresh,print,pdf}) b.FlatAppearance.BorderSize=0;
        var grid = new DataGridView { Left=24, Top=112, Width=1080, Height=480, Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right, ReadOnly=true, AllowUserToAddRows=false, RowHeadersVisible=false, AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill, BackgroundColor=Color.White, BorderStyle=BorderStyle.None, SelectionMode=DataGridViewSelectionMode.FullRowSelect };
        grid.Columns.Add("Date","Date / Heure"); grid.Columns.Add("Source","Source"); grid.Columns.Add("Destination","Destination"); grid.Columns.Add("Montant","Montant"); grid.Columns.Add("Motif","Motif"); grid.Columns.Add("Reference","Référence");
        var summary = new Label { Left=24, Top=604, Width=1080, Height=30, Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right, ForeColor=Color.White, Font=new Font("Segoe UI",10,FontStyle.Bold), TextAlign=ContentAlignment.MiddleLeft };
        d.Controls.AddRange(new Control[]{title,start,end,source,destination,refresh,print,pdf,grid,summary});

        List<Database.CaisseTransferRow> current = new();
        string MapCaisse(string text) => text == "Caisse en espèce" ? "Caisse" : text;
        void Load()
        {
            var s = source.SelectedIndex == 0 ? "" : MapCaisse(source.Text);
            var dest = destination.SelectedIndex == 0 ? "" : MapCaisse(destination.Text);
            var endEx = end.Value.Date.AddDays(1);
            current = Database.GetCaisseTransfers(start.Value.Date, endEx, s, dest);
            grid.Rows.Clear(); decimal total=0;
            foreach(var r in current) { grid.Rows.Add(r.DateMouvement, r.Source=="Caisse"?"Caisse en espèce":r.Source, r.Destination=="Caisse"?"Caisse en espèce":r.Destination, Money(r.Montant), r.Motif, r.Reference); total += r.Montant; }
            summary.Text = $"{current.Count} virement(s)   •   Total transféré : {Money(total)} FCFA   •   Gérant : {GetManagerName()}";
        }
        void PrintRows(List<Database.CaisseTransferRow> data)
        {
            if(data.Count==0){MessageBox.Show("Aucun virement trouvé sur la période sélectionnée.","SANKHÉ — Virements");return;}
            using var doc=new PrintDocument(); doc.DocumentName="Rapport des virements entre caisses";
            doc.PrintPage += (_,e)=>{
                var g=e.Graphics!; using var titleFont=new Font("Segoe UI",15,FontStyle.Bold); using var font=new Font("Segoe UI",8.5f); using var bold=new Font("Segoe UI",9,FontStyle.Bold);
                g.DrawString("SANKHÉ TRANSFERT D’ARGENT — RAPPORT DES VIREMENTS",titleFont,Brushes.Black,40,35);
                g.DrawString($"Gérant : {GetManagerName()}",font,Brushes.Black,40,60);
                g.DrawString($"Période : {start.Value:dd/MM/yyyy} au {end.Value:dd/MM/yyyy}    Imprimé le {DateTime.Now:dd/MM/yyyy HH:mm}",font,Brushes.Black,40,78);
                var y=110; g.DrawString("Date / Heure",bold,Brushes.Black,40,y); g.DrawString("Source",bold,Brushes.Black,155,y); g.DrawString("Destination",bold,Brushes.Black,275,y); g.DrawString("Montant",bold,Brushes.Black,415,y); g.DrawString("Référence",bold,Brushes.Black,520,y); g.DrawString("Motif",bold,Brushes.Black,650,y); y+=24;
                int i=0; foreach(var r in data){ g.DrawString(r.DateMouvement,font,Brushes.Black,40,y); g.DrawString(r.Source=="Caisse"?"Caisse en espèce":r.Source,font,Brushes.Black,155,y); g.DrawString(r.Destination=="Caisse"?"Caisse en espèce":r.Destination,font,Brushes.Black,275,y); g.DrawString(Money(r.Montant)+" FCFA",font,Brushes.Black,415,y); g.DrawString(r.Reference,font,Brushes.Black,520,y); g.DrawString(r.Motif,font,Brushes.Black,650,y); y+=18; i++; if(y>e.PageBounds.Height-45){e.HasMorePages=i<data.Count; break;} }
                if(!e.HasMorePages){g.DrawString($"Total des virements : {Money(data.Sum(x=>x.Montant))} FCFA",bold,Brushes.Black,40,e.PageBounds.Height-35);}
            }; using var dlg=new PrintDialog{Document=doc,UseEXDialog=true}; if(dlg.ShowDialog(this)==DialogResult.OK) doc.Print();
        }
        void SavePdf(List<Database.CaisseTransferRow> data)
        {
            if(data.Count==0){MessageBox.Show("Aucun virement à exporter.","SANKHÉ — Virements");return;}
            using var dlg=new SaveFileDialog{Title="Enregistrer le rapport des virements PDF",Filter="Document PDF (*.pdf)|*.pdf",FileName=$"Rapport_Virements_Caisses_{start.Value:yyyyMMdd}_{end.Value:yyyyMMdd}.pdf",AddExtension=true,DefaultExt="pdf"};
            if(dlg.ShowDialog(this)!=DialogResult.OK)return;
            using var bmp=new Bitmap(1400,900); using(var g=Graphics.FromImage(bmp)){g.Clear(Color.White); using var titleFont=new Font("Segoe UI",22,FontStyle.Bold); using var font=new Font("Segoe UI",11); using var bold=new Font("Segoe UI",11,FontStyle.Bold); g.DrawString("SANKHÉ TRANSFERT D’ARGENT — RAPPORT DES VIREMENTS",titleFont,Brushes.Black,45,35); g.DrawString($"Gérant : {GetManagerName()}   •   Période : {start.Value:dd/MM/yyyy} au {end.Value:dd/MM/yyyy}",font,Brushes.Black,45,78); int y=125; g.DrawString("Date / Heure",bold,Brushes.Black,45,y);g.DrawString("Source",bold,Brushes.Black,220,y);g.DrawString("Destination",bold,Brushes.Black,410,y);g.DrawString("Montant",bold,Brushes.Black,610,y);g.DrawString("Référence",bold,Brushes.Black,790,y); y+=30; foreach(var r in data){g.DrawString(r.DateMouvement,font,Brushes.Black,45,y);g.DrawString(r.Source=="Caisse"?"Caisse en espèce":r.Source,font,Brushes.Black,220,y);g.DrawString(r.Destination=="Caisse"?"Caisse en espèce":r.Destination,font,Brushes.Black,410,y);g.DrawString(Money(r.Montant)+" FCFA",font,Brushes.Black,610,y);g.DrawString(r.Reference,font,Brushes.Black,790,y);y+=24;if(y>840)break;}g.DrawString($"Total : {Money(data.Sum(x=>x.Montant))} FCFA",bold,Brushes.Black,45,850); } WriteJpegPagesPdf(dlg.FileName,new List<byte[]>{BitmapToJpeg(bmp)}); MessageBox.Show("Rapport des virements PDF créé.","SANKHÉ",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
        refresh.Click += (_,_)=>Load(); print.Click += (_,_)=>PrintRows(current); pdf.Click += (_,_)=>SavePdf(current); Load();
        d.ShowDialog(this);
    }

    static void AddBoutiqueReportRow(List<Database.OperationRow> rows, string typeFilter, string operationType, string date, decimal amount, string clientLabel, Database.BoutiqueSessionRow session, string observation)
    {
        if (amount <= 0) return;
        if (!string.IsNullOrWhiteSpace(typeFilter) && !string.Equals(typeFilter, operationType, StringComparison.OrdinalIgnoreCase)) return;
        rows.Add(new Database.OperationRow(date, "Boutique", operationType, clientLabel, session.Telephone, amount, 0, 0, $"Boutique session {session.Id}", observation, session.Id));
    }

    void ShowIndividualClientReport(DateTime rangeStart, DateTime rangeEnd)
    {
        var clients = Database.GetClients();
        if (clients.Count == 0)
        {
            MessageBox.Show("Aucun client enregistré dans la base de données.", "SANKHÉ — Rapport client", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var dialog = new Form
        {
            Text = "Rapport individuel client",
            Width = 560, Height = 235,
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false, MinimizeBox = false,
            BackColor = Color.FromArgb(8, 27, 52)
        };
        var title = new Label { Text = "👤 RAPPORT INDIVIDUEL CLIENT", Left = 24, Top = 18, Width = 490, Height = 32, ForeColor = Color.White, Font = new Font("Segoe UI", 15, FontStyle.Bold) };
        var label = new Label { Text = "Sélectionner le client :", Left = 24, Top = 66, Width = 180, Height = 28, ForeColor = Color.FromArgb(210,225,245), Font = new Font("Segoe UI", 10, FontStyle.Bold) };
        // Recherche client rapide : le champ est saisissable. Il suffit de taper
        // le début du prénom ou du nom pour faire apparaître les clients correspondants.
        var combo = new ComboBox
        {
            Left = 205, Top = 62, Width = 310, Height = 32,
            DropDownStyle = ComboBoxStyle.DropDown, Font = new Font("Segoe UI", 10),
            AutoCompleteMode = AutoCompleteMode.SuggestAppend,
            AutoCompleteSource = AutoCompleteSource.CustomSource
        };
        combo.DisplayMember = nameof(Database.ClientRow.Nom);
        foreach (var c in clients) combo.Items.Add(c);
        var clientNames = new AutoCompleteStringCollection();
        foreach (var c in clients)
            if (!string.IsNullOrWhiteSpace(c.Nom)) clientNames.Add(c.Nom);
        combo.AutoCompleteCustomSource = clientNames;
        combo.SelectedIndex = 0;

        bool updatingClientSearch = false;
        combo.TextChanged += (_, _) =>
        {
            if (updatingClientSearch) return;
            var q = NormalizeSearch(combo.Text);
            if (string.IsNullOrWhiteSpace(q)) return;

            // Recherche sur le début du prénom/nom (et pas uniquement sur le nom complet).
            var match = clients.FirstOrDefault(c =>
            {
                var normalized = NormalizeSearch(c.Nom);
                if (normalized.StartsWith(q, StringComparison.OrdinalIgnoreCase)) return true;
                return normalized.Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .Any(part => part.StartsWith(q, StringComparison.OrdinalIgnoreCase));
            });

            if (match is not null)
            {
                updatingClientSearch = true;
                combo.SelectedItem = match;
                combo.Text = match.Nom;
                combo.SelectionStart = combo.Text.Length;
                combo.SelectionLength = 0;
                updatingClientSearch = false;
            }
            if (combo.DroppedDown == false) combo.DroppedDown = true;
        };
        combo.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter && combo.SelectedItem is not Database.ClientRow)
            {
                var q = NormalizeSearch(combo.Text);
                var match = clients.FirstOrDefault(c => NormalizeSearch(c.Nom).StartsWith(q, StringComparison.OrdinalIgnoreCase) ||
                    NormalizeSearch(c.Nom).Split(' ', StringSplitOptions.RemoveEmptyEntries).Any(part => part.StartsWith(q, StringComparison.OrdinalIgnoreCase)));
                if (match is not null)
                {
                    combo.SelectedItem = match;
                    e.SuppressKeyPress = true;
                }
            }
        };
        var print = new Button { Text = "🖨 IMPRIMER LE RAPPORT", Left = 205, Top = 112, Width = 200, Height = 38, BackColor = Color.FromArgb(0,190,110), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var cancel = new Button { Text = "ANNULER", Left = 415, Top = 112, Width = 100, Height = 38, BackColor = Color.FromArgb(55,72,100), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        print.FlatAppearance.BorderSize = cancel.FlatAppearance.BorderSize = 0;
        dialog.Controls.AddRange(new Control[] { title, label, combo, print, cancel });
        cancel.Click += (_, _) => dialog.Close();
        print.Click += (_, _) =>
        {
            if (combo.SelectedItem is not Database.ClientRow client) return;
            var all = Database.GetOperationsReport("", "", rangeStart, rangeEnd);
            var rows = all.Where(o => NormalizeSearch(o.ClientNom) == NormalizeSearch(client.Nom)).ToList();
            if (rows.Count == 0)
            {
                MessageBox.Show($"Aucune opération trouvée pour {client.Nom} sur la période sélectionnée.", "SANKHÉ — Rapport client", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            dialog.Hide();
            PrintIndividualClientReport(client, rows, rangeStart, rangeEnd);
            dialog.Close();
        };
        dialog.ShowDialog(this);
    }

    void PrintIndividualClientReport(Database.ClientRow client, List<Database.OperationRow> rows, DateTime start, DateTime endExclusive)
    {
        using var dialog = new PrintDialog();
        using var doc = new PrintDocument();
        doc.DocumentName = $"Rapport client - {client.Nom}";
        doc.DefaultPageSettings.Landscape = false;
        doc.DefaultPageSettings.Margins = new Margins(42, 42, 42, 42);

        int page = 0;
        const int rowsPerPage = 20;
        string logoPath = Path.Combine(Application.StartupPath, "Assets", "sankhe_logo_header.png");

        doc.PrintPage += (_, e) =>
        {
            var g = e.Graphics ?? throw new InvalidOperationException("Le contexte graphique d'impression est indisponible.");
            var b = e.MarginBounds;
            float left = b.Left, right = b.Right, y = b.Top;
            float pageWidth = b.Width;
            Color navy = Color.FromArgb(16, 43, 79);
            Color blue = Color.FromArgb(28, 83, 145);
            Color gold = Color.FromArgb(236, 174, 45);
            Color light = Color.FromArgb(245, 247, 250);
            Color line = Color.FromArgb(205, 213, 223);
            Color green = Color.FromArgb(22, 145, 92);
            Color red = Color.FromArgb(205, 60, 60);

            using var companyFont = new Font("Segoe UI", 18, FontStyle.Bold);
            using var subFont = new Font("Segoe UI", 8.5f);
            using var titleFont = new Font("Segoe UI", 17, FontStyle.Bold);
            using var infoBold = new Font("Segoe UI", 9, FontStyle.Bold);
            using var infoFont = new Font("Segoe UI", 8.5f);
            using var headFont = new Font("Segoe UI", 7.5f, FontStyle.Bold);
            using var bodyFont = new Font("Segoe UI", 7.2f);
            using var totalFont = new Font("Segoe UI", 8.8f, FontStyle.Bold);
            using var footerFont = new Font("Segoe UI", 7.2f);
            using var navyBrush = new SolidBrush(navy);
            using var blueBrush = new SolidBrush(blue);
            using var goldBrush = new SolidBrush(gold);
            using var lightBrush = new SolidBrush(light);
            using var whiteBrush = new SolidBrush(Color.White);
            using var grayBrush = new SolidBrush(Color.FromArgb(90, 100, 115));
            using var linePen = new Pen(line, 0.8f);

            // Bandeau supérieur façon facture professionnelle.
            g.FillRectangle(navyBrush, left, y, pageWidth, 76);
            float logoW = 92, logoH = 52;
            if (File.Exists(logoPath))
            {
                using var logo = Image.FromFile(logoPath);
                float scale = Math.Min(logoW / logo.Width, logoH / logo.Height);
                float lw = logo.Width * scale, lh = logo.Height * scale;
                g.DrawImage(logo, right - lw - 12, y + (76 - lh) / 2, lw, lh);
            }
            g.DrawString("Sankhe & Frères", companyFont, whiteBrush, left + 18, y + 10);
            g.DrawString("TRANSFERT D’ARGENT", new Font("Segoe UI", 8.5f, FontStyle.Bold), goldBrush, left + 19, y + 39);
            g.DrawString($"Gérant : {GetManagerName()}", subFont, whiteBrush, left + 210, y + 42);
            y += 88;

            // Coordonnées société.
            g.DrawString("RC : SN LGA 2015 - A - 568   •   NINEA : 005597333/20", subFont, grayBrush, left, y); y += 14;
            g.DrawString("Tél : 77 519 57 75 - 70 811 04 04   •   DAHRA - SENEGAL", subFont, grayBrush, left, y); y += 14;
            g.DrawString("Email : sankhebaba@gmail.com", subFont, grayBrush, left, y); y += 23;

            // Titre central.
            g.FillRectangle(goldBrush, left + pageWidth * .30f, y, pageWidth * .40f, 4); y += 10;
            string title = "FACTURE / RAPPORT CLIENT";
            var ts = g.MeasureString(title, titleFont);
            g.DrawString(title, titleFont, navyBrush, left + (pageWidth - ts.Width) / 2, y); y += 30;
            string dateText = $"Édité le {DateTime.Now:dd/MM/yyyy HH:mm}";
            var ds = g.MeasureString(dateText, subFont);
            g.DrawString(dateText, subFont, grayBrush, left + (pageWidth - ds.Width) / 2, y); y += 23;

            // Bloc client et période.
            float infoH = 76;
            g.FillRectangle(lightBrush, left, y, pageWidth, infoH);
            g.DrawRectangle(linePen, left, y, pageWidth, infoH);
            g.DrawString("FACTURÉ À", infoBold, blueBrush, left + 14, y + 10);
            g.DrawString(client.Nom, new Font("Segoe UI", 11, FontStyle.Bold), navyBrush, left + 14, y + 28);
            g.DrawString($"Téléphone : {client.Telephone}", infoFont, grayBrush, left + 14, y + 48);
            float rightCol = left + pageWidth * .57f;
            g.DrawString("PÉRIODE", infoBold, blueBrush, rightCol, y + 10);
            g.DrawString($"Du {start:dd/MM/yyyy} au {endExclusive.AddDays(-1):dd/MM/yyyy}", infoFont, navyBrush, rightCol, y + 30);
            g.DrawString($"N° opérations : {rows.Count}", infoFont, grayBrush, rightCol, y + 49);
            y += infoH + 16;

            // Tableau facture.
            string[] heads = { "N°", "DATE", "SERVICE", "DESCRIPTION", "MONTANT", "COMM.", "DETTE", "STATUT" };
            float[] widths = { 28, 62, 68, 250, 72, 58, 62, 72 };
            float sum = widths.Sum();
            float scaleTable = Math.Min(1f, pageWidth / sum);
            if (scaleTable < 1f) for (int i = 0; i < widths.Length; i++) widths[i] *= scaleTable;
            float tableW = widths.Sum();
            float tableLeft = left + (pageWidth - tableW) / 2;
            using var headerBrush = new SolidBrush(navy);
            g.FillRectangle(headerBrush, tableLeft, y, tableW, 28);
            float x = tableLeft;
            for (int i = 0; i < heads.Length; i++)
            {
                g.DrawRectangle(Pens.White, x, y, widths[i], 28);
                var sfh = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                g.DrawString(heads[i], headFont, whiteBrush, new RectangleF(x + 2, y + 2, widths[i] - 4, 24), sfh);
                sfh.Dispose(); x += widths[i];
            }
            y += 28;
            g.DrawRectangle(linePen, tableLeft, y - 28, tableW, 28);

            int startIndex = page * rowsPerPage;
            int endIndex = Math.Min(rows.Count, startIndex + rowsPerPage);
            var cache = new Dictionary<string, Database.DebtReportStatus?>();
            for (int i = startIndex; i < endIndex; i++)
            {
                var op = rows[i];
                float rh = 42;
                if ((i - startIndex) % 2 == 1) g.FillRectangle(lightBrush, tableLeft, y, tableW, rh);
                var debtInfo = GetReportDebtStatus(op, cache);
                string status = debtInfo?.Statut ?? "—";
                string reportService = GetReportService(op, debtInfo);
                string[] vals = { (i + 1).ToString(), op.DateOperation, reportService, GetReportDescription(op), Money(op.Montant), Money(op.Commission), Money(op.Dette), status };
                x = tableLeft;
                for (int j = 0; j < vals.Length; j++)
                {
                    g.DrawRectangle(linePen, x, y, widths[j], rh);
                    var sf = new StringFormat
                    {
                        Trimming = StringTrimming.EllipsisCharacter,
                        Alignment = j == 0 || j >= 4 ? StringAlignment.Center : StringAlignment.Near,
                        LineAlignment = StringAlignment.Center
                    };
                    Brush br = (j == 7 && status == "Soldée") ? new SolidBrush(green) :
                               (j == 7 && status == "Non soldée") ? new SolidBrush(red) : Brushes.Black;
                    g.DrawString(vals[j], bodyFont, br, new RectangleF(x + 3, y + 2, widths[j] - 6, rh - 4), sf);
                    if (br != Brushes.Black && br != Brushes.White) br.Dispose();
                    sf.Dispose(); x += widths[j];
                }
                y += rh;
            }

            page++;
            e.HasMorePages = page * rowsPerPage < rows.Count;
            if (!e.HasMorePages)
            {
                y += 18;
                decimal total = rows.Sum(r => r.Montant);
                decimal comm = rows.Sum(r => r.Commission);
                decimal debt = rows.Sum(r => r.Dette);
                var infos = rows.Select(r => GetReportDebtStatus(r, cache)).Where(v => v is not null).Cast<Database.DebtReportStatus>().GroupBy(v => v.Id).Select(g => g.First()).ToList();
                int sold = infos.Count(v => v.Statut == "Soldée");
                int non = infos.Count(v => v.Statut == "Non soldée");
                decimal remaining = infos.Where(v => v.Statut == "Non soldée").Sum(v => v.MontantRestant);

                float boxW = pageWidth / 3f - 8;
                string[] labels = { "TOTAL OPÉRATIONS", "MONTANT TOTAL", "COMMISSION" };
                string[] values = { rows.Count.ToString(), Money(total), Money(comm) };
                for (int i = 0; i < 3; i++)
                {
                    float bx = left + i * (boxW + 12);
                    g.FillRectangle(i == 1 ? goldBrush : lightBrush, bx, y, boxW, 50);
                    g.DrawRectangle(linePen, bx, y, boxW, 50);
                    var labBrush = i == 1 ? Brushes.White : blueBrush;
                    var valBrush = i == 1 ? Brushes.White : navyBrush;
                    g.DrawString(labels[i], new Font("Segoe UI", 7.5f, FontStyle.Bold), labBrush, bx + 9, y + 7);
                    g.DrawString(values[i], totalFont, valBrush, bx + 9, y + 25);
                }
                y += 63;
                g.FillRectangle(navyBrush, left, y, pageWidth, 34);
                g.DrawString($"DETTES : {infos.Count}   •   SOLDÉES : {sold}   •   NON SOLDÉES : {non}   •   RESTANT : {Money(remaining)}", new Font("Segoe UI", 8.2f, FontStyle.Bold), whiteBrush, left + 12, y + 9);
                y += 48;
            }

            // Pied de page sur chaque page.
            float footerY = b.Bottom + 9;
            g.DrawLine(new Pen(gold, 2), left, footerY, right, footerY);
            g.DrawString("SANKHÉ TRANSFERT D’ARGENT  •  Document professionnel", footerFont, grayBrush, left, footerY + 5);
            string pg = $"Page {page}";
            var pgSize = g.MeasureString(pg, footerFont);
            g.DrawString(pg, footerFont, grayBrush, right - pgSize.Width, footerY + 5);
        };

        dialog.Document = doc;
        if (dialog.ShowDialog(this) == DialogResult.OK) doc.Print();
    }

    static string NormalizeSearch(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        var normalized = value.Trim().Normalize(NormalizationForm.FormD);
        var chars = normalized.Where(c => System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c) != System.Globalization.UnicodeCategory.NonSpacingMark);
        return new string(chars.ToArray()).ToLowerInvariant();
    }

    static Database.DebtReportStatus? GetReportDebtStatus(Database.OperationRow op, Dictionary<string, Database.DebtReportStatus?> cache)
    {
        if (!string.Equals(op.TypeOperation, "Transfert", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(op.TypeOperation, "Envoi", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(op.TypeOperation, "Rééquilibrage", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(op.TypeOperation, "Remboursement dette", StringComparison.OrdinalIgnoreCase))
            return null;
        // Chaque transfert/envoi doit être relié à SA propre dette.
        // L'ancien couple ClientNom|Reference pouvait pointer vers la dette
        // du dernier transfert lorsque plusieurs opérations partageaient
        // la même référence (ou une référence vide).
        var key = op.Id > 0 ? $"op:{op.Id}" : $"{op.ClientNom}|{op.Reference}";
        if (cache.TryGetValue(key, out var cached)) return cached;
        var result = Database.GetDebtReportStatus(op.Id, op.ClientNom, op.Reference, op.Observation);
        cache[key] = result;
        return result;
    }

    static string GetReportService(Database.OperationRow op, Database.DebtReportStatus? debtInfo)
    {
        // La colonne SERVICE indique toujours le service d'origine de l'opération.
        // Le moyen/caisse ayant servi au remboursement est affiché séparément
        // dans la colonne CAISSE REMB.
        return op.Service ?? "";
    }

    static string GetReportSettlementService(Database.OperationRow op, Database.DebtReportStatus? debtInfo)
    {
        if (debtInfo is null) return "—";
        if (!string.Equals(op.TypeOperation, "Transfert", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(op.TypeOperation, "Envoi", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(op.TypeOperation, "Rééquilibrage", StringComparison.OrdinalIgnoreCase))
            return "—";

        var settlement = debtInfo.SettlementService?.Trim() ?? "";
        if (string.IsNullOrWhiteSpace(settlement)) return "—";
        return string.Equals(settlement, "Caisse", StringComparison.OrdinalIgnoreCase)
            ? "Caisse en espèce"
            : settlement;
    }

    static string GetServiceRemboursement(Database.OperationRow op)
    {
        if (!string.Equals(op.TypeOperation, "Remboursement dette", StringComparison.OrdinalIgnoreCase)) return "";
        const string marker = "Moyen :";
        var obs = op.Observation ?? "";
        var pos = obs.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
        if (pos < 0) return "";
        var value = obs[(pos + marker.Length)..].Trim();
        var sep = value.IndexOf(" — ", StringComparison.Ordinal);
        if (sep >= 0) value = value[..sep].Trim();
        return value switch
        {
            "Caisse" => "Caisse en espèce",
            "Caisse Wave" => "Caisse Wave",
            "Caisse Orange Money" => "Caisse Orange Money",
            // Seddo n'intervient jamais dans le règlement des dettes.
            "Caisse Seddo" => "",
            _ => value
        };
    }

    static string GetReportDescription(Database.OperationRow op)
    {
        if (string.Equals(op.Service, "Seddo", StringComparison.OrdinalIgnoreCase))
        {
            var caisseDesc = Database.GetSeddoCaisseDescription(op.Id);
            return string.IsNullOrWhiteSpace(caisseDesc) ? "Seddo" : $"Seddo — {caisseDesc}";
        }

        // Pour un échange, afficher le sens exact du mouvement dans tous les rapports.
        // La direction est conservée dans Observation (ex. « Échange Wave vers Orange Money »).
        if (string.Equals(op.TypeOperation, "Échange", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(op.TypeOperation, "Echange", StringComparison.OrdinalIgnoreCase))
        {
            var exchangeDescription = (op.Observation ?? "").Trim();
            if (exchangeDescription.Contains("Échange", StringComparison.OrdinalIgnoreCase) ||
                exchangeDescription.Contains("Echange", StringComparison.OrdinalIgnoreCase))
                return exchangeDescription;
            return "Échange — sens non précisé";
        }

        // Pour un rééquilibrage, le rapport doit toujours préciser le type
        // réellement effectué : Vente UV ou Achat UV. Le type est enregistré
        // dans Observation par AddReequilibrage().
        if (string.Equals(op.TypeOperation, "Rééquilibrage", StringComparison.OrdinalIgnoreCase))
        {
            var obs = (op.Observation ?? "").Trim();
            string type = "";
            if (string.Equals(obs, "Vente UV", StringComparison.OrdinalIgnoreCase)) type = "Vente UV";
            else if (string.Equals(obs, "Achat UV", StringComparison.OrdinalIgnoreCase)) type = "Achat UV";
            else if (obs.Contains("Vente UV", StringComparison.OrdinalIgnoreCase)) type = "Vente UV";
            else if (obs.Contains("Achat UV", StringComparison.OrdinalIgnoreCase)) type = "Achat UV";

            if (string.IsNullOrWhiteSpace(type))
                return "Rééquilibrage";

            // La description du rapport doit préciser le moyen de règlement de Vente UV.
            if (type == "Vente UV")
            {
                if (obs.Contains("Orange Money", StringComparison.OrdinalIgnoreCase))
                    return "Vente UV — réglée par Orange Money";
                if (obs.Contains("Espèces", StringComparison.OrdinalIgnoreCase) ||
                    obs.Contains("Especes", StringComparison.OrdinalIgnoreCase))
                    return "Vente UV — réglée par Espèces";
                if (obs.Contains("paiement différé", StringComparison.OrdinalIgnoreCase) ||
                    obs.Contains("dette", StringComparison.OrdinalIgnoreCase))
                    return "Vente UV — paiement différé (dette)";
                return "Vente UV — mode de règlement non précisé";
            }

            return $"Rééquilibrage — {type}";
        }

        if (!string.Equals(op.TypeOperation, "Remboursement dette", StringComparison.OrdinalIgnoreCase))
            return op.TypeOperation ?? "";

        var caisse = GetServiceRemboursement(op);
        var origin = Database.GetDebtOriginType(op.Observation);
        if (string.Equals(origin, "Vente UV", StringComparison.OrdinalIgnoreCase))
        {
            return string.IsNullOrWhiteSpace(caisse)
                ? "Remboursement dette — Vente UV"
                : $"Remboursement dette — {caisse} — Vente UV";
        }
        return string.IsNullOrWhiteSpace(caisse)
            ? "Remboursement dette"
            : $"Remboursement dette — {caisse}";
    }

    static string FormatRemboursementBreakdown(List<Database.OperationRow> rows)
    {
        var remboursements = rows.Where(x => string.Equals(x.TypeOperation, "Remboursement dette", StringComparison.OrdinalIgnoreCase)).ToList();
        if (remboursements.Count == 0) return "";
        var groups = remboursements
            .Select(x => new { Service = GetServiceRemboursement(x), x.Montant })
            .Where(x => !string.IsNullOrWhiteSpace(x.Service))
            .GroupBy(x => x.Service)
            .OrderBy(g => g.Key);
        return string.Join("    |    ", groups.Select(g => $"{g.Key} : {Money(g.Sum(x => x.Montant))}"));
    }

    void PrintReport(List<Database.OperationRow> rows, string service, string type, DateTime start, DateTime endExclusive)
    {
        using var dialog = new PrintDialog();
        using var doc = new PrintDocument();
        doc.DocumentName = $"Rapport Sankhé & Frères - {service} - {type}";
        doc.DefaultPageSettings.Landscape = true;
        doc.DefaultPageSettings.Margins = new Margins(38, 38, 38, 38);

        int page = 0;
        const int rowsPerPage = 22;
        string logoPath = Path.Combine(Application.StartupPath, "Assets", "sankhe_logo_header.png");

        doc.PrintPage += (_, e) =>
        {
            var g = e.Graphics ?? throw new InvalidOperationException("Le contexte graphique d'impression est indisponible.");
            var b = e.MarginBounds;
            float left = b.Left, right = b.Right, y = b.Top;
            float width = b.Width;
            Color navy = Color.FromArgb(16, 43, 79);
            Color blue = Color.FromArgb(28, 83, 145);
            Color gold = Color.FromArgb(236, 174, 45);
            Color light = Color.FromArgb(246, 248, 251);
            Color line = Color.FromArgb(205, 213, 223);

            using var whiteBrush = new SolidBrush(Color.White);
            using var navyBrush = new SolidBrush(navy);
            using var blueBrush = new SolidBrush(blue);
            using var goldBrush = new SolidBrush(gold);
            using var lightBrush = new SolidBrush(light);
            using var grayBrush = new SolidBrush(Color.FromArgb(90, 100, 115));
            using var linePen = new Pen(line, 1.15f);
            using var companyFont = new Font("Segoe UI", 18, FontStyle.Bold);
            using var titleFont = new Font("Segoe UI", 16, FontStyle.Bold);
            using var subFont = new Font("Segoe UI", 8.5f);
            using var infoFont = new Font("Segoe UI", 8.5f);
            using var headFont = new Font("Segoe UI", 7.6f, FontStyle.Bold);
            using var bodyFont = new Font("Segoe UI", 7.1f);
            using var totalFont = new Font("Segoe UI", 9, FontStyle.Bold);
            using var footerFont = new Font("Segoe UI", 7.2f);

            // Bandeau supérieur.
            g.FillRectangle(navyBrush, left, y, width, 72);
            if (File.Exists(logoPath))
            {
                using var logo = Image.FromFile(logoPath);
                float maxW = 105, maxH = 55, sc = Math.Min(maxW / logo.Width, maxH / logo.Height);
                float lw = logo.Width * sc, lh = logo.Height * sc;
                g.DrawImage(logo, right - lw - 14, y + (72 - lh) / 2, lw, lh);
            }
            g.DrawString("Sankhe & Frères", companyFont, whiteBrush, left + 18, y + 9);
            g.DrawString("TRANSFERT D’ARGENT", new Font("Segoe UI", 8.5f, FontStyle.Bold), goldBrush, left + 19, y + 39);
            g.DrawString($"Gérant : {GetManagerName()}", subFont, whiteBrush, left + 210, y + 42);
            y += 83;

            g.DrawString("RC : SN LGA 2015 - A - 568   •   NINEA : 005597333/20", subFont, grayBrush, left, y); y += 13;
            g.DrawString("Tél : 77 519 57 75 - 70 811 04 04   •   DAHRA - SENEGAL   •   Email : sankhebaba@gmail.com", subFont, grayBrush, left, y); y += 23;

            string title = "RAPPORT DES OPÉRATIONS";
            var tsize = g.MeasureString(title, titleFont);
            g.DrawString(title, titleFont, navyBrush, left + (width - tsize.Width) / 2, y); y += 28;
            string filters = $"Période : {start:dd/MM/yyyy} au {endExclusive.AddDays(-1):dd/MM/yyyy}   •   Service : {(string.IsNullOrWhiteSpace(service) ? "Tous les services" : service)}   •   Opération : {(string.IsNullOrWhiteSpace(type) ? "Toutes" : type)}";
            var fsize = g.MeasureString(filters, infoFont);
            g.DrawString(filters, infoFont, grayBrush, left + (width - fsize.Width) / 2, y); y += 22;

            string[] heads = { "DATE", "SERVICE", "NOM & PRÉNOM", "DESCRIPTION", "MONTANT", "COMM.", "DETTE", "STATUT", "RÉFÉRENCE", "TÉLÉPHONE" };
            float[] widths = { 72, 68, 118, 285, 76, 62, 68, 72, 96, 76 };
            float tableWidth = widths.Sum();
            if (tableWidth > width)
            {
                float sc = width / tableWidth;
                for (int i = 0; i < widths.Length; i++) widths[i] *= sc;
                tableWidth = width;
            }
            float tableLeft = left + (width - tableWidth) / 2;
            g.FillRectangle(blueBrush, tableLeft, y, tableWidth, 28);
            float x = tableLeft;
            for (int i = 0; i < heads.Length; i++)
            {
                g.DrawRectangle(Pens.White, x, y, widths[i], 28);
                var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                g.DrawString(heads[i], headFont, whiteBrush, new RectangleF(x + 2, y + 2, widths[i] - 4, 24), sf);
                sf.Dispose(); x += widths[i];
            }
            y += 28;
            g.DrawRectangle(linePen, tableLeft, y - 28, tableWidth, 28);

            int startIndex = page * rowsPerPage;
            int endIndex = Math.Min(rows.Count, startIndex + rowsPerPage);
            var cache = new Dictionary<string, Database.DebtReportStatus?>();
            for (int i = startIndex; i < endIndex; i++)
            {
                var op = rows[i];
                // Une ligne d'espacement entre deux journées différentes.
                if (i > startIndex && !string.Equals(ReportDayKey(rows[i - 1].DateOperation), ReportDayKey(op.DateOperation), StringComparison.OrdinalIgnoreCase))
                    y += 10;
                // Hauteur suffisante pour afficher la description sur 2 lignes sans la tronquer.
                float rh = 42;
                if ((i - startIndex) % 2 == 1) g.FillRectangle(lightBrush, tableLeft, y, tableWidth, rh);
                var debtInfo = GetReportDebtStatus(op, cache);
                string status = debtInfo?.Statut ?? "—";
                string reportService = GetReportService(op, debtInfo);
                string description = GetReportDescription(op);
                string[] vals = { op.DateOperation, reportService, op.ClientNom, description, Money(op.Montant), Money(op.Commission), Money(op.Dette), status, op.Reference, op.Telephone };
                x = tableLeft;
                for (int j = 0; j < vals.Length; j++)
                {
                    g.DrawRectangle(linePen, x, y, widths[j], rh);
                    var sf = new StringFormat
                    {
                        Trimming = StringTrimming.Word,
                        FormatFlags = StringFormatFlags.LineLimit,
                        Alignment = (j >= 4 && j <= 6) ? StringAlignment.Far : StringAlignment.Near,
                        LineAlignment = StringAlignment.Center
                    };
                    Brush br = status == "Soldée" && j == 7 ? new SolidBrush(Color.FromArgb(22,145,92)) : status == "Non soldée" && j == 7 ? new SolidBrush(Color.FromArgb(205,60,60)) : Brushes.Black;
                    g.DrawString(vals[j], bodyFont, br, new RectangleF(x + 4, y + 3, widths[j] - 8, rh - 6), sf);
                    if (br != Brushes.Black) br.Dispose();
                    sf.Dispose(); x += widths[j];
                }
                y += rh;
            }

            page++;
            e.HasMorePages = page * rowsPerPage < rows.Count;
            if (!e.HasMorePages)
            {
                y += 14;
                decimal total = rows.Sum(r => r.Montant), commission = rows.Sum(r => r.Commission), dette = rows.Sum(r => r.Dette);
                var infos = rows.Select(r => GetReportDebtStatus(r, cache)).Where(v => v is not null).Cast<Database.DebtReportStatus>().GroupBy(v => v.Id).Select(g => g.First()).ToList();
                int soldes = infos.Count(x => x.Statut == "Soldée"), nonSoldes = infos.Count(x => x.Statut == "Non soldée");
                decimal remaining = infos.Where(x => x.Statut == "Non soldée").Sum(x => x.MontantRestant);

                float boxGap = 10, boxW = (tableWidth - boxGap * 3) / 4f;
                string[] labels = { "OPÉRATIONS", "MONTANT TOTAL", "COMMISSION", "DETTE RESTANTE" };
                string[] values = { rows.Count.ToString(), Money(total), Money(commission), Money(remaining) };
                for (int i = 0; i < 4; i++)
                {
                    float bx = tableLeft + i * (boxW + boxGap);
                    g.FillRectangle(i == 1 ? goldBrush : lightBrush, bx, y, boxW, 48);
                    g.DrawRectangle(linePen, bx, y, boxW, 48);
                    var lb = i == 1 ? Brushes.White : blueBrush; var vb = i == 1 ? Brushes.White : navyBrush;
                    g.DrawString(labels[i], new Font("Segoe UI", 6.6f, FontStyle.Bold), lb, bx + 9, y + 6);
                    g.DrawString(values[i], totalFont, vb, bx + 9, y + 23);
                }
                y += 61;
                g.FillRectangle(navyBrush, tableLeft, y, tableWidth, 32);
                g.DrawString($"DETTES : {infos.Count}   •   SOLDÉES : {soldes}   •   NON SOLDÉES : {nonSoldes}   •   RESTANT : {Money(remaining)}", new Font("Segoe UI", 8.2f, FontStyle.Bold), whiteBrush, tableLeft + 12, y + 8);
            }

            float footerY = b.Bottom + 8;
            g.DrawLine(new Pen(gold, 2), left, footerY, right, footerY);
            g.DrawString("SANKHÉ TRANSFERT D’ARGENT  •  Rapport imprimable", footerFont, grayBrush, left, footerY + 4);
            string pg = $"Page {page}"; var pgs = g.MeasureString(pg, footerFont);
            g.DrawString(pg, footerFont, grayBrush, right - pgs.Width, footerY + 4);
        };

        dialog.Document = doc;
        if (dialog.ShowDialog(this) == DialogResult.OK) doc.Print();
    }

    static string PdfSafe(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "";
        var n = value.Normalize(NormalizationForm.FormD);
        var chars = n.Where(c => System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c) != System.Globalization.UnicodeCategory.NonSpacingMark).ToArray();
        return new string(chars).Replace("€", "EUR");
    }

    static string PdfEscape(string value)
    {
        return PdfSafe(value).Replace("\\", "\\\\").Replace("(", "\\(").Replace(")", "\\)");
    }

    static void PdfText(StringBuilder page, string text, float x, float y, float size, string color = "0 0 0")
    {
        page.AppendLine($"BT /F1 {size:0.##} Tf {color} rg 1 0 0 1 {x:0.##} {y:0.##} Tm ({PdfEscape(text)}) Tj ET");
    }

    static void PdfRect(StringBuilder page, float x, float y, float w, float h, string fill)
    {
        page.AppendLine($"q {fill} rg {x:0.##} {y:0.##} {w:0.##} {h:0.##} re f Q");
    }

    static List<string> PdfWrap(string text, int maxChars)
    {
        text = PdfSafe(text);
        if (text.Length <= maxChars) return new List<string> { text };
        var words = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var result = new List<string>();
        var line = "";
        foreach (var word in words)
        {
            if ((line.Length + word.Length + 1) > maxChars && line.Length > 0)
            {
                result.Add(line); line = word;
            }
            else line = string.IsNullOrEmpty(line) ? word : line + " " + word;
        }
        if (!string.IsNullOrEmpty(line)) result.Add(line);
        return result.Count == 0 ? new List<string> { "" } : result;
    }

    Bitmap RenderReportPdfPage(List<Database.OperationRow> rows, string service, string type, DateTime start, DateTime endExclusive, int pageIndex, int rowsPerPage)
    {
        // Même mise en page que PrintReport : unités d'affichage = 1/100 pouce,
        // ce qui permet au PDF de reprendre visuellement le rendu de l'impression.
        const int pageW = 1169, pageH = 827; // A4 paysage à 100 dpi
        const int margin = 38;
        var bmp = new Bitmap(pageW, pageH, PixelFormat.Format24bppRgb);
        bmp.SetResolution(100, 100);
        using var g = Graphics.FromImage(bmp);
        g.PageUnit = GraphicsUnit.Pixel;
        g.SmoothingMode = SmoothingMode.HighQuality;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
        g.Clear(Color.White);

        float left = margin, right = pageW - margin, y = margin;
        float width = pageW - margin * 2;
        Color navy = Color.FromArgb(16, 43, 79);
        Color blue = Color.FromArgb(28, 83, 145);
        Color gold = Color.FromArgb(236, 174, 45);
        Color light = Color.FromArgb(246, 248, 251);
        Color line = Color.FromArgb(205, 213, 223);
        string logoPath = Path.Combine(Application.StartupPath, "Assets", "sankhe_logo_header.png");

        using var whiteBrush = new SolidBrush(Color.White);
        using var navyBrush = new SolidBrush(navy);
        using var blueBrush = new SolidBrush(blue);
        using var goldBrush = new SolidBrush(gold);
        using var lightBrush = new SolidBrush(light);
        using var grayBrush = new SolidBrush(Color.FromArgb(90, 100, 115));
        using var linePen = new Pen(line, 1.15f);
        using var goldPen = new Pen(gold, 2);
        using var companyFont = new Font("Segoe UI", 18, FontStyle.Bold);
        using var titleFont = new Font("Segoe UI", 16, FontStyle.Bold);
        using var subFont = new Font("Segoe UI", 8.5f);
        using var infoFont = new Font("Segoe UI", 8.5f);
        using var headFont = new Font("Segoe UI", 7.6f, FontStyle.Bold);
        using var bodyFont = new Font("Segoe UI", 7.1f);
        using var totalFont = new Font("Segoe UI", 9, FontStyle.Bold);
        using var footerFont = new Font("Segoe UI", 7.2f);
        using var serviceFont = new Font("Segoe UI", 8.5f, FontStyle.Bold);
        using var totalLabelFont = new Font("Segoe UI", 6.6f, FontStyle.Bold);
        using var debtBarFont = new Font("Segoe UI", 8.2f, FontStyle.Bold);

        // Bandeau identique à l'impression.
        g.FillRectangle(navyBrush, left, y, width, 72);
        if (File.Exists(logoPath))
        {
            using var logo = Image.FromFile(logoPath);
            float maxW = 105, maxH = 55, sc = Math.Min(maxW / logo.Width, maxH / logo.Height);
            float lw = logo.Width * sc, lh = logo.Height * sc;
            g.DrawImage(logo, right - lw - 14, y + (72 - lh) / 2, lw, lh);
        }
        g.DrawString("Sankhe & Frères", companyFont, whiteBrush, left + 18, y + 9);
        g.DrawString("TRANSFERT D’ARGENT", serviceFont, goldBrush, left + 19, y + 39);
        g.DrawString($"Gérant : {GetManagerName()}", subFont, whiteBrush, left + 210, y + 42);
        y += 83;
        g.DrawString("RC : SN LGA 2015 - A - 568   •   NINEA : 005597333/20", subFont, grayBrush, left, y); y += 13;
        g.DrawString("Tél : 77 519 57 75 - 70 811 04 04   •   DAHRA - SENEGAL   •   Email : sankhebaba@gmail.com", subFont, grayBrush, left, y); y += 23;

        string title = "RAPPORT DES OPÉRATIONS";
        var tsize = g.MeasureString(title, titleFont);
        g.DrawString(title, titleFont, navyBrush, left + (width - tsize.Width) / 2, y); y += 28;
        string filters = $"Période : {start:dd/MM/yyyy} au {endExclusive.AddDays(-1):dd/MM/yyyy}   •   Service : {(string.IsNullOrWhiteSpace(service) ? "Tous les services" : service)}   •   Opération : {(string.IsNullOrWhiteSpace(type) ? "Toutes" : type)}";
        var fsize = g.MeasureString(filters, infoFont);
        g.DrawString(filters, infoFont, grayBrush, left + (width - fsize.Width) / 2, y); y += 22;

        string[] heads = { "DATE", "SERVICE", "NOM & PRÉNOM", "DESCRIPTION", "MONTANT", "COMM.", "DETTE", "STATUT", "RÉFÉRENCE", "TÉLÉPHONE" };
        float[] widths = { 72, 68, 118, 285, 76, 62, 68, 72, 96, 76 };
        float tableWidth = widths.Sum();
        if (tableWidth > width)
        {
            float sc = width / tableWidth;
            for (int i = 0; i < widths.Length; i++) widths[i] *= sc;
            tableWidth = width;
        }
        float tableLeft = left + (width - tableWidth) / 2;
        g.FillRectangle(blueBrush, tableLeft, y, tableWidth, 28);
        float x = tableLeft;
        for (int i = 0; i < heads.Length; i++)
        {
            g.DrawRectangle(Pens.White, x, y, widths[i], 28);
            using var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            g.DrawString(heads[i], headFont, whiteBrush, new RectangleF(x + 2, y + 2, widths[i] - 4, 24), sf);
            x += widths[i];
        }
        y += 28;
        g.DrawRectangle(linePen, tableLeft, y - 28, tableWidth, 28);

        int startIndex = pageIndex * rowsPerPage;
        int endIndex = Math.Min(rows.Count, startIndex + rowsPerPage);
        var cache = new Dictionary<string, Database.DebtReportStatus?>();
        for (int i = startIndex; i < endIndex; i++)
        {
            var op = rows[i];
            // Une ligne d'espacement entre deux journées différentes, identique à l'impression.
            if (i > startIndex && !string.Equals(ReportDayKey(rows[i - 1].DateOperation), ReportDayKey(op.DateOperation), StringComparison.OrdinalIgnoreCase))
                y += 10;
            float rh = 42;
            if ((i - startIndex) % 2 == 1) g.FillRectangle(lightBrush, tableLeft, y, tableWidth, rh);
            var debtInfo = GetReportDebtStatus(op, cache);
            string status = debtInfo?.Statut ?? "—";
            string reportService = GetReportService(op, debtInfo);
            string description = GetReportDescription(op);
            string[] vals = { op.DateOperation, reportService, op.ClientNom, description, Money(op.Montant), Money(op.Commission), Money(op.Dette), status, op.Reference, op.Telephone };
            x = tableLeft;
            for (int j = 0; j < vals.Length; j++)
            {
                g.DrawRectangle(linePen, x, y, widths[j], rh);
                using var sf = new StringFormat
                {
                    Trimming = StringTrimming.Word,
                    FormatFlags = StringFormatFlags.LineLimit,
                    Alignment = (j >= 4 && j <= 6) ? StringAlignment.Far : StringAlignment.Near,
                    LineAlignment = StringAlignment.Center
                };
                Brush? br = null;
                if (status == "Soldée" && j == 7) br = new SolidBrush(Color.FromArgb(22,145,92));
                else if (status == "Non soldée" && j == 7) br = new SolidBrush(Color.FromArgb(205,60,60));
                g.DrawString(vals[j], bodyFont, br ?? Brushes.Black, new RectangleF(x + 4, y + 3, widths[j] - 8, rh - 6), sf);
                br?.Dispose();
                x += widths[j];
            }
            y += rh;
        }

        bool lastPage = pageIndex == Math.Max(0, (int)Math.Ceiling(rows.Count / (double)rowsPerPage) - 1);
        if (lastPage)
        {
            y += 14;
            decimal total = rows.Sum(r => r.Montant), commission = rows.Sum(r => r.Commission), dette = rows.Sum(r => r.Dette);
            var infos = rows.Select(r => GetReportDebtStatus(r, cache)).Where(v => v is not null).Cast<Database.DebtReportStatus>().GroupBy(v => v.Id).Select(gr => gr.First()).ToList();
            int soldes = infos.Count(v => v.Statut == "Soldée"), nonSoldes = infos.Count(v => v.Statut == "Non soldée");
            decimal remaining = infos.Where(v => v.Statut == "Non soldée").Sum(v => v.MontantRestant);
            float boxGap = 10, boxW = (tableWidth - boxGap * 3) / 4f;
            string[] labels = { "OPÉRATIONS", "MONTANT TOTAL", "COMMISSION", "DETTE RESTANTE" };
            string[] values = { rows.Count.ToString(), Money(total), Money(commission), Money(remaining) };
            for (int i = 0; i < 4; i++)
            {
                float bx = tableLeft + i * (boxW + boxGap);
                g.FillRectangle(i == 1 ? goldBrush : lightBrush, bx, y, boxW, 48);
                g.DrawRectangle(linePen, bx, y, boxW, 48);
                var lb = i == 1 ? Brushes.White : blueBrush; var vb = i == 1 ? Brushes.White : navyBrush;
                g.DrawString(labels[i], totalLabelFont, lb, bx + 9, y + 6);
                g.DrawString(values[i], totalFont, vb, bx + 9, y + 23);
            }
            y += 61;
            g.FillRectangle(navyBrush, tableLeft, y, tableWidth, 32);
            g.DrawString($"DETTES : {infos.Count}   •   SOLDÉES : {soldes}   •   NON SOLDÉES : {nonSoldes}   •   RESTANT : {Money(remaining)}", debtBarFont, whiteBrush, tableLeft + 12, y + 8);
        }

        float footerY = pageH - margin - 1;
        g.DrawLine(goldPen, left, footerY, right, footerY);
        g.DrawString("SANKHÉ TRANSFERT D’ARGENT  •  Rapport imprimable", footerFont, grayBrush, left, footerY + 4);
        string pg = $"Page {pageIndex + 1}";
        var pgs = g.MeasureString(pg, footerFont);
        g.DrawString(pg, footerFont, grayBrush, right - pgs.Width, footerY + 4);
        return bmp;
    }

    static byte[] BitmapToJpeg(Bitmap bmp)
    {
        using var ms = new MemoryStream();
        var codec = ImageCodecInfo.GetImageEncoders().First(c => c.FormatID == ImageFormat.Jpeg.Guid);
        using var enc = new EncoderParameters(1);
        enc.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 95L);
        bmp.Save(ms, codec, enc);
        return ms.ToArray();
    }

    void SaveReportAsPdf(List<Database.OperationRow> rows, string service, string type, DateTime start, DateTime endExclusive)
    {
        using var dialog = new SaveFileDialog
        {
            Title = "Enregistrer le rapport PDF",
            Filter = "Document PDF (*.pdf)|*.pdf",
            FileName = $"Rapport_{(string.IsNullOrWhiteSpace(service) ? "Tous" : service).Replace(" ", "_")}_{start:yyyyMMdd}_{endExclusive.AddDays(-1):yyyyMMdd}.pdf",
            AddExtension = true,
            DefaultExt = "pdf"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;

        const int rowsPerPage = 22;
        int totalPages = Math.Max(1, (int)Math.Ceiling(rows.Count / (double)rowsPerPage));
        var jpegPages = new List<byte[]>(totalPages);
        for (int p = 0; p < totalPages; p++)
        {
            using var bmp = RenderReportPdfPage(rows, service, type, start, endExclusive, p, rowsPerPage);
            jpegPages.Add(BitmapToJpeg(bmp));
        }

        const double pageW = 841.8898, pageH = 595.2756; // A4 paysage en points
        using var fs = new FileStream(dialog.FileName, FileMode.Create, FileAccess.Write);
        using var bw = new BinaryWriter(fs);
        var objects = new List<byte[]>();
        objects.Add(Encoding.ASCII.GetBytes("<< /Type /Catalog /Pages 2 0 R >>"));
        int pageCount = jpegPages.Count;
        int firstPageObj = 4;
        var kids = Enumerable.Range(0, pageCount).Select(i => $"{firstPageObj + i * 3} 0 R");
        objects.Add(Encoding.ASCII.GetBytes($"<< /Type /Pages /Count {pageCount} /Kids [{string.Join(" ", kids)}] >>"));
        objects.Add(Encoding.ASCII.GetBytes("<< /Type /XObject /Subtype /Image /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode >>"));

        foreach (var jpg in jpegPages)
        {
            int pageObj = objects.Count + 1;
            int contentObj = pageObj + 1;
            int imageObj = pageObj + 2;
            // L'image est un objet JPEG dédié; dimensions A4 restent dans la page PDF.
            objects.Add(Encoding.ASCII.GetBytes(string.Format(System.Globalization.CultureInfo.InvariantCulture, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {0:0.##} {1:0.##}] /Resources << /XObject << /Im0 {2} 0 R >> >> /Contents {3} 0 R >>", pageW, pageH, imageObj, contentObj)));
            string stream = string.Format(System.Globalization.CultureInfo.InvariantCulture, "q {0:0.##} 0 0 {1:0.##} 0 0 cm /Im0 Do Q", pageW, pageH);
            objects.Add(Encoding.ASCII.GetBytes($"<< /Length {Encoding.ASCII.GetByteCount(stream)} >>\nstream\n{stream}\nendstream"));
            // Marqueur spécial traité ci-dessous : JPEG binaire + dictionnaire.
            objects.Add(jpg);
        }

        var offsets = new List<long> { 0 };
        bw.Write(Encoding.ASCII.GetBytes("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n"));
        for (int i = 0; i < objects.Count; i++)
        {
            offsets.Add(fs.Position);
            int objNo = i + 1;
            if ((i >= 3) && ((i - 3) % 3 == 2))
            {
                // Objet image : récupérer le JPEG et ses dimensions via le flux.
                using var ms = new MemoryStream(objects[i]);
                using var img = Image.FromStream(ms, false, false);
                string header = $"{objNo} 0 obj\n<< /Type /XObject /Subtype /Image /Width {img.Width} /Height {img.Height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length {objects[i].Length} >>\nstream\n";
                bw.Write(Encoding.ASCII.GetBytes(header));
                bw.Write(objects[i]);
                bw.Write(Encoding.ASCII.GetBytes("\nendstream\nendobj\n"));
            }
            else
            {
                bw.Write(Encoding.ASCII.GetBytes($"{objNo} 0 obj\n"));
                bw.Write(objects[i]);
                bw.Write(Encoding.ASCII.GetBytes("\nendobj\n"));
            }
        }
        long xref = fs.Position;
        bw.Write(Encoding.ASCII.GetBytes($"xref\n0 {objects.Count + 1}\n0000000000 65535 f \n"));
        for (int i = 1; i < offsets.Count; i++) bw.Write(Encoding.ASCII.GetBytes($"{offsets[i]:D10} 00000 n \n"));
        bw.Write(Encoding.ASCII.GetBytes($"trailer\n<< /Size {objects.Count + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF"));
        MessageBox.Show("Rapport PDF créé avec la même mise en page que l’impression.", "SANKHÉ — Rapport PDF", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    void SaveReportAsText(List<Database.OperationRow> rows, string service, string type, DateTime start, DateTime endExclusive)
    {
        using var dialog = new SaveFileDialog { Title = "Enregistrer le rapport", Filter = "Rapport CSV (*.csv)|*.csv|Fichier texte (*.txt)|*.txt", FileName = $"Rapport_{service.Replace(" ", "_")}_{start:yyyyMMdd}_{endExclusive.AddDays(-1):yyyyMMdd}.csv", AddExtension = true };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        using var sw = new StreamWriter(dialog.FileName, false, System.Text.Encoding.UTF8);
        sw.WriteLine("Date;Service;Nom & Prénom;Type;Description;Montant;Commission;Dette;Statut dette;Référence;Téléphone;Observation");
        var csvCache = new Dictionary<string, Database.DebtReportStatus?>();
        foreach (var op in rows)
        {
            var debtInfo = GetReportDebtStatus(op, csvCache);
            var reportService = GetReportService(op, debtInfo);
            sw.WriteLine($"{op.DateOperation};{reportService};{op.ClientNom};{op.TypeOperation};{GetReportDescription(op)};{op.Montant};{op.Commission};{op.Dette};{debtInfo?.Statut ?? ""};{op.Reference};{op.Telephone};{op.Observation}");
        }
        MessageBox.Show("Rapport enregistré avec succès.", "SANKHÉ — Rapport", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    void ShowHistory()
    {
        ClearContent();
        content.Paint -= DrawAnimatedBackground;
        content.Paint += DrawAnimatedBackground;
        content.AutoScroll = true;

        var host = CreatePageHost(1160);
        host.Height = Math.Max(560, content.ClientSize.Height - 20);
        content.Controls.Add(host);

        var title = Heading("Historique des opérations");
        title.Font = new Font("Segoe UI", 22, FontStyle.Bold);
        title.Location = new Point(0, 0);
        host.Controls.Add(title);
        host.Controls.Add(new Label { Text = "Toutes les opérations avec leurs références, séparées par service", AutoSize = true, Left = 2, Top = 39, ForeColor = Color.FromArgb(100,116,139), Font = new Font("Segoe UI", 9) });

        var tabs = new TabControl
        {
            Left = 0, Top = 70, Width = host.Width, Height = host.Height - 75,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
            DrawMode = TabDrawMode.OwnerDrawFixed,
            ItemSize = new Size(180, 46),
            SizeMode = TabSizeMode.Fixed,
            Padding = new Point(12, 5),
            BackColor = Color.FromArgb(6, 20, 42),
            Appearance = TabAppearance.Normal
        };
        tabs.TabPages.Add(CreateHistoryTab("Wave", Color.FromArgb(0,145,255)));
        tabs.TabPages.Add(CreateHistoryTab("Orange Money", Color.FromArgb(255,121,0)));
        tabs.TabPages.Add(CreateSeddoHistoryTab());
        tabs.TabPages.Add(CreateBoutiqueHistoryTab());
        tabs.TabPages.Add(CreateCaisseHistoryTab());
        tabs.DrawItem += (_, e) =>
        {
            var page = tabs.TabPages[e.Index];
            var rect = e.Bounds;
            rect.Inflate(-4, -4);
            var selected = e.Index == tabs.SelectedIndex;
            Color accent = e.Index switch
            {
                0 => Color.FromArgb(0,145,255),
                1 => Color.FromArgb(255,121,0),
                2 => Color.FromArgb(0,205,145),
                3 => Color.FromArgb(37,99,235),
                _ => Color.FromArgb(210,160,35)
            };
            using var bg = new SolidBrush(selected ? Color.FromArgb(28, 53, 84) : Color.FromArgb(10, 28, 52));
            using var border = new Pen(selected ? accent : Color.FromArgb(50,75,105), selected ? 2.2f : 1f);
            using var path = RoundedPath(rect, 12);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.FillPath(bg, path);
            e.Graphics.DrawPath(border, path);
            using var font = new Font("Segoe UI", selected ? 10.5f : 9.5f, FontStyle.Bold);
            using var brush = new SolidBrush(selected ? Color.White : Color.FromArgb(190,210,230));
            using var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            e.Graphics.DrawString(page.Text, font, brush, rect, sf);
        };
        tabs.SelectedIndexChanged += (_, _) => tabs.Invalidate();
        host.Controls.Add(tabs);
    }

    TabPage CreateHistoryTab(string service, Color accent)
    {
        var tab = new TabPage(service) { BackColor = Color.White, Padding = new Padding(8) };
        var info = Database.GetOperationSums(service);
        tab.Controls.Add(new Label
        {
            Text = $"Dépôts : {Money(info.Depot)}     Retraits : {Money(info.Retrait)}     Transferts : {Money(info.Transfert)}",
            Dock = DockStyle.Top, Height = 32, TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 9, FontStyle.Bold), ForeColor = accent
        });

        // La liste est volontairement descendue d'environ 2 cm pour laisser plus d'espace
        // sous les indicateurs et améliorer la visibilité sur les écrans compacts.
        var gridHost = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.White,
            Padding = new Padding(0, 76, 0, 0)
        };

        var grid = new DataGridView
        {
            Dock = DockStyle.Fill, BackgroundColor = Color.White, BorderStyle = BorderStyle.None,
            AllowUserToAddRows = false, AllowUserToDeleteRows = false, ReadOnly = true,
            AutoGenerateColumns = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            RowHeadersVisible = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false
        };
        grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(241,245,249);
        grid.EnableHeadersVisualStyles = false;
        AddGridColumn(grid, "Date", "DateOperation");
        AddGridColumn(grid, "Type", "TypeOperation");
        AddGridColumn(grid, "Client", "ClientNom");
        AddGridColumn(grid, "Téléphone", "Telephone");
        AddGridColumn(grid, "Montant", "Montant", true);
        AddGridColumn(grid, "Commission", "Commission", true);
        AddGridColumn(grid, "Dette", "Dette", true);
        AddGridColumn(grid, "Référence", "Reference");
        AddGridColumn(grid, "Observation", "Observation");
        foreach (var op in Database.GetOperations(service))
            grid.Rows.Add(op.DateOperation, op.TypeOperation, op.ClientNom, op.Telephone, Money(op.Montant), Money(op.Commission), Money(op.Dette), op.Reference, op.Observation);
        gridHost.Controls.Add(grid);
        tab.Controls.Add(gridHost);
        return tab;
    }

    TabPage CreateSeddoHistoryTab()
    {
        var tab = new TabPage("Seddo") { BackColor = Color.White, Padding = new Padding(8) };
        var grid = CreateHistoryGrid();
        AddGridColumn(grid, "Date / Heure", "DateOperation");
        AddGridColumn(grid, "Client", "ClientNom");
        AddGridColumn(grid, "Téléphone", "Telephone");
        AddGridColumn(grid, "Montant", "Montant", true);
        AddGridColumn(grid, "Commission", "Commission", true);
        AddGridColumn(grid, "Référence", "Reference");
        AddGridColumn(grid, "Observation", "Observation");
        foreach (var op in Database.GetSeddoOperations(500))
            grid.Rows.Add(op.DateOperation, op.ClientNom, op.Telephone, Money(op.Montant), Money(op.Commission), op.Reference, op.PaiementDiffere ? $"Paiement différé — reste {Money(op.Reste)}" : op.Observation);
        tab.Controls.Add(grid);
        return tab;
    }

    TabPage CreateBoutiqueHistoryTab()
    {
        var tab = new TabPage("Mon Boutique") { BackColor = Color.White, Padding = new Padding(8) };
        var grid = CreateHistoryGrid();
        AddGridColumn(grid, "Date / Heure", "DateOperation");
        AddGridColumn(grid, "Poste", "Poste");
        AddGridColumn(grid, "Employé", "Employe");
        AddGridColumn(grid, "Opération", "Operation");
        AddGridColumn(grid, "Wave", "Wave", true);
        AddGridColumn(grid, "Orange Money", "Orange", true);
        AddGridColumn(grid, "Espèces", "Cash", true);
        AddGridColumn(grid, "Statut", "Statut");
        var start = DateTime.MinValue;
        var end = DateTime.MaxValue;
        var employees = Database.GetBoutiqueEmployees(false).ToDictionary(x => x.Id);
        foreach (var session in Database.GetBoutiqueSessions(start, end))
        {
            employees.TryGetValue(session.EmployeId, out var employee);
            var poste = employee is null ? "—" : $"Poste {employee.Poste}";
            grid.Rows.Add(session.Ouverture, poste, session.Employe, "Distribution matin", Money(session.WaveDonne), Money(session.OrangeDonne), Money(session.EspecesDonne), session.Statut);
            var additions = Database.GetBoutiqueOperations(start, end, session.EmployeId)
                .Where(o => o.SessionId == session.Id && string.Equals(o.TypeOperation, "Complément dotation", StringComparison.OrdinalIgnoreCase))
                .OrderBy(o => o.DateOperation);
            foreach (var a in additions)
                grid.Rows.Add(a.DateOperation, poste, session.Employe, "+ Ajout dotation", string.Equals(a.Service, "Wave", StringComparison.OrdinalIgnoreCase) ? Money(a.Montant) : "0 FCFA", string.Equals(a.Service, "Orange Money", StringComparison.OrdinalIgnoreCase) ? Money(a.Montant) : "0 FCFA", string.Equals(a.Service, "Espèces", StringComparison.OrdinalIgnoreCase) ? Money(a.Montant) : "0 FCFA", session.Statut);
            if (!string.IsNullOrWhiteSpace(session.Fermeture) || session.WaveRetour > 0 || session.OrangeRetour > 0 || session.EspecesRetour > 0)
                grid.Rows.Add(session.Fermeture, poste, session.Employe, "Retour soir", Money(session.WaveRetour), Money(session.OrangeRetour), Money(session.EspecesRetour), session.Statut);
        }
        tab.Controls.Add(grid);
        return tab;
    }

    TabPage CreateCaisseHistoryTab()
    {
        var tab = new TabPage("Caisses") { BackColor = Color.White, Padding = new Padding(8) };
        var selector = new ComboBox { Dock = DockStyle.Top, Height = 32, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
        selector.Items.AddRange(new object[] { "Toutes les caisses", "Caisse Wave", "Caisse Orange Money", "Caisse Seddo", "Caisse en espèce" });
        selector.SelectedIndex = 0;
        var grid = CreateHistoryGrid();
        AddGridColumn(grid, "Date / Heure", "DateOperation");
        AddGridColumn(grid, "Caisse", "Caisse");
        AddGridColumn(grid, "Mouvement", "Mouvement");
        AddGridColumn(grid, "Montant", "Montant", true);
        AddGridColumn(grid, "Motif", "Motif");
        AddGridColumn(grid, "Référence", "Reference");
        Action load = () =>
        {
            grid.Rows.Clear();
            string[] services;
            switch (selector.SelectedIndex)
            {
                case 1: services = new[] { "Caisse Wave" }; break;
                case 2: services = new[] { "Caisse Orange Money" }; break;
                case 3: services = new[] { "Caisse Seddo" }; break;
                case 4: services = new[] { "Caisse" }; break;
                default: services = new[] { "Caisse Wave", "Caisse Orange Money", "Caisse Seddo", "Caisse" }; break;
            }
            foreach (var service in services)
                foreach (var movement in Database.GetCaisseJournal(service, 500))
                    grid.Rows.Add(movement.DateMouvement, service == "Caisse" ? "Caisse en espèce" : service, movement.TypeMouvement, Money(movement.Montant), movement.Motif, movement.Reference);
        };
        selector.SelectedIndexChanged += (_, _) => load();
        tab.Controls.Add(grid);
        tab.Controls.Add(selector);
        load();
        return tab;
    }

    DataGridView CreateHistoryGrid()
    {
        var grid = new DataGridView
        {
            Dock = DockStyle.Fill, BackgroundColor = Color.White, BorderStyle = BorderStyle.None,
            AllowUserToAddRows = false, AllowUserToDeleteRows = false, ReadOnly = true,
            AutoGenerateColumns = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            RowHeadersVisible = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false,
            EnableHeadersVisualStyles = false, CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
            GridColor = Color.FromArgb(220, 228, 238)
        };
        grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(241, 245, 249);
        grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(30, 41, 59);
        grid.DefaultCellStyle.ForeColor = Color.FromArgb(30, 41, 59);
        grid.DefaultCellStyle.BackColor = Color.White;
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
        return grid;
    }

    static void AddGridColumn(DataGridView grid, string header, string name, bool numeric = false)
    {
        var c = new DataGridViewTextBoxColumn { HeaderText = header, Name = name, FillWeight = numeric ? 80 : 110 };
        if (numeric) c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        grid.Columns.Add(c);
    }

    void ShowSettings()
    {
        ClearContent();
        content.Padding = new Padding(24, 20, 24, 28);

        var title = Heading("Paramètres");
        content.Controls.Add(title);

        // Mise en page réorganisée : cartes alignées sur trois colonnes, avec défilement vertical.
        int settingsWidth = Math.Min(1320, Math.Max(760, content.ClientSize.Width - 24));
        int pageLeft = Math.Max(0, (content.ClientSize.Width - settingsWidth) / 2);
        int gap = 14;
        int colWidth = Math.Max(230, (settingsWidth - gap * 2) / 3);
        int top1 = 94;
        int cardHeight = 160;

        var developerNote = new Label
        {
            Text = "MESSAGE DU CONCEPTEUR  •  Pour toute difficulté, contactez Mr Sidy Thiam au 77 813 90 93.",
            AutoSize = false, Left = pageLeft, Top = 48, Width = settingsWidth, Height = 36,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            ForeColor = Color.FromArgb(255, 232, 90), BackColor = Color.FromArgb(32, 32, 18),
            Padding = new Padding(12, 5, 12, 5), BorderStyle = BorderStyle.FixedSingle,
            TextAlign = ContentAlignment.MiddleLeft
        };
        content.Controls.Add(developerNote);

        // 1. Informations de l'entreprise
        var managerCard = new Panel
        {
            Left = pageLeft, Top = top1, Width = colWidth, Height = cardHeight,
            BackColor = Color.FromArgb(20, 36, 58), BorderStyle = BorderStyle.FixedSingle
        };
        var managerTitle = new Label
        {
            Text = "🏢  INFORMATIONS DE L’ENTREPRISE", AutoSize = false,
            Left = 14, Top = 12, Width = colWidth - 28, Height = 26,
            Font = new Font("Segoe UI", 10.5f, FontStyle.Bold), ForeColor = Color.FromArgb(70, 210, 255)
        };
        var managerInfo = new Label
        {
            Text = "Nom du gérant affiché dans l’en-tête et les rapports imprimés/PDF.",
            AutoSize = false, Left = 14, Top = 42, Width = colWidth - 28, Height = 34,
            Font = new Font("Segoe UI", 8.5f), ForeColor = Color.FromArgb(205, 220, 235)
        };
        var managerInput = new TextBox
        {
            Left = 14, Top = 80, Width = colWidth - 28, Height = 27,
            Font = new Font("Segoe UI", 9.5f), Text = Database.GetSetting("ManagerName", "")
        };
        var saveManager = new Button
        {
            Text = "ENREGISTRER", Left = 14, Top = 115, Width = Math.Min(170, colWidth - 28), Height = 32,
            BackColor = Color.FromArgb(0, 145, 225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), Cursor = Cursors.Hand
        };
        saveManager.FlatAppearance.BorderSize = 0;
        saveManager.Click += (_, _) =>
        {
            var name = managerInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Veuillez saisir le nom du gérant.", "SANKHÉ — Paramètres", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                managerInput.Focus(); return;
            }
            Database.SetSetting("ManagerName", name);
            RefreshManagerHeader();
            MessageBox.Show("Le nom du gérant a été enregistré.", "SANKHÉ — Paramètres", MessageBoxButtons.OK, MessageBoxIcon.Information);
        };
        managerCard.Controls.AddRange(new Control[] { managerTitle, managerInfo, managerInput, saveManager });
        content.Controls.Add(managerCard);

        // 2. Sécurité et mot de passe
        var passwordCard = CreateSettingsCard(
            "🔐  SÉCURITÉ & MOT DE PASSE",
            "Protégez l’accès au logiciel et modifiez le mot de passe quand nécessaire.",
            Color.FromArgb(130, 70, 220), "MODIFIER LE MOT DE PASSE", ChangeAccessPassword);
        passwordCard.SetBounds(pageLeft + colWidth + gap, top1, colWidth, cardHeight);
        content.Controls.Add(passwordCard);

        // 3. Carnet clients
        var clients = Database.GetClients();
        var clientCard = CreateSettingsCard(
            "👥  CARNET CLIENTS",
            $"Gérez les noms, prénoms, téléphones et coordonnées. {clients.Count} client(s) enregistré(s).",
            Color.FromArgb(0, 170, 105), "GÉRER LES CLIENTS", ShowClientManager);
        clientCard.SetBounds(pageLeft + (colWidth + gap) * 2, top1, colWidth, cardHeight);
        content.Controls.Add(clientCard);

        // 4. Notifications WhatsApp : une seule carte large pour éviter les champs serrés.
        int whatsappTop = top1 + cardHeight + 14;
        var whatsappCard = new Panel
        {
            Left = pageLeft, Top = whatsappTop, Width = settingsWidth, Height = 205,
            BackColor = Color.FromArgb(20, 36, 58), BorderStyle = BorderStyle.FixedSingle
        };
        var whatsappTitle = new Label
        {
            Text = "🟢  NOTIFICATIONS WHATSAPP — DETTES INTÉGRALEMENT SOLDÉES",
            Left = 16, Top = 12, Width = settingsWidth - 32, Height = 26,
            Font = new Font("Segoe UI", 11, FontStyle.Bold), ForeColor = Color.FromArgb(70, 220, 150)
        };
        var whatsappInfo = new Label
        {
            Text = "L’envoi automatique est prévu uniquement au solde complet d’une dette. Nécessite WhatsApp Business Cloud API et un modèle approuvé par Meta.",
            Left = 16, Top = 40, Width = settingsWidth - 32, Height = 30,
            Font = new Font("Segoe UI", 8.8f), ForeColor = Color.FromArgb(205, 220, 235)
        };
        int wGap = 12;
        int wCol = Math.Max(160, (settingsWidth - 56) / 3);
        TextBox waPhoneId = new TextBox { Left = 16, Top = 88, Width = wCol, Height = 27, Font = new Font("Segoe UI", 9), Text = Database.GetSetting("WhatsAppPhoneNumberId", "") };
        TextBox waToken = new TextBox { Left = 16 + wCol + wGap, Top = 88, Width = wCol, Height = 27, Font = new Font("Segoe UI", 9), UseSystemPasswordChar = true, Text = Database.GetSetting("WhatsAppAccessToken", "") };
        TextBox waTemplate = new TextBox { Left = 16 + (wCol + wGap) * 2, Top = 88, Width = wCol, Height = 27, Font = new Font("Segoe UI", 9), Text = Database.GetSetting("WhatsAppTemplateName", "") };
        var waPhoneLabel = new Label { Text = "ID du numéro WhatsApp", Left = waPhoneId.Left, Top = 68, Width = wCol, Height = 18, ForeColor = Color.White, Font = new Font("Segoe UI", 8.5f) };
        var waTokenLabel = new Label { Text = "Jeton d’accès (masqué)", Left = waToken.Left, Top = 68, Width = wCol, Height = 18, ForeColor = Color.White, Font = new Font("Segoe UI", 8.5f) };
        var waTemplateLabel = new Label { Text = "Nom du modèle approuvé", Left = waTemplate.Left, Top = 68, Width = wCol, Height = 18, ForeColor = Color.White, Font = new Font("Segoe UI", 8.5f) };
        var waLanguage = new TextBox { Left = 16, Top = 143, Width = 90, Height = 26, Font = new Font("Segoe UI", 9), Text = Database.GetSetting("WhatsAppLanguageCode", "fr") };
        var waLanguageLabel = new Label { Text = "Langue", Left = 16, Top = 123, Width = 90, Height = 18, ForeColor = Color.White, Font = new Font("Segoe UI", 8.5f) };
        var waStatus = new Label { Text = "Configuration : " + (string.IsNullOrWhiteSpace(waPhoneId.Text) || string.IsNullOrWhiteSpace(waToken.Text) || string.IsNullOrWhiteSpace(waTemplate.Text) ? "incomplète" : "champs renseignés"), Left = 120, Top = 146, Width = Math.Max(180, settingsWidth - 390), Height = 22, ForeColor = Color.FromArgb(255, 210, 80), Font = new Font("Segoe UI", 8.8f, FontStyle.Bold) };
        var waSave = new Button { Text = "ENREGISTRER WHATSAPP", Left = settingsWidth - 235, Top = 136, Width = 215, Height = 36, BackColor = Color.FromArgb(0, 165, 145), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), Cursor = Cursors.Hand };
        waSave.FlatAppearance.BorderSize = 0;
        waSave.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(waPhoneId.Text) || string.IsNullOrWhiteSpace(waToken.Text) || string.IsNullOrWhiteSpace(waTemplate.Text))
            {
                MessageBox.Show("Renseignez l’ID du numéro, le jeton d’accès et le nom du modèle approuvé.", "WhatsApp", MessageBoxButtons.OK, MessageBoxIcon.Warning); return;
            }
            Database.SetSetting("WhatsAppPhoneNumberId", waPhoneId.Text.Trim());
            Database.SetSetting("WhatsAppAccessToken", waToken.Text.Trim());
            Database.SetSetting("WhatsAppTemplateName", waTemplate.Text.Trim());
            Database.SetSetting("WhatsAppLanguageCode", string.IsNullOrWhiteSpace(waLanguage.Text) ? "fr" : waLanguage.Text.Trim());
            waStatus.Text = "Configuration enregistrée — envoi réel à valider avec l’API Meta";
            waStatus.ForeColor = Color.FromArgb(70, 220, 150);
            MessageBox.Show("Configuration WhatsApp enregistrée. Vérifiez que le modèle Meta approuvé comporte les 7 paramètres attendus.", "WhatsApp", MessageBoxButtons.OK, MessageBoxIcon.Information);
        };
        whatsappCard.Controls.AddRange(new Control[] { whatsappTitle, whatsappInfo, waPhoneLabel, waTokenLabel, waTemplateLabel, waPhoneId, waToken, waTemplate, waLanguageLabel, waLanguage, waStatus, waSave });
        content.Controls.Add(whatsappCard);

        // 5. Gestion des données : sauvegarde et restauration.
        int dataTop = whatsappTop + 205 + 14;
        var intro = new Label
        {
            Text = "GESTION DES DONNÉES  •  Sauvegarde recommandée avant toute suppression",
            AutoSize = false, Left = pageLeft, Top = dataTop, Width = settingsWidth, Height = 28,
            Font = new Font("Segoe UI", 10.5f, FontStyle.Bold), ForeColor = Color.FromArgb(210, 228, 245),
            TextAlign = ContentAlignment.MiddleLeft
        };
        content.Controls.Add(intro);
        int row2 = dataTop + 34;
        int dataCardHeight = 150;
        var backupCard = CreateSettingsCard(
            "💾  SAUVEGARDER LA BASE",
            "Créer une copie complète de la base de données sur votre ordinateur.",
            Color.FromArgb(0, 165, 105), "ENREGISTRER LA BASE", SaveDatabaseAs);
        backupCard.SetBounds(pageLeft, row2, colWidth, dataCardHeight); content.Controls.Add(backupCard);

        var openBackupCard = CreateSettingsCard(
            "📂  RESTAURER UNE SAUVEGARDE",
            "Ouvrir une ancienne copie .db. Faites une sauvegarde de la base actuelle avant de continuer.",
            Color.FromArgb(0, 115, 220), "OUVRIR UNE SAUVEGARDE", OpenDatabaseBackup);
        openBackupCard.SetBounds(pageLeft + colWidth + gap, row2, colWidth, dataCardHeight); content.Controls.Add(openBackupCard);

        var auditCard = CreateSettingsCard(
            "🔎  MAINTENANCE & CONTRÔLE",
            "Consulter le journal des actions et vérifier la cohérence des soldes calculés.",
            Color.FromArgb(0, 145, 150), "JOURNAL & CONTRÔLE", ShowAuditAndConsistency);
        auditCard.SetBounds(pageLeft + (colWidth + gap) * 2, row2, colWidth, dataCardHeight); content.Controls.Add(auditCard);

        // 6. Suppressions séparées et clairement identifiées.
        int deleteTop = row2 + dataCardHeight + 14;
        var keepClientsCard = CreateSettingsCard(
            "🟠  RÉINITIALISER — GARDER LES CLIENTS",
            "Efface les opérations, dettes et historiques, mais conserve les fiches clients.",
            Color.FromArgb(230, 125, 30), "EFFACER EN GARDANT LES CLIENTS", () => ClearDatabaseWithConfirmation(true));
        keepClientsCard.SetBounds(pageLeft, deleteTop, colWidth, 165); content.Controls.Add(keepClientsCard);

        var deleteClientsCard = CreateSettingsCard(
            "🔴  TOUT EFFACER, CLIENTS INCLUS",
            "Supprime aussi les noms, prénoms et numéros du carnet clients. Action définitive.",
            Color.FromArgb(215, 50, 60), "EFFACER AUSSI LES CLIENTS", () => ClearDatabaseWithConfirmation(false));
        deleteClientsCard.SetBounds(pageLeft + colWidth + gap, deleteTop, colWidth, 165); content.Controls.Add(deleteClientsCard);

        var warning = new Label
        {
            Text = "⚠  AVANT DE SUPPRIMER : enregistrez une sauvegarde. Choisissez soigneusement si le carnet clients doit être conservé.",
            AutoSize = false, Left = pageLeft + (colWidth + gap) * 2, Top = deleteTop, Width = colWidth, Height = 92,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = Color.FromArgb(255, 210, 80),
            BackColor = Color.FromArgb(40, 32, 12), Padding = new Padding(12), BorderStyle = BorderStyle.FixedSingle,
            TextAlign = ContentAlignment.MiddleLeft
        };
        content.Controls.Add(warning);
    }

    void ShowClientManager()
    {
        using var dlg = new Form
        {
            Text = "SANKHÉ — Gestion des clients",
            Width = 1120, Height = 720,
            StartPosition = FormStartPosition.CenterParent,
            BackColor = Color.FromArgb(7, 18, 38)
        };

        var title = new Label { Text = "GESTION DES CLIENTS", Left = 22, Top = 18, Width = 700, Height = 34, Font = new Font("Segoe UI", 20, FontStyle.Bold), ForeColor = Color.White };
        var subtitle = new Label { Text = "Ajouter • rechercher • modifier • supprimer un client", Left = 24, Top = 54, Width = 700, Height = 24, Font = new Font("Segoe UI", 9.5f), ForeColor = Color.FromArgb(190, 210, 230) };
        dlg.Controls.Add(title); dlg.Controls.Add(subtitle);

        var search = new TextBox { Left = 22, Top = 92, Width = 430, Height = 34, PlaceholderText = "Rechercher par nom, prénom ou téléphone…" };
        var add = new Button { Text = "＋ AJOUTER UN CLIENT", Left = 770, Top = 90, Width = 300, Height = 38, BackColor = Color.FromArgb(0, 190, 130), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        add.FlatAppearance.BorderSize = 0;
        dlg.Controls.Add(search); dlg.Controls.Add(add);

        var grid = new DataGridView
        {
            Left = 22, Top = 145, Width = 1048, Height = 445,
            ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false,
            AutoGenerateColumns = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false,
            BackgroundColor = Color.FromArgb(5, 18, 42), BorderStyle = BorderStyle.None,
            EnableHeadersVisualStyles = false, GridColor = Color.FromArgb(35, 74, 120)
        };
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(18, 91, 168); grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White; grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold); grid.ColumnHeadersHeight = 38;
        grid.DefaultCellStyle.BackColor = Color.FromArgb(7, 24, 52); grid.DefaultCellStyle.ForeColor = Color.White; grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 116, 205); grid.RowTemplate.Height = 34;
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Id", HeaderText = "N°", FillWeight = 45 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Nom", HeaderText = "Nom / Prénom", FillWeight = 170 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Telephone", HeaderText = "Téléphone", FillWeight = 110 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Note", HeaderText = "Coordonnées / Note", FillWeight = 170 });
        dlg.Controls.Add(grid);

        var edit = new Button { Text = "✎ MODIFIER", Left = 22, Top = 608, Width = 155, Height = 40, BackColor = Color.FromArgb(0, 145, 225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var del = new Button { Text = "🗑 SUPPRIMER", Left = 187, Top = 608, Width = 155, Height = 40, BackColor = Color.FromArgb(205, 45, 55), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        var close = new Button { Text = "FERMER", Left = 920, Top = 608, Width = 150, Height = 40, BackColor = Color.FromArgb(70, 85, 105), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        foreach (var b in new[] { edit, del, close }) b.FlatAppearance.BorderSize = 0;
        dlg.Controls.Add(edit); dlg.Controls.Add(del); dlg.Controls.Add(close);
        close.Click += (_, _) => dlg.Close();

        List<Database.ClientRow> current = new();
        void LoadClients()
        {
            var q = search.Text.Trim();
            current = Database.GetClients().Where(c => string.IsNullOrWhiteSpace(q) || c.Nom.Contains(q, StringComparison.OrdinalIgnoreCase) || c.Telephone.Contains(q, StringComparison.OrdinalIgnoreCase) || c.Note.Contains(q, StringComparison.OrdinalIgnoreCase)).ToList();
            grid.Rows.Clear();
            foreach (var c in current) grid.Rows.Add(c.Id, c.Nom, c.Telephone, c.Note);
            title.Text = $"GESTION DES CLIENTS  •  {current.Count} résultat(s)";
        }

        void EditClient(Database.ClientRow? selected)
        {
            bool isNew = selected == null;
            using var form = new Form { Text = isNew ? "Ajouter un client" : "Modifier le client", Width = 560, Height = 330, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, BackColor = Color.White };
            form.Controls.Add(new Label { Text = "Nom et prénom", Left = 24, Top = 22, Width = 180, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
            var name = new TextBox { Left = 24, Top = 48, Width = 490, Height = 32, Text = selected?.Nom ?? "" }; form.Controls.Add(name);
            form.Controls.Add(new Label { Text = "Téléphone", Left = 24, Top = 92, Width = 180, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
            var phone = new TextBox { Left = 24, Top = 118, Width = 490, Height = 32, Text = selected?.Telephone ?? "" }; form.Controls.Add(phone);
            form.Controls.Add(new Label { Text = "Autres coordonnées / note", Left = 24, Top = 162, Width = 220, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
            var note = new TextBox { Left = 24, Top = 188, Width = 490, Height = 45, Multiline = true, Text = selected?.Note ?? "" }; form.Controls.Add(note);
            var save = new Button { Text = "ENREGISTRER", Left = 334, Top = 245, Width = 180, Height = 38, DialogResult = DialogResult.OK, BackColor = Color.FromArgb(0, 170, 120), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9, FontStyle.Bold) }; save.FlatAppearance.BorderSize = 0; form.Controls.Add(save); form.AcceptButton = save;
            save.Click += (_, _) =>
            {
                if (string.IsNullOrWhiteSpace(name.Text)) { MessageBox.Show("Le nom et prénom sont obligatoires.", "SANKHÉ"); form.DialogResult = DialogResult.None; name.Focus(); return; }
                try
                {
                    if (isNew) Database.AddClient(name.Text.Trim(), phone.Text.Trim(), note.Text.Trim());
                    else Database.UpdateClient(selected!.Id, name.Text.Trim(), phone.Text.Trim(), note.Text.Trim());
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "Client", MessageBoxButtons.OK, MessageBoxIcon.Warning); form.DialogResult = DialogResult.None; }
            };
            form.ShowDialog(dlg);
            LoadClients();
        }

        add.Click += (_, _) => EditClient(null);
        edit.Click += (_, _) => { if (grid.CurrentRow == null || grid.CurrentRow.Index < 0 || grid.CurrentRow.Index >= current.Count) { MessageBox.Show("Sélectionnez un client.", "SANKHÉ"); return; } EditClient(current[grid.CurrentRow.Index]); };
        del.Click += (_, _) =>
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Index < 0 || grid.CurrentRow.Index >= current.Count) { MessageBox.Show("Sélectionnez un client.", "SANKHÉ"); return; }
            var c = current[grid.CurrentRow.Index];
            if (MessageBox.Show($"Supprimer le client « {c.Nom} » ?\n\nLe logiciel vérifiera d’abord s’il possède des opérations ou des dettes.", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            try { Database.DeleteClient(c.Id); LoadClients(); MessageBox.Show("Client supprimé.", "SANKHÉ", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Suppression impossible", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        };
        search.TextChanged += (_, _) => LoadClients();
        search.KeyDown += (_, e) => { if (e.KeyCode == Keys.Escape) { search.Clear(); e.SuppressKeyPress = true; } };
        LoadClients();
        dlg.ShowDialog(this);
    }

    void ShowAuditAndConsistency()
    {
        using var dialog = new Form { Text = "SANKHÉ — Contrôle & journal", Width = 1120, Height = 700, StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(7,18,38) };
        var tabs = new TabControl { Left = 18, Top = 18, Width = 1065, Height = 590 };
        var tabCheck = new TabPage("Contrôle des caisses") { BackColor = Color.FromArgb(7,18,38) };
        var tabAudit = new TabPage("Journal des actions") { BackColor = Color.FromArgb(7,18,38) };
        var checkGrid = new DataGridView { Left=12,Top=12,Width=1030,Height=500,ReadOnly=true,AllowUserToAddRows=false,RowHeadersVisible=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,BackgroundColor=Color.FromArgb(5,18,42),ForeColor=Color.White,EnableHeadersVisualStyles=false };
        checkGrid.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(18,91,168); checkGrid.ColumnHeadersDefaultCellStyle.ForeColor=Color.White;
        checkGrid.Columns.Add("c","Caisse"); checkGrid.Columns.Add("a","Solde affiché"); checkGrid.Columns.Add("b","Solde calculé"); checkGrid.Columns.Add("e","Écart");
        var check = Database.CheckCaisseConsistency();
        foreach (var x in check) checkGrid.Rows.Add(x.Caisse, Money(x.SoldeAffiche), Money(x.SoldeCalcule), Money(x.Ecart));
        var ok = check.All(x => Math.Abs(x.Ecart) < 0.01m);
        var state = new Label { Left=12,Top=525,Width=1030,Height=40,Text=ok ? "✓ Les soldes des caisses sont cohérents avec les mouvements enregistrés." : "⚠ Une différence a été détectée. Vérifiez le journal des mouvements.",ForeColor=ok?Color.FromArgb(100,230,160):Color.FromArgb(255,190,80),Font=new Font("Segoe UI",11,FontStyle.Bold) };
        tabCheck.Controls.Add(checkGrid); tabCheck.Controls.Add(state);

        var auditGrid = new DataGridView { Left=12,Top=12,Width=1030,Height=530,ReadOnly=true,AllowUserToAddRows=false,RowHeadersVisible=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,BackgroundColor=Color.FromArgb(5,18,42),ForeColor=Color.White,EnableHeadersVisualStyles=false };
        auditGrid.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(18,91,168); auditGrid.ColumnHeadersDefaultCellStyle.ForeColor=Color.White;
        auditGrid.Columns.Add("d","Date"); auditGrid.Columns.Add("a","Action"); auditGrid.Columns.Add("x","Détail"); auditGrid.Columns.Add("m","Montant"); auditGrid.Columns.Add("r","Référence");
        foreach (var x in Database.GetAuditLog()) auditGrid.Rows.Add(x.DateAction,x.Action,x.Details,Money(x.Montant),x.Reference);
        tabAudit.Controls.Add(auditGrid);
        tabs.TabPages.Add(tabCheck); tabs.TabPages.Add(tabAudit); dialog.Controls.Add(tabs);
        var close = new Button { Text="FERMER", Left=930,Top=620,Width=150,Height=38,DialogResult=DialogResult.Cancel,BackColor=Color.FromArgb(70,85,105),ForeColor=Color.White,FlatStyle=FlatStyle.Flat }; close.FlatAppearance.BorderSize=0; dialog.Controls.Add(close); dialog.CancelButton=close;
        dialog.ShowDialog(this);
    }

    void ChangeAccessPassword()
    {
        using var dialog = new Form
        {
            Text = "Modifier le mot de passe",
            Width = 470, Height = 360,
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false, MinimizeBox = false,
            BackColor = Color.FromArgb(7, 18, 38)
        };

        var current = new TextBox { Left = 40, Top = 58, Width = 370, UseSystemPasswordChar = true };
        var next = new TextBox { Left = 40, Top = 128, Width = 370, UseSystemPasswordChar = true };
        var confirm = new TextBox { Left = 40, Top = 198, Width = 370, UseSystemPasswordChar = true };
        foreach (var box in new[] { current, next, confirm }) box.Font = new Font("Segoe UI", 11);

        dialog.Controls.Add(new Label { Text = "Ancien mot de passe", Left = 40, Top = 30, AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) });
        dialog.Controls.Add(current);
        dialog.Controls.Add(new Label { Text = "Nouveau mot de passe (4 caractères minimum)", Left = 40, Top = 100, AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) });
        dialog.Controls.Add(next);
        dialog.Controls.Add(new Label { Text = "Confirmer le nouveau mot de passe", Left = 40, Top = 170, AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) });
        dialog.Controls.Add(confirm);

        var save = new Button { Text = "ENREGISTRER", Left = 40, Top = 250, Width = 180, Height = 42, BackColor = Color.FromArgb(180, 90, 255), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
        save.FlatAppearance.BorderSize = 0;
        save.Click += (_, _) =>
        {
            if (next.Text != confirm.Text)
            {
                MessageBox.Show(dialog, "Les deux nouveaux mots de passe ne correspondent pas.", "Mot de passe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                Database.ChangeAccessPassword(current.Text, next.Text);
                MessageBox.Show(dialog, "Mot de passe modifié avec succès.", "SANKHÉ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dialog.DialogResult = DialogResult.OK;
                dialog.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(dialog, ex.Message, "Mot de passe", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        };
        dialog.Controls.Add(save);

        var cancel = new Button { Text = "ANNULER", Left = 230, Top = 250, Width = 180, Height = 42, BackColor = Color.FromArgb(65, 78, 100), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
        cancel.FlatAppearance.BorderSize = 0; cancel.Click += (_, _) => dialog.Close();
        dialog.Controls.Add(cancel);

        dialog.AcceptButton = save;
        dialog.ShowDialog(this);
    }

    Panel CreateSettingsCard(string title, string description, Color accent, string buttonText, Action action)
    {
        var card = new Panel { BackColor = Color.FromArgb(10, 27, 53), Padding = new Padding(20) };
        EnableDoubleBuffer(card);
        card.Paint += (_, e) => DrawGlassPanel(e.Graphics, card.ClientRectangle, Color.FromArgb(8, 27, 52), accent, 20, 235);

        var titleLabel = new Label
        {
            Text = title,
            AutoSize = false,
            Left = 16,
            Top = 14,
            Width = 300,
            Height = 34,
            Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = Color.Transparent
        };
        card.Controls.Add(titleLabel);

        var desc = new Label
        {
            Text = description,
            Left = 16,
            Top = 51,
            Width = 300,
            Height = 48,
            Font = new Font("Segoe UI", 8.7f),
            ForeColor = Color.FromArgb(210, 228, 245),
            BackColor = Color.Transparent
        };
        card.Controls.Add(desc);

        var button = new Button
        {
            Text = buttonText,
            Left = 16,
            Top = 105,
            Width = 220,
            Height = 34,
            BackColor = accent,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Cursor = Cursors.Hand
        };
        button.FlatAppearance.BorderSize = 0;
        button.Click += (_, _) => action();
        card.Controls.Add(button);
        void FitCardControls()
        {
            int innerWidth = Math.Max(150, card.ClientSize.Width - 32);
            titleLabel.Width = innerWidth;
            desc.Width = innerWidth;
            button.Width = Math.Min(270, innerWidth);
            button.Top = Math.Max(105, card.ClientSize.Height - 45);
        }
        card.Resize += (_, _) => FitCardControls();
        FitCardControls();
        return card;
    }

    void SaveDatabaseAs()
    {
        try
        {
            var source = Database.DbPath;
            if (!File.Exists(source))
            {
                Database.Initialize();
            }

            using var dialog = new SaveFileDialog
            {
                Title = "Enregistrer la base de données SANKHÉ TRANSFERT",
                Filter = "Base de données SQLite (*.db)|*.db|Tous les fichiers (*.*)|*.*",
                FileName = $"sankhe_transfert_{DateTime.Now:yyyyMMdd_HHmmss}.db",
                AddExtension = true,
                OverwritePrompt = true
            };

            if (dialog.ShowDialog(this) != DialogResult.OK) return;

            Database.BackupDatabaseTo(dialog.FileName);
            MessageBox.Show(
                $"La base de données a été enregistrée avec succès.\\n\\n{dialog.FileName}",
                "SANKHÉ — Sauvegarde",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Impossible d’enregistrer la base de données.\\n\\n" + ex.Message, "Erreur de sauvegarde", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    void OpenDatabaseBackup()
    {
        try
        {
            using var dialog = new OpenFileDialog
            {
                Title = "Ouvrir une sauvegarde SANKHÉ TRANSFERT",
                Filter = "Base de données SQLite (*.db)|*.db|Tous les fichiers (*.*)|*.*",
                CheckFileExists = true,
                Multiselect = false
            };

            if (dialog.ShowDialog(this) != DialogResult.OK) return;

            var result = MessageBox.Show(
                "Vous allez remplacer les données actuellement ouvertes par celles de cette sauvegarde.\n\n" +
                "Pour éviter toute perte, faites d'abord une sauvegarde de la base actuelle.\n\n" +
                "Voulez-vous continuer ?",
                "OUVRIR UNE SAUVEGARDE",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (result != DialogResult.Yes) return;

            Database.OpenBackup(dialog.FileName);
            MessageBox.Show(
                "La sauvegarde a été ouverte avec succès.\n\nVous pouvez maintenant vérifier ou travailler sur ces données.",
                "SANKHÉ — Sauvegarde ouverte",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            ShowSettings();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Impossible d’ouvrir cette sauvegarde.\n\n" + ex.Message,
                "Erreur d’ouverture",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    void ClearDatabaseWithConfirmation(bool keepClients)
    {
        string scope = keepClients
            ? "• opérations\n• soldes et caisses\n• dettes et paiements\n• historiques Boutique\n\n✅ Les noms, prénoms et numéros de téléphone des clients seront conservés."
            : "• opérations\n• soldes et caisses\n• dettes et paiements\n• historiques Boutique\n• clients et leurs coordonnées (nom, prénom, numéro)";

        string title = keepClients
            ? "EFFACER LES DONNÉES — GARDER LES CLIENTS"
            : "EFFACER TOUT — SUPPRIMER LES CLIENTS";

        var first = MessageBox.Show(
            "ATTENTION : cette action va supprimer :\n\n" + scope +
            "\n\nLa suppression est définitive pour les données supprimées. Voulez-vous continuer ?",
            title,
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning,
            MessageBoxDefaultButton.Button2);

        if (first != DialogResult.Yes) return;

        var second = MessageBox.Show(
            keepClients
                ? "Dernière confirmation. Les données d’exploitation seront supprimées et les soldes remis à 0. Le carnet clients (nom, prénom et numéro) restera enregistré.\n\nContinuer ?"
                : "Dernière confirmation. Les données d’exploitation ET le carnet clients seront supprimés. Les soldes seront remis à 0.\n\nContinuer ?",
            "CONFIRMATION FINALE",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Stop,
            MessageBoxDefaultButton.Button2);

        if (second != DialogResult.Yes) return;

        try
        {
            Database.ClearAllData(keepClients);
            MessageBox.Show(
                keepClients
                    ? "Les données d’exploitation ont été supprimées. Les clients et leurs coordonnées (nom, prénom et numéro) ont été conservés."
                    : "Toutes les données d’exploitation ainsi que les clients et leurs coordonnées ont été supprimés.",
                "Données réinitialisées",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            ShowSettings();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Impossible d’effacer la base de données.\n\n" + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    void Backup()
    {
        var source = Database.DbPath;
        var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SankheTransfert_Sauvegardes");
        Directory.CreateDirectory(folder);
        var dest = Path.Combine(folder, $"sankhe_{DateTime.Now:yyyyMMdd_HHmmss}.db");
        Database.BackupDatabaseTo(dest);
        MessageBox.Show($"Sauvegarde créée :\n{dest}", "SANKHÉ TRANSFERT D’ARGENT");
    }

    // Logos exacts fournis par l'utilisateur : fallback intégré dans l'exécutable
    const string EMBEDDED_WAVE_LOGO = "iVBORw0KGgoAAAANSUhEUgAAAb8AAAG/CAMAAAD/zSlAAAABGlBMVEUSue7///8QEQ3ufR8At+4AAAAAte0PAAAAs+3vfBz1fQBDteRVxPHp9v1FwfAAsewAAAvK6vqb2vYRv/b1+/4QCwDd8vzB6PkWAADQ7fqo3/cACAwSsOKz4vgQBgAwve90zfON1vURn8vLy8tjyvLr6+uD0fSMi4upqKgFBwDidx74gh/i4uIQKjYVp9UUi7FycXEYXnW4uLhkY2MaGxkQUWkQGB4RQlUWeJgUaIVBQD+cnJtMS0pgNBTWcR2sXR7EaB8kGBA8JRSJShklJSUxHxJxrMgSNkUXKzAzNDNKKRNsORRVMRWbVB17QhcTICJvRy3FknDYiFJ/qryLpK7ngjbSkWhTsNOxm478dQC3lIPOYwDAYgDhhEGlG/RXAAAgAElEQVR4nO2dC3vauLb3bSIM6WAIYKCQECAhpEna9DJt02mnSTrp7N7bd8+es/c57+X7f41XxthYsiRLvkiLJv/nmWfahhjjH5LWWlprybJ/EnlYrtvvDwfj0WyxmM7njUajuVSjMZ9Pp4vZaDwY9vuu6+KXmr7domSZvoG88tz+sD0YdRbzRtNy6q163QlkYaGl8B9W/1bHP3esSWO+6IwGGKa78Rw3mZ83xENtOm9MfDzI8TnJCQWAJ835dNYZD13THySHNpSf1+5MG83JxFqNr0xC+LcdNJk0G/POYEMhbho/vMi1Ow2rvpwfM5OjMPrza91pztruxi2Mm8TP6w/Hi6YTsCtceCzWncli3O5vEsON4dcfd6bYQFFY5bIxdJzmtDPum/64stoMfsMZNi6zL3SqFB2r2Vi0N2IYgufnueMmtjJ0sYtBRM0RfP8CNj932GmUPGWK5NSbnSHsqRQwP3c8a6h4dWUIr4fNGeTVECo/b+xbK2bhBfJXw+kI6kQKk99wbnrgkcKe/rxt+qEwBY+fO5xZrVI8vHyqowXASBs0fsPRvA4Qni/s3887Q9MPiBIsfoPpBNbESQmhyRzWUgiInzeb6HfzlIURLgBNo1D4ecNpCz68QE5rDma7AgY/d4QNTtNYFOQ4jREMpxACv/6sAXnRYwphvx6CLWOenzvdhGWPIWTNzY9Bw/y84RyiryerVsP0LoVRft5gulHLXlLImQ+MEjTJb+Pp+ULOdGzwGZrjN2wUlL9iWAih5sDYUzTEz1/3TD/44oRazaGhWdQMv+FiM01OrvAsamZ/wgS/fsfa/HWPlmPNTHgTBvh1Jj/X2AuFJjP9D1M3P2/wE469UI4z1r0MaubXntdNP+RSVW9odge18uvPfuLBFwhZC61hUZ38xs2NC1OrC6FJR+MQ1Mev3/j54QVCTX1DUBc/t2Nqe7brS+9botZM1/6uJn4DAzt8Pre9vfPz8wP8396eVoxOU1NQVAs/b6Hb5fPRPX719MXFxYcPHx7h/y4uXjx99fhcG0NkTbUMQR382roTqbvW46ePXu7WarX9/f2eL/x//Lfayx8Xr/b0IEQW0jEEy+fnLrT6DN2988cXGFWvwlIP/+Tjq4M9LQjrGvbnS+eHVz4dz2olPGs+rdRqTHah8Kh88epcxyh0mqOyH2/J/LyOzk2+7t6ri30xvBDhh9/ONQBEaFayL1guv77Owde1Xr2Uoudrv/byqaWDYMm+YKn8RhrtFmyzvOQsemzhpfCVhnUQtUoNx5TIz51p3GLvHlzcV6EXTKMfHpc/BlF9WqIZUx6/oca5E0+dP2RnTgJg7TcNQ9CZlJcfUxq/UemPZa3u3gulqZMYggca5lA0K+sxl8TP05me1H18P8vgC4fgKw1mTL1R0iJYDj+dc6dlvco6+FYEtcyhzXLym0rhN9Ya7vxtPw89H+CL8/LvEk06ZTzqMvjNdCYHdl/kxecvgnsa7hQtSnjWxfPz5loDZo+yL30xgPd1AHQaxW9JFM5vqHWbHRueBeDDAD/qCKc5xSfaF81v0NS6VfS0GHwY4IWOPQk0KXpPqWB+Y601Kd1X+de+COALHXeMUMFWTLH8Onq3+h4XNfqWAJ/q2dddFOoJFsnP07xTe1AkPgzwsZ5d3UITKwrk5041b7R/KG729NXb1xBKs3wztMB4dnH8+lr9Bqzfih1+umwYPIU2itsTLIzfUK/h6Qc9C8bnR9L03DuaFAawKH5t3RmCe4U47qR6FT0zKDbSi3IEC+I31F3L3i3M84urdqHr/p2CABbDb6C9JPO8DHzabFBfxXjyhfAbaO8k0b0oh1/vpTZ+qJDcwiL4jbUX9XUf75aCDw9AHbu5gepFhGIK4DcwUJNZUNg6qX0tW0mBWgWMwPz8Bto+b6TuwY9cO+5CgPpWQOTkB5ibnwF8fsZEWfgqtRf6BqCVH2BefvrXPqzzl6UNPwzwQN8HQa28a2BOfibWvoL3HRL8NAVhAtVzjsB8/IxMnqU5D4F6z7V+mJxVgrn4Dc10UtorE5/eCdRXrkhMHn5tMw0guyVaL0t+L/S2O8gVSsvBz9DoS5k+T6pYQj7VlFf0eprbVTg5diOy8+tr3jBaS2R9VqtPjo9/F/CpVl8fHz95Xz3hX6OmaRciVJ7tpMz83Lmpfi4H/NjZSfX44ZHnHR3+zgNYff/syLO9owcCxBpjaIFQ9h35rPw8vckSMQmWv5P3h+H9HbPxVH89Wr3gIRdxpXahmR8GmDUnJis/valKhPixz+qz9Q0+YeGp/n4UveDwOW8K7WmMga7kTDNmpWXkpzdRkNDeBS9tqfpr7A6PWCtc9TD2ije8Adh7pKGehVI9Y3FENn5GomaBuucfeOZL9WH8HhkDsPop/gKPy++lZgPGl5MtkpaJn5mwS6DuwUcOv+p7Yg46ZPB7Q3yMX7kroL49iJgyRdKy8NOdakao+5g7/J4Qd3nE4HdIvII7gWo3QH2hTFXyGfh5Rht58s3P6jHFL7EAkhOs/YDLT2sIOxRqZvAiMvAz5fitxOdX3PjTuQe4Fmrq4Dcz28J6j5s4WH1NrH8PGfweEJ+E6WIs+V0Y4Wehafn8xoa7IO/xo5/k9Mjw4Ku/Ex+FG0PbN+BALKVeXabKz1TQOtL5I27VCjGBsv2/OGHu8odlwIEIpGrDKPIza7v4OhcFr2PrGzOAFvfwjz7x+d034kBYfqsmxUCaIj/dNUZJiYr+qq8jgBzbZG2jHvG9P9+BMPXxHEUbRo3fyPyhb8Lcl+rzZ8sA50OuaVL99dB/xdHha9EWoDl+lqMWSFPiNzT2qdYSb76fVF8fP3hwfCLa/3vy5sGbX8V7vHqK4dlCSkugCj+3Ye5ThUqtO1rurgs2Z9P3331+Hwx+RCU3XoXfzLTt4utDuckvgXo9Mw7gUmiusJekwA/A4odVfNUtSzVDDuBS9VkZ/PrGTU9fJecORvw05xASQi35XoXS/Mx7fksV3DOEy8/EDkQk1JT2AqX5Gdxxj6nc1PkYPz3NfHiSb1Uoy8/klm1MXeWmIbuBVPl9MMpPvjhXkp8LY/ZULH3Y3dl59/ntly9f3n6u7OyoMOzdN8xvIulESPIzmG5GqMtLnmDB2/367er68vT0dOv08vrq5rMKwprhD+rMi+TXBoLP6r6Uhbfz9erydPtse3t7a2trG/9h6/T6mzzCmkEHcCnJ0k4pfp7hz7LWucTjx6vdu69XW2dLcoTOzrauvr6TWg1159An5UjZoFL8oMyeEi0H8az5x5dvl5gUW2dnp9++4NUwDaFZB2IpqTCMDD/93Xl4SnEf8Kz5x83VJR56HHq+8FR6eX3zdVc8lRp2IJaSqeyU4AfF9rRE7gPGge0VvOSJ4YUIsUVz9QXbpDs7nOvta6+BSEjKi5fgB8NzX6r7lJM8sfvl6jqyVqTkmzSn11ffOQB7JncgVpLZCkzn1y/94O9u19rb25M6CYxXu7JzJTHsWAPxksvPtAGKJREHTedX+uzZPX/824uLF789Tu+ees6rXdn985pnsYh0dvqWswj2Hhk3QLEmqSZMKr/S8wW7rz7UlqpcpGUNdQ8e8dz33XdX6gDPLt/y1r/KS1MpTHE5s7z8+s2Sb7F7UQvHVK32m/iZdR/z+2bt7isDPLv+zDdBe+YdCKzUyuo0fiVnW3cPPsZXtNpT8asfizqW79xsqayB21tXIg8i7bukR6l1nSn8Sm4RgidE0iARVx6kdA7Z+XIqPwTPLm+4c6fEV0mTUFo2k5hfyWdRJfD5pQeig4hSdo92vkpbMXjuFOIzVcNCy0kxYcT8BvUy7617/jI5H9YqfICpp1XtVm6kPMCzre+VlAja/oXJFJi1UjrcifmVemdddilD7/5j3m8IaldC7VSu01bB7e3Tb9y4y/o2PkJwILDqwgEo5Fdu5IVHo/eSl/18/jH9xJXdne/XW4JZFLvsVylT5+o2IDgQVlouhYhff1LqjXEXs16FY/sdSB2Ys/PuyxUvCnqGzZbPcnuAxmpYKCFLFIUR8Ss3X1ewFdSrveiyHp5s8tnu/ueby7MziuH22dnp1dc/ZXNhDNZAkBKeWCbgV261Q7ciGky1DywrRr7xoL879Pbq8vQ0hHd6enr1/Z1SBsVTEAaoJa6I4PMr9zS4tCaQtQ8M80GtceTOzs7zP95++XJzc/P9y+d3O2oZTEZrWEiJEur5/Ialzp6ph7/VHiXXH/VTA3b9fUGfnHIGYWX/I5TxJ+oQyudXapsJiR6s+8kIspbalVC9fTj8+JS4PxmWWq1yLpHH2UtYEHpqV0IZrWEh1eKmUnD5lVvrJ5cGX3tKbOqWdGYV9925cQT9avJWQB6/kvPlJdPgay/ie7qaaleiNwexgxSIm0/P4edNy7VeJAIpwTOMhbN11a5E7w0gBS0UmnNymTj8BuXuusuPpNqPyI8o58hGwVsbrmEh5HBWQDa/krsjq1QR7Ufh7K5W8xPLcA0LIdRgr4BsfuX6fmokevdX61C3vEPH2DJdw0KoxfYB2fxKbtPTVXIEemE7R83Dz3wNS1zORJ6fW3KnAtUi9mAvXFPpe+xtgexABGIngzL5lX02gLIjV/uw19VtfsJyILCYnbVY/Ere98viyPnh7JKPPWK8KSAHwhdrALL4ld6nJ4MjXvt4oFz6nlf7kBwIzkY8g1/59UZZAim1Hz+KJyRW71HJz0FRrGReBr9R6fVGmgNhWWXiHA+RWEdEJPl55fcn3xB+FRPneAiEGM1dk/xK9t19bQq/XVAOBNOHT/LTcLCY5o2gzALmQLBciAQ/T0OXQbX4izlBcyCsVsKCSfDT0eSz+1xzJDOjYNSwxOQkDohI8Cvbd/fVVU9EMiJT53gIRFswNL+SN/4C6Q+lZNP+B1gOBBbtQtD8yt13D7W3GQsgmBqWSIltQIrfUMf0aWnOBMwuKDUskRB9QAvFb6SpVc+GTKD3odRARKJjMCQ/V9P5Kt2DykZYoGBqWCLRTZlIfsO6rlZZGnORTk6Ex0GIBKeGJVJ9IOCn7Wy/7uMiCXG1PKrj/af3J+lHdjAF0IFAcwE/jfeh1Ag5kzC010/ePHh2eHj47MGbJ69TjmVhCVANS6S6y+VXbs0DofROnjl1Uj05Pnx4FH22o4eHxxVlgvfBOYBWfcTlp/N0uHKzcavV5+RZqYGePRecbMWS0XM8OCKC2HF+nt4+nz8kc+gzqPr6jc3WG+G5cQlBqmEJheKt6eP8xlobfXYfvyzJhzipHj+kuUV6eKwyicLookWKcAHj/PTEztYqKSGpWn0gbJnyTMEUrb2Ax4+wQGP83LJbDSZUyjZE9dNhAhk1BOXn0NojePyIPKYYv7H+OynBiaj+yp87I4Cis29JQaphCRUvBozx0+a8r5Xa0CwDvqMkr4SOuOfj0gJVw7ISijWVXPMz0ma+aIBy+FJOnyb4wXMA8QS6tkDX/DTknTEk0ZJOBd/v6ZNnoIe/ywGEVcOyUiwPbc3P1DEBBQKsvpbFJw0QogMRT4OJ+Bk7X7O4EXhSTbM84zqU2paA6EBgRQtgxM81dkpHYWtglRUy4+uZzAAEVsOyUitaACN+eoMvhAoagdUnSvhsW8YIhVbDEmh9rkDEr2nykKMiAKosfoGOJPz43kuIBiiKiqkjfmbPqMoP8OT5M0V8eAl8n74EAqthWSk6HDDkNzR7SFX+NVB59vQlMYPuQ3Qg1u1gQn460uZFyr0GVuUcd1JH6QMQpANhodCDCPmV265ORvkAVnkbfmI9SB2A4GpYAoV5vCt+pR9zJKE8AE8+ZcJn26kDEE4b3rjQpE3wM7D3kFCeNbCqbrwESnUC9+GloPkK9yBW/DoQjkjNvgbKhq2TSg1k91iNuM0LzeL8Sm4XKa2sABUjLyoDsPcDJr+GG+MHYflbKhvA7MNPYgCC3IHAGsb4lXvUg4KyrYEZjc9AD1IsGHg1EEut8ugDfgaDn5SyrIEnz7MPPzwAP4kBht0PgWmVhbbkV+5RHWrKADBT6GWtlCAMwBoWX6tDPQJ+RoPXtJQBVlUD16QepvCD6UBYyI34mdv7Y0l1Day+zoXPtj8JAe5/hLgDEe4BLvm1Sz1mU1mKAHM4D4FSgmgAa1h8OaOIn6nUF56U1sCTnNMntmDEGfUQa1iwnHnErwGMn9IaWH2Sx/r05YktGKAOhGVF/EzfSFIKU2ju6TNtAoW5g4Q9wJCfB2v5W0oa4Ml7laQztsT78EBT0CxnuOLXBjd9WvJrYJ7YWShxDG3/I1B+oxU/aOZLIMlDPqrHufHZ9hvhBHrf9KPgaLriNzV9I0x1z+UKdLPu/MX17LnoHUCd4xFTY8XPfO4EU93HEvxOPuX1Hnw9fC1cAAEWUfvyDwW0/OiZ6RvhSaJAN3PiBClhMQS4Nrwr+WVIlt+zDlL0M6auhA1TyPJn28dCfjBTmCy/lx3mN9bUc1BdEl2aMie+kDoU8rsAym+05DcyfRt8dVMHYKa0z6SORPx6UB2I2ZKf6dRdgdK7NFULwWfbQn4vTT8HtvwDdSwwuUtMdZ+LbdDq7wXxExowL2FGsP1DcS3bLf+8lexKOzSuIPMlxYCpwExhQs0+5tc3VXgrpfOU8Zc/eB1ImEYI1oEYYn66Wl5nlDiOrVQxLZIwiQLoDgSy2phf2/RtiCXslJ1/7zaU0AAFuwMxxvwGIKPXocQLYPV9Me6DX0kmAFi7MP0Y2HJGmF/5x/3lUffgo6BLYfX3wviJDFCgNSx+DqgFdPcoVPf8g8CCyZ87EUmUQ9F7BLIGAjuAnuUtIJuf2AAVhWAKcx9SHIiXQB2IOeans2lyBgkTKXIVPpASbuECdSBQE/MD7f5ZYgeiMPcv1QE0/RSYQpZrwd39W0nIr5jdh3R+MGtYLMfFBGFLPH8Wx0+8g/QCpgFax/xgL39A+H0Ayq9v9QEmf8Z1fiHyHzTx6/2AWQNRH1p9fWeuZFH34BHffz+pFBX+TOEHtQaiPraGsMdf90CQ2nfy/Jbzc0bWADY/67HgqFWN/GA6EE7HglP6zpZo/0EjP5gOhDOzYIevrT1RDqhGfjBT0JyFZeDUByWJjinTx2//o+nnwJQztQC1nmAKBr/KfZgO4Bw6P3EKti7/D+g5HpbVsKbA+X0UJTBp5AezhqVpAd8+Ohe4D/ri11B3kNAEz6CgJU7A1sgPZg3LxAJa/BdKnL9b4P5tShMYmOd4gOfXFZcA6tp/x3oOkp8FnV9K+u6x8KRUFYkT6OEWUYNqXZdQV2h+FtJ8YqW0oyCARrCh8xOan7ryP5f8YKagAee3Jy4/OnleWP58JbUN7x0/dZ2n1G/qqX9Y8oPpQMDml1b+p6n+aMkPaA0LbH7C6qNKgQ5E6kE6+0BrWED7D13R7sOSX77W12ulnkQGtYYFNr+0LoTVYtr32HbqUY69DxB3IIDHPyX6hxTEL/Ucst6jc4AL4AT2/kN6D8KCDNBU8wVmDRmawN7/64qKNwN+xexApJ9FDZNfc+P5FWPApB+kCpIftl5A509I8Mt7+EOgtEOsoPKbw84/S+d38r78/p9w+TlT2Pmf6fwqlSJKOB+kvgtQfgvY+dddUfOCQIWUwKdt/oHlN4Nd/5Du/2noPx/yA+j/OR3Y9Uep8ZdicngPn6cuf0D5jWDX/6XGPysazl9Z8YMYP6uPYdffpu4/VIqYQGWmT5j7D/UB7Pr31P2/JcD854+lvwnmB2/69OvfYfefkOKXdw8wLXVwKZD7t37/CdDtP1PyXwJ+z3Pyq0jxg5j/4rjA+y91Zc5AyplEkVK5EvIDmH+27L8Euf211ZU5A6n6ay5+6bHrJT+A7rvl9z+DHcCWOQYwXxbhw5Tz30N+ANMnUMMD3v9TxoHIGUOTiJ1VgJ7hgaYe9P67qQd4LPn9nn0APkxLvA4EMv3TmYHvf33eS9+ByBWDSd95D/gBNF+C/tcD03chlNwxqtkH4FFq4lkgkP0Llv3nwR4fF0hqAcw+AGVCnxWg/UOC8x/6oBu4SkXQ/E52GYOgaWUrK4Hsv4SW56+APv9I3H8wpowmqJzxiadPkNV/y/OPQJ8/Jn0Q/Eklywr4UHjw+1r7HwFuHq3OH7NBZzBJeoC+CZOhlFpm48hX7SlE8yU4/8/ugB5/3YMfUhNolkSmB3KjD48/iN5DeP4m3PNvl5LIYVqqqnyS+MNPksNvH+LeOx5/HdjnTwdKaSESA6gaxpaLvFSABl+wxkt+LmgHAkuSn6oNKmt7At17iM5/t0GXAEolEYYAVYpZDmUXv8r+I5D4rKYb8ANdAmhJxrCX/N7L7+Qeyi5+QGOfWA074Ad6BwlrL7UKMAL4WtaGOZLH19s3/QA4mq74wd6BsOSymFYAJctZjqRyXgIB7T3v7z4E/FzIKaC+hGcAZgEo7TlU/NgLRN8dyxmu+NkOaAfCkt2ECAC+Tl8DDyU3jZYCmXjmy/FCfqB7wFj+IapyQewA4Ps0K/RQdFYxrX2IdQ9LOXbID3YE1FLw4ZcAU2qqj6vSnkMF8vCbR/za0BdAq1uRH4DiOfRQOuqy1P4H0x+dp6X5EvBzwS+Aktu4EcDnx2yCh8cqc2cFru9nWa1hxM+DHQFdSt4E9XVS/fQkaYg+PP6kNHeCPTfHF3LX/EDn8C7VPaipzKA+wcrrN/GkCu/B64oivUqvB3LjwRdqeBE/G3QR/EoqJkygarX6/smbZ4eHh8/ePHmP/6Z6gco+zFM7fPmbfxG/Nnx+3XPJfUAaYSj1X67UXpj+1Hw5gxg/2DlogSgTZiemDGji2uVcqvcS5r5RoGGMH/AcpkDrYnj8wCtvb66ur09Pr6+vbr7u7OzuZmWHr/U5din81+hScG1Pf/lzY/zAb0EsFXQj3N398+23yzOs7e2tre1t/0/XN1/f7agj3N159/WGutTlt7d/BpeCuuu+FFp4cX5j0/cjpYNH+xU8Wq7x894itH22df39T9V5dOfP79dbjEtd3nzGBGtAG+4GQiM7zm8TFkB/CXxZubrET5gh/Ni/Ka2Euzs3l1vsS51dXr2rwsxZWglNBgQ/6DkUgVD3ydb2NuuRL0fO9ulXeYA7ny+Fl/pfkG2XIHcizm+xAQYM+uWf93hPfDX3fXsntwruvruiJ056EP7zF8CPBM1tkt8meID/+EuMz3/q11JDcOfzNXPmjOveX/+COwLD5S/i5wH+sgVC/zpNxYcBysyhO18vU/FhgFt/d6E+FdSn+NnQDRjnb7axQWv79EsawJ23p+K5M7zU9t9AZyWEbJof7DJ4C/19T+qZLwGK18DdL1uyl7r3N8wp1Fkk+MFOYur+g+01sHR2+lkEcPcPmclzBXD7XyBn0Powwc+DnASDJv8lsfZFAC9FM+huuukS/y7AtEK9BD/IITTUTXEc6Kf+jQ9w55sCPmzE/BvgDOpMGfyGcPl13yg9c6zvPIA7XxSvdO8NPID1sZ3k14c7gf7nL0V+25d/cpbAdyqz5/JS/+8/0J4LmvQZ/OBmEaI3SrPnUjdsfrvfla90779Nf35aaD19xvmB3YP4Rc5diwsPQPbwu1S/1Cm0Aeh0bBY/qHsQ6L//R/WZYxPmO2sA7nxRXUi3/AEIjN+kzeRnw9yER11Zz53gx/QhdtSHnx8VN/0ISK0yz5L8RqbvjCnnXxmGHwbIsGB2/8ww/La2/gdWFGaVeZbkBzOGXVfz/SJ+DB9w5yYTP2A+IBpy+MEspJ78V4Y5D+uUwS/L9Ikn0K1fTD+EmNDE5vGDWMeC/pGJHlZiAt394zTblbb/AWhmilufFD8bAbrPlbpvsg0/RgxGOfYS6gxSDKbu8vkBrIPo/u9Myx8eNIkFcOcmI797/4TDL8qcYPGDeBhZNvMF87tO8LvKyO/s33A24usDAT+AvUB/+Xcmm5HJTzX2GV3qLzgGTCz2meQHrxch+uWve9vZdE3hO9m9Pst2pbO/wITQnJkn4jeE1osQ/eevexn1f+7X7pP6v1kvBWgPgpw+aX42wAk0s/ZoZb+U6YcQKixb4fIbgeN3p7g6tpifB20CvROhfgo/iC7gnUJRzh+Lnwv5POPbrtYglZ89vxuAYDVJ0EryA99N8vYqlnfG5+eCPlD1VmviSvCDXglxe0VsvPP5Qc1julNbip89u5tAIQpNGaxY/Iam7/ROTCWtFzY/mHkwt10o6Tzw+PXvfHh4YjgPPH72nQsBT8zhx+G3Ad0obpvYw4/Dz4O3DXjLhZpJ353Pzx6A74h9y+SM2KA4/DaioeQtUmLfPYWfPb7jB0r0vnsaP/BnstByHN1TPsJvWdf0tozIdQq/AUwfMPmwEHLqLdScT+eNSb2u8DTzPHfktFBj0RmNRrNFE9XLNtcd3vDj8ytoADYINZMfdEK8IPlQyZ83Euk5zqQxWyeFuINF01pVcZAX9tUUXyoUIt+TDucjhJrTcTwN0xtMm7m+DilCfEr8nxTST6ROhszdxIekXpDooYDmnugFTrMztEl54+kSIOHvLrsTITL7oM2bYah9mgF1R9Z0lDxq3hsvrNJGIc/4tEX8vGkB9+OQCTeM/HwyoSpRgIHIZ2mTV5+M6Hys5Z2353WKn+vzcxbkc+d9Poe8KNkatT5tJ+kt1V6gcggSBdOU+PzsdhHvXSevSTd5QnNyYU4OUPKr14//vDXnrereqI6S/FZHzkTifkHJt4zPn44z5j9LbzgpBWCLHXpZSsCvkH3AFjk/0ge90AtzYtBPyOlxtv4JYu6nhMJPPf7XgF+d/DJwqq2oexrHXhVrXMVWGW2MkehNRfz6BeTyOuSmI11fgWgGdPIGNXWsA+uoSS98pFxi4Qz4UTFgzsH3LWL69GKxfNRJwYdpl3AUWCJpMCYRv0I6Mk2Ij0wHVpv0+jWgPj4PP0r8Ji1irlzxo9AwPx9qEnfcX7/GEQ346APkf2TU/bC23SMJ+XFXeBWRE/DXfBAAAA5DSURBVCgZl6Oty0TyDfXI1qMTpY4EQit+1LNgBpmo6XOdjy6Fr/gmAnXhF1XMb5z/XtatYlmPbEa/IxV4dVzmD5HFs1w4WvGjZgNWqiRyyHl5/RWWw1d0Ai0r6SwmMT8v/0YuNcTINRUlp3ayghTZ7F8WLQkshfwoc5ZhblAWcWRw8UMgyY9QIEA0EU80Yn54Ns8NkLIgSQMmeXODuAFAWT/hNxvN1GbPNT/KlmO07EMkp2l4J4nKEb68AksQBK77Uin8vPwGMbVsEA5CM/mOhFFIbTqHN8PZyxQoGn/ktylZLRcdTBMoHPHMCbs/6HRGA8YP2oUV4dH+cUIp/AooqKZ8pkHcnWLNSfEpm+x14oW/xpg9PXc8m047vNhIxI/6PifiQVSso8N9S3eKHH8HAjmTTuIZF5VBi1IXijR+RXQ0II32WNSxxfpyxT3AJgs9So5ad9xs+Vs5TsuZ9lkII37URuiQjoGS8bow3pdwod2ZE/MrHJqgm/uZre6GNP4YSuWXvy891bEkvr6x3jDucBEPMxwsrYTjPm7Uo4s6aMb4VkT8LK55yfrxMFj+E8Og3aDC6A3KyC+ql3HqQpHKL/kVVRXldMUcKrZNwHWYV2OhSQ+wDmFkIZZrH+NHfqWpeB2VJLuyJOmy12EiyOJQ71lMFawo8LlSOr/83yWHuNzav+WkxEWPFJHGxiqpsU4vCR26axtyEl/bNT/u3QQ/JFZkN/xikDfaZ8TI6PywIkxQGZtXgp+bdwYln/h6iwGxIwuRhUMZX4vgX6kGRMwgSsJpin0GMojtkvYZaTCFcMlByc7toh52AU48SjQrYEiCH/aS8gEkp591TICTU+VGLvOM/L3gYtQmXp91b/SLiO9gg7gqMbtQptFqlUPCEFIoclkuIPaPZCIGMvzsac4bYS4qRCsoL/ZVW1tMxEhpB7MWohxa5kSF6FI5Yg4hvtZEwJz0LkJTuc7dkCDek/xe5E7AdAS7tmtJ8XPz9gUlJtAwJBW3TvrxiEo4JMjlr8M0BfucPTzK4I/zI4dTP35yLNGaOPJkWsSlBi2HLfYvZxYS74+tJMUvbxybfGJhSCCOZxgfFGH1BfEFDF0x2k7gvCPlZBD8yHk7FmGi3LxVJIha2cazDkfEW+Y9TSMlbh1Kjl9Oc4qMYa9IEP/YiXc2Wa0dpN8RumLkrMLZgk2EdkgbjJwOYvdJ/NKAfSlJ5QxckbMxX5L88h2ORAUVg2884Yg167GHFAImFqPVrEs5k/zdUnqrPR4VJ8LfMQt0QqyaYRAs4bDIPbGcJ3pLzZ7S/HL2tSPtglECj9cixlVg4RDuRZQYQ9qC/K0actEixx/pbEdTMDVNhHZKMt4jo3xbb9JjXpZfvpAs+WSC+THux2GXL+55jYMhEX/7yGucEXfF3x4hUyVIfmTgYB1gIh5atObXs/HLY4AKU5YISfPLGQclnubyUnFXCy+v8We6TKIgvcboaVLZDXx+xFMn+VGLSxQvIAc8Yv2zvHLwQ3SMgi9pfvhrmgMg+Y3350LCvppQuPy5h/yVcDYiF0XB9iQV9CG/feTGR2icEc57zGfSzo8TWGRJnp/dyeFEkGaHb4vEE+f7/kvicclZ4hlH7y09/ghbhOJHGuerMBn5j1HiBHJ086OyDoRS4Jcrob5O1Hu0SPtimZUbX2aGiNr7W4cTSfuFvyq3WPmDkYi8mpUF2iLWnPXrs61/2fk5iQ0WgRT4MePusiKnBOzLxSer5Uclvv6IGg3T6EKU/cl9Q5H9SeUNBzFQclGMtVDRzW+i8n4q/BLJtQoigxgLJ24gBzmfxPNrIGL98iI3nfb/eF4yEvh/icssP5eTWKJXUliNiCtkfFh0gFcsJX72LMcSGL9Oux7/Uq+c8LhXhv26+KqzdtMLib9Qb7aydwnrc8K91KAtpUFG/10l0c1W5Wc3Mi+BRKqn68QLgkMnPPY9d8naotgy1xQVd8UeA7UfTvMjoeCrkBHveLiC8jbmdU78mlLWB6WCQ5lfDi8wvnB5jdjTipKEZrEXEMtfrGxQcv+BdoAT/Mi94TEdIiImP4e4VsmH7Ckau4r8sqc2klH/Rexp9cNXxB/pNP4427H9K3pXk20UT0T7f8vLEAFG/GPCaiCDz2QooICcdK5Qoh4rTar8MucTkjHscewvYb4E8QgH8VfH99ISI4uVHODQeXfJHBByAp07RISP3LyTqXopRon7TpUyv8wHRBAPzItv10apYWP2C6iiM8q8bjOSiRKbL6wcHsK/jO9/JMu8qSfATNkg9yUz+VqKtosvdX5ZbRhuKnj0Sen69FBkiksiNJ9Iz3EYCb5JfmSAjbA+6VAhZdK7jN1QeuLLkr/E7vApVgZ+GfPReOlUsVRJTpcaKhUhkVw2IMrOEZomL8O4Z3KQzoi/0FX6VCqKm/gKJypzMyySSMlxXykDP7JESF6c+scYHU6pIuXjJfdT+9N12566xeowwPrOEVmiZOws8WLq1t0pYYQ6Lfo93QxGqrLt4isLv4y5HZw2GDE/l7NrmchlTr6kv/CrSZDjTNjRC+acMeN8vEHi4Sfbx/ljfuX2ICe5MmQIvkilCyaUiV9GI7TF4ufFPWVGPVmyZwUHc38wGg95kV8mP16CHiOmU0++ZXvRaE6azcacUW/BTEoVqz7j3LpY2fjZiyxOLDOQSJiPLcYLGClm8tubodhrNjuxpc94JV32srpqf9hnLdkeJytOIJU9o7gy8su0l8TMqSLckTrjhAo3GTGQTy+ILsLiR/d2Wom5J5WsmhFI3UN0eP0905SRX7ZTklDyOmQ0g1Xvxlps06qKk7fL5MfsQcL5ZAoDRD13Pr0bCk9Z+dn9LBZy8rEPycWGsQAyveXkQXhisedPZmYgb/BIx0aYESGxsngOgTLzYxTBpSv5HaZGV/KD8IaD2idm80u2n7EF5XKSGdFJ5zBdjGVDUtn5ZTlmJ9l4gH5aCTtvwK69oFKCWbfH6J9FK1koyN9RtJDUFNpXb90vUabJVQ5+GWJEiYdORxqTCyA/Q1f8qYdkNhmHX9ItEH0o5ngllSFRva66mMeVh596r6/EFJQYw3QhucBOaomeZsdh9I9kPLvELwqXdWQNhAS9kXqSpbItRigXP2VDORHDpgubEoV7nB6PwSdv8p7mcIoY/VtZl6BXnrTAV2sqsBTb07o6vkxhl0j5+NkjVT+eMjsScSb62yjsRYWsKWsVdDt+QFuKX6K5X1qxP3KaM47pNFhkqFPOGHaJlJOf3VGbMCg8XuKX6cJLsSuFbZsGvQz2F0GvXYof5wq0RSVhVKNJI/mtcUcNK0OVa158ufmp1pk6dUKMp5P2gsQVW83R0PV8uX08BqJm/vG34t8keUNSxw8gy3Hmo37wnvhd3cHMynaEgKRLUiY/DLC8fAI5IcwANZvNidNSOf8h33ti1pPmfD5vNJHo6yGUo9yHrwR+9gjKSR95q/TV3w85+D0zv2s9P74i+OUqbLnFyr32+SqCX87i3Fuq/Gufr0L45W62cAuV0+8LVQy/gns+3wLlCprFVBC/uwM71dQqCF9h/DJtJ91e5dhxIFUYP3t4d+i4pBBdnZFDxfGz+9mLy26VnJSTf5RUID86q/VOTCV6LedSkfxsL2ttyy1SnZHdn0OF8qNbUd8pIU7OYmYVzM8e3ZmhAiHuOeBZVTS/rMUtt0JoUpjfEKpwfjlbTf7McrKneXJVPL9cnb9+YqEM1bXpKoMftmLu7NCE0s/CyaJS+FEVsXfyVfjSt1Q5/Gy3eQcwLidjE8pUlcSvnJO0N1b0AUrFqTR+9uDODl2JV9RdhMrjZ/fn6tnIP6MKjVfTKpGf7c3ytFz+SYTqysXCKiqTn223b/0cWkLIhVC5/Gx3oTspE5YcUblLESqZnx/Qvr2eBLLotkyFq3R+2Iy5rQCdRomGy0rl8yvgKLWNlFP0Vh9TOvjZ7vzWbesipGHw2Zr42d74lsXTnPJXvkB6+PmG6G3yBVvzks3OSLr4+Z2zb8kQxB5TuT5fXPr42d5schuS7JG1KDTDTCyN/JZtIX72MYiceabjOrNKKz/bG0ygFOuWI2cy0jj4bN38MMGOthJ1/UJFVESrSTc/P0n7J3UGkVV2sJMh/fz8zsM/YVAbtZi9hMqWCX54GZxnP98JpJDTYLW9L19G+PkErZ/JkHHQyAg9Y/ywxs2fZBZF1qToqgZ5meNne6P5T2CK4pmzo9dlIGSQn22740Zrw9fBelOzw0fJKL9Nd+hRfTI2Ss84P9vPcdpQfxCve/ri1DyZ5+f7gxsY2HasqXl6MPjZ9rAz2aztwfpkVlwPkDyCwQ+bMoPmxpgyqGV82YsEhZ/t7y75HTVNw0kTvkG9O0RiAeLnNx5vWLBXQsdqdPQHqQUCxc/3JzpNsFUv2F2YDaBMnCsB42f7K+Fcpm25biGnPh/0DUU5+YLHz/bjMk0Eah7FdzMxGSXjCyQ/rH5nPoFhzCDkTBq8MzuMCyo/rOFoOjHuUzj1ybTTBjdtRgLMD1sz/cHUahmbSfGSZ03H8Na8uEDz8+X1ZxPHyXHKQjZ0viuKFkMPNDx7A/j5csfTxkSfb4/fadKcjkD5eTxtBD8srz2aNazycw+Rg130xQiam8fVpvDz5Q4HnTmql5b65Dgt1JgNhi70STOmTeLny3P7o7lVPEPH8c8U2yh0S20av5Wwb9FoTvzErxwHSPm/6scJJs3GdDTcNHKBNpSfL+xdjGaLOcaIxw5SMW+W3PAQnjTni1ln3N+UxY6hDeYXyO0P2+Mlx+AoRn8idJaMqKG2nCKDl1h4wM1G4/Zwk8kF2nh+Ky3PwcQsx6PObDGd48l1sj56Ff+52ZhP8VgbjQd9/DoPvF8nq/8PKoCH/YkMDV4AAAAASUVORK5CYII=";
    const string EMBEDDED_ORANGE_LOGO = "iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABGdBTUEAALGPC/xhBQAACklpQ0NQc1JHQiBJRUM2MTk2Ni0yLjEAAEiJnVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/stRzjPAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAAJcEhZcwAACxMAAAsTAQCanBgAAB53SURBVHic7d15vNx1fe/x90CCJIQQFknCIgphS+sSESyVBrnaBhIUkBYfuRUQ24pAUQO4tVxq4RZBILEUiXlYNRa19pFWMZQtSNgJEJDlYlkVRCwIKCEEQsh2/8DQUiE55+TMfOc33+fz8cifzHxKkfeLmTlzWklWBwCoygalDwAAOk8AAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVEgAAECFBAAAVGhI6QMAqMdGGyRv3SrZdVTypk2TzTdOhmyQLF+Z/HpZ8tDi5L5FyZ2/SlasKn1tbxMAALTV2E2SD+2S/PGOyV5jkgztw1/0YnLjY8m//jT59v3JE0vbfWV9WklWlz4CgN7ze2OSU/ZIDhiXl9ZmoFYllzyYfP7WZOETg3UdAgCAQfXGTZOZE5P9dx78x/7Bvclx1yW/eG7wH7s2AgCAQXP8m5NzJ6ZvL/MP1IvJn1+VfO2eNj5HBQQAAOtt2JDkX/4wed+unXvO7/44+fD8ZNnKzj1nLxEAAKyXzTdOrjwwmbBd5597wSPJpH9Pnn2x88/ddAIAgAHbYuPklg8kO21d7oZbf57sc6FXAvrLFwEBMCBbDis//knyju2T7++/fj9oUCMBAEC/bTksufmQ8uO/xgE7J597e+krmsVbAAD0S7eN/8tWJnv9i+8K6CuvAADQZ107/kmyYTJ7P28F9JUAAKBPunr8f2P82OTDu5W+ohm8BQDAOq35wN+Ory99ybo98qvkjRcYt3XxCgAAa9Wk8U+SN2yZHLBD6Su6nwAA4DU1bfzX+Ii3AdbJWwAAvKqmjn+SZFkydFayYlXpQ7qXVwAA+C2NHv8keV3ye6NLH9HdhpQ+gIHZaKONMmLEiIwaNar0KQzA888/nyVLlmTJkiWlTylq042SjTZMVq1Onn6h9DWs8fphyU1NHv/f2G+b5PrHSl/RvQRAA+y44455z3vek4kTJ2b8+PHZZZddMmLEiNJnMQhWrlyZhx56KPfdd19uueWWzJ8/PzfddFNWrFhR+rRBNWSD5A/GJH/0huT3RyfjN0+22iy/9QPbzy9J/uPp5NYnkysefemPX/LSWb0y/kkyfovSF3Q3nwHoUiNGjMiRRx6ZI488MnvuuWfpc+igJ554Iv/8z/+cWbNm5Z57mv0Lz393i+QTb06O3C0ZOmwAD7AimftgMvM/ksseGfTz+B96afyT5EePJnv8a+krupcA6DLDhg3LtGnTcsIJJ2TLLbcsfQ4FrVq1Kt///vdz8skn59577y19Tr/8zhbJ2Xsn+4/LoH0t272PJyctSC7+2eA8Hq/Ua+OfvPR9ADtcUPqK7iUAusjkyZNz3nnn5U1velPpU+giL774Ys4555yceuqpeeGF7n6jfNiQ5Ix3Jh9/e5IN2/Mclz2Q/PnVyS+ea8/j16gXxz9JFi1ONv966Su6lwDoAkOHDs2ZZ56ZT37yk2m1fIs1r+6OO+7IYYcdlgceeKD0Ka9qt82TSyYnb+rAiKxYmhx8mVcDBsPrhyU3f6Az/3/rtCefTrb+ZukrupcfAyxs5MiRufzyyzNt2jTjz1q97W1vyy233JJ999239Cm/5b3bJfd8sHMjMmRY8u8HJ5+a0Jnn61W9PP5J8mxvfZZ20AmAgjbbbLNcffXV2W+//UqfQkOMGjUql156aSZPnlz6lJcdsmNyxcFJNu7wE7eSL+6bnP7ODj9vj+j18U+8TbQuAqCQ4cOH5+KLL86ECf4Thv4ZNmxY5syZk3e+s/zyvWtM8r0DUvQHij+3dzLtreWev4lqGP8kue/p0hd0NwFQyKxZs/Kud72r9Bk01PDhwzN37txss802xW7YdpPkqoOSDC12wsumvzvZ/w2lr2iGWsY/SX70q9IXdDcBUMBRRx2VD33oQ6XPoOG23nrrfOc738kGG3T+f8YbtJKLDhjgz/a3Qyu5cP9k7CalD+luW1c0/kly5aOlL+huAqDDxowZk+nTp5c+gx6x77775uijj+74837iLcmE7Tr+tGv1uuHJV/6g9BXda+vf/KhfLeP/1KLk/kWlr+huAqDDzjjjDN/fz6A6/fTTO/qlUa8flkz//Y49Xb+8f7eXfiKBV6pt/JPkgu78admuIgA6aOedd/bSP4Nu1KhRmTZtWsee77MTkryuY0/Xb1/8vdIXdJcaxz+rk1k/Ln1E9xMAHfSZz3wmG27Ypq9Ho2rHHXdcNt1007Y/z8iNkhPe0vanWS8Ttkv+YGzpK7pDleOf5LIHk/sWlb6i+wmADhk5cmSmTp1a+gx61KhRo/KBD3yg7c/zwXHp/M/7D8Axv1v6gvK2HpbcfGh945/Vycm3lD6iGQRAhxx44IEZPnx46TPoYYcffnjbn+PPd2/7UwyKqeOSjSt+sW3N+L9xq9KXdN4//b/ktidLX9EMAqBDJk2aVPoEetzEiRMzcuTItj3+yI2SvbZt28MPrtcl/6vSDwPWPP7PLE6m3Vj6iuYQAB3i635pt6FDh7b12wH3GZtG/Rtjv3LfkVRMzeOfVcn7L0t+3d2/MLOrNOh/zs21+eabZ/vtty99BhXYY4892vbY79y6bQ/dFns17N71VfX4Jzl2fnLtf5a+olkEQAfsvntD3jil8caNG9e2x95lVNseui123az0BZ0zenjd4/+31ycz7y59RfMIgA4YO9bPJNEZY8aMadtjb9Owz7COHlH6gs4YPfylH/WrdfzPuCn5/K2lr2gmAdABI0ZU8m8iimvndwGM3KhtD90eXfBLitrN+Cefu6n0Fc0lADpg2LBu+Y0p9Lp2BsAGrbY9dHu0khE9HAG1j/8XFhj/9SUAOmDx4sWlT6ASQ4YMKX1CVxnSo/+GM/7JX91c+orm82+LDli0aFHpE4AeMXr4S7/Sdwfjz3rq0T7uLg899FDpE4AeYPyN/2ASAB3w4IMPZsWKFaXPABrM+Bv/wSYAOmD58uW59VY/pwIMTO3jf7rxbwsB0CHz588vfQLQQMY/+Wvj3xYCoEMuvPDC0icADTN6eHLLocaf9hAAHbJw4cLcc889pc8AGmLN+L9hy9KXlGH8208AdNB5551X+gSgAYy/8e8EAdBB3/jGN/LYY4+VPgPoYrWP/9/daPw7RQB00NKlS3PyySeXPgPoUsY/OfmW0lfUQwB02De+8Y3ceOONpc8Auszo4clC408HCYAOW716dQ4//PA888wzpU8BusSa8d/e+NNBAqCAn/70p/nwhz+clStXlj4FKMz4G/9SBEAhF154YY4//vjSZwAF1T7+/9f4FyUACpo5c2ZOOumkrF69uvQpQIcZ/+T/GP+iBEBh55xzTo444ogsXbq09ClAh4wentz6x8afsgRAF/jWt76VvfbayzcFQgXWjP92W5S+pAzj3z0EQJe4++67M2HChJxyyileDYAeZfyNfzcRAF1k2bJlOe2007LTTjtl+vTpWbJkSemTgEFS+/ifdoPx7zYCoAs99thjOfHEEzN27NgcddRRueSSS/Lcc8+VPgsYoDHGP6csLH0F/9OQ0gfw2pYsWZLZs2dn9uzZGTp0aN7xjndk/Pjx2WWXXTJq1KhsvvnmpU9suylTpmT48OGlz4ABGzM8WWj86UICoCGWL1+eBQsWZMGCBaVP6ZgzzzzT+NNoxt/4dzNvAdCVzjzzzHz6058ufQYMmPE3/t1OANB1jD9NV/v4n2r8G8FbAHSVL37xi/nUpz5V+gwYMOOf/I3xbwQBQNcw/jTdmk/7b2v8aQBvAdAVjD9NZ/yNf9MIAIoz/jSd8Tf+TeQtAIo666yzctJJJ5U+Awas9vH/2+uTz99a+goGwisAFGP8abqxmxh/499cAoAijD9NN3aTZOGhxp/mEgB0nPGn6Yy/8e8FPgNARxl/mq728f/89cnfGv+e4BUAOsb403TG3/j3Eq8A0BFnn312TjzxxNJnwICt+cDfNr3/SzhflfHvPV4BoO2MP01n/I1/LxIAtJXxp+mMv/HvVQKAtjH+NJ3xN/69zGcAaItzzjknJ5xwQukzYMBqH/+/uT451fj3NK8AMOiMP023zXDjb/x7nwBgUBl/mm6b4cnCPzH+9D4BwKAx/jSd8Tf+NfEZAAaF8afpah//U65LTrut9BV0klcAWG/Gn6Yz/sa/Rl4BYL1Mnz4906ZNK30GDNg2w5Pb/jgZY/ypjFcAGDDjT9O9PP6Vfre/8a+bAGBAjD9NZ/yNf+0EAP1m/Gk642/88RkA+mnGjBn55Cc/WfoMGLDax//k65K/M/7EKwD0g/Gn6bbdxPgbf9YQAPSJ8afptt0kufVQ4w9rCADWyfjTdMbf+PPbBABrVfP433jjjaVPYBDUPv5/fa3x59UJAF5Vq9WqfvwPOOCA0mewnox/cvqPSl9Bt/JTAPyWVquV6dOnVz/+ixcvLn0K6+mGg5PNRpa+ogzjz7p4BYBXMP7Gv5cYf3htAoCX1T7+N9xwg/Gn8Yw/fSUASGL8b7jhhkyePNn402jGn/7wGQBe/sDfJz7xidKnFGH86QV/dW3yBeNPP3gFoHLG3/jTfMafgRAAFTP+xp/mM/4MlAColPE3/jSf8Wd9+AxAhYz/S5/2f/bZZ0ufAgP2uWuSM24vfQVNJgAq02q18qUvfSkf//jHS59ShPGnFxh/BoO3ACpi/I0/zWf8GSwCoBLG3/jTfMafwSQAKlD7+F9//fXGn8Yz/gw2AdDjjP/1mTx5svGn0Yw/7eBDgD2s1Wrl7//+73P88ceXPqUI408vMP60i1cAepTxN/40n/GnnQRADzL+xp/mM/60mwDoMcbf+NN8xp9O8BmAHtJqtXLuuefmL//yL0ufUsSaT/svWbKk9CkwYJ+9JjnT+NMBXgHoEcbf+NN8xp9OEgA9wPgbf5rP+NNpAqDhjL/xp/mMPyUIgAarffyvu+4640/jGX9K8SHAhjL+12Xy5MnGn0b7zNXJF+8ofQW1EgAN1Gq18g//8A857rjjSp9ShPGnFxh/SvMWQMMYf+NP8xl/uoEAaBDjb/xpPuNPt/AWQEMY/5c+8Pfcc8+VPgUGzPjTTQRAA7RarZx33nk59thjS59ShPGnF3z6muSsO0pfAf/FWwBdzvgbf5rv09ckZ/lRP7qMAOhixt/403zGn24lALqU8Tf+NJ/xp5v5DEAXqn38r7322kyePNn402wrko/u/tKfXvXiymTJiuSx55L7nknueiq56hfJfz5f+jL6QgB0GeNv/OkRQ5JxW5c+ooxHf51ccF/y9XuTB58pfQ2vxVsAXaTVauXLX/6y8Tf+0GjbbZF8bu/kgQ8nl0xJ3lFpCHU7AdAl1oz/McccU/qUIow/9KBWcsDOycKpybffm2w9rPRB/HcCoAsYf+MPPa2V/O/fTR45PNn/DaWPYQ0BUJjxv9an/aESrxueXHpI8jfvKH0JiQAoqtVq5fzzz69+/J9/3keGoRqt5PP7JLP2TVqlb6mcAChkzfh/7GMfK31KEcYf6vbRCcmX3lX6iroJgAKMv/EHko/vmRz/5tJX1EsAdJjxN/7Afzl332RPPyZYhADooNrH/5prrjH+wCsNSf5tUrKRNeo4f8s7xPhfk8mTJxt/4Ldsv2XymQmlr6iPAOiAVquVmTNnGn/jD7yGU/dMNntd6SvqIgDabM34H3300aVPKcL4A32ycXLiW0ofURcB0Ea1j//VV19t/IE+m/bWZENfDtAxAqBNjP/VmTJlivEH+mzEiOSPti99RT0EQBu0Wq185StfMf7GH+in97+x9AX1EACDbM34f/SjHy19ShHGH1gffllQ5wiAQWT8jT+wft64ZTJsSOkr6iAABonxN/7AIGglu40qfUQdBMAgqH38r7rqKuMPDJodNyt9QR0EwHoy/lflwAMPNP7AoNlsaOkL6uCdlvXQarUya9as/MVf/EXpU4ow/t3nxRdfLH0CrDffCNgZXgEYIONfx/ivWLGi9An98uyzz7btsVesattDwyssWV76gjoIgAGoffznz59fxfgnyZIlS0qf0C/tDIBn/UuZDlm8rPQFdRAAA3DeeedVPf7ve9/7qhj/JHnkkUdKn9AvP//5z9v22A+3ry3gFX72XOkL6iAA+umzn/1sjj322NJnFFHb+CfJvffeW/qEfrnvvvva9tg/frptDw2vcI9/1jpCAPTDlClTcvrpp5c+o4gaxz9J7rrrrtIn9Mudd97Ztse+/cm2PTS87KlFyTPeAugIAdBHY8eOzezZs9Nq1ferqmod/+SlX2fcFEuXLs0tt9zStse/8fEkzfpMJA10+aOlL6iHAOijs88+O1tttVXpMzqu5vFPkgULFuSJJ54ofUafzJs3L0uXLm3b4z+/IpnfrI9E0EAXP1z6gnoIgD7YZ599MnXq1NJndNyVV15Z9fgnycqVK/Pd73639Bl98u1vf7vtz/H1e9r+FNTsheQHD5c+oh4CoA9OPvnk6l76v/LKK/P+97+/6vFf46tf/WpWr15d+oy1evzxxzN37ty2P8+//TRZ5h8J2uQf73nplSY6QwCsw1vf+tZMmjSp9BkdZfxf6e67785FF11U+oy1mjFjRpYta/8np15YmZz+o7Y/DTVamZx6W+kj6iIA1uGII44ofUJHGf9Xd8opp2TlypWlz3hVv/jFL3L++ed37Pmm35k836zvR6IB/vGu5Of+ueooAbAWrVYrH/zgB0uf0TE//OEPjf9ruPPOOzNz5szSZ7yqE088saPfWLhkeXLMtR17Oiqw7PnkpJtKX1GfVpLufnOzoPHjx+fHP/5x6TM64oc//GEOOugg478WI0eOzG233ZZx48aVPuVl3/ve93LooYcWee55ByZ/2D1/K2iwP7ko+deflL6iPl4BWIuJEyeWPqEjjH/fLF68OIcddlhH3mvvi4ceeih/9md/Vuz5D7siefqZYk9Pj5h5m/EvRQCsxZvf/ObSJ7Sd8e+f22+/PYcddljxzwM8+eSTmTRpUhYtWlTshkXLkr2/n6xo31cP0OOu+mly/PWlr6iXAFiLnXbaqfQJbWX8B2bu3Lk5+uiji0XA008/nSlTpuSBBx4o8vz/3X2Lkok/SNIdL4rQIDf8LJlySbLSm9DFCIC1GD16dOkT2sb4r5+vfe1rmTp1al544YWOPu+jjz6ad7/73Vm4cGFHn3dtFjyevH1O0rDfnExBP7g3ec/cZKmf+S9KAKzFiBEjSp/QFldccYXxHwRz5szJ3nvvnfvvv78jzzdv3ry8/e1v78pfUHT7U8m47yQLfFUwa7Mq+atrk0MuS5Z150/VVkUArMUGG/Te354rrrgiBx98sPEfJHfccUf22GOPzJgxIytWtOc/ZxYtWpTjjjsu+++/f558snt/Jd8vn0/2+X5y0tVJOvvCCA1w7+PJXt9NvvAjP3rWLXpv4QZRJ3+2uhOMf3ssWbIkJ5xwQt72trdlzpw5WbVq1aA87nPPPZcZM2Zk1113zfnnn9/1X0ecJKtWJ+fckYz9p2TWj5IsL30Rpf3y18lH5yW/8y/Jwmb8Xq1q+B6Atbjiiivy3ve+t/QZg8L4d86uu+6ao446Kn/6p3+a7bbbrt9//V133ZXZs2fnW9/6Vlf/F39fjB6efGS35OjxyQ71/TLNeq1Mrngo+eo9L/3+iFVWpisJgLWYOXNmPvaxj5U+Y73NmzcvhxxyiPHvsFarlbe85S3Zb7/9MmHChOy6667ZdtttM2LEiGy66aZZvHhxFi1alIcffjj3339/br755syfPz8/+9nPSp/eFm8amUzaPnnXmGT3UcmOI5PNN06yUV76NxHNsyJZsTz55dLk3qeTu59Ornw0ufo/k2dfLH0c6yIA1uL444/PueeeW/qM9WL8AXg1PgOwFtddd13pE9aL8QfgtXgFYC022GCD/PKXv8xWWzXvzUvjD8DaeAVgLVatWpU5c+aUPqPfjD8A6yIA1uGb3/xm6RP6xfgD0BcCYB1uvvnm3HjjjaXP6JN58+b5UT8A+kQA9MFpp51W+oR1WjP+S5f61WwArJsA6IPLLrssF198cekzXpPxB6C//BRAH40bNy6333571/2CIOMPwEB4BaCPHnzwwRx77LGlz3iFyy+/3PgDMCAbJvl86SOa4q677sro0aOz5557lj4ll19+eQ455BDjD8CAeAugnzbccMNccMEFmTp1arEbjD8A68tbAP20cuXKHHHEEZk9e3aR558zZ04OOugg4w/AevEWwACsWrUqc+fOTZJMnDgxrVb7f5XZ6tWrc9ZZZ+WYY47JihUr2v58APQ2bwGsp/322y8XXHBBtt1227Y9x+OPP56PfOQjufTSS9v2HADUxVsA6+mqq67Kbrvtli984QtZtmzZoD728uXLM2PGjOy+++7GH4BBt9qfwfkzZsyY1WecccbqX/3qV6vXx6JFi1ZPnz599fbbb1/8/yZ//PHHH39684+3ANpg6NChmTRpUg4++OBMnDgxO++88zr/mp/85Ce59tprc9FFF+WSSy4Z9FcTAOC/EwAdsMUWW2TnnXfODjvskFGjRmXjjTfOCy+8kMWLF+fhhx/Ogw8+mKeeeqr0mQBURAAAQIV8CBAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBC/x/jgc+nGfwg5gAAAABJRU5ErkJggg==";

    Image? LoadAsset(string fileName)
    {
        // Cache permanent des images : évite de relire/décoder les PNG à chaque repaint.
        if (AssetCache.TryGetValue(fileName, out var cached)) return cached;
        try
        {
            string[] candidates =
            {
                Path.Combine(AppContext.BaseDirectory, "Assets", fileName),
                Path.Combine(Directory.GetCurrentDirectory(), "Assets", fileName),
                Path.Combine(AppContext.BaseDirectory, fileName)
            };

            foreach (var path in candidates)
            {
                if (!File.Exists(path)) continue;
                using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var temp = Image.FromStream(fs);
                var image = new Bitmap(temp);
                AssetCache.TryAdd(fileName, image);
                return image;
            }

            string? data = fileName.Equals("wave_exact.png", StringComparison.OrdinalIgnoreCase)
                ? EMBEDDED_WAVE_LOGO
                : fileName.Equals("orange_money_exact.png", StringComparison.OrdinalIgnoreCase)
                    ? EMBEDDED_ORANGE_LOGO
                    : null;

            if (string.IsNullOrWhiteSpace(data)) return null;
            byte[] bytes = Convert.FromBase64String(data);
            using var ms = new MemoryStream(bytes);
            using var embedded = Image.FromStream(ms);
            var embeddedImage = new Bitmap(embedded);
            AssetCache.TryAdd(fileName, embeddedImage);
            return embeddedImage;
        }
        catch
        {
            return null;
        }
    }

    void DrawAnimatedBackground(object? sender, PaintEventArgs e)
    {
        // V137 : fond global inspiré de la nouvelle maquette Opérations.
        // Il reste statique pour conserver une interface fluide et sans scintillement.
        var r = content.ClientRectangle;
        if (r.Width <= 0 || r.Height <= 0) return;
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.CompositingQuality = CompositingQuality.HighSpeed;
        e.Graphics.PixelOffsetMode = PixelOffsetMode.HighSpeed;
        using var bg = new LinearGradientBrush(r,
            Color.FromArgb(2, 12, 35), Color.FromArgb(9, 30, 62), 25f);
        e.Graphics.FillRectangle(bg, r);

        // Halo bleu Wave à gauche.
        using var waveGlow = new SolidBrush(Color.FromArgb(34, 0, 145, 255));
        e.Graphics.FillEllipse(waveGlow, -220, 50, 720, 720);
        using var waveGlow2 = new SolidBrush(Color.FromArgb(22, 0, 210, 255));
        e.Graphics.FillEllipse(waveGlow2, -80, r.Height / 3, 420, 420);

        // Halo orange à droite pour rappeler Orange Money.
        using var orangeGlow = new SolidBrush(Color.FromArgb(30, 255, 110, 20));
        e.Graphics.FillEllipse(orangeGlow, r.Width - 520, -80, 760, 760);
        using var orangeGlow2 = new SolidBrush(Color.FromArgb(18, 255, 180, 35));
        e.Graphics.FillEllipse(orangeGlow2, r.Width - 350, r.Height / 3, 480, 480);

        // Lueur violette centrale, comme dans la maquette.
        using var purpleGlow = new SolidBrush(Color.FromArgb(20, 190, 40, 210));
        e.Graphics.FillEllipse(purpleGlow, r.Width / 3, r.Height / 4, 520, 520);

        // Voile sombre pour conserver une excellente lisibilité des textes.
        using var veil = new SolidBrush(Color.FromArgb(38, 2, 12, 30));
        e.Graphics.FillRectangle(veil, r);
    }

    static void EnableDoubleBuffer(Control control)
    {
        var prop = typeof(Control).GetProperty("DoubleBuffered",
            System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
        prop?.SetValue(control, true, null);
    }

    static void DrawRoundedBorder(Graphics g, Rectangle rect, int radius, Color border)
    {
        if (rect.Width <= 1 || rect.Height <= 1) return;
        rect.Width -= 1;
        rect.Height -= 1;
        using var path = new GraphicsPath();
        int r = Math.Min(radius, Math.Min(rect.Width, rect.Height));
        path.AddArc(rect.X, rect.Y, r, r, 180, 90);
        path.AddArc(rect.Right - r, rect.Y, r, r, 270, 90);
        path.AddArc(rect.Right - r, rect.Bottom - r, r, r, 0, 90);
        path.AddArc(rect.X, rect.Bottom - r, r, r, 90, 90);
        path.CloseFigure();
        g.SmoothingMode = SmoothingMode.AntiAlias;
        using var pen = new Pen(border, 1.2f);
        g.DrawPath(pen, path);
    }

    void Debounce(Action action)
    {
        searchDebounce.Stop();
        searchDebounce.Tick -= SearchDebounceTick;
        searchDebounce.Tick += SearchDebounceTick;
        searchDebounce.Tag = action;
        searchDebounce.Start();
    }

    void SearchDebounceTick(object? sender, EventArgs e)
    {
        searchDebounce.Stop();
        searchDebounce.Tick -= SearchDebounceTick;
        if (searchDebounce.Tag is Action action) action();
    }


    // Formatage des zones de saisie : l'espace est uniquement visuel.
    // Les calculs continuent à utiliser la valeur numérique sans espaces.
    static void ApplyMoneyInputFormat(TextBox tb)
    {
        bool busy = false;
        tb.TextChanged += (_, _) =>
        {
            if (busy) return;
            var raw = new string(tb.Text.Where(char.IsDigit).ToArray());
            if (string.IsNullOrEmpty(raw)) return;
            var formatted = string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0:N0}", decimal.Parse(raw, System.Globalization.CultureInfo.InvariantCulture)).Replace(",", " ");
            if (tb.Text == formatted) return;
            var caret = tb.SelectionStart;
            var digitsBefore = tb.Text.Take(Math.Min(caret, tb.Text.Length)).Count(char.IsDigit);
            busy = true;
            tb.Text = formatted;
            int pos = 0, seen = 0;
            while (pos < tb.Text.Length && seen < digitsBefore) { if (char.IsDigit(tb.Text[pos])) seen++; pos++; }
            tb.SelectionStart = pos;
            busy = false;
        };
        tb.KeyPress += (_, e) =>
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
        };
    }

    static void ApplyPhoneInputFormat(TextBox tb)
    {
        bool busy = false;
        tb.TextChanged += (_, _) =>
        {
            if (busy) return;
            var raw = new string(tb.Text.Where(char.IsDigit).Take(9).ToArray());
            var formatted = raw.Length switch
            {
                <= 2 => raw,
                <= 5 => raw.Insert(2, " "),
                <= 7 => raw.Insert(2, " ").Insert(6, " "),
                _ => raw.Insert(2, " ").Insert(6, " ").Insert(9, " ")
            };
            if (tb.Text == formatted) return;
            var caret = tb.SelectionStart;
            var digitsBefore = tb.Text.Take(Math.Min(caret, tb.Text.Length)).Count(char.IsDigit);
            busy = true;
            tb.Text = formatted;
            int pos = 0, seen = 0;
            while (pos < tb.Text.Length && seen < digitsBefore) { if (char.IsDigit(tb.Text[pos])) seen++; pos++; }
            tb.SelectionStart = pos;
            busy = false;
        };
        tb.KeyPress += (_, e) =>
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
        };
    }

    static string Money(decimal value) => $"{value:N0} FCFA";

    static string TruncateText(string? value, int maxChars)
    {
        value ??= "";
        if (value.Length <= maxChars) return value;
        return value.Substring(0, Math.Max(0, maxChars - 1)) + "…";
    }
}
