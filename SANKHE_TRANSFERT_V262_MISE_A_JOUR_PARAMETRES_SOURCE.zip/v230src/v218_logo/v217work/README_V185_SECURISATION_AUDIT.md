# SANKHE TRANSFERT D'ARGENT — V185

## Sécurisation et contrôle global

Cette version part de la V184 et ajoute notamment :

- sauvegarde SQLite cohérente avec `VACUUM INTO`, vérification `integrity_check` et fichier temporaire avant remplacement ;
- ouverture d'une sauvegarde après validation SQLite ;
- correction de l'affichage de l'origine dans le menu Dettes (`Rééquilibrage — Vente UV`) ;
- contrôle des retours Boutique : un retour Wave/Orange/espèces ne peut pas dépasser la dotation correspondante ;
- journal d'audit pour les opérations, rééquilibrages, remboursements de dettes, Seddo et clôtures Boutique ;
- contrôle de cohérence des soldes des quatre caisses par comparaison avec les mouvements enregistrés ;
- accès au contrôle et au journal depuis Paramètres ;
- sauvegarde automatique locale utilisant le même mécanisme sécurisé ;
- maintien de la règle : une dette ne peut être soldée que par Caisse Wave, Caisse Orange Money ou Caisse générale, jamais Caisse Seddo ;
- maintien de la logique Vente UV / Achat UV et des règles précédentes.

## Limite de validation

Le SDK .NET 8 n'est pas installé dans l'environnement de préparation. Le code n'a donc pas pu être compilé ici. Le projet reste un projet .NET 8 Windows Forms et doit être compilé sur Windows avec le SDK .NET 8.

La partie multi-appareils (2 PC + 3 iPhone) n'est pas transformée dans cette V185 : elle nécessite une architecture serveur/base centralisée, différente de SQLite local.
