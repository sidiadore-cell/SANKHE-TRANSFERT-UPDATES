SANKHE TRANSFERT — V87
Correction de la colonne SERVICE dans les rapports de dettes.

Règle :
- Une dette créée par un transfert Wave affiche Wave tant qu'elle n'a pas de règlement.
- Une dette créée par un transfert Orange Money affiche Orange Money tant qu'elle n'a pas de règlement.
- Si la dette Wave est réglée par Caisse Wave, le rapport affiche Wave.
- Si la dette Orange Money est réglée par Caisse Orange Money, le rapport affiche Orange Money.
- Si la dette est réglée depuis une autre caisse, le rapport affiche cette caisse :
  Caisse Wave, Caisse Orange Money, Caisse générale ou Caisse Seddo.
- Les rapports général et individuel utilisent la même règle.
