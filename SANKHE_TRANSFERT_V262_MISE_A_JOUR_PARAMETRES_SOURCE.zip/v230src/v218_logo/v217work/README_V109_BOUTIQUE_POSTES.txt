V109 — MON BOUTIQUE PAR POSTES

- Suppression de l'interface « opérations indépendantes des agents ».
- La Boutique fonctionne désormais par 6 postes fixes : Poste 1 à Poste 6.
- Chaque poste possède son propre tableau/carte avec l'employé affecté.
- L'employé peut être modifié (nom, téléphone, observation) depuis le poste.
- Chaque poste permet la distribution du matin Wave/Orange Money et le retour du soir.
- Le Poste 1 à Poste 6 est stocké en base de données pour conserver l'identité du poste.
- Un poste ne peut pas être affecté simultanément à deux employés actifs.
- Le rapport Boutique est basé sur les postes, les distributions et les retours.
- Les anciennes opérations Boutique restent conservées dans la base, mais ne sont plus saisies depuis l'interface.
