SANKHÉ TRANSFERT — VERSION 8

Amélioration du tableau de bord :
- Cartes/cages modernes, colorées et semi-transparentes.
- Grande cage WAVE — MOUVEMENTS avec volume total et sous-indicateurs Dépôts, Retraits, Transferts.
- Grande cage ORANGE MONEY — MOUVEMENTS avec volume total et sous-indicateurs Dépôts, Retraits, Transferts.
- Cages globales séparées : DÉPÔTS, RETRAITS, CAISSE et DETTES.
- Effet glass/translucide, coins arrondis, bordures légères et accents de couleur.
- Mise en page responsive dans la fenêtre.
- Les données restent liées à la base SQLite existante.

Compilation :
Ouvrir le fichier SankheTransfert.csproj avec Visual Studio 2022 (ou un environnement .NET 8 compatible Windows Forms) puis Compiler/Rebuild.
