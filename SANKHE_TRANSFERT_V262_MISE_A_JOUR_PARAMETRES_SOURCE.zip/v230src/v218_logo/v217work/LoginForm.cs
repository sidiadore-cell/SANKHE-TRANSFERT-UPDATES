using System;
using System.Drawing;
using System.Windows.Forms;

namespace SankheTransfert;

public sealed class LoginForm : Form
{
    readonly TextBox password = new();
    readonly Label message = new();
    int attempts;

    public LoginForm()
    {
        Text = "SANKHÉ — Accès sécurisé";
        Width = 500;
        Height = 360;
        MinimumSize = new Size(500, 360);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        BackColor = Color.FromArgb(7, 18, 38);

        var title = new Label
        {
            Text = "SANKHÉ TRANSFERT D’ARGENT",
            AutoSize = false, Left = 35, Top = 32, Width = 430, Height = 45,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 18, FontStyle.Bold), ForeColor = Color.White
        };
        Controls.Add(title);

        var subtitle = new Label
        {
            Text = "ACCÈS SÉCURISÉ",
            AutoSize = false, Left = 35, Top = 82, Width = 430, Height = 28,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = Color.FromArgb(255, 214, 0)
        };
        Controls.Add(subtitle);

        var label = new Label
        {
            Text = "Mot de passe",
            AutoSize = true, Left = 72, Top = 132,
            Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = Color.White
        };
        Controls.Add(label);

        password.Left = 72; password.Top = 160; password.Width = 356; password.Height = 36;
        password.Font = new Font("Segoe UI", 12, FontStyle.Bold);
        password.UseSystemPasswordChar = true;
        password.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) Login(); };
        Controls.Add(password);

        var login = new Button
        {
            Text = "SE CONNECTER", Left = 72, Top = 210, Width = 356, Height = 44,
            BackColor = Color.FromArgb(15, 122, 205), ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold), Cursor = Cursors.Hand
        };
        login.FlatAppearance.BorderSize = 0;
        login.Click += (_, _) => Login();
        Controls.Add(login);

        message.Text = "Entrez votre mot de passe pour accéder au logiciel.";
        message.AutoSize = false; message.Left = 55; message.Top = 270; message.Width = 390; message.Height = 45;
        message.TextAlign = ContentAlignment.MiddleCenter;
        message.Font = new Font("Segoe UI", 9.5f); message.ForeColor = Color.FromArgb(190, 215, 235);
        Controls.Add(message);
    }

    void Login()
    {
        if (Database.VerifyAccessPassword(password.Text))
        {
            DialogResult = DialogResult.OK;
            Close();
            return;
        }

        attempts++;
        password.Clear();
        message.ForeColor = Color.FromArgb(255, 100, 100);
        message.Text = attempts >= 3
            ? "Mot de passe incorrect. Vérifiez puis réessayez."
            : "Mot de passe incorrect.";
        password.Focus();
    }
}
