using System;
using System.Windows.Forms;

namespace SankheTransfert;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        // Adaptation automatique aux différents écrans/PC : mise à l'échelle par moniteur.
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        ApplicationConfiguration.Initialize();
        Database.Initialize();
        Database.EnsureDefaultAccessPassword();

        using (var login = new LoginForm())
        {
            if (login.ShowDialog() != DialogResult.OK) return;
        }

        Application.Run(new MainForm());
    }
}
