# V189 — Boutique : cages plus larges et boutons réduits

- Cartes des 6 postes élargies de 425 à 455 px.
- Espacement entre cartes augmenté pour conserver une lecture propre.
- Zone des remboursements élargie afin d'afficher clairement les montants Wave, Orange Money et Espèces versés.
- Libellé « ORANGE MONEY VERSÉ » explicite.
- Zone TOTAL VERSÉ / RESTE élargie.
- Boutons DISTRIBUTION, + AJOUTER et REMBOURSER légèrement réduits pour libérer de l'espace.
- Taille de police des boutons légèrement diminuée.
- Fonctionnement et calculs de remboursement inchangés.
