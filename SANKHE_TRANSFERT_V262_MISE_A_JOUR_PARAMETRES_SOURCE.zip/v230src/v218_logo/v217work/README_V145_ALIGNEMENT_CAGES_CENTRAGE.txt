V145 — ALIGNEMENT ET CENTRAGE DES CAGES DE SAISIE

- Les champs blancs sont alignés sur la même ligne horizontale que leurs libellés.
- Les champs blancs sont centrés verticalement dans chaque cage.
- Tous les champs utilisent le même alignement gauche/droite pour un affichage propre.
- Le champ Montant conserve sa cage plus haute et son affichage renforcé, avec centrage vertical.
- Aucune logique métier ni calcul n'a été modifié.
