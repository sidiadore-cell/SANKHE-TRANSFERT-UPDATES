# V177 — Rééquilibrage Achat UV / Vente UV

- Achat UV : le montant est retiré directement de la Caisse générale et enregistré comme sortie de caisse. Aucune dette n’est créée.
- Vente UV : aucun mouvement de caisse au moment de la vente. Le montant est enregistré comme dette liée au client et apparaît dans le menu Dettes, comme un Transfert.
- Le remboursement de la Vente UV utilise les mêmes moyens de paiement du menu Dettes (Caisse Wave, Caisse Orange Money, Caisse générale/espèces) et met à jour la caisse correspondante.
- Pour une Vente UV, Nom & Prénom et Téléphone sont obligatoires. Pour un Achat UV, le client peut rester vide.
