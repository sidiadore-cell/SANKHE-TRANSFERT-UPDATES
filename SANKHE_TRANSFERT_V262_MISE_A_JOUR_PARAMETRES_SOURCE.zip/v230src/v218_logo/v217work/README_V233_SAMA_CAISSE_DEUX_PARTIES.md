# V233 — SAMA CAISSE simplifiée en deux parties

- Affichage ramené à deux synthèses : argent confié par les clients et prêts restant à récupérer.
- Le solde du portefeuille personnel reste suivi, mais il est affiché dans la synthèse des prêts plutôt que comme une troisième partie séparée.
- Suppression des boutons « Nouveau client », « + Portefeuille » et « - Portefeuille ».
- Les formulaires de dépôt et d'octroi de prêt demandent directement le nom et le téléphone du client; le client est retrouvé par téléphone (si renseigné) ou créé automatiquement.
- La restitution demande directement les informations du client existant.
- Lorsqu'un prêt dépasse le solde personnel disponible, le logiciel demande l'apport personnel nécessaire dans la fenêtre du prêt, puis comptabilise l'apport et le prêt séparément.
- Les remboursements de prêts réapprovisionnent le portefeuille personnel.
- Aucun prêt personnel n'est enregistré comme mouvement des caisses Wave, Orange Money ou espèces.
