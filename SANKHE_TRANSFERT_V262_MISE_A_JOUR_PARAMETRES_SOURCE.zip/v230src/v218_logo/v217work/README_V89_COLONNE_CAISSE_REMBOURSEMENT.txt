SANKHÉ TRANSFERT D'ARGENT — V89

RAPPORTS : COLONNE « CAISSE REMBOURSEMENT »

La colonne SERVICE conserve désormais toujours le service d'origine de l'opération :
- Wave
- Orange Money

Une nouvelle colonne « CAISSE REMB. » indique la caisse utilisée pour le remboursement de la dette :
- Caisse Wave
- Caisse Orange Money
- Caisse générale

Si la dette n'est pas soldée ou si aucun remboursement n'est enregistré : « — ».

La Caisse Seddo n'intervient pas dans les dettes et n'apparaît pas comme caisse de remboursement.

La modification est appliquée :
- au tableau des rapports,
- au rapport imprimé général,
- au rapport individuel client,
- à l'export CSV.
