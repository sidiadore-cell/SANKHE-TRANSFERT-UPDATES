SANKHE TRANSFERT — V186

CORRECTION MON BOUTIQUE
- Le total à rembourser est la somme de toutes les distributions initiales et de tous les compléments, tous modes confondus.
- Le remboursement du soir peut être réparti librement entre Wave, Orange Money et espèces.
- La clôture est autorisée uniquement si la somme des remboursements est exactement égale au total distribué.
- Si le total est inférieur ou supérieur, un message indique le total distribué, le total versé et l’écart.
- Après clôture complète, « Diadieuf » apparaît en haut de la cage du poste et le point d’état devient blanc.
- La carte affiche également TOTAL DISTRIBUÉ, VERSÉ et RESTE.
