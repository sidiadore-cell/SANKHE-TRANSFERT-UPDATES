# V211 — Gestion clients + corrections visuelles Annulation

- Annulation : suppression du grand logo à l'intérieur de la page pour gagner de l'espace.
- Annulation : cartes de synthèse plus hautes pour éviter les libellés coupés.
- Annulation : bouton rouge « Annuler l'opération » agrandi et repositionné.
- Annulation : recherche séparée Nom et Prénom, en plus de la recherche libre.
- Annulation : formulaire de recherche réorganisé pour rester lisible.
- Menu : icône Annulation remplacée par une version carrée complète afin d'éviter le découpage à gauche.
- Paramètres : nouveau carnet « Gestion des clients ».
- Gestion clients : liste des clients, recherche nom/prénom/téléphone/note, ajout, modification et suppression protégée.
- Suppression protégée : un client ayant déjà des opérations ou une dette ne peut pas être supprimé afin de préserver la traçabilité.
