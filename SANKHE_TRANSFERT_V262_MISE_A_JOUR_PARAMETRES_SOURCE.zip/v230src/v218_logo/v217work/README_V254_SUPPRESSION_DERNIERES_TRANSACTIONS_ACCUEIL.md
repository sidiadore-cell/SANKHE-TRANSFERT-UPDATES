# V254 — Suppression des dernières transactions sur Accueil

- Suppression du panneau « Dernières transactions » de la page Accueil.
- Les cartes de soldes permanents, dettes et caisses journalières sont conservées.
- Aucune donnée de transaction n’est supprimée de la base ; seul l’affichage sur Accueil est retiré.
- Les opérations restent accessibles dans les menus d’historique et de rapports.

Compilation et test visuel Windows/.NET à effectuer.
