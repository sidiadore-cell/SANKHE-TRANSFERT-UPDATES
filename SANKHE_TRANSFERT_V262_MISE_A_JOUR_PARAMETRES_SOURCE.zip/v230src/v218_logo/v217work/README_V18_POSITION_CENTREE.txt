V18 - Positionnement corrigé

Le contenu central du tableau de bord a été descendu de 60 pixels supplémentaires (environ 1,6 cm à 96 DPI) afin de mieux dégager l’en-tête et les logos Wave / Orange Money. Le reste du design et des données est conservé.
