SANKHE TRANSFERT D'ARGENT - V53

Les icônes fournies par le concepteur sont utilisées dans la navigation supérieure :
Accueil, Opérations, Historique, Caisse, Dettes, Rapports et Paramètres.
Les images sont intégrées dans Assets/navicons et affichées en petite taille dans les boutons.
Le logo officiel de l'en-tête et l'icône Windows sont conservés.
