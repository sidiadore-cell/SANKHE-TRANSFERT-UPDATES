SANKHE TRANSFERT D'ARGENT - V137

Nouvelle maquette globale inspiree de la page Nouvelle operation :
- deux caisses separees au-dessus des formulaires : Caisse Wave et Caisse Orange Money ;
- design neon/verre, coins arrondis, montants grands ;
- fond global bleu nuit avec halos bleu, orange et violet sur toutes les pages principales ;
- operation Transfert signalee comme Dette a encaisser avec montant rouge ;
- Depôt, Retrait, Transfert et Ree quilibrage sous forme de boutons de selection ;
- adaptation DPI/ecran conservee.
