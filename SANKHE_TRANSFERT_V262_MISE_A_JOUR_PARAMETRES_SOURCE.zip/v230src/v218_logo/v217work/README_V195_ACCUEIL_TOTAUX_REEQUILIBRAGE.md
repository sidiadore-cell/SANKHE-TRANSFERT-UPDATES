# V195 — Totaux Rééquilibrage sur Accueil

- Ajout sur l'écran Accueil, sur la même ligne que Dépôts / Retraits / Transferts dans la carte Wave.
- Affichage de `VENTE UV` et `ACHAT UV` avec leurs totaux en FCFA.
- Les rééquilibrages étant actuellement accessibles depuis Wave uniquement, ils ne sont pas dupliqués dans la carte Orange Money.
- Aucun calcul de caisse, dette ou opération n'est modifié.
