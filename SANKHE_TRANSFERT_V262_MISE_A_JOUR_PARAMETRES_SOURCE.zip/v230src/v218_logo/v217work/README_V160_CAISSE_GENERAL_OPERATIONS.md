# SANKHÉ TRANSFERT — V160

## Comptabilité croisée des opérations

La V160 applique la nouvelle règle demandée dans le menu **Opérations** pour Wave et Orange Money.

### Dépôt
- Caisse Wave / Caisse Orange Money : **+ montant du dépôt**.
- Caisse générale : **- montant du dépôt**.
- Le mouvement de caisse est enregistré dans l'historique avec la référence de l'opération.

### Transfert / Envoi
- Même principe que le dépôt pour les caisses :
  - Caisse Wave / Caisse Orange Money : **+ montant**.
  - Caisse générale : **- montant**.
- La gestion existante de la dette de transfert est conservée.

### Retrait
- Caisse Wave / Caisse Orange Money : **- montant du retrait**.
- Caisse générale : **+ montant du retrait**.

### Rééquilibrage
- **Aucun changement.** La logique Vente UV / Achat UV reste celle de la version précédente.

### Sécurité
- La Caisse générale ne peut pas passer sous zéro lorsqu'une opération doit la diminuer.
- La Caisse Wave/Orange ne peut pas passer sous zéro lorsqu'un retrait doit la diminuer.
- Les deux mouvements de contrepartie sont enregistrés dans `CaisseMouvements` et reliés à la même opération.
