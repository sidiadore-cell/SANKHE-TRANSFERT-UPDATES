V112 — BOUTIQUE : POSTES + AUGMENTATION DE DOTATION

- Gestion des 6 postes : les postes 1 à 6 sont toujours visibles dans Gestion des postes.
- Affectation d’un employé au poste sélectionné, sans retomber systématiquement sur le Poste 1.
- Le nom/prénom de l’employé est affiché en gros caractères dans chaque carte.
- Une journée ouverte dispose du bouton « AJOUTER » pour augmenter la dotation Wave et/ou Orange en cours de journée.
- L’ajout contrôle le solde disponible de la Caisse Wave et de la Caisse Orange Money, puis déduit le montant et augmente la dotation du poste.
- La distribution du matin, les compléments et les retours du soir restent comptabilisés dans les caisses correspondantes.
- Les boutons des cartes restent arrondis.
