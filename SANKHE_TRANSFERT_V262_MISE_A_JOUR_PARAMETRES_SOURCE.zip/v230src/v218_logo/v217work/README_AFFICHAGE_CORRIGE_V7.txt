SANKHE TRANSFERT - V7

Nouveautés :
- Tableau de bord avec sommes séparées Wave : Dépôts / Retraits / Transferts.
- Tableau de bord avec sommes séparées Orange Money : Dépôts / Retraits / Transferts.
- Dettes Wave, Orange Money et dette totale conservées.
- Historique complet avec deux onglets séparés : Wave et Orange Money.
- L'historique affiche date, type, client, téléphone, montant, commission, dette, référence et observation.
- Toutes les références enregistrées sont affichées.
- Les données sont lues depuis la base SQLite existante.

Compilation :
1. Ouvrir SankheTransfert.csproj dans Visual Studio avec .NET 8 Desktop.
2. Restaurer les packages NuGet.
3. Construire le projet en Release.
4. Ou lancer CONSTRUIRE_EXE.bat sous Windows avec le SDK .NET 8 installé.
