V146 — Marge intérieure des zones de saisie

Les zones blanches de saisie ont été décalées légèrement vers la droite dans les cages, avec une petite marge visuelle supplémentaire entre le bord de la cage et le début du champ. La largeur a été réduite de façon à conserver la même marge à droite. Le champ Montant (FCFA) suit le même alignement. Aucune logique métier ou de calcul n’a été modifiée.
