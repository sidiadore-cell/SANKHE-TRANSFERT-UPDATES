SANKHÉ TRANSFERT D’ARGENT — V42

Correction définitive de la caisse : le solde de départ est ajouté au solde actuel existant, puis les entrées et sorties sont appliquées.
Exemple : caisse actuelle 5 000 000 + solde de départ 20 000 000 = nouvelle caisse 25 000 000 FCFA.

La structure, les dettes, rapports, recherche Nom & Prénom et l’affichage de la caisse sont conservés.
