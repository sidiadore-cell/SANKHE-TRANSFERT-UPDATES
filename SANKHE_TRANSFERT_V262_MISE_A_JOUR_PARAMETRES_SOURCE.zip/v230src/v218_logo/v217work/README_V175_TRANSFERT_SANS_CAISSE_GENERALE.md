# V175 — Correction comptable des transferts

- Un **Transfert / Envoi** reste une dette.
- Le montant est **déduit uniquement de la Caisse Wave** ou de la **Caisse Orange Money** selon le service choisi.
- Aucun mouvement n'est créé dans la **Caisse générale** lors de l'enregistrement du transfert.
- La Caisse générale intervient uniquement lors du remboursement de la dette lorsque le moyen d'encaissement est l'argent liquide.
- Les règles Dépôt / Retrait restent inchangées.
