SANKHE TRANSFERT — V91

Rapports : suppression de la colonne « CAISSE REMB. » afin de donner davantage de largeur à « DESCRIPTION ».
Les remboursements restent détaillés dans DESCRIPTION sous la forme « Remboursement dette — Caisse Wave/Orange Money/Caisse générale ».
Les descriptions sont affichées sur plusieurs lignes à l'impression pour éviter les ellipses.
La même mise en page est appliquée au rapport individuel client et au rapport CSV.
Seddo n'intervient pas dans les dettes.
