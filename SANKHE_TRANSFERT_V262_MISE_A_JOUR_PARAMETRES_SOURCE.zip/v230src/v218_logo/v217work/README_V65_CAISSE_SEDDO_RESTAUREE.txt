SANKHÉ TRANSFERT D'ARGENT — V65

CORRECTION : CAISSE SEDDO RESTAURÉE
- La page Caisse affiche maintenant 4 caisses : Caisse Wave, Caisse Orange Money, Caisse Seddo et Caisse générale.
- La Caisse Seddo possède son propre solde, ses entrées, ses sorties et son journal.
- Ajout du bouton CAISSE SEDDO avec changement de couleur lorsqu'il est sélectionné.
- Ajout de la carte de solde Caisse Seddo avec son icône.
- La Caisse générale inclut Caisse générale + Wave + Orange Money + Seddo.
- La page Dettes conserve uniquement les 3 moyens demandés : Caisse Wave, Caisse Orange Money et Caisse générale.
