V16 - LOGOS EXACTS

Cette version utilise exactement les deux logos fournis par l'utilisateur :
- Wave : IMG_7629.png
- Orange Money : IMG_7631.png

Les logos sont présents dans Assets et intégrés en fallback dans l'exécutable pour éviter qu'ils disparaissent après publication.
Le rendu et la disposition V15 sont conservés.
