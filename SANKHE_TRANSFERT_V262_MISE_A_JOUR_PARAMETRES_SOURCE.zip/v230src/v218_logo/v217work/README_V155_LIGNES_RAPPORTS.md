# V155 — Lignes de rapports renforcées
- Description conservée large.
- Bordures horizontales et verticales renforcées entre chaque cellule.
- Hauteur de ligne portée à 42 px/points pour éviter les confusions et laisser respirer les descriptions.
- Bordure extérieure du tableau ajoutée.
- Présentation harmonisée écran, impression et PDF.
- Aucun calcul ni traitement de données modifié.
