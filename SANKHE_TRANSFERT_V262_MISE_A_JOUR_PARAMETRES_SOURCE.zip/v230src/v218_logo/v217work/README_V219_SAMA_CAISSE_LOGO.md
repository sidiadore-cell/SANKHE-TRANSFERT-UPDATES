# V219 — Logo SAMA CAISSE intégré

- Intègre `Assets/sama_caisse_logo.png` dans le logiciel.
- La carte SAMA CAISSE utilise désormais son logo officiel au lieu de l'icône générique de caisse.
- SAMA CAISSE reste totalement indépendante de Wave, Orange Money, Seddo, espèces et caisse journalière.
- Aucun changement de logique financière.
