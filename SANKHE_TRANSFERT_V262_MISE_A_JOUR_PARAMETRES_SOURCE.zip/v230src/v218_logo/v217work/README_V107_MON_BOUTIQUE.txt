V107 — MON BOUTIQUE

Nouveau menu après Accueil et Opérations : Mon Boutique.
- Gestion des employés : ajout, modification des coordonnées et activation/désactivation.
- Distribution du matin : avance séparée depuis Caisse Wave et Caisse Orange Money pour chaque employé.
- Journée indépendante par employé.
- Enregistrement des opérations boutique par agent, service et type.
- Retour du soir : Wave/Orange retournés automatiquement vers les caisses correspondantes.
- Historique et rapport Boutique disponibles depuis Rapports, avec filtre par employé et période.
- Les opérations Boutique sont séparées des dettes Wave/Orange.
- Les clients existants sont proposés automatiquement lors de la saisie d'une opération Boutique et le téléphone est rempli.
