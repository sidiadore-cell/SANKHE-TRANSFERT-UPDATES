V23 - Téléphones grands mais réellement en arrière-plan

Modification par rapport à V22 :
- Les téléphones Wave et Orange Money sont dessinés directement dans le Paint des grandes cages.
- Ils sont donc derrière tous les contrôles et ne peuvent plus recouvrir les cartes Dépôt/Retrait.
- Ils restent volontairement grands, comme demandé.
- Transparence du téléphone : 24%.
- Position : coin supérieur droit, légèrement débordant vers le haut.
- Les textes, montants, icônes et pièces restent au premier plan.
- Aucun changement de données ou de navigation.
