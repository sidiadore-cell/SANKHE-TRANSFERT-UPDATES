SANKHÉ TRANSFERT D'ARGENT — V46

Modification : dans Historique, la liste des opérations est descendue d'environ 2 cm (76 px) sous les indicateurs Dépôts/Retraits/Transferts pour améliorer la visibilité.
Aucune logique de données n'est modifiée.
