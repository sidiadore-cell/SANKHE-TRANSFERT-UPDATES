SANKHE TRANSFERT - V99 CAISSE SEDDO DESIGN

Amélioration de la page Seddo :
- carte Caisse Seddo beaucoup plus visible et lisible;
- solde affiché en grand avec FCFA séparé;
- fond dégradé sombre professionnel et bordure rose/or;
- commission affichée dans un bloc dédié;
- bouton Modifier le taux mieux visible;
- espace de la page rééquilibré après agrandissement de la carte;
- historique Seddo conservé en bas de page.

Aucune modification du fonctionnement des dettes : Seddo reste indépendant des dettes.
