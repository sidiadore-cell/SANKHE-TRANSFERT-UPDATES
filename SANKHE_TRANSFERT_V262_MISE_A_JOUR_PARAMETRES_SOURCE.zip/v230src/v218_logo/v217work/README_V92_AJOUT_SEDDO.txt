V92 - AJOUT SEDDO
- Ajout du menu horizontal « Ajout Seddo » entre Opérations et Historique.
- Écran dédié pour enregistrer une entrée ou une sortie dans la Caisse Seddo.
- La Caisse Seddo reste indépendante et n'intervient pas dans le règlement des dettes.
- Affichage du solde Seddo, motif et référence.
