# V184 — Origine des dettes / Vente UV

- Le menu Dettes affiche désormais une colonne **Origine**.
- Une dette issue de Rééquilibrage → Vente UV apparaît comme **Rééquilibrage — Vente UV**.
- Dans la fenêtre de règlement, l'origine est également affichée.
- Les rapports identifient correctement l'origine réelle d'une dette Rééquilibrage → Vente UV.
- Lorsqu'un remboursement est enregistré, la description de rapport devient :
  **Remboursement dette — [caisse versée] — Vente UV**.
- Les autres origines (Transfert, Envoi, etc.) conservent leur libellé normal.
