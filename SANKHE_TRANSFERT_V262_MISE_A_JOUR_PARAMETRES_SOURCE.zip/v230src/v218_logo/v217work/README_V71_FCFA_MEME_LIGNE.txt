V71 — CAISSES ACCUEIL : FCFA IMMEDIATEMENT A DROITE DU MONTANT

Correction demandée : dans les cartes CAISSE WAVE et CAISSE ORANGE MONEY de l’accueil,
le nombre et « FCFA » sont regroupés dans le même conteneur horizontal.
FCFA reste donc immédiatement à droite du montant, sur la même ligne, même lorsque
le montant comporte plusieurs chiffres.

Le montant adapte légèrement sa taille pour conserver cette disposition.
