# V203 — Caisse en espèces : règlement des dettes + libellé Accueil

- Correction de `SettleDebt()` : le moyen d'encaissement **Caisse en espèce** est désormais mappé vers le service comptable `Caisse` et crédite réellement cette caisse.
- La correction s'applique notamment aux dettes issues des **Transferts** et des **Rééquilibrages — Vente UV**, ainsi qu'à tout autre règlement choisi avec ce moyen.
- Une ligne `CaisseMouvements` de type `Entrée` est créée pour tracer l'encaissement.
- Dans Accueil, le titre `CAISSE` est renommé **CAISSE EN ESPÈCES**. Le montant reste celui du service comptable `Caisse`.
- Aucun changement des montants des dettes ni des autres caisses.
