# V208 — Module Annulation des opérations

## Nouveau menu
- Menu **Annulation** placé entre **Dettes** et **Rapports**.
- Logo fourni par le client intégré à la page et à la navigation.

## Recherche
- Numéro d'opération
- Nom / prénom
- Téléphone
- Référence / description
- Type d'opération
- Service (Wave, Orange Money, Seddo)
- Statut (Active / Annulée)
- Montant exact
- Période

## Vérification avant annulation
La fiche complète affiche les informations de l'opération, les mouvements de caisse liés et l'impact estimé de l'annulation.

## Annulation sécurisée
- L'opération originale n'est jamais supprimée.
- Elle passe à **Annulée** avec date, motif et gérant.
- Chaque mouvement de caisse lié est neutralisé par un mouvement inverse dans la même transaction SQLite.
- Une dette liée est annulée si elle n'a reçu aucun paiement.
- Si une dette a déjà été remboursée, l'annulation de l'opération d'origine est bloquée afin d'éviter une incohérence.
- Les nouveaux remboursements de dette sont liés directement à leur opération pour permettre une annulation sûre.
- Les tableaux de bord et rapports standards excluent les opérations annulées des totaux actifs.

## Sécurité
Toutes les corrections sont atomiques : en cas d'erreur, la transaction est annulée et les soldes restent inchangés.
