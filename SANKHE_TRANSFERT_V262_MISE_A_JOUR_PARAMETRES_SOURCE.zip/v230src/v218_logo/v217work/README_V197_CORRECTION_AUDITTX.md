# V197 — Correction compilation AuditTx

Correction de l'erreur CS0122 signalée lors de la compilation :
`Database.AuditTx(...)` était inaccessible depuis MainForm.

- `AuditTx` est maintenant `public static`.
- `details` et `reference` acceptent explicitement `null` pour supprimer les avertissements de nullable liés aux appels d'audit.
- Aucun calcul de caisse, dette, opération, rapport ou PDF n'est modifié.
