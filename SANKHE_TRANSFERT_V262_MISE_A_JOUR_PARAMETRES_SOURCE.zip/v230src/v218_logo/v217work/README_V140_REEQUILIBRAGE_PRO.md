SANKHÉ TRANSFERT D’ARGENT — V140

AMÉLIORATION RÉÉQUILIBRAGE (VENTE IV / ACHAT IV)

- La zone Vente UV / Achat UV est maintenant beaucoup plus grande et clairement délimitée.
- Les deux choix sont présentés comme de grandes cartes professionnelles cliquables.
- Le choix actif est mis en évidence avec la couleur du service (Wave ou Orange Money).
- Vente UV indique clairement « SORTIE DE CAISSE » et retire le montant de la caisse concernée.
- Achat UV indique clairement « ENTRÉE EN CAISSE » et ajoute le montant à la caisse concernée.
- Les champs inutiles pour le rééquilibrage (Nom, Téléphone, Commission) sont masqués pour éviter les espaces vides.
- Montant et Référence restent visibles et sont repositionnés proprement sous la zone de choix.
- Une information explicative apparaît sous le montant.
- Le bouton Enregistrer reste accessible et se repositionne automatiquement.
- Le reste de la maquette V136/V139 (fond, couleurs, logos et structure Wave/Orange Money) est conservé.
