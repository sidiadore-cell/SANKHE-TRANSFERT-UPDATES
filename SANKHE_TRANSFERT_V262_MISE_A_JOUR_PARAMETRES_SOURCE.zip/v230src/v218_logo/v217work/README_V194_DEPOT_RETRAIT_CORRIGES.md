# V194 — Correction Dépôt / Retrait

Correction du sens comptable des opérations dans le menu Opérations :

- **Dépôt** : le montant augmente la caisse/portefeuille Wave ou Orange Money.
- **Retrait** : le montant diminue la caisse/portefeuille Wave ou Orange Money.
- La contrepartie de la **Caisse générale** reste conforme à cette logique :
  - Dépôt → Caisse générale diminue.
  - Retrait → Caisse générale augmente.
- **Transfert / Envoi** restent inchangés : ils diminuent la caisse du service et créent/maintiennent la dette.
- Les rapports et tableaux de synthèse utilisent déjà `TypeOperation` pour distinguer Dépôt et Retrait ; aucun changement de libellé n'est nécessaire.
