# SANKHÉ TRANSFERT — V139

Correction de l'affichage du formulaire **Nouvelle opération** à partir de V136.

- Chaque champ (Nom & Prénom, Téléphone, Montant, Commission, Référence) est maintenant placé dans une cage visuelle distincte.
- La cage de l'opération choisie reste clairement séparée.
- Les quatre boutons Dépôt / Retrait / Transfert / Rééquilibrage restent indépendants et arrondis.
- La zone Vente UV / Achat UV est délimitée dans une cage dédiée.
- Les libellés sont plus lisibles et les champs restent blancs et nets.
- Le badge **DETTE À ENCAISSER** reste visible pour Transfert.
- Le fond et les couleurs Wave / Orange de la maquette V136 sont conservés.
