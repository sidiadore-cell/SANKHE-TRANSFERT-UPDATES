SANKHÉ TRANSFERT D'ARGENT — V57

Modification : affichage des caisses Wave et Orange Money directement dans les cages correspondantes du tableau de bord.

- Cage WAVE : zone supérieure droite -> CAISSE WAVE + solde actuel.
- Cage ORANGE MONEY : zone supérieure droite -> CAISSE ORANGE MONEY + solde actuel.
- Les soldes proviennent de Caisse Wave et Caisse Orange Money, séparément de la caisse générale.
- Le fonctionnement de la page Caisse et des mouvements n'est pas supprimé.
