V106 — MOT DE PASSE D’ACCÈS

- Le logiciel demande un mot de passe au démarrage avant d’ouvrir SANKHÉ TRANSFERT.
- Le mot de passe est stocké sous forme de hash SHA-256 dans AppSettings, pas en clair.
- Mot de passe initial des anciennes installations : 1234.
- Le mot de passe peut être modifié dans Paramètres > Mot de passe d’accès.
- Pour changer le mot de passe : ancien mot de passe + nouveau mot de passe + confirmation.
- Minimum : 4 caractères.
- La suppression de toutes les données ne supprime pas le mot de passe.
