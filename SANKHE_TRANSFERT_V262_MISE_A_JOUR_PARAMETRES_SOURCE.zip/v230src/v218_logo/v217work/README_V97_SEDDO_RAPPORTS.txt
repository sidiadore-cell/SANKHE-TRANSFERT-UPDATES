V97 — RAPPORTS AVEC SEDDO

Le filtre Service des rapports inclut maintenant : Tous les services, Wave, Orange Money et Seddo. Les opérations Seddo sont récupérées depuis la table Operations et apparaissent avec Service = Seddo, sans intervenir dans les dettes Wave/Orange.
