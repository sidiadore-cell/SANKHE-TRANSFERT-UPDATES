﻿using Microsoft.Data.Sqlite;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace SankheTransfert;

public static class Database
{
    public static string AppFolder =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                     "SankheTransfert");

    public static string DbPath => Path.Combine(AppFolder, "sankhe_transfert.db");

    private static string ConnectionString =>
        $"Data Source={DbPath};Cache=Shared;Pooling=True;Default Timeout=5";

    public static SqliteConnection Open()
    {
        Directory.CreateDirectory(AppFolder);
        var c = new SqliteConnection(ConnectionString);
        c.Open();
        using (var pragma = c.CreateCommand())
        {
            // Réglages SQLite orientés fluidité : WAL + cache mémoire + mmap.
            // Ils accélèrent surtout les lectures répétées sans modifier les données.
            pragma.CommandText = "PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA temp_store=MEMORY; PRAGMA cache_size=-32000; PRAGMA mmap_size=268435456;";
            pragma.ExecuteNonQuery();
        }
        return c;
    }

    public static void AuditTx(SqliteConnection c, SqliteTransaction tx, string action, string? details = "", decimal montant = 0, string? reference = "")
    {
        using var cmd = c.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = "INSERT INTO AuditLog(DateAction,Action,Details,Montant,Reference) VALUES($d,$a,$x,$m,$r)";
        cmd.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
        cmd.Parameters.AddWithValue("$a", action ?? "");
        cmd.Parameters.AddWithValue("$x", details ?? "");
        cmd.Parameters.AddWithValue("$m", montant);
        cmd.Parameters.AddWithValue("$r", reference ?? "");
        cmd.ExecuteNonQuery();
    }

    public sealed record AuditRow(long Id, string DateAction, string Action, string Details, decimal Montant, string Reference);

    public static List<AuditRow> GetAuditLog(int limit = 300)
    {
        var list = new List<AuditRow>();
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Id,DateAction,Action,Details,Montant,Reference FROM AuditLog ORDER BY Id DESC LIMIT $n";
        cmd.Parameters.AddWithValue("$n", Math.Clamp(limit, 1, 2000));
        using var r = cmd.ExecuteReader();
        while (r.Read()) list.Add(new AuditRow(r.GetInt64(0), Convert.ToString(r.GetValue(1)) ?? "", Convert.ToString(r.GetValue(2)) ?? "", Convert.ToString(r.GetValue(3)) ?? "", Convert.ToDecimal(r.GetValue(4)), Convert.ToString(r.GetValue(5)) ?? ""));
        return list;
    }

    public sealed record CaisseCheckRow(string Caisse, decimal SoldeAffiche, decimal SoldeCalcule, decimal Ecart);

    public static List<CaisseCheckRow> CheckCaisseConsistency()
    {
        var names = new[] { "Caisse", "Caisse Wave", "Caisse Orange Money", "Caisse Seddo", "Sama caisse" };
        var result = new List<CaisseCheckRow>();
        using var c = Open();
        foreach (var name in names)
        {
            decimal shown = 0, calculated = 0;
            using (var q = c.CreateCommand()) { q.CommandText = "SELECT COALESCE(Montant,0) FROM Soldes WHERE Service=$s"; q.Parameters.AddWithValue("$s", name); shown = Convert.ToDecimal(q.ExecuteScalar() ?? 0); }
            using (var q = c.CreateCommand()) { q.CommandText = "SELECT COALESCE(SUM(CASE WHEN TypeMouvement='Solde initial' OR TypeMouvement='Entrée' THEN Montant ELSE -Montant END),0) FROM CaisseMouvements WHERE ServiceCaisse=$s"; q.Parameters.AddWithValue("$s", name); calculated = Convert.ToDecimal(q.ExecuteScalar() ?? 0); }
            result.Add(new CaisseCheckRow(name, shown, calculated, shown - calculated));
        }
        return result;
    }

    public static void Initialize()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
        PRAGMA foreign_keys=ON;
        PRAGMA journal_mode=WAL;
        PRAGMA synchronous=NORMAL;
        PRAGMA temp_store=MEMORY;
        PRAGMA cache_size=-32000;

        CREATE TABLE IF NOT EXISTS Clients(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nom TEXT NOT NULL,
            Telephone TEXT,
            Note TEXT
        );

        CREATE TABLE IF NOT EXISTS Operations(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            DateOperation TEXT NOT NULL,
            Service TEXT NOT NULL,
            TypeOperation TEXT NOT NULL,
            ClientId INTEGER,
            ClientNom TEXT,
            Telephone TEXT,
            Montant REAL NOT NULL DEFAULT 0,
            Commission REAL NOT NULL DEFAULT 0,
            Dette REAL NOT NULL DEFAULT 0,
            Reference TEXT,
            Observation TEXT,
            PaiementDiffere INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(ClientId) REFERENCES Clients(Id)
        );

        CREATE TABLE IF NOT EXISTS Soldes(
            Service TEXT PRIMARY KEY,
            Montant REAL NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS CaisseMouvements(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            DateMouvement TEXT NOT NULL,
            TypeMouvement TEXT NOT NULL,
            Montant REAL NOT NULL DEFAULT 0,
            Motif TEXT,
            Reference TEXT,
            OperationId INTEGER,
            ServiceCaisse TEXT NOT NULL DEFAULT 'Caisse'
        );

        CREATE TABLE IF NOT EXISTS Dettes(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            OperationId INTEGER NOT NULL,
            ClientId INTEGER,
            Service TEXT NOT NULL,
            ClientNom TEXT,
            Telephone TEXT,
            MontantInitial REAL NOT NULL DEFAULT 0,
            MontantRestant REAL NOT NULL DEFAULT 0,
            DateCreation TEXT NOT NULL,
            DateSolde TEXT,
            Statut TEXT NOT NULL DEFAULT 'Non soldée',
            Reference TEXT,
            Observation TEXT,
            FOREIGN KEY(OperationId) REFERENCES Operations(Id),
            FOREIGN KEY(ClientId) REFERENCES Clients(Id)
        );

        CREATE TABLE IF NOT EXISTS AppSettings(
            Key TEXT PRIMARY KEY,
            Value TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS AuditLog(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            DateAction TEXT NOT NULL,
            Action TEXT NOT NULL,
            Details TEXT NOT NULL DEFAULT '',
            Montant REAL NOT NULL DEFAULT 0,
            Reference TEXT NOT NULL DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS SamaClients(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nom TEXT NOT NULL,
            Telephone TEXT NOT NULL DEFAULT '',
            Note TEXT NOT NULL DEFAULT '',
            DateCreation TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS SamaTransactions(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            DateOperation TEXT NOT NULL,
            ClientId INTEGER,
            TypeOperation TEXT NOT NULL,
            Montant REAL NOT NULL DEFAULT 0,
            LoanId INTEGER,
            DateEcheance TEXT,
            Motif TEXT NOT NULL DEFAULT '',
            Reference TEXT NOT NULL DEFAULT '',
            FOREIGN KEY(ClientId) REFERENCES SamaClients(Id),
            FOREIGN KEY(LoanId) REFERENCES SamaTransactions(Id)
        );
        INSERT OR IGNORE INTO AppSettings(Key,Value) VALUES('SamaPortefeuilleSolde','0');
        CREATE INDEX IF NOT EXISTS IX_SamaTransactions_ClientDate ON SamaTransactions(ClientId,DateOperation,Id);
        CREATE INDEX IF NOT EXISTS IX_SamaTransactions_Loan ON SamaTransactions(LoanId,TypeOperation);

        CREATE TABLE IF NOT EXISTS CaisseJournaliereClotures(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            DateJour TEXT NOT NULL,
            ServiceCaisse TEXT NOT NULL,
            MontantTheorique REAL NOT NULL DEFAULT 0,
            MontantVerifie REAL NOT NULL DEFAULT 0,
            Ecart REAL NOT NULL DEFAULT 0,
            DateCloture TEXT NOT NULL,
            Observation TEXT NOT NULL DEFAULT '',
            UNIQUE(DateJour, ServiceCaisse)
        );

        CREATE TABLE IF NOT EXISTS SeddoPaiements(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            OperationId INTEGER NOT NULL,
            DatePaiement TEXT NOT NULL,
            Montant REAL NOT NULL DEFAULT 0,
            Reference TEXT,
            Observation TEXT,
            ServicePaiement TEXT NOT NULL DEFAULT 'Caisse Seddo',
            FOREIGN KEY(OperationId) REFERENCES Operations(Id)
        );

        CREATE TABLE IF NOT EXISTS BoutiqueEmployes(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nom TEXT NOT NULL,
            Telephone TEXT,
            Note TEXT,
            Actif INTEGER NOT NULL DEFAULT 1,
            Poste INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS BoutiqueSessions(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            EmployeId INTEGER NOT NULL,
            DateJour TEXT NOT NULL,
            Ouverture TEXT NOT NULL,
            Fermeture TEXT,
            WaveDonne REAL NOT NULL DEFAULT 0,
            OrangeDonne REAL NOT NULL DEFAULT 0,
            WaveRetour REAL NOT NULL DEFAULT 0,
            OrangeRetour REAL NOT NULL DEFAULT 0,
            EspecesDonne REAL NOT NULL DEFAULT 0,
            EspecesRetour REAL NOT NULL DEFAULT 0,
            Statut TEXT NOT NULL DEFAULT 'Ouverte',
            Observation TEXT,
            FOREIGN KEY(EmployeId) REFERENCES BoutiqueEmployes(Id)
        );

        CREATE TABLE IF NOT EXISTS BoutiqueOperations(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            SessionId INTEGER NOT NULL,
            DateOperation TEXT NOT NULL,
            Service TEXT NOT NULL,
            TypeOperation TEXT NOT NULL,
            ClientNom TEXT,
            Telephone TEXT,
            Montant REAL NOT NULL DEFAULT 0,
            Commission REAL NOT NULL DEFAULT 0,
            Reference TEXT,
            Observation TEXT,
            FOREIGN KEY(SessionId) REFERENCES BoutiqueSessions(Id)
        );

        CREATE TABLE IF NOT EXISTS PaiementsDettes(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            DetteId INTEGER NOT NULL,
            OperationId INTEGER,
            DatePaiement TEXT NOT NULL,
            Montant REAL NOT NULL,
            MoyenPaiement TEXT NOT NULL,
            Reference TEXT,
            Observation TEXT,
            FOREIGN KEY(DetteId) REFERENCES Dettes(Id)
        );

        INSERT OR IGNORE INTO Soldes(Service,Montant) VALUES
            ('Caisse',0),('Caisse Wave',0),('Caisse Orange Money',0),('Caisse Seddo',0),('Sama caisse',0),('Wave',0),('Orange Money',0);
        INSERT OR IGNORE INTO AppSettings(Key,Value) VALUES('SeddoCommissionPercent','5.5');
        INSERT OR IGNORE INTO AppSettings(Key,Value) VALUES('AccessPasswordHash', '');
        INSERT OR IGNORE INTO AppSettings(Key,Value) VALUES('ManagerName', '');
        
        CREATE INDEX IF NOT EXISTS IX_Operations_DateServiceType ON Operations(DateOperation, Service, TypeOperation, Id);
        CREATE INDEX IF NOT EXISTS IX_Operations_ServiceId ON Operations(Service, Id DESC);
        CREATE INDEX IF NOT EXISTS IX_Operations_ClientId ON Operations(ClientId);
        CREATE INDEX IF NOT EXISTS IX_Dettes_OperationId ON Dettes(OperationId);
        CREATE INDEX IF NOT EXISTS IX_Dettes_ServiceRestant ON Dettes(Service, MontantRestant);
        CREATE INDEX IF NOT EXISTS IX_PaiementsDettes_DetteId ON PaiementsDettes(DetteId, Id DESC);
        CREATE INDEX IF NOT EXISTS IX_SeddoPaiements_OperationId ON SeddoPaiements(OperationId, Id DESC);
        CREATE INDEX IF NOT EXISTS IX_CaisseMouvements_ServiceDate ON CaisseMouvements(ServiceCaisse, DateMouvement, Id);
        CREATE INDEX IF NOT EXISTS IX_BoutiqueSessions_EmployeDate ON BoutiqueSessions(EmployeId, DateJour, Id DESC);
        CREATE INDEX IF NOT EXISTS IX_BoutiqueOperations_SessionDate ON BoutiqueOperations(SessionId, DateOperation, Id);
        CREATE INDEX IF NOT EXISTS IX_BoutiqueOperations_ServiceDate ON BoutiqueOperations(Service, DateOperation, Id);
        
        """;
        cmd.ExecuteNonQuery();

        // V208 : statut et traçabilité des annulations. Les anciennes opérations restent
        // compatibles grâce à une valeur par défaut "Active". Une opération annulée
        // n'est jamais supprimée de la base : elle reste consultable et traçable.
        using (var alterOps = c.CreateCommand())
        {
            try { alterOps.CommandText = "ALTER TABLE Operations ADD COLUMN Statut TEXT NOT NULL DEFAULT 'Active'"; alterOps.ExecuteNonQuery(); }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { }
            try { alterOps.CommandText = "ALTER TABLE Operations ADD COLUMN DateAnnulation TEXT"; alterOps.ExecuteNonQuery(); }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { }
            try { alterOps.CommandText = "ALTER TABLE Operations ADD COLUMN MotifAnnulation TEXT"; alterOps.ExecuteNonQuery(); }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { }
            try { alterOps.CommandText = "ALTER TABLE Operations ADD COLUMN AnnuleePar TEXT"; alterOps.ExecuteNonQuery(); }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { }
        }
        using (var alterPay = c.CreateCommand())
        {
            try { alterPay.CommandText = "ALTER TABLE PaiementsDettes ADD COLUMN OperationId INTEGER"; alterPay.ExecuteNonQuery(); }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { }
        }
        using (var payIndex = c.CreateCommand())
        {
            payIndex.CommandText = "CREATE INDEX IF NOT EXISTS IX_PaiementsDettes_OperationId ON PaiementsDettes(OperationId)";
            payIndex.ExecuteNonQuery();
        }

        using (var annIndex = c.CreateCommand())
        {
            annIndex.CommandText = "CREATE INDEX IF NOT EXISTS IX_Operations_StatutDate ON Operations(Statut, DateOperation, Id DESC);";
            annIndex.ExecuteNonQuery();
        }

        // Migration Boutique : affecter chaque employé à un poste fixe (Poste 1 à Poste 6).
        using (var alterBoutique = c.CreateCommand())
        {
            try
            {
                alterBoutique.CommandText = "ALTER TABLE BoutiqueEmployes ADD COLUMN Poste INTEGER NOT NULL DEFAULT 0";
                alterBoutique.ExecuteNonQuery();
            }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { /* colonne déjà présente */ }
        }
        // Les anciens employés sont affectés une seule fois aux six postes disponibles.
        using (var assignPosts = c.CreateCommand())
        {
            assignPosts.CommandText = "SELECT Id FROM BoutiqueEmployes WHERE Poste=0 ORDER BY Id LIMIT 6";
            var ids = new List<long>();
            using var rr = assignPosts.ExecuteReader();
            while (rr.Read()) ids.Add(rr.GetInt64(0));
            rr.Close();
            for (int i = 0; i < ids.Count; i++)
            {
                using var up = c.CreateCommand();
                up.CommandText = "UPDATE BoutiqueEmployes SET Poste=$p WHERE Id=$id";
                up.Parameters.AddWithValue("$p", i + 1);
                up.Parameters.AddWithValue("$id", ids[i]);
                up.ExecuteNonQuery();
            }
        }

        // Migration Boutique V158 : ajouter la dotation en espèces, prise dans la caisse générale.
        using (var alterBoutiqueCash = c.CreateCommand())
        {
            try { alterBoutiqueCash.CommandText = "ALTER TABLE BoutiqueSessions ADD COLUMN EspecesDonne REAL NOT NULL DEFAULT 0"; alterBoutiqueCash.ExecuteNonQuery(); }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { }
            try { alterBoutiqueCash.CommandText = "ALTER TABLE BoutiqueSessions ADD COLUMN EspecesRetour REAL NOT NULL DEFAULT 0"; alterBoutiqueCash.ExecuteNonQuery(); }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { }
        }

        // Migration V56 : séparer les liquidités Wave et Orange Money de la caisse générale.
        using (var alter = c.CreateCommand())
        {
            try
            {
                alter.CommandText = "ALTER TABLE CaisseMouvements ADD COLUMN ServiceCaisse TEXT NOT NULL DEFAULT 'Caisse'";
                alter.ExecuteNonQuery();
            }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { /* colonne déjà présente */ }
        }
        // Migration Seddo : paiement différé / encaissements ultérieurs.
        using (var alterSeddo = c.CreateCommand())
        {
            try
            {
                alterSeddo.CommandText = "ALTER TABLE Operations ADD COLUMN PaiementDiffere INTEGER NOT NULL DEFAULT 0";
                alterSeddo.ExecuteNonQuery();
            }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { /* colonne déjà présente */ }
        }
        // Migration Seddo : mode de paiement pour les encaissements.
        using (var alterSeddoPay = c.CreateCommand())
        {
            try
            {
                alterSeddoPay.CommandText = "ALTER TABLE SeddoPaiements ADD COLUMN ServicePaiement TEXT NOT NULL DEFAULT 'Caisse Seddo'";
                alterSeddoPay.ExecuteNonQuery();
            }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 1) { /* colonne déjà présente */ }
        }
        MigrateExistingTransfersToDebts();
    }

    public sealed record SamaClientRow(long Id, string Nom, string Telephone, string Note);
    public sealed record SamaLoanRow(long Id, long ClientId, string ClientNom, string Telephone, string DateOperation, string DateEcheance, decimal MontantInitial, decimal MontantRestant, string Motif, string Reference);
    public sealed record SamaTransactionRow(long Id, string DateOperation, string ClientNom, string TypeOperation, decimal Montant, string DateEcheance, string Motif, string Reference);

    public static List<SamaClientRow> GetSamaClients()
    {
        var rows = new List<SamaClientRow>(); using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Id,Nom,Telephone,Note FROM SamaClients ORDER BY Nom COLLATE NOCASE";
        using var r = cmd.ExecuteReader(); while (r.Read()) rows.Add(new SamaClientRow(r.GetInt64(0), r.GetString(1), r.GetString(2), r.GetString(3))); return rows;
    }

    public static long FindOrCreateSamaClient(string nom, string telephone, string note = "")
    {
        nom = (nom ?? "").Trim(); telephone = (telephone ?? "").Trim();
        if (string.IsNullOrWhiteSpace(nom)) throw new ArgumentException("Le nom du client est obligatoire.");
        using (var c = Open())
        using (var cmd = c.CreateCommand())
        {
            if (!string.IsNullOrWhiteSpace(telephone))
            {
                cmd.CommandText = "SELECT Id FROM SamaClients WHERE Telephone=$t AND $t<>'' ORDER BY Id LIMIT 1";
                cmd.Parameters.AddWithValue("$t", telephone);
            }
            else
            {
                cmd.CommandText = "SELECT Id FROM SamaClients WHERE Nom=$n COLLATE NOCASE ORDER BY Id LIMIT 1";
                cmd.Parameters.AddWithValue("$n", nom);
            }
            var existing = cmd.ExecuteScalar();
            if (existing != null && existing != DBNull.Value) return Convert.ToInt64(existing);
        }
        return AddSamaClient(nom, telephone, note);
    }

    public static long FindSamaClient(string nom, string telephone)
    {
        nom = (nom ?? "").Trim(); telephone = (telephone ?? "").Trim();
        using var c = Open(); using var cmd = c.CreateCommand();
        if (!string.IsNullOrWhiteSpace(telephone))
        {
            cmd.CommandText = "SELECT Id FROM SamaClients WHERE Telephone=$t AND $t<>'' ORDER BY Id LIMIT 1";
            cmd.Parameters.AddWithValue("$t", telephone);
        }
        else
        {
            cmd.CommandText = "SELECT Id FROM SamaClients WHERE Nom=$n COLLATE NOCASE ORDER BY Id LIMIT 1";
            cmd.Parameters.AddWithValue("$n", nom);
        }
        var value = cmd.ExecuteScalar();
        return value == null || value == DBNull.Value ? 0 : Convert.ToInt64(value);
    }

    public static long AddSamaClient(string nom, string telephone, string note = "")
    {
        if (string.IsNullOrWhiteSpace(nom)) throw new ArgumentException("Le nom du client est obligatoire.");
        using var c = Open(); using var tx = c.BeginTransaction();
        using (var cmd = c.CreateCommand())
        {
            cmd.Transaction = tx;
            cmd.CommandText = "INSERT INTO SamaClients(Nom,Telephone,Note,DateCreation) VALUES($n,$t,$note,$d)";
            cmd.Parameters.AddWithValue("$n", nom.Trim()); cmd.Parameters.AddWithValue("$t", telephone?.Trim() ?? ""); cmd.Parameters.AddWithValue("$note", note?.Trim() ?? ""); cmd.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            cmd.ExecuteNonQuery();
        }
        long id;
        using (var idCmd = c.CreateCommand()) { idCmd.Transaction = tx; idCmd.CommandText = "SELECT last_insert_rowid()"; id = Convert.ToInt64(idCmd.ExecuteScalar()); }
        tx.Commit(); return id;
    }

    public static (decimal ArgentConfie, decimal PretsRestants, decimal PortefeuillePersonnel) GetSamaSummary()
    {
        using var c = Open(); decimal held = 0, loans = 0, wallet = 0;
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT COALESCE(SUM(CASE WHEN TypeOperation='Dépôt client' THEN Montant WHEN TypeOperation='Restitution client' THEN -Montant ELSE 0 END),0) FROM SamaTransactions";
            held = Convert.ToDecimal(cmd.ExecuteScalar() ?? 0);
        }
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT COALESCE(SUM(CASE WHEN TypeOperation='Prêt accordé' THEN Montant ELSE 0 END),0)-COALESCE(SUM(CASE WHEN TypeOperation='Remboursement prêt' THEN Montant ELSE 0 END),0) FROM SamaTransactions";
            loans = Convert.ToDecimal(cmd.ExecuteScalar() ?? 0);
        }
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = "SELECT Value FROM AppSettings WHERE Key='SamaPortefeuilleSolde'";
            decimal.TryParse(Convert.ToString(cmd.ExecuteScalar()), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out wallet);
        }
        return (held, loans, wallet);
    }

    public static List<SamaLoanRow> GetSamaOpenLoans(long clientId = 0)
    {
        var rows = new List<SamaLoanRow>(); using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT l.Id,l.ClientId,cl.Nom,cl.Telephone,l.DateOperation,COALESCE(l.DateEcheance,''),l.Montant,
                   l.Montant-COALESCE((SELECT SUM(p.Montant) FROM SamaTransactions p WHERE p.TypeOperation='Remboursement prêt' AND p.LoanId=l.Id),0),l.Motif,l.Reference
            FROM SamaTransactions l JOIN SamaClients cl ON cl.Id=l.ClientId
            WHERE l.TypeOperation='Prêt accordé' AND l.Montant-COALESCE((SELECT SUM(p.Montant) FROM SamaTransactions p WHERE p.TypeOperation='Remboursement prêt' AND p.LoanId=l.Id),0)>0.0001
              AND ($id=0 OR l.ClientId=$id) ORDER BY l.Id ASC
            """;
        cmd.Parameters.AddWithValue("$id", clientId); using var r = cmd.ExecuteReader();
        while (r.Read()) rows.Add(new SamaLoanRow(r.GetInt64(0),r.GetInt64(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetString(5),Convert.ToDecimal(r.GetValue(6)),Convert.ToDecimal(r.GetValue(7)),r.GetString(8),r.GetString(9)));
        return rows;
    }

    public static List<SamaTransactionRow> GetSamaTransactions(int limit = 300)
    {
        var rows = new List<SamaTransactionRow>(); using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT t.Id,t.DateOperation,COALESCE(c.Nom,'Portefeuille personnel'),t.TypeOperation,t.Montant,COALESCE(t.DateEcheance,''),t.Motif,t.Reference FROM SamaTransactions t LEFT JOIN SamaClients c ON c.Id=t.ClientId ORDER BY t.Id DESC LIMIT $n";
        cmd.Parameters.AddWithValue("$n", Math.Clamp(limit,1,2000)); using var r = cmd.ExecuteReader();
        while (r.Read()) rows.Add(new SamaTransactionRow(r.GetInt64(0),r.GetString(1),r.GetString(2),r.GetString(3),Convert.ToDecimal(r.GetValue(4)),r.GetString(5),r.GetString(6),r.GetString(7)));
        return rows;
    }


    public sealed record SamaClientBalance(long ClientId, string Nom, string Telephone, decimal MontantInitial, decimal MontantRembourse, decimal Reste, string DerniereOperation);
    public sealed record SamaLoanBalance(long ClientId, string Nom, string Telephone, decimal MontantInitial, decimal MontantRembourse, decimal Reste, string DerniereOperation, string ProchaineEcheance);

    public static List<SamaClientBalance> GetSamaEntrustedBalances()
    {
        var rows = new List<SamaClientBalance>(); using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT cl.Id,cl.Nom,cl.Telephone,COALESCE(SUM(CASE WHEN t.TypeOperation='Dépôt client' THEN t.Montant ELSE 0 END),0),COALESCE(SUM(CASE WHEN t.TypeOperation='Restitution client' THEN t.Montant ELSE 0 END),0),COALESCE(MAX(t.DateOperation),'') FROM SamaClients cl JOIN SamaTransactions t ON t.ClientId=cl.Id WHERE t.TypeOperation IN ('Dépôt client','Restitution client') GROUP BY cl.Id,cl.Nom,cl.Telephone ORDER BY MAX(t.DateOperation) DESC";
        using var r = cmd.ExecuteReader(); while(r.Read()) { var initial=Convert.ToDecimal(r.GetValue(3)); var repaid=Convert.ToDecimal(r.GetValue(4)); var date=Convert.ToString(r.GetValue(5))??""; if(DateTime.TryParse(date,out var dt)) date=dt.ToString("dd/MM/yyyy HH:mm"); rows.Add(new SamaClientBalance(r.GetInt64(0),r.GetString(1),r.GetString(2),initial,repaid,initial-repaid,date)); } return rows;
    }

    public static List<SamaLoanBalance> GetSamaLoanBalances()
    {
        var rows = new List<SamaLoanBalance>(); using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT cl.Id,cl.Nom,cl.Telephone,COALESCE(SUM(CASE WHEN t.TypeOperation='Prêt accordé' THEN t.Montant ELSE 0 END),0),COALESCE(SUM(CASE WHEN t.TypeOperation='Remboursement prêt' THEN t.Montant ELSE 0 END),0),COALESCE(MAX(t.DateOperation),''),COALESCE(MIN(CASE WHEN t.TypeOperation='Prêt accordé' AND COALESCE(t.DateEcheance,'')<>'' THEN t.DateEcheance END),'') FROM SamaClients cl JOIN SamaTransactions t ON t.ClientId=cl.Id WHERE t.TypeOperation IN ('Prêt accordé','Remboursement prêt') GROUP BY cl.Id,cl.Nom,cl.Telephone ORDER BY MAX(t.DateOperation) DESC";
        using var r = cmd.ExecuteReader(); while(r.Read()) { var initial=Convert.ToDecimal(r.GetValue(3)); var repaid=Convert.ToDecimal(r.GetValue(4)); var last=Convert.ToString(r.GetValue(5))??""; if(DateTime.TryParse(last,out var lastDt)) last=lastDt.ToString("dd/MM/yyyy HH:mm"); var due=Convert.ToString(r.GetValue(6))??""; if(DateTime.TryParse(due,out var dt)) due=dt.ToString("dd/MM/yyyy"); rows.Add(new SamaLoanBalance(r.GetInt64(0),r.GetString(1),r.GetString(2),initial,repaid,initial-repaid,last,due)); } return rows;
    }

    public static SamaClientRow? GetSamaClientById(long id)
    { using var c=Open(); using var cmd=c.CreateCommand(); cmd.CommandText="SELECT Id,Nom,Telephone,Note FROM SamaClients WHERE Id=$id LIMIT 1"; cmd.Parameters.AddWithValue("$id",id); using var r=cmd.ExecuteReader(); return r.Read()?new SamaClientRow(r.GetInt64(0),r.GetString(1),r.GetString(2),r.GetString(3)):null; }

    public static void RecordSamaEntrustedMovement(long clientId, decimal montant, bool depot, string motif, string reference)
    {
        if (montant <= 0) throw new ArgumentException("Le montant doit être supérieur à zéro.");
        using var c = Open(); using var tx = c.BeginTransaction();
        if (!depot)
        {
            using var check = c.CreateCommand(); check.Transaction = tx;
            check.CommandText = "SELECT COALESCE(SUM(CASE WHEN TypeOperation='Dépôt client' THEN Montant WHEN TypeOperation='Restitution client' THEN -Montant ELSE 0 END),0) FROM SamaTransactions WHERE ClientId=$id";
            check.Parameters.AddWithValue("$id",clientId); var held=Convert.ToDecimal(check.ExecuteScalar()??0);
            if (held < montant) throw new InvalidOperationException("Le montant dépasse le solde confié par ce client.");
        }
        using (var ins=c.CreateCommand())
        {
            ins.Transaction=tx; ins.CommandText="INSERT INTO SamaTransactions(DateOperation,ClientId,TypeOperation,Montant,Motif,Reference) VALUES($d,$c,$t,$m,$motif,$r)";
            ins.Parameters.AddWithValue("$d",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); ins.Parameters.AddWithValue("$c",clientId); ins.Parameters.AddWithValue("$t",depot?"Dépôt client":"Restitution client"); ins.Parameters.AddWithValue("$m",montant); ins.Parameters.AddWithValue("$motif",motif??""); ins.Parameters.AddWithValue("$r",reference??""); ins.ExecuteNonQuery();
        }
        using (var mov=c.CreateCommand())
        {
            mov.Transaction=tx; mov.CommandText="INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,ServiceCaisse) VALUES($d,$t,$m,$motif,$r,'Sama caisse')";
            mov.Parameters.AddWithValue("$d",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); mov.Parameters.AddWithValue("$t",depot?"Entrée":"Sortie"); mov.Parameters.AddWithValue("$m",montant); mov.Parameters.AddWithValue("$motif",(depot?"Argent confié par client — ":"Restitution argent client — ")+motif); mov.Parameters.AddWithValue("$r",reference??""); mov.ExecuteNonQuery();
        }
        using (var sol=c.CreateCommand()) { sol.Transaction=tx; sol.CommandText="UPDATE Soldes SET Montant=Montant+$delta WHERE Service='Sama caisse'"; sol.Parameters.AddWithValue("$delta",depot?montant:-montant); sol.ExecuteNonQuery(); }
        AuditTx(c,tx,depot?"Dépôt argent confié SAMA":"Restitution argent confié SAMA",motif,montant,reference); tx.Commit();
    }

    public static void RecordSamaLoan(long clientId, decimal montant, DateTime? echeance, string motif, string reference)
    {
        if (montant <= 0) throw new ArgumentException("Le montant doit être supérieur à zéro.");
        using var c=Open(); using var tx=c.BeginTransaction(); decimal wallet=0;
        using (var get=c.CreateCommand()) { get.Transaction=tx; get.CommandText="SELECT Value FROM AppSettings WHERE Key='SamaPortefeuilleSolde'"; decimal.TryParse(Convert.ToString(get.ExecuteScalar()),System.Globalization.NumberStyles.Any,System.Globalization.CultureInfo.InvariantCulture,out wallet); }
        // Le portefeuille est suivi à titre informatif : son solde ne bloque jamais l'enregistrement d'un prêt.
        using (var ins=c.CreateCommand()) { ins.Transaction=tx; ins.CommandText="INSERT INTO SamaTransactions(DateOperation,ClientId,TypeOperation,Montant,DateEcheance,Motif,Reference) VALUES($d,$c,'Prêt accordé',$m,$e,$motif,$r)"; ins.Parameters.AddWithValue("$d",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); ins.Parameters.AddWithValue("$c",clientId); ins.Parameters.AddWithValue("$m",montant); ins.Parameters.AddWithValue("$e",echeance?.ToString("yyyy-MM-dd")??""); ins.Parameters.AddWithValue("$motif",motif??""); ins.Parameters.AddWithValue("$r",reference??""); ins.ExecuteNonQuery(); }
        using (var upd=c.CreateCommand()) { upd.Transaction=tx; upd.CommandText="UPDATE AppSettings SET Value=$v WHERE Key='SamaPortefeuilleSolde'"; upd.Parameters.AddWithValue("$v",(wallet-montant).ToString(System.Globalization.CultureInfo.InvariantCulture)); upd.ExecuteNonQuery(); }
        AuditTx(c,tx,"Prêt personnel accordé SAMA",motif,montant,reference); tx.Commit();
    }

    public static void RecordSamaRepayment(long loanId, decimal montant, string motif, string reference)
    {
        if (montant <= 0) throw new ArgumentException("Le montant doit être supérieur à zéro.");
        using var c=Open(); using var tx=c.BeginTransaction(); long clientId; decimal remaining;
        using (var q=c.CreateCommand()) { q.Transaction=tx; q.CommandText="SELECT l.ClientId,l.Montant-COALESCE((SELECT SUM(p.Montant) FROM SamaTransactions p WHERE p.TypeOperation='Remboursement prêt' AND p.LoanId=l.Id),0) FROM SamaTransactions l WHERE l.Id=$id AND l.TypeOperation='Prêt accordé'"; q.Parameters.AddWithValue("$id",loanId); using var r=q.ExecuteReader(); if(!r.Read()) throw new InvalidOperationException("Prêt introuvable."); clientId=r.GetInt64(0); remaining=Convert.ToDecimal(r.GetValue(1)); }
        if(montant>remaining) throw new InvalidOperationException("Le remboursement dépasse le montant restant du prêt.");
        decimal wallet=0; using(var q=c.CreateCommand()){q.Transaction=tx;q.CommandText="SELECT Value FROM AppSettings WHERE Key='SamaPortefeuilleSolde'";decimal.TryParse(Convert.ToString(q.ExecuteScalar()),System.Globalization.NumberStyles.Any,System.Globalization.CultureInfo.InvariantCulture,out wallet);}
        using(var ins=c.CreateCommand()){ins.Transaction=tx;ins.CommandText="INSERT INTO SamaTransactions(DateOperation,ClientId,TypeOperation,Montant,LoanId,Motif,Reference) VALUES($d,$c,'Remboursement prêt',$m,$loan,$motif,$r)";ins.Parameters.AddWithValue("$d",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));ins.Parameters.AddWithValue("$c",clientId);ins.Parameters.AddWithValue("$m",montant);ins.Parameters.AddWithValue("$loan",loanId);ins.Parameters.AddWithValue("$motif",motif??"");ins.Parameters.AddWithValue("$r",reference??"");ins.ExecuteNonQuery();}
        using(var upd=c.CreateCommand()){upd.Transaction=tx;upd.CommandText="UPDATE AppSettings SET Value=$v WHERE Key='SamaPortefeuilleSolde'";upd.Parameters.AddWithValue("$v",(wallet+montant).ToString(System.Globalization.CultureInfo.InvariantCulture));upd.ExecuteNonQuery();}
        AuditTx(c,tx,"Remboursement prêt personnel SAMA",motif,montant,reference); tx.Commit();
    }

    public static void AdjustSamaWallet(decimal montant, bool entree, string motif, string reference)
    {
        if(montant<=0) throw new ArgumentException("Le montant doit être supérieur à zéro."); using var c=Open(); using var tx=c.BeginTransaction(); decimal wallet=0;
        using(var q=c.CreateCommand()){q.Transaction=tx;q.CommandText="SELECT Value FROM AppSettings WHERE Key='SamaPortefeuilleSolde'";decimal.TryParse(Convert.ToString(q.ExecuteScalar()),System.Globalization.NumberStyles.Any,System.Globalization.CultureInfo.InvariantCulture,out wallet);}
        if(!entree && wallet<montant) throw new InvalidOperationException("Le portefeuille personnel ne dispose pas d'un solde suffisant.");
        using(var upd=c.CreateCommand()){upd.Transaction=tx;upd.CommandText="UPDATE AppSettings SET Value=$v WHERE Key='SamaPortefeuilleSolde'";upd.Parameters.AddWithValue("$v",(wallet+(entree?montant:-montant)).ToString(System.Globalization.CultureInfo.InvariantCulture));upd.ExecuteNonQuery();}
        using(var ins=c.CreateCommand()){ins.Transaction=tx;ins.CommandText="INSERT INTO SamaTransactions(DateOperation,TypeOperation,Montant,Motif,Reference) VALUES($d,$t,$m,$motif,$r)";ins.Parameters.AddWithValue("$d",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));ins.Parameters.AddWithValue("$t",entree?"Approvisionnement portefeuille":"Retrait portefeuille");ins.Parameters.AddWithValue("$m",montant);ins.Parameters.AddWithValue("$motif",motif??"");ins.Parameters.AddWithValue("$r",reference??"");ins.ExecuteNonQuery();}
        AuditTx(c,tx,entree?"Approvisionnement portefeuille SAMA":"Retrait portefeuille SAMA",motif,montant,reference); tx.Commit();
    }

    static void MigrateExistingTransfersToDebts()
    {
        using var c = Open();
        using var tx = c.BeginTransaction();
        using var cmd = c.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = """
            INSERT INTO Dettes(OperationId,ClientId,Service,ClientNom,Telephone,MontantInitial,MontantRestant,DateCreation,Statut,Reference,Observation)
            SELECT o.Id,o.ClientId,o.Service,o.ClientNom,o.Telephone,
                   CASE WHEN o.Dette>0 THEN o.Dette ELSE o.Montant+o.Commission END,
                   CASE WHEN o.Dette>0 THEN o.Dette ELSE o.Montant+o.Commission END,
                   o.DateOperation,'Non soldée',o.Reference,'Dette importée automatiquement depuis un ancien transfert/envoi'
            FROM Operations o
            WHERE o.TypeOperation IN ('Transfert','Envoi')
              AND NOT EXISTS (SELECT 1 FROM Dettes d WHERE d.OperationId=o.Id);
            """;
        cmd.ExecuteNonQuery();
        tx.Commit();
    }


    public sealed record OperationRow(
        string DateOperation, string Service, string TypeOperation, string ClientNom,
        string Telephone, decimal Montant, decimal Commission, decimal Dette,
        string Reference, string Observation, long Id = 0);

    public sealed record DashboardSnapshot(decimal Caisse, decimal Wave, decimal Orange, decimal CaisseWave, decimal CaisseOrange, decimal CaisseSeddo, decimal DetteWave, decimal DetteOrange, decimal TodayOperations, decimal WaveDepot, decimal WaveRetrait, decimal WaveTransfert, decimal OrangeDepot, decimal OrangeRetrait, decimal OrangeTransfert);

    public static DashboardSnapshot GetDashboardSnapshot()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        // Une seule lecture de Operations et une seule lecture de Dettes au lieu
        // de nombreuses sous-requêtes qui rescannaient les mêmes tables.
        cmd.CommandText = """
            WITH s AS (
                SELECT
                    COALESCE(MAX(CASE WHEN Service='Caisse' THEN Montant END),0) AS Caisse,
                    COALESCE(MAX(CASE WHEN Service='Wave' THEN Montant END),0) AS Wave,
                    COALESCE(MAX(CASE WHEN Service='Orange Money' THEN Montant END),0) AS Orange,
                    COALESCE(MAX(CASE WHEN Service='Caisse Wave' THEN Montant END),0) AS CaisseWave,
                    COALESCE(MAX(CASE WHEN Service='Caisse Orange Money' THEN Montant END),0) AS CaisseOrange,
                    COALESCE(MAX(CASE WHEN Service='Caisse Seddo' THEN Montant END),0) AS CaisseSeddo
                FROM Soldes
            ),
            d AS (
                SELECT
                    COALESCE(SUM(CASE WHEN Service='Wave' AND MontantRestant>0 THEN MontantRestant ELSE 0 END),0) AS DetteWave,
                    COALESCE(SUM(CASE WHEN Service='Orange Money' AND MontantRestant>0 THEN MontantRestant ELSE 0 END),0) AS DetteOrange
                FROM Dettes
            ),
            o AS (
                SELECT
                    COUNT(CASE WHEN DateOperation >= date('now','localtime') AND DateOperation < date('now','localtime','+1 day') THEN 1 END) AS TodayOperations,
                    COALESCE(SUM(CASE WHEN Service='Wave' AND TypeOperation='Dépôt' THEN Montant ELSE 0 END),0) AS WaveDepot,
                    COALESCE(SUM(CASE WHEN Service='Wave' AND TypeOperation='Retrait' THEN Montant ELSE 0 END),0) AS WaveRetrait,
                    COALESCE(SUM(CASE WHEN Service='Wave' AND TypeOperation IN ('Transfert','Envoi') THEN Montant ELSE 0 END),0) AS WaveTransfert,
                    COALESCE(SUM(CASE WHEN Service='Orange Money' AND TypeOperation='Dépôt' THEN Montant ELSE 0 END),0) AS OrangeDepot,
                    COALESCE(SUM(CASE WHEN Service='Orange Money' AND TypeOperation='Retrait' THEN Montant ELSE 0 END),0) AS OrangeRetrait,
                    COALESCE(SUM(CASE WHEN Service='Orange Money' AND TypeOperation IN ('Transfert','Envoi') THEN Montant ELSE 0 END),0) AS OrangeTransfert
                FROM Operations
                WHERE COALESCE(Statut,'Active')='Active'
            )
            SELECT s.Caisse,s.Wave,s.Orange,s.CaisseWave,s.CaisseOrange,s.CaisseSeddo,
                   d.DetteWave,d.DetteOrange,o.TodayOperations,o.WaveDepot,o.WaveRetrait,o.WaveTransfert,
                   o.OrangeDepot,o.OrangeRetrait,o.OrangeTransfert
            FROM s CROSS JOIN d CROSS JOIN o;
            """;
        using var r = cmd.ExecuteReader();
        if (!r.Read()) return new DashboardSnapshot(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
        return new DashboardSnapshot(
            Convert.ToDecimal(r.GetValue(0)), Convert.ToDecimal(r.GetValue(1)), Convert.ToDecimal(r.GetValue(2)),
            Convert.ToDecimal(r.GetValue(3)), Convert.ToDecimal(r.GetValue(4)), Convert.ToDecimal(r.GetValue(5)),
            Convert.ToDecimal(r.GetValue(6)), Convert.ToDecimal(r.GetValue(7)), Convert.ToDecimal(r.GetValue(8)),
            Convert.ToDecimal(r.GetValue(9)), Convert.ToDecimal(r.GetValue(10)), Convert.ToDecimal(r.GetValue(11)),
            Convert.ToDecimal(r.GetValue(12)), Convert.ToDecimal(r.GetValue(13)), Convert.ToDecimal(r.GetValue(14)));
    }

    public static (decimal VenteUV, decimal AchatUV) GetReequilibrageSums()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT
                COALESCE(SUM(CASE WHEN TypeOperation='Rééquilibrage' AND Dette>0 THEN Montant ELSE 0 END),0),
                COALESCE(SUM(CASE WHEN TypeOperation='Rééquilibrage' AND Dette<=0 THEN Montant ELSE 0 END),0)
            FROM Operations WHERE COALESCE(Statut,'Active')='Active';
            """;
        using var r = cmd.ExecuteReader();
        if (!r.Read()) return (0, 0);
        return (Convert.ToDecimal(r.GetValue(0)), Convert.ToDecimal(r.GetValue(1)));
    }

    public static (decimal Depot, decimal Retrait, decimal Transfert) GetOperationSums(string service)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT
                COALESCE(SUM(CASE WHEN TypeOperation='Dépôt' THEN Montant ELSE 0 END),0),
                COALESCE(SUM(CASE WHEN TypeOperation='Retrait' THEN Montant ELSE 0 END),0),
                COALESCE(SUM(CASE WHEN TypeOperation IN ('Transfert','Envoi') THEN Montant ELSE 0 END),0)
            FROM Operations WHERE Service=$s AND COALESCE(Statut,'Active')='Active';
            """;
        cmd.Parameters.AddWithValue("$s", service);
        using var r = cmd.ExecuteReader();
        if (!r.Read()) return (0,0,0);
        return (Convert.ToDecimal(r.GetValue(0)), Convert.ToDecimal(r.GetValue(1)), Convert.ToDecimal(r.GetValue(2)));
    }

    public sealed record AnnulationOperationRow(
        long Id, string DateOperation, string Service, string TypeOperation, string ClientNom,
        string Telephone, decimal Montant, decimal Commission, decimal Dette, string Reference,
        string Observation, string Statut, string DateAnnulation, string MotifAnnulation, string AnnuleePar);

    public sealed record AnnulationMovementRow(
        long Id, string DateMouvement, string TypeMouvement, decimal Montant,
        string Motif, string Reference, string ServiceCaisse);

    public static List<AnnulationOperationRow> SearchAnnulationOperations(
        string search, string type, string service, string statut,
        DateTime? start, DateTime? end, decimal? montant)
    {
        var list = new List<AnnulationOperationRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        var where = new List<string>();
        if (!string.IsNullOrWhiteSpace(search))
        {
            where.Add("(CAST(o.Id AS TEXT) LIKE $q OR o.ClientNom LIKE $q OR o.Telephone LIKE $q OR o.Reference LIKE $q OR o.Observation LIKE $q)");
            cmd.Parameters.AddWithValue("$q", "%" + search.Trim() + "%");
        }
        if (!string.IsNullOrWhiteSpace(type) && type != "Tous les types") { where.Add("o.TypeOperation=$type"); cmd.Parameters.AddWithValue("$type", type); }
        if (!string.IsNullOrWhiteSpace(service) && service != "Toutes les caisses / services") { where.Add("o.Service=$service"); cmd.Parameters.AddWithValue("$service", service); }
        if (!string.IsNullOrWhiteSpace(statut) && statut != "Toutes") { where.Add("COALESCE(o.Statut,'Active')=$statut"); cmd.Parameters.AddWithValue("$statut", statut); }
        if (start.HasValue) { where.Add("o.DateOperation >= $start"); cmd.Parameters.AddWithValue("$start", start.Value.ToString("yyyy-MM-dd 00:00:00")); }
        if (end.HasValue) { where.Add("o.DateOperation < $end"); cmd.Parameters.AddWithValue("$end", end.Value.AddDays(1).ToString("yyyy-MM-dd 00:00:00")); }
        if (montant.HasValue) { where.Add("o.Montant=$montant"); cmd.Parameters.AddWithValue("$montant", montant.Value); }
        var sql = $"""
            SELECT o.Id,o.DateOperation,o.Service,o.TypeOperation,COALESCE(o.ClientNom,''),COALESCE(o.Telephone,''),
                   o.Montant,o.Commission,o.Dette,COALESCE(o.Reference,''),COALESCE(o.Observation,''),
                   COALESCE(o.Statut,'Active'),COALESCE(o.DateAnnulation,''),COALESCE(o.MotifAnnulation,''),COALESCE(o.AnnuleePar,'')
            FROM Operations o
            {(where.Count == 0 ? "" : "WHERE " + string.Join(" AND ", where))}
            ORDER BY o.Id DESC LIMIT 1000;
        """;
        cmd.CommandText = sql;
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            list.Add(new AnnulationOperationRow(
                Convert.ToInt64(r.GetValue(0)), Convert.ToString(r.GetValue(1)) ?? "", Convert.ToString(r.GetValue(2)) ?? "",
                Convert.ToString(r.GetValue(3)) ?? "", Convert.ToString(r.GetValue(4)) ?? "", Convert.ToString(r.GetValue(5)) ?? "",
                Convert.ToDecimal(r.GetValue(6)), Convert.ToDecimal(r.GetValue(7)), Convert.ToDecimal(r.GetValue(8)), Convert.ToString(r.GetValue(9)) ?? "",
                Convert.ToString(r.GetValue(10)) ?? "", Convert.ToString(r.GetValue(11)) ?? "Active", Convert.ToString(r.GetValue(12)) ?? "",
                Convert.ToString(r.GetValue(13)) ?? "", Convert.ToString(r.GetValue(14)) ?? ""));
        }
        return list;
    }

    public static AnnulationOperationRow? GetAnnulationOperation(long operationId)
        => SearchAnnulationOperations(operationId.ToString(), "Tous les types", "Toutes les caisses / services", "Toutes", null, null, null)
            .FirstOrDefault(x => x.Id == operationId);

    public static List<AnnulationMovementRow> GetOperationMovements(long operationId)
    {
        var list = new List<AnnulationMovementRow>();
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Id,DateMouvement,TypeMouvement,Montant,COALESCE(Motif,''),COALESCE(Reference,''),ServiceCaisse FROM CaisseMouvements WHERE OperationId=$id ORDER BY Id";
        cmd.Parameters.AddWithValue("$id", operationId);
        using var r = cmd.ExecuteReader();
        while (r.Read()) list.Add(new AnnulationMovementRow(Convert.ToInt64(r.GetValue(0)), Convert.ToString(r.GetValue(1)) ?? "", Convert.ToString(r.GetValue(2)) ?? "", Convert.ToDecimal(r.GetValue(3)), Convert.ToString(r.GetValue(4)) ?? "", Convert.ToString(r.GetValue(5)) ?? "", Convert.ToString(r.GetValue(6)) ?? ""));
        return list;
    }

    public static void CancelOperation(long operationId, string motif, string annuleePar)
    {
        if (operationId <= 0) throw new ArgumentException("Opération invalide.");
        if (string.IsNullOrWhiteSpace(motif)) throw new ArgumentException("Veuillez indiquer le motif de l'annulation.");
        using var c = Open(); using var tx = c.BeginTransaction();
        string type = "", client = "", reference = ""; decimal amount = 0; string status = "Active";
        using (var get = c.CreateCommand())
        {
            get.Transaction = tx;
            get.CommandText = "SELECT TypeOperation,COALESCE(ClientNom,''),COALESCE(Reference,''),Montant,COALESCE(Statut,'Active') FROM Operations WHERE Id=$id";
            get.Parameters.AddWithValue("$id", operationId);
            using var r = get.ExecuteReader();
            if (!r.Read()) throw new InvalidOperationException("Opération introuvable.");
            type = Convert.ToString(r.GetValue(0)) ?? ""; client = Convert.ToString(r.GetValue(1)) ?? ""; reference = Convert.ToString(r.GetValue(2)) ?? ""; amount = Convert.ToDecimal(r.GetValue(3)); status = Convert.ToString(r.GetValue(4)) ?? "Active";
        }
        if (!string.Equals(status, "Active", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Cette opération est déjà annulée.");

        // Une dette qui a déjà reçu un paiement ne peut pas être annulée silencieusement.
        // Il faut d'abord annuler les opérations de remboursement concernées.
        using (var checkDebt = c.CreateCommand())
        {
            checkDebt.Transaction = tx;
            checkDebt.CommandText = "SELECT d.Id FROM Dettes d WHERE d.OperationId=$op LIMIT 1";
            checkDebt.Parameters.AddWithValue("$op", operationId);
            var debtObj = checkDebt.ExecuteScalar();
            if (debtObj != null && debtObj != DBNull.Value)
            {
                long debtId = Convert.ToInt64(debtObj);
                using var p = c.CreateCommand(); p.Transaction = tx;
                p.CommandText = "SELECT COUNT(*) FROM PaiementsDettes WHERE DetteId=$d"; p.Parameters.AddWithValue("$d", debtId);
                if (Convert.ToInt32(p.ExecuteScalar() ?? 0) > 0)
                    throw new InvalidOperationException("Cette opération est liée à une dette déjà remboursée en partie ou totalement. Annulez d'abord les remboursements liés à cette dette, puis annulez l'opération d'origine.");
            }
        }

        // Pour un remboursement de dette, le paiement est lié à l'opération depuis V208.
        // Les anciennes lignes sans lien sont volontairement bloquées pour éviter de supprimer
        // par erreur un autre remboursement du même client.
        if (string.Equals(type, "Remboursement dette", StringComparison.OrdinalIgnoreCase))
        {
            long paymentId = 0, debtId = 0; decimal paid = 0;
            using var payQ = c.CreateCommand();
            payQ.Transaction = tx;
            payQ.CommandText = "SELECT p.Id,p.DetteId,p.Montant FROM PaiementsDettes p WHERE p.OperationId=$op LIMIT 1";
            payQ.Parameters.AddWithValue("$op", operationId);
            using (var pr = payQ.ExecuteReader())
            {
                if (!pr.Read()) throw new InvalidOperationException("Ce remboursement est ancien et n'est pas lié directement à son paiement. Pour éviter toute erreur, cette opération doit être annulée depuis une version récente du logiciel après sauvegarde de la base.");
                paymentId = Convert.ToInt64(pr.GetValue(0)); debtId = Convert.ToInt64(pr.GetValue(1)); paid = Convert.ToDecimal(pr.GetValue(2));
            }
            using var restore = c.CreateCommand();
            restore.Transaction = tx; restore.CommandText = "UPDATE Dettes SET MontantRestant=MIN(MontantInitial,MontantRestant+$m),Statut=CASE WHEN MIN(MontantInitial,MontantRestant+$m)>=MontantInitial THEN 'Non soldée' ELSE 'Partiellement soldée' END,DateSolde=NULL WHERE Id=$d";
            restore.Parameters.AddWithValue("$m", paid); restore.Parameters.AddWithValue("$d", debtId); restore.ExecuteNonQuery();
            using var delPay = c.CreateCommand(); delPay.Transaction = tx; delPay.CommandText = "DELETE FROM PaiementsDettes WHERE Id=$id"; delPay.Parameters.AddWithValue("$id", paymentId); delPay.ExecuteNonQuery();
        }

        var movements = new List<AnnulationMovementRow>();
        using (var mov = c.CreateCommand())
        {
            mov.Transaction = tx; mov.CommandText = "SELECT Id,DateMouvement,TypeMouvement,Montant,COALESCE(Motif,''),COALESCE(Reference,''),ServiceCaisse FROM CaisseMouvements WHERE OperationId=$id ORDER BY Id"; mov.Parameters.AddWithValue("$id", operationId);
            using var r = mov.ExecuteReader(); while (r.Read()) movements.Add(new AnnulationMovementRow(Convert.ToInt64(r.GetValue(0)), Convert.ToString(r.GetValue(1)) ?? "", Convert.ToString(r.GetValue(2)) ?? "", Convert.ToDecimal(r.GetValue(3)), Convert.ToString(r.GetValue(4)) ?? "", Convert.ToString(r.GetValue(5)) ?? "", Convert.ToString(r.GetValue(6)) ?? ""));
        }
        foreach (var m in movements)
        {
            bool originalEntry = string.Equals(m.TypeMouvement, "Entrée", StringComparison.OrdinalIgnoreCase) || string.Equals(m.TypeMouvement, "Solde initial", StringComparison.OrdinalIgnoreCase);
            decimal delta = originalEntry ? -m.Montant : m.Montant;
            using var balance = c.CreateCommand(); balance.Transaction = tx; balance.CommandText = "SELECT Montant FROM Soldes WHERE Service=$s"; balance.Parameters.AddWithValue("$s", m.ServiceCaisse); var curObj = balance.ExecuteScalar();
            if (curObj == null || curObj == DBNull.Value) throw new InvalidOperationException($"La caisse {m.ServiceCaisse} est introuvable.");
            var current = Convert.ToDecimal(curObj); if (delta < 0 && current + delta < 0) throw new InvalidOperationException($"Annulation impossible : la caisse {m.ServiceCaisse} ne dispose plus de {m.Montant:N0} FCFA disponibles pour neutraliser cette opération.");
            using var upd = c.CreateCommand(); upd.Transaction = tx; upd.CommandText = "UPDATE Soldes SET Montant=Montant+$delta WHERE Service=$s"; upd.Parameters.AddWithValue("$delta", delta); upd.Parameters.AddWithValue("$s", m.ServiceCaisse); upd.ExecuteNonQuery();
            using var reverse = c.CreateCommand(); reverse.Transaction = tx; reverse.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($d,$t,$m,$motif,$ref,$op,$s)"; reverse.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); reverse.Parameters.AddWithValue("$t", originalEntry ? "Sortie" : "Entrée"); reverse.Parameters.AddWithValue("$m", m.Montant); reverse.Parameters.AddWithValue("$motif", "ANNULATION — " + (m.Motif ?? "Opération")); reverse.Parameters.AddWithValue("$ref", "ANN-" + operationId); reverse.Parameters.AddWithValue("$op", operationId); reverse.Parameters.AddWithValue("$s", m.ServiceCaisse); reverse.ExecuteNonQuery();
        }

        using (var debtStatus = c.CreateCommand())
        {
            debtStatus.Transaction = tx; debtStatus.CommandText = "UPDATE Dettes SET MontantRestant=0,Statut='Annulée',DateSolde=$d,Observation=COALESCE(Observation,'') || ' — Dette annulée avec opération ' || $op WHERE OperationId=$op"; debtStatus.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); debtStatus.Parameters.AddWithValue("$op", operationId); debtStatus.ExecuteNonQuery();
        }
        using (var update = c.CreateCommand())
        {
            update.Transaction = tx; update.CommandText = "UPDATE Operations SET Statut='Annulée',DateAnnulation=$d,MotifAnnulation=$m,AnnuleePar=$p WHERE Id=$id"; update.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); update.Parameters.AddWithValue("$m", motif.Trim()); update.Parameters.AddWithValue("$p", string.IsNullOrWhiteSpace(annuleePar) ? "Gérant" : annuleePar.Trim()); update.Parameters.AddWithValue("$id", operationId); update.ExecuteNonQuery();
        }
        AuditTx(c, tx, "Annulation opération", $"Opération #{operationId} — {type} — {client} — Motif : {motif.Trim()}", amount, reference);
        tx.Commit();
    }

    public static List<OperationRow> GetRecentOperations(int limit = 8)
    {
        var list = new List<OperationRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT DateOperation, Service, TypeOperation, ClientNom, Telephone,
                   Montant, Commission, Dette, Reference, Observation, Id
            FROM Operations ORDER BY Id DESC LIMIT $limit;
            """;
        cmd.Parameters.AddWithValue("$limit", Math.Max(1, limit));
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            list.Add(new OperationRow(
                Convert.ToString(r.GetValue(0)) ?? "",
                Convert.ToString(r.GetValue(1)) ?? "",
                Convert.ToString(r.GetValue(2)) ?? "",
                Convert.ToString(r.GetValue(3)) ?? "",
                Convert.ToString(r.GetValue(4)) ?? "",
                Convert.ToDecimal(r.GetValue(5)),
                Convert.ToDecimal(r.GetValue(6)),
                Convert.ToDecimal(r.GetValue(7)),
                Convert.ToString(r.GetValue(8)) ?? "",
                Convert.ToString(r.GetValue(9)) ?? "",
                Convert.ToInt64(r.GetValue(10))));
        }
        return list;
    }

    public static List<OperationRow> GetOperationsReport(string? service, string? type, DateTime start, DateTime endExclusive)
    {
        var list = new List<OperationRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        var where = new List<string> { "DateOperation >= $start", "DateOperation < $end", "COALESCE(Statut,'Active')='Active'" };
        cmd.Parameters.AddWithValue("$start", start.ToString("yyyy-MM-dd HH:mm:ss"));
        cmd.Parameters.AddWithValue("$end", endExclusive.ToString("yyyy-MM-dd HH:mm:ss"));
        if (!string.IsNullOrWhiteSpace(service)) { where.Add("Service = $service"); cmd.Parameters.AddWithValue("$service", service); }
        if (!string.IsNullOrWhiteSpace(type)) { where.Add("TypeOperation = $type"); cmd.Parameters.AddWithValue("$type", type); }
        cmd.CommandText = $"""
            SELECT DateOperation, Service, TypeOperation, ClientNom, Telephone,
                   Montant, Commission, Dette, Reference, Observation, Id
            FROM Operations
            WHERE {string.Join(" AND ", where)}
            ORDER BY DateOperation ASC, Id ASC;
            """;
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            list.Add(new OperationRow(
                Convert.ToString(r.GetValue(0)) ?? "",
                Convert.ToString(r.GetValue(1)) ?? "",
                Convert.ToString(r.GetValue(2)) ?? "",
                Convert.ToString(r.GetValue(3)) ?? "",
                Convert.ToString(r.GetValue(4)) ?? "",
                Convert.ToDecimal(r.GetValue(5)),
                Convert.ToDecimal(r.GetValue(6)),
                Convert.ToDecimal(r.GetValue(7)),
                Convert.ToString(r.GetValue(8)) ?? "",
                Convert.ToString(r.GetValue(9)) ?? "",
                Convert.ToInt64(r.GetValue(10))));
        }
        return list;
    }

    public static List<OperationRow> GetOperations(string service)
    {
        var list = new List<OperationRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT DateOperation, Service, TypeOperation, ClientNom, Telephone,
                   Montant, Commission, Dette, Reference, Observation, Id
            FROM Operations WHERE Service=$s
            ORDER BY Id DESC;
            """;
        cmd.Parameters.AddWithValue("$s", service);
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            list.Add(new OperationRow(
                Convert.ToString(r.GetValue(0)) ?? "",
                Convert.ToString(r.GetValue(1)) ?? "",
                Convert.ToString(r.GetValue(2)) ?? "",
                Convert.ToString(r.GetValue(3)) ?? "",
                Convert.ToString(r.GetValue(4)) ?? "",
                Convert.ToDecimal(r.GetValue(5)),
                Convert.ToDecimal(r.GetValue(6)),
                Convert.ToDecimal(r.GetValue(7)),
                Convert.ToString(r.GetValue(8)) ?? "",
                Convert.ToString(r.GetValue(9)) ?? "",
                Convert.ToInt64(r.GetValue(10))));
        }
        return list;
    }

    public static decimal GetSolde(string service)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Montant FROM Soldes WHERE Service=$s";
        cmd.Parameters.AddWithValue("$s", service);
        return Convert.ToDecimal(cmd.ExecuteScalar() ?? 0);
    }

    public static decimal GetDette(string service)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT COALESCE(SUM(MontantRestant),0) FROM Dettes WHERE Service=$s AND MontantRestant>0";
        cmd.Parameters.AddWithValue("$s", service);
        return Convert.ToDecimal(cmd.ExecuteScalar() ?? 0);
    }

    public static decimal GetTotalDettes()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT COALESCE(SUM(MontantRestant),0) FROM Dettes WHERE MontantRestant>0";
        return Convert.ToDecimal(cmd.ExecuteScalar() ?? 0);
    }

    public sealed record DebtReportStatus(
        long Id, decimal MontantInitial, decimal MontantRestant, string Statut,
        string SettlementService = "");

    public static DebtReportStatus? GetDebtReportStatus(long operationId, string clientNom, string reference, string observation = "")
    {
        using var c = Open();

        // Pour une opération de remboursement, l'observation contient directement
        // l'identifiant de la dette réglée.
        long debtId = 0;
        var marker = "Règlement dette ";
        var pos = (observation ?? "").IndexOf(marker, StringComparison.OrdinalIgnoreCase);
        if (pos >= 0)
        {
            var obs = observation ?? string.Empty;
            var rest = obs[(pos + marker.Length)..];
            var digits = new string(rest.TakeWhile(char.IsDigit).ToArray());
            long.TryParse(digits, out debtId);
        }

        using var cmd = c.CreateCommand();
        if (debtId > 0)
        {
            cmd.CommandText = """
                SELECT d.Id,d.MontantInitial,d.MontantRestant,d.Statut,
                       COALESCE((SELECT p.MoyenPaiement FROM PaiementsDettes p
                                 WHERE p.DetteId=d.Id
                                 ORDER BY p.DatePaiement DESC, p.Id DESC LIMIT 1), '')
                FROM Dettes d WHERE d.Id=$id LIMIT 1;
                """;
            cmd.Parameters.AddWithValue("$id", debtId);
        }
        else if (operationId > 0)
        {
            // IMPORTANT : une dette appartient à une opération précise.
            // On utilise OperationId avant le couple Nom/Référence afin que
            // plusieurs transferts du même client (ou sans référence unique)
            // ne récupèrent pas la dette du dernier transfert.
            cmd.CommandText = """
                SELECT d.Id,d.MontantInitial,d.MontantRestant,d.Statut,
                       COALESCE((SELECT p.MoyenPaiement FROM PaiementsDettes p
                                 WHERE p.DetteId=d.Id
                                 ORDER BY p.DatePaiement DESC, p.Id DESC LIMIT 1), '')
                FROM Dettes d WHERE d.OperationId=$oid LIMIT 1;
                """;
            cmd.Parameters.AddWithValue("$oid", operationId);
        }
        else
        {
            cmd.CommandText = """
                SELECT d.Id,d.MontantInitial,d.MontantRestant,d.Statut,
                       COALESCE((SELECT p.MoyenPaiement FROM PaiementsDettes p
                                 WHERE p.DetteId=d.Id
                                 ORDER BY p.DatePaiement DESC, p.Id DESC LIMIT 1), '')
                FROM Dettes d WHERE d.Reference=$r AND d.ClientNom=$n
                ORDER BY d.Id DESC LIMIT 1;
                """;
            cmd.Parameters.AddWithValue("$r", reference ?? "");
            cmd.Parameters.AddWithValue("$n", clientNom ?? "");
        }

        using var r = cmd.ExecuteReader();
        if (!r.Read()) return null;
        var remaining = Convert.ToDecimal(r.GetValue(2));
        var status = remaining <= 0 ? "Soldée" : "Non soldée";
        var settlementService = Convert.ToString(r.GetValue(4)) ?? "";
        // Le service de règlement n'est affiché comme service du rapport que
        // lorsque la dette est effectivement soldée.
        if (status != "Soldée") settlementService = "";
        return new DebtReportStatus(Convert.ToInt64(r.GetValue(0)), Convert.ToDecimal(r.GetValue(1)), remaining, status, settlementService);
    }

    // Retourne l'origine réelle de la dette. Pour un Rééquilibrage,
    // le sous-type (Vente UV / Achat UV) est stocké dans Observation de l'opération.
    // Cela permet aux rapports et au menu Dettes d'identifier précisément l'origine.
    public static string GetDebtOriginType(string observation)
    {
        const string marker = "Règlement dette ";
        var obs = observation ?? string.Empty;
        var pos = obs.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
        if (pos < 0) return "";
        var rest = obs[(pos + marker.Length)..];
        var digits = new string(rest.TakeWhile(char.IsDigit).ToArray());
        if (!long.TryParse(digits, out var debtId) || debtId <= 0) return "";

        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT o.TypeOperation, o.Observation FROM Dettes d LEFT JOIN Operations o ON o.Id=d.OperationId WHERE d.Id=$id LIMIT 1";
        cmd.Parameters.AddWithValue("$id", debtId);
        using var r = cmd.ExecuteReader();
        if (!r.Read()) return "";
        var type = Convert.ToString(r.GetValue(0)) ?? "";
        var originObs = Convert.ToString(r.GetValue(1)) ?? "";
        if (string.Equals(type, "Rééquilibrage", StringComparison.OrdinalIgnoreCase))
        {
            if (originObs.Contains("Vente UV", StringComparison.OrdinalIgnoreCase)) return "Vente UV";
            if (originObs.Contains("Achat UV", StringComparison.OrdinalIgnoreCase)) return "Achat UV";
        }
        return type;
    }

    public static string GetDebtOriginLabel(long detteId)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT o.TypeOperation, o.Observation FROM Dettes d LEFT JOIN Operations o ON o.Id=d.OperationId WHERE d.Id=$id LIMIT 1";
        cmd.Parameters.AddWithValue("$id", detteId);
        using var r = cmd.ExecuteReader();
        if (!r.Read()) return "";
        var type = Convert.ToString(r.GetValue(0)) ?? "";
        var obs = Convert.ToString(r.GetValue(1)) ?? "";
        if (string.Equals(type, "Rééquilibrage", StringComparison.OrdinalIgnoreCase))
        {
            if (obs.Contains("Vente UV", StringComparison.OrdinalIgnoreCase)) return "Rééquilibrage — Vente UV";
            if (obs.Contains("Achat UV", StringComparison.OrdinalIgnoreCase)) return "Rééquilibrage — Achat UV";
        }
        return type;
    }

    // Compatibilité avec les anciens appels.
    public static DebtReportStatus? GetDebtReportStatus(string clientNom, string reference, string observation = "")
        => GetDebtReportStatus(0, clientNom, reference, observation);

    public static int GetTodayOperations()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM Operations WHERE date(DateOperation)=date('now','localtime') AND COALESCE(Statut,'Active')='Active'";
        return Convert.ToInt32(cmd.ExecuteScalar() ?? 0);
    }


    public static void BackupDatabaseTo(string destinationPath)
    {
        if (string.IsNullOrWhiteSpace(destinationPath)) throw new ArgumentException("Destination invalide.", nameof(destinationPath));
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(destinationPath))!);
        var dest = Path.GetFullPath(destinationPath);
        if (string.Equals(dest, Path.GetFullPath(DbPath), StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("La sauvegarde doit être différente de la base active.");
        if (File.Exists(dest)) File.Delete(dest);
        var temp = dest + ".tmp";
        if (File.Exists(temp)) File.Delete(temp);
        using (var c = Open())
        {
            using var checkpoint = c.CreateCommand();
            checkpoint.CommandText = "PRAGMA wal_checkpoint(PASSIVE);";
            try { checkpoint.ExecuteNonQuery(); } catch { }
            using var cmd = c.CreateCommand();
            cmd.CommandText = "VACUUM INTO $p";
            cmd.Parameters.AddWithValue("$p", temp);
            cmd.ExecuteNonQuery();
        }
        ValidateDatabaseFile(temp);
        File.Move(temp, dest, true);
    }

    public static void ValidateDatabaseFile(string path)
    {
        if (!File.Exists(path)) throw new FileNotFoundException("Base SQLite introuvable.", path);
        using var c = new SqliteConnection($"Data Source={Path.GetFullPath(path)};Mode=ReadOnly");
        c.Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "PRAGMA integrity_check;";
        var result = Convert.ToString(cmd.ExecuteScalar()) ?? "";
        if (!string.Equals(result, "ok", StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("La vérification SQLite a échoué : " + result);
    }

    public static void OpenBackup(string backupPath)
    {
        if (string.IsNullOrWhiteSpace(backupPath))
            throw new ArgumentException("Le fichier de sauvegarde est invalide.", nameof(backupPath));

        if (!File.Exists(backupPath))
            throw new FileNotFoundException("Le fichier de sauvegarde est introuvable.", backupPath);

        var fullPath = Path.GetFullPath(backupPath);
        if (!fullPath.EndsWith(".db", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Veuillez sélectionner un fichier de base de données SQLite (.db).");

        Directory.CreateDirectory(AppFolder);

        // Vérifie que le fichier est bien une base SQLite exploitable avant remplacement.
        ValidateDatabaseFile(fullPath);

        if (string.Equals(fullPath, Path.GetFullPath(DbPath), StringComparison.OrdinalIgnoreCase))
        {
            Initialize();
            return;
        }

        // Copie atomique autant que possible : l'ancienne base est remplacée uniquement
        // après validation de la sauvegarde sélectionnée.
        var tempPath = DbPath + ".restore.tmp";
        File.Copy(fullPath, tempPath, true);
        File.Copy(tempPath, DbPath, true);
        File.Delete(tempPath);

        Initialize();
    }

    public static void ClearAllData(bool keepClients = true)
    {
        using var c = Open();
        using var tx = c.BeginTransaction();
        using var cmd = c.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = keepClients ? """
            DELETE FROM PaiementsDettes;
            DELETE FROM Dettes;
            DELETE FROM SeddoPaiements;
            DELETE FROM BoutiqueOperations;
            DELETE FROM BoutiqueSessions;
            DELETE FROM CaisseMouvements;
            DELETE FROM Operations;
            DELETE FROM Soldes;
            INSERT INTO Soldes(Service,Montant) VALUES
                ('Caisse',0),('Caisse Wave',0),('Caisse Orange Money',0),('Caisse Seddo',0),('Sama caisse',0),('Wave',0),('Orange Money',0);
            DELETE FROM sqlite_sequence WHERE name IN ('Operations','CaisseMouvements','Dettes','PaiementsDettes','SeddoPaiements','BoutiqueOperations','BoutiqueSessions');
            """ : """
            DELETE FROM PaiementsDettes;
            DELETE FROM Dettes;
            DELETE FROM SeddoPaiements;
            DELETE FROM BoutiqueOperations;
            DELETE FROM BoutiqueSessions;
            DELETE FROM CaisseMouvements;
            DELETE FROM Operations;
            DELETE FROM Clients;
            DELETE FROM Soldes;
            INSERT INTO Soldes(Service,Montant) VALUES
                ('Caisse',0),('Caisse Wave',0),('Caisse Orange Money',0),('Caisse Seddo',0),('Sama caisse',0),('Wave',0),('Orange Money',0);
            DELETE FROM sqlite_sequence WHERE name IN ('Operations','CaisseMouvements','Dettes','PaiementsDettes','SeddoPaiements','BoutiqueOperations','BoutiqueSessions','Clients');
            """;
        cmd.ExecuteNonQuery();
        tx.Commit();
    }

    public sealed record ClientRow(long Id, string Nom, string Telephone, string Note);

    public static List<ClientRow> GetClients()
    {
        var list = new List<ClientRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Id, Nom, Telephone, Note FROM Clients WHERE TRIM(COALESCE(Nom,'')) <> '' ORDER BY Nom COLLATE NOCASE;";
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            list.Add(new ClientRow(
                Convert.ToInt64(r.GetValue(0)),
                Convert.ToString(r.GetValue(1)) ?? "",
                Convert.ToString(r.GetValue(2)) ?? "",
                Convert.ToString(r.GetValue(3)) ?? ""));
        }
        return list;
    }

    public static void AddClient(string nom, string telephone, string note)
    {
        if (string.IsNullOrWhiteSpace(nom)) throw new ArgumentException("Le nom et prénom sont obligatoires.");
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "INSERT INTO Clients(Nom,Telephone,Note) VALUES($n,$t,$note);";
        cmd.Parameters.AddWithValue("$n", nom.Trim());
        cmd.Parameters.AddWithValue("$t", telephone?.Trim() ?? "");
        cmd.Parameters.AddWithValue("$note", note?.Trim() ?? "");
        cmd.ExecuteNonQuery();
    }

    public static void UpdateClient(long id, string nom, string telephone, string note)
    {
        if (id <= 0) throw new ArgumentException("Client invalide.");
        if (string.IsNullOrWhiteSpace(nom)) throw new ArgumentException("Le nom et prénom sont obligatoires.");
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "UPDATE Clients SET Nom=$n,Telephone=$t,Note=$note WHERE Id=$id";
        cmd.Parameters.AddWithValue("$n", nom.Trim());
        cmd.Parameters.AddWithValue("$t", telephone?.Trim() ?? "");
        cmd.Parameters.AddWithValue("$note", note?.Trim() ?? "");
        cmd.Parameters.AddWithValue("$id", id);
        if (cmd.ExecuteNonQuery() == 0) throw new InvalidOperationException("Client introuvable.");
    }

    public static void DeleteClient(long id)
    {
        if (id <= 0) throw new ArgumentException("Client invalide.");
        using var c = Open();
        using var tx = c.BeginTransaction();
        long operationCount;
        using (var q = c.CreateCommand())
        {
            q.Transaction = tx;
            q.CommandText = "SELECT COUNT(*) FROM Operations WHERE ClientId=$id OR ClientNom=(SELECT Nom FROM Clients WHERE Id=$id)";
            q.Parameters.AddWithValue("$id", id);
            operationCount = Convert.ToInt64(q.ExecuteScalar() ?? 0);
        }
        long debtCount;
        using (var q = c.CreateCommand())
        {
            q.Transaction = tx;
            q.CommandText = "SELECT COUNT(*) FROM Dettes WHERE ClientId=$id";
            q.Parameters.AddWithValue("$id", id);
            debtCount = Convert.ToInt64(q.ExecuteScalar() ?? 0);
        }
        if (operationCount > 0 || debtCount > 0)
            throw new InvalidOperationException("Ce client possède déjà un historique d'opérations ou une dette. Pour préserver la traçabilité, il ne peut pas être supprimé. Vous pouvez toutefois modifier ses coordonnées.");
        using var del = c.CreateCommand();
        del.Transaction = tx;
        del.CommandText = "DELETE FROM Clients WHERE Id=$id";
        del.Parameters.AddWithValue("$id", id);
        if (del.ExecuteNonQuery() == 0) throw new InvalidOperationException("Client introuvable.");
        tx.Commit();
    }

    public static void AddOperation(
        string service, string type, string client, string telephone,
        decimal montant, decimal commission, decimal dette,
        string reference, string observation)
    {
        using var c = Open();
        using var tx = c.BeginTransaction();

        long clientId;
        using (var find = c.CreateCommand())
        {
            find.Transaction = tx;
            find.CommandText = "SELECT Id FROM Clients WHERE Telephone=$t LIMIT 1";
            find.Parameters.AddWithValue("$t", telephone ?? "");
            var existing = find.ExecuteScalar();
            if (existing != null && existing != DBNull.Value)
            {
                clientId = Convert.ToInt64(existing);
                using var upd = c.CreateCommand();
                upd.Transaction = tx;
                upd.CommandText = "UPDATE Clients SET Nom=$n WHERE Id=$id";
                upd.Parameters.AddWithValue("$n", client ?? "");
                upd.Parameters.AddWithValue("$id", clientId);
                upd.ExecuteNonQuery();
            }
            else
            {
                using var ins = c.CreateCommand();
                ins.Transaction = tx;
                ins.CommandText = "INSERT INTO Clients(Nom,Telephone) VALUES($n,$t); SELECT last_insert_rowid();";
                ins.Parameters.AddWithValue("$n", client ?? "");
                ins.Parameters.AddWithValue("$t", telephone ?? "");
                clientId = Convert.ToInt64(ins.ExecuteScalar());
            }
        }

        long operationId;
        using (var op = c.CreateCommand())
        {
            op.Transaction = tx;
            op.CommandText = """
                INSERT INTO Operations
                (DateOperation,Service,TypeOperation,ClientId,ClientNom,Telephone,Montant,Commission,Dette,Reference,Observation)
                VALUES($d,$s,$ty,$cid,$n,$tel,$m,$co,$de,$r,$o)
                """;
            op.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            op.Parameters.AddWithValue("$s", service);
            op.Parameters.AddWithValue("$ty", type);
            op.Parameters.AddWithValue("$cid", clientId);
            op.Parameters.AddWithValue("$n", client ?? "");
            op.Parameters.AddWithValue("$tel", telephone ?? "");
            op.Parameters.AddWithValue("$m", montant);
            op.Parameters.AddWithValue("$co", commission);
            op.Parameters.AddWithValue("$de", dette);
            op.Parameters.AddWithValue("$r", reference ?? "");
            op.Parameters.AddWithValue("$o", observation ?? "");
            op.CommandText += "; SELECT last_insert_rowid();";
            operationId = Convert.ToInt64(op.ExecuteScalar() ?? 0);

            if (type is "Transfert" or "Envoi")
            {
                using var debt = c.CreateCommand();
                debt.Transaction = tx;
                debt.CommandText = """
                    INSERT INTO Dettes(OperationId,ClientId,Service,ClientNom,Telephone,MontantInitial,MontantRestant,DateCreation,Statut,Reference,Observation)
                    VALUES($oid,$cid,$s,$n,$tel,$d,$d,$date,'Non soldée',$r,$o)
                    """;
                debt.Parameters.AddWithValue("$oid", operationId);
                debt.Parameters.AddWithValue("$cid", clientId);
                debt.Parameters.AddWithValue("$s", service);
                debt.Parameters.AddWithValue("$n", client ?? "");
                debt.Parameters.AddWithValue("$tel", telephone ?? "");
                debt.Parameters.AddWithValue("$d", montant + commission);
                debt.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                debt.Parameters.AddWithValue("$r", reference ?? "");
                debt.Parameters.AddWithValue("$o", observation ?? "Dette créée automatiquement pour le transfert/envoi");
                debt.ExecuteNonQuery();
            }
        }

        // Comptabilité des portefeuilles et des caisses.
        // Le portefeuille Wave/Orange conserve son mouvement métier historique.
        // Règle métier SANKHÉ :
        // - Retrait : augmente le portefeuille Wave/Orange.
        // - Dépôt : diminue le portefeuille Wave/Orange.
        // - Transfert/Envoi : sort du portefeuille (dette client).
        decimal walletDelta = type switch
        {
            "Retrait" => montant,
            "Dépôt" => -montant,
            "Transfert" or "Envoi" => -montant,
            _ => 0
        };

        if (type is "Dépôt" or "Retrait" or "Transfert" or "Envoi")
        {
            using var solde = c.CreateCommand();
            solde.Transaction = tx;
            solde.CommandText = "UPDATE Soldes SET Montant=Montant+$d WHERE Service=$s";
            solde.Parameters.AddWithValue("$d", walletDelta);
            solde.Parameters.AddWithValue("$s", service);
            solde.ExecuteNonQuery();
        }

        // Comptabilité demandée pour les caisses séparées :
        // - Retrait : augmente la Caisse Wave/Orange et diminue la Caisse générale.
        // - Dépôt : diminue la Caisse Wave/Orange et augmente la Caisse générale.
        // - Transfert / Envoi : le montant est directement déduit de la caisse
        //   correspondant au service (Wave ou Orange Money). La dette reste créée
        //   et sera soldée plus tard via le menu Dettes.
        // - Rééquilibrage conserve sa logique dédiée dans AddReequilibrage().
        if ((type is "Dépôt" or "Retrait" or "Transfert" or "Envoi")
            && (service == "Wave" || service == "Orange Money"))
        {
            var caisseService = service == "Wave" ? "Caisse Wave" : "Caisse Orange Money";
            var caisseDelta = type switch
            {
                "Retrait" => montant,
                "Dépôt" => -montant,
                "Transfert" or "Envoi" => -montant,
                _ => 0
            };
            // Un Transfert/Envoi est une dette : il sort de la caisse Wave/Orange
            // mais ne doit PAS être versé dans la Caisse générale. La Caisse générale
            // n'est mouvementée que lors du remboursement en espèces/liquide.
            var mouvementGeneral = type is "Transfert" or "Envoi" ? 0 : -caisseDelta;

            // Pour Dépôt/Retrait, la contrepartie passe par la Caisse générale.
            // Pour Transfert/Envoi, aucune contrepartie générale n'est créée.
            if (mouvementGeneral != 0)
            {
                using var checkGeneral = c.CreateCommand();
                checkGeneral.Transaction = tx;
                checkGeneral.CommandText = "SELECT Montant FROM Soldes WHERE Service='Caisse'";
                var general = Convert.ToDecimal(checkGeneral.ExecuteScalar() ?? 0);
                if (general + mouvementGeneral < 0)
                    throw new InvalidOperationException("La Caisse générale ne dispose pas de suffisamment de liquidités pour cette opération.");
            }
            if (caisseDelta < 0)
            {
                using var checkCaisse = c.CreateCommand();
                checkCaisse.Transaction = tx;
                checkCaisse.CommandText = "SELECT Montant FROM Soldes WHERE Service=$s";
                checkCaisse.Parameters.AddWithValue("$s", caisseService);
                var caisse = Convert.ToDecimal(checkCaisse.ExecuteScalar() ?? 0);
                if (caisse + caisseDelta < 0)
                    throw new InvalidOperationException($"La {caisseService} ne dispose pas de suffisamment de liquidités.");
            }

            using (var updateCaisse = c.CreateCommand())
            {
                updateCaisse.Transaction = tx;
                updateCaisse.CommandText = "UPDATE Soldes SET Montant=Montant+$d WHERE Service=$s";
                updateCaisse.Parameters.AddWithValue("$d", caisseDelta);
                updateCaisse.Parameters.AddWithValue("$s", caisseService);
                if (updateCaisse.ExecuteNonQuery() == 0)
                    throw new InvalidOperationException($"La {caisseService} n'est pas disponible.");
            }

            if (mouvementGeneral != 0)
            {
                using var updateGeneral = c.CreateCommand();
                updateGeneral.Transaction = tx;
                updateGeneral.CommandText = "UPDATE Soldes SET Montant=Montant+$d WHERE Service='Caisse'";
                updateGeneral.Parameters.AddWithValue("$d", mouvementGeneral);
                if (updateGeneral.ExecuteNonQuery() == 0)
                    throw new InvalidOperationException("La Caisse générale n'est pas disponible.");
            }

            using (var mouvCaisse = c.CreateCommand())
            {
                mouvCaisse.Transaction = tx;
                mouvCaisse.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($date,$type,$m,$motif,$ref,$opid,$sc)";
                mouvCaisse.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                mouvCaisse.Parameters.AddWithValue("$type", caisseDelta >= 0 ? "Entrée" : "Sortie");
                mouvCaisse.Parameters.AddWithValue("$m", Math.Abs(caisseDelta));
                mouvCaisse.Parameters.AddWithValue("$opid", operationId);
                mouvCaisse.Parameters.AddWithValue("$motif", $"{type} — mouvement {caisseService}");
                mouvCaisse.Parameters.AddWithValue("$ref", reference ?? "");
                mouvCaisse.Parameters.AddWithValue("$sc", caisseService);
                mouvCaisse.ExecuteNonQuery();
            }

            if (mouvementGeneral != 0)
            {
                using var mouvGeneral = c.CreateCommand();
                mouvGeneral.Transaction = tx;
                mouvGeneral.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($date,$type,$m,$motif,$ref,$opid,$sc)";
                mouvGeneral.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                mouvGeneral.Parameters.AddWithValue("$type", mouvementGeneral >= 0 ? "Entrée" : "Sortie");
                mouvGeneral.Parameters.AddWithValue("$m", Math.Abs(mouvementGeneral));
                mouvGeneral.Parameters.AddWithValue("$opid", operationId);
                mouvGeneral.Parameters.AddWithValue("$motif", $"{type} — contrepartie {caisseService}");
                mouvGeneral.Parameters.AddWithValue("$ref", reference ?? "");
                mouvGeneral.Parameters.AddWithValue("$sc", "Caisse");
                mouvGeneral.ExecuteNonQuery();
            }
        }

        AuditTx(c, tx, "Opération", $"{type} — {service} — {client}", montant, reference);
        tx.Commit();
    }

    public static void AddExchangeOperation(string sourceService, string clientNom, string telephone, decimal montant, string reference = "")
    {
        if (sourceService is not ("Wave" or "Orange Money")) throw new ArgumentException("Service source invalide.");
        if (montant <= 0) throw new ArgumentException("Le montant doit être supérieur à zéro.");
        var sourceCaisse = sourceService == "Wave" ? "Caisse Wave" : "Caisse Orange Money";
        var destinationService = sourceService == "Wave" ? "Orange Money" : "Wave";
        var destinationCaisse = destinationService == "Wave" ? "Caisse Wave" : "Caisse Orange Money";
        using var c = Open(); using var tx = c.BeginTransaction();
        long clientId = 0;
        if (!string.IsNullOrWhiteSpace(telephone))
        {
            using var find = c.CreateCommand(); find.Transaction = tx;
            find.CommandText = "SELECT Id FROM Clients WHERE Telephone=$t LIMIT 1"; find.Parameters.AddWithValue("$t", telephone.Trim());
            var found = find.ExecuteScalar();
            if (found != null && found != DBNull.Value) clientId = Convert.ToInt64(found);
        }
        if (clientId == 0 && !string.IsNullOrWhiteSpace(clientNom))
        {
            using var ins = c.CreateCommand(); ins.Transaction = tx;
            ins.CommandText = "INSERT INTO Clients(Nom,Telephone) VALUES($n,$t); SELECT last_insert_rowid();";
            ins.Parameters.AddWithValue("$n", clientNom.Trim()); ins.Parameters.AddWithValue("$t", telephone?.Trim() ?? "");
            clientId = Convert.ToInt64(ins.ExecuteScalar());
        }
        using (var check = c.CreateCommand())
        {
            check.Transaction = tx; check.CommandText = "SELECT Montant FROM Soldes WHERE Service=$s"; check.Parameters.AddWithValue("$s", sourceCaisse);
            if (Convert.ToDecimal(check.ExecuteScalar() ?? 0m) < montant) throw new InvalidOperationException($"La {sourceCaisse} ne dispose pas de suffisamment de liquidités.");
        }
        using var op = c.CreateCommand(); op.Transaction = tx;
        op.CommandText = "INSERT INTO Operations(DateOperation,Service,TypeOperation,ClientId,ClientNom,Telephone,Montant,Commission,Dette,Reference,Observation) VALUES($d,$s,'Échange',$cid,$n,$tel,$m,0,0,$r,$o); SELECT last_insert_rowid();";
        op.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); op.Parameters.AddWithValue("$s", sourceService);
        op.Parameters.AddWithValue("$cid", clientId == 0 ? DBNull.Value : clientId); op.Parameters.AddWithValue("$n", clientNom?.Trim() ?? "");
        op.Parameters.AddWithValue("$tel", telephone?.Trim() ?? ""); op.Parameters.AddWithValue("$m", montant); op.Parameters.AddWithValue("$r", reference ?? "");
        op.Parameters.AddWithValue("$o", $"Échange {sourceService} vers {destinationService}");
        var opId = Convert.ToInt64(op.ExecuteScalar() ?? 0);
        foreach (var movement in new[] { (Service: sourceCaisse, Delta: -montant, Type: "Sortie"), (Service: destinationCaisse, Delta: montant, Type: "Entrée") })
        {
            using var update = c.CreateCommand(); update.Transaction = tx;
            update.CommandText = "UPDATE Soldes SET Montant=Montant+$d WHERE Service=$s"; update.Parameters.AddWithValue("$d", movement.Delta); update.Parameters.AddWithValue("$s", movement.Service);
            if (update.ExecuteNonQuery() == 0) throw new InvalidOperationException($"La {movement.Service} n'est pas disponible.");
            using var move = c.CreateCommand(); move.Transaction = tx;
            move.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($d,$t,$m,$motif,$r,$id,$s)";
            move.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); move.Parameters.AddWithValue("$t", movement.Type); move.Parameters.AddWithValue("$m", montant);
            move.Parameters.AddWithValue("$motif", $"Échange {sourceService} vers {destinationService}"); move.Parameters.AddWithValue("$r", reference ?? ""); move.Parameters.AddWithValue("$id", opId); move.Parameters.AddWithValue("$s", movement.Service); move.ExecuteNonQuery();
        }
        AuditTx(c, tx, "Échange", $"{sourceCaisse} vers {destinationCaisse} — {clientNom}", montant, reference);
        tx.Commit();
    }

    public static void AddReequilibrage(string service, string type, decimal montant, string reference, string observation = "", string clientNom = "", string telephone = "", string destinationService = "", string paymentMethod = "")
    {
        if (service is not ("Wave" or "Orange Money")) throw new ArgumentException("Service invalide.");
        if (type is not ("Vente UV" or "Achat UV")) throw new ArgumentException("Type de rééquilibrage invalide.");
        if (montant <= 0) throw new ArgumentException("Le montant doit être supérieur à zéro.");
        // Règle définitive : le Rééquilibrage n'est accessible que depuis Wave.
        // L'Achat UV est exclusivement : Caisse générale -> Caisse Wave.
        if (service != "Wave")
            throw new ArgumentException("Le Rééquilibrage est disponible uniquement sur la partie Wave.");
        if (type == "Achat UV" && destinationService != "Wave")
            throw new ArgumentException("Un Achat UV est versé uniquement dans la Caisse Wave.");
        if (type == "Vente UV" && !string.IsNullOrWhiteSpace(paymentMethod) && paymentMethod is not ("Orange Money" or "Espèces"))
            throw new ArgumentException("Pour une Vente UV payée immédiatement, le règlement est uniquement par Orange Money ou Espèces.");


        // Règles métier :
        // - ACHAT UV : sortie immédiate de la Caisse générale. Il ne crée pas de dette.
        // - VENTE UV : le montant sort immédiatement de la caisse du service concerné
        //              (Wave ou Orange Money), puis devient une dette à recouvrer.
        //              Lors de la solvabilité dans le menu Dettes, le montant est ajouté
        //              à la caisse choisie pour le remboursement.
        using var c = Open();
        using var tx = c.BeginTransaction();

        long clientId = 0;
        if (type == "Vente UV")
        {
            if (string.IsNullOrWhiteSpace(clientNom) || string.IsNullOrWhiteSpace(telephone))
                throw new ArgumentException("Pour une Vente UV, veuillez renseigner le Nom & Prénom et le Numéro du client.");

            using var find = c.CreateCommand();
            find.Transaction = tx;
            find.CommandText = "SELECT Id FROM Clients WHERE Telephone=$t LIMIT 1";
            find.Parameters.AddWithValue("$t", telephone.Trim());
            var existing = find.ExecuteScalar();
            if (existing != null && existing != DBNull.Value)
            {
                clientId = Convert.ToInt64(existing);
                using var upd = c.CreateCommand();
                upd.Transaction = tx;
                upd.CommandText = "UPDATE Clients SET Nom=$n WHERE Id=$id";
                upd.Parameters.AddWithValue("$n", clientNom.Trim());
                upd.Parameters.AddWithValue("$id", clientId);
                upd.ExecuteNonQuery();
            }
            else
            {
                using var ins = c.CreateCommand();
                ins.Transaction = tx;
                ins.CommandText = "INSERT INTO Clients(Nom,Telephone) VALUES($n,$t); SELECT last_insert_rowid();";
                ins.Parameters.AddWithValue("$n", clientNom.Trim());
                ins.Parameters.AddWithValue("$t", telephone.Trim());
                clientId = Convert.ToInt64(ins.ExecuteScalar());
            }
        }

        using var op = c.CreateCommand();
        op.Transaction = tx;
        op.CommandText = "INSERT INTO Operations(DateOperation,Service,TypeOperation,ClientId,ClientNom,Telephone,Montant,Commission,Dette,Reference,Observation) VALUES($d,$s,'Rééquilibrage',$cid,$cn,$tel,$m,0,$de,$r,$o)";
        op.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
        op.Parameters.AddWithValue("$s", service);
        op.Parameters.AddWithValue("$cid", clientId == 0 ? DBNull.Value : clientId);
        op.Parameters.AddWithValue("$cn", clientNom?.Trim() ?? "");
        op.Parameters.AddWithValue("$tel", telephone?.Trim() ?? "");
        op.Parameters.AddWithValue("$m", montant);
        op.Parameters.AddWithValue("$de", type == "Vente UV" && string.IsNullOrWhiteSpace(paymentMethod) ? montant : 0m);
        op.Parameters.AddWithValue("$r", reference ?? "");
        var rapportDescription = type == "Vente UV"
            ? (string.IsNullOrWhiteSpace(paymentMethod)
                ? "Vente UV — paiement différé (dette)"
                : $"Vente UV — réglée par {paymentMethod}")
            : "Achat UV — réglé en espèces";
        op.Parameters.AddWithValue("$o", string.IsNullOrWhiteSpace(observation) ? rapportDescription : observation);
        op.ExecuteNonQuery();

        using var idCmd = c.CreateCommand();
        idCmd.Transaction = tx;
        idCmd.CommandText = "SELECT last_insert_rowid()";
        long opId = Convert.ToInt64(idCmd.ExecuteScalar() ?? 0);

        if (type == "Achat UV")
        {
            // Achat UV : sortie de la Caisse générale puis versement immédiat
            // exclusivement dans la Caisse Wave.
            using var check = c.CreateCommand();
            check.Transaction = tx;
            check.CommandText = "SELECT Montant FROM Soldes WHERE Service='Caisse'";
            var general = Convert.ToDecimal(check.ExecuteScalar() ?? 0);
            if (general < montant)
                throw new InvalidOperationException($"La Caisse générale ne dispose pas de suffisamment de liquidités. Solde : {general:N0} FCFA.");

            using var sol = c.CreateCommand();
            sol.Transaction = tx;
            sol.CommandText = "UPDATE Soldes SET Montant=Montant-$m WHERE Service='Caisse'";
            sol.Parameters.AddWithValue("$m", montant);
            if (sol.ExecuteNonQuery() == 0)
                throw new InvalidOperationException("La Caisse générale n'est pas disponible.");

            using var mouv = c.CreateCommand();
            mouv.Transaction = tx;
            mouv.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($d,'Sortie',$m,$motif,$r,$id,'Caisse')";
            mouv.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            mouv.Parameters.AddWithValue("$m", montant);
            mouv.Parameters.AddWithValue("$motif", "Rééquilibrage — Achat UV");
            mouv.Parameters.AddWithValue("$r", reference ?? "");
            mouv.Parameters.AddWithValue("$id", opId);
            mouv.ExecuteNonQuery();

            var caisseDestination = "Caisse Wave";
            using var solDest = c.CreateCommand();
            solDest.Transaction = tx;
            solDest.CommandText = "UPDATE Soldes SET Montant=Montant+$m WHERE Service=$service";
            solDest.Parameters.AddWithValue("$m", montant);
            solDest.Parameters.AddWithValue("$service", caisseDestination);
            if (solDest.ExecuteNonQuery() == 0)
                throw new InvalidOperationException($"La {caisseDestination} n'est pas disponible.");

            using var mouvDest = c.CreateCommand();
            mouvDest.Transaction = tx;
            mouvDest.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($d,'Entrée',$m,$motif,$r,$id,$sc)";
            mouvDest.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            mouvDest.Parameters.AddWithValue("$m", montant);
            mouvDest.Parameters.AddWithValue("$motif", "Rééquilibrage — Achat UV vers Caisse Wave");
            mouvDest.Parameters.AddWithValue("$r", reference ?? "");
            mouvDest.Parameters.AddWithValue("$id", opId);
            mouvDest.Parameters.AddWithValue("$sc", caisseDestination);
            mouvDest.ExecuteNonQuery();
        }
        else
        {
            // Vente UV : le montant sort de la Caisse Wave. Si le client paie immédiatement,
            // il est aussitôt crédité dans la caisse choisie et aucune dette n'est créée.
            var caisseVente = "Caisse Wave";

            using var checkVente = c.CreateCommand();
            checkVente.Transaction = tx;
            checkVente.CommandText = "SELECT Montant FROM Soldes WHERE Service=$service";
            checkVente.Parameters.AddWithValue("$service", caisseVente);
            var soldeVente = Convert.ToDecimal(checkVente.ExecuteScalar() ?? 0m);
            if (soldeVente < montant)
                throw new InvalidOperationException($"La {caisseVente} ne dispose pas de suffisamment de liquidités. Solde : {soldeVente:N0} FCFA.");

            using var solVente = c.CreateCommand();
            solVente.Transaction = tx;
            solVente.CommandText = "UPDATE Soldes SET Montant=Montant-$m WHERE Service=$service";
            solVente.Parameters.AddWithValue("$m", montant);
            solVente.Parameters.AddWithValue("$service", caisseVente);
            if (solVente.ExecuteNonQuery() == 0)
                throw new InvalidOperationException($"La {caisseVente} n'est pas disponible.");

            using var mouvVente = c.CreateCommand();
            mouvVente.Transaction = tx;
            mouvVente.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($d,'Sortie',$m,$motif,$r,$id,$sc)";
            mouvVente.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            mouvVente.Parameters.AddWithValue("$m", montant);
            mouvVente.Parameters.AddWithValue("$motif", "Rééquilibrage — Vente UV (avance) ");
            mouvVente.Parameters.AddWithValue("$r", reference ?? "");
            mouvVente.Parameters.AddWithValue("$id", opId);
            mouvVente.Parameters.AddWithValue("$sc", caisseVente);
            mouvVente.ExecuteNonQuery();

            if (string.IsNullOrWhiteSpace(paymentMethod))
            {
                using var debt = c.CreateCommand();
                debt.Transaction = tx;
                debt.CommandText = """
                    INSERT INTO Dettes(OperationId,ClientId,Service,ClientNom,Telephone,MontantInitial,MontantRestant,DateCreation,Statut,Reference,Observation)
                    VALUES($oid,$cid,$s,$n,$tel,$m,$m,$date,'Non soldée',$r,$o)
                    """;
                debt.Parameters.AddWithValue("$oid", opId);
                debt.Parameters.AddWithValue("$cid", clientId);
                debt.Parameters.AddWithValue("$s", service);
                debt.Parameters.AddWithValue("$n", clientNom?.Trim() ?? "");
                debt.Parameters.AddWithValue("$tel", telephone?.Trim() ?? "");
                debt.Parameters.AddWithValue("$m", montant);
                debt.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                debt.Parameters.AddWithValue("$r", reference ?? "");
                debt.Parameters.AddWithValue("$o", "Dette créée automatiquement pour la Vente UV");
                debt.ExecuteNonQuery();
            }
            else
            {
                var caissePaiement = paymentMethod switch
                {
                    "Orange Money" => "Caisse Orange Money",
                    "Espèces" => "Caisse",
                    _ => throw new ArgumentException("Moyen de paiement Vente UV invalide. Choisissez Orange Money ou Espèces.")
                };
                using var solPay = c.CreateCommand();
                solPay.Transaction = tx;
                solPay.CommandText = "UPDATE Soldes SET Montant=Montant+$m WHERE Service=$service";
                solPay.Parameters.AddWithValue("$m", montant);
                solPay.Parameters.AddWithValue("$service", caissePaiement);
                if (solPay.ExecuteNonQuery() == 0)
                    throw new InvalidOperationException($"La {caissePaiement} n'est pas disponible.");

                using var movPay = c.CreateCommand();
                movPay.Transaction = tx;
                movPay.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($d,'Entrée',$m,$motif,$r,$id,$sc)";
                movPay.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                movPay.Parameters.AddWithValue("$m", montant);
                movPay.Parameters.AddWithValue("$motif", $"Rééquilibrage — Vente UV payée immédiatement ({paymentMethod})");
                movPay.Parameters.AddWithValue("$r", reference ?? "");
                movPay.Parameters.AddWithValue("$id", opId);
                movPay.Parameters.AddWithValue("$sc", caissePaiement);
                movPay.ExecuteNonQuery();
            }
        }

        AuditTx(c, tx, "Rééquilibrage", $"{type} — {service} — {clientNom}" + (string.IsNullOrWhiteSpace(paymentMethod) ? "" : $" — Payé {paymentMethod}"), montant, reference);
        tx.Commit();
    }

    public sealed record DetteRow(
        long Id, string DateCreation, string Service, string ClientNom, string Telephone,
        decimal MontantInitial, decimal MontantRestant, string Statut, string Reference, string Observation,
        string Origine);

    static string BuildDebtOriginLabel(string type, string observation)
    {
        if (string.Equals(type, "Rééquilibrage", StringComparison.OrdinalIgnoreCase))
        {
            if (observation.Contains("Vente UV", StringComparison.OrdinalIgnoreCase)) return "Rééquilibrage — Vente UV";
            if (observation.Contains("Achat UV", StringComparison.OrdinalIgnoreCase)) return "Rééquilibrage — Achat UV";
        }
        return type;
    }

    public static List<DetteRow> GetDettes(string? service = null, string? clientSearch = null, bool onlyOpen = true)
    {
        var list = new List<DetteRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT d.Id,d.DateCreation,d.Service,d.ClientNom,d.Telephone,d.MontantInitial,d.MontantRestant,d.Statut,d.Reference,d.Observation,
                   COALESCE(o.TypeOperation,''), COALESCE(o.Observation,'')
            FROM Dettes d
            LEFT JOIN Operations o ON o.Id=d.OperationId
            WHERE ($s='' OR d.Service=$s)
              AND ($open=0 OR d.MontantRestant>0)
            ORDER BY CASE WHEN d.MontantRestant>0 THEN 0 ELSE 1 END, d.DateCreation DESC, d.Id DESC;
            """;
        cmd.Parameters.AddWithValue("$s", service ?? "");
        cmd.Parameters.AddWithValue("$open", onlyOpen ? 1 : 0);
        using var r = cmd.ExecuteReader();
        var q = Normalize(clientSearch ?? "");
        while (r.Read())
        {
            var row = new DetteRow(
                Convert.ToInt64(r.GetValue(0)), Convert.ToString(r.GetValue(1)) ?? "",
                Convert.ToString(r.GetValue(2)) ?? "", Convert.ToString(r.GetValue(3)) ?? "",
                Convert.ToString(r.GetValue(4)) ?? "", Convert.ToDecimal(r.GetValue(5)),
                Convert.ToDecimal(r.GetValue(6)), Convert.ToString(r.GetValue(7)) ?? "",
                Convert.ToString(r.GetValue(8)) ?? "", Convert.ToString(r.GetValue(9)) ?? "",
                BuildDebtOriginLabel(Convert.ToString(r.GetValue(10)) ?? "", Convert.ToString(r.GetValue(11)) ?? ""));
            if (string.IsNullOrWhiteSpace(q) || Normalize(row.ClientNom).Contains(q, StringComparison.OrdinalIgnoreCase) || Normalize(row.Telephone).Contains(q, StringComparison.OrdinalIgnoreCase))
                list.Add(row);
        }
        return list;
    }

    public static void SettleDebt(long detteId, decimal montant, string moyenPaiement, string reference, string observation)
    {
        if (montant <= 0) throw new ArgumentException("Le montant doit être supérieur à zéro.");
        using var c = Open();
        using var tx = c.BeginTransaction();
        string service, client, tel, debtRef, dateCreation;
        decimal restant;
        long clientId = 0;
        using (var get = c.CreateCommand())
        {
            get.Transaction = tx;
            get.CommandText = "SELECT Service,ClientId,ClientNom,Telephone,MontantRestant,Reference,DateCreation FROM Dettes WHERE Id=$id";
            get.Parameters.AddWithValue("$id", detteId);
            using var r = get.ExecuteReader();
            if (!r.Read()) throw new InvalidOperationException("Dette introuvable.");
            service = Convert.ToString(r.GetValue(0)) ?? "";
            clientId = r.IsDBNull(1) ? 0 : Convert.ToInt64(r.GetValue(1));
            client = Convert.ToString(r.GetValue(2)) ?? "";
            tel = Convert.ToString(r.GetValue(3)) ?? "";
            restant = Convert.ToDecimal(r.GetValue(4));
            debtRef = Convert.ToString(r.GetValue(5)) ?? "";
            dateCreation = Convert.ToString(r.GetValue(6)) ?? "";
        }
        var detteAnterieure = !string.IsNullOrWhiteSpace(dateCreation) && string.Compare(dateCreation.Substring(0, Math.Min(10, dateCreation.Length)), DateTime.Now.ToString("yyyy-MM-dd"), StringComparison.Ordinal) < 0;
        if (montant > restant) throw new InvalidOperationException($"Le montant à solder ne peut pas dépasser {restant:N0} FCFA.");

        // La Caisse Seddo est volontairement EXCLUE du remboursement des dettes.
        // Une dette peut uniquement être solvabilisée par Wave, Orange Money
        // ou la Caisse générale.
        if (string.Equals(moyenPaiement?.Trim(), "Caisse Seddo", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("La Caisse Seddo ne peut pas être utilisée pour solder une dette. Choisissez Caisse Wave, Caisse Orange Money ou Caisse générale.");

        var nouveau = restant - montant;
        using (var pay = c.CreateCommand())
        {
            pay.Transaction = tx;
            pay.CommandText = "INSERT INTO PaiementsDettes(DetteId,DatePaiement,Montant,MoyenPaiement,Reference,Observation,OperationId) VALUES($d,$date,$m,$mp,$r,$o,NULL)";
            pay.Parameters.AddWithValue("$d", detteId);
            pay.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            pay.Parameters.AddWithValue("$m", montant);
            pay.Parameters.AddWithValue("$mp", moyenPaiement);
            pay.Parameters.AddWithValue("$r", reference ?? "");
            pay.Parameters.AddWithValue("$o", observation ?? "");
            pay.ExecuteNonQuery();
        }
        using (var upd = c.CreateCommand())
        {
            upd.Transaction = tx;
            upd.CommandText = "UPDATE Dettes SET MontantRestant=$rest,Statut=$statut,DateSolde=CASE WHEN $rest<=0 THEN $date ELSE DateSolde END WHERE Id=$id";
            upd.Parameters.AddWithValue("$rest", nouveau);
            upd.Parameters.AddWithValue("$statut", nouveau <= 0 ? "Soldée" : "Partiellement soldée");
            upd.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            upd.Parameters.AddWithValue("$id", detteId);
            upd.ExecuteNonQuery();
        }

        // Tous les moyens de règlement qui représentent une caisse doivent
        // réellement créditer la caisse choisie. L'interface utilise
        // "Caisse en espèce" pour la caisse générale.
        var caisseService = moyenPaiement switch
        {
            "Caisse Wave" => "Caisse Wave",
            "Caisse Orange Money" => "Caisse Orange Money",
            "Caisse générale" => "Caisse",
            "Caisse en espèce" => "Caisse",
            // Compatibilité avec les anciennes données utilisant simplement "Caisse".
            "Caisse" => "Caisse",
            _ => ""
        };
        var isCaisse = !string.IsNullOrWhiteSpace(caisseService);
        long repaymentOperationId;
        using (var op = c.CreateCommand())
        {
            op.Transaction = tx;
            op.CommandText = """
                INSERT INTO Operations(DateOperation,Service,TypeOperation,ClientId,ClientNom,Telephone,Montant,Commission,Dette,Reference,Observation)
                VALUES($date,$service,'Remboursement dette',$cid,$client,$tel,$m,0,0,$ref,$obs)
                """;
            op.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            op.Parameters.AddWithValue("$service", service);
            op.Parameters.AddWithValue("$cid", clientId == 0 ? DBNull.Value : clientId);
            op.Parameters.AddWithValue("$client", client);
            op.Parameters.AddWithValue("$tel", tel);
            op.Parameters.AddWithValue("$m", montant);
            op.Parameters.AddWithValue("$ref", string.IsNullOrWhiteSpace(reference) ? debtRef : reference);
            op.Parameters.AddWithValue("$obs", $"Règlement dette {detteId} — Moyen : {moyenPaiement} — {observation}");
            op.CommandText += "; SELECT last_insert_rowid();";
            repaymentOperationId = Convert.ToInt64(op.ExecuteScalar() ?? 0);
        }
        using (var linkPay = c.CreateCommand())
        {
            linkPay.Transaction = tx;
            linkPay.CommandText = "UPDATE PaiementsDettes SET OperationId=$op WHERE Id=(SELECT Id FROM PaiementsDettes WHERE DetteId=$d ORDER BY Id DESC LIMIT 1)";
            linkPay.Parameters.AddWithValue("$op", repaymentOperationId);
            linkPay.Parameters.AddWithValue("$d", detteId);
            linkPay.ExecuteNonQuery();
        }

        if (isCaisse)
        {
            // Un remboursement de dette est une ENTRÉE dans la caisse réellement choisie.
            // Contrairement au transfert initial, aucune caisse n'est mouvementée avant cet encaissement.
            using var check = c.CreateCommand();
            check.Transaction = tx;
            check.CommandText = "SELECT Montant FROM Soldes WHERE Service=$s";
            check.Parameters.AddWithValue("$s", caisseService);
            var exists = check.ExecuteScalar();
            if (exists == null || exists == DBNull.Value)
                throw new InvalidOperationException($"{caisseService} n'est pas disponible.");

            using var solde = c.CreateCommand();
            solde.Transaction = tx;
            solde.CommandText = "UPDATE Soldes SET Montant=Montant+$m WHERE Service=$s";
            solde.Parameters.AddWithValue("$m", montant);
            solde.Parameters.AddWithValue("$s", caisseService);
            solde.ExecuteNonQuery();

            using var mouv = c.CreateCommand();
            mouv.Transaction = tx;
            mouv.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($date,'Entrée',$m,$motif,$ref,$opid,$sc)";
            mouv.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            mouv.Parameters.AddWithValue("$m", montant);
            mouv.Parameters.AddWithValue("$motif", detteAnterieure
                ? $"Règlement dette ancienne hors caisse journalière {detteId} — {client}"
                : $"Règlement dette {detteId} — {client}");
            mouv.Parameters.AddWithValue("$ref", string.IsNullOrWhiteSpace(reference) ? debtRef : reference);
            mouv.Parameters.AddWithValue("$opid", repaymentOperationId);
            mouv.Parameters.AddWithValue("$sc", caisseService);
            mouv.ExecuteNonQuery();
        }
        AuditTx(c, tx, "Remboursement dette", $"Dette {detteId} — {client} — {moyenPaiement}", montant, string.IsNullOrWhiteSpace(reference) ? debtRef : reference);
        tx.Commit();
    }

    public sealed record CaisseJournaliereMouvementRow(string Heure, string Type, decimal Montant, string Motif, string Reference, string OperationType, long OperationId);
    public sealed record CaisseJournaliereSummary(string ServiceCaisse, decimal SoldeDebut, decimal Entrees, decimal Sorties, decimal SoldeTheorique, decimal SoldeActuel, decimal Ecart, bool Cloturee, decimal MontantVerifie);

    public static List<CaisseJournaliereSummary> GetCaisseJournaliereSummaries(DateTime date)
    {
        var start = date.Date.ToString("yyyy-MM-dd HH:mm:ss");
        var end = date.Date.AddDays(1).ToString("yyyy-MM-dd HH:mm:ss");
        var day = date.ToString("yyyy-MM-dd");
        var result = new List<CaisseJournaliereSummary>();
        // Une seule connexion pour les trois caisses, et intervalle de dates indexable.
        using var c = Open();
        foreach (var service in new[] { "Caisse Wave", "Caisse Orange Money", "Caisse" })
        {
            decimal entrees = 0, sorties = 0;
            using (var q = c.CreateCommand())
            {
                q.CommandText = "SELECT COALESCE(SUM(CASE WHEN TypeMouvement IN ('Solde initial','Entrée') THEN Montant ELSE 0 END),0), COALESCE(SUM(CASE WHEN TypeMouvement='Sortie' THEN Montant ELSE 0 END),0) FROM CaisseMouvements WHERE DateMouvement >= $start AND DateMouvement < $end AND ServiceCaisse=$s AND COALESCE(Motif,'') NOT LIKE 'Règlement dette ancienne hors caisse journalière%'";
                q.Parameters.AddWithValue("$start", start); q.Parameters.AddWithValue("$end", end); q.Parameters.AddWithValue("$s", service);
                using var r = q.ExecuteReader(); if (r.Read()) { entrees = Convert.ToDecimal(r.GetValue(0)); sorties = Convert.ToDecimal(r.GetValue(1)); }
            }
            // La caisse journalière est un compteur indépendant : elle repart de zéro
            // chaque jour. Le solde réel de la caisse (current) reste inchangé.
            var net = entrees - sorties;
            decimal debut = 0m;
            var theorique = net;
            var soldeJournalierActuel = net;
            decimal verifie = 0; bool cloturee = false;
            using (var q = c.CreateCommand())
            {
                q.CommandText = "SELECT MontantVerifie FROM CaisseJournaliereClotures WHERE DateJour=$d AND ServiceCaisse=$s LIMIT 1";
                q.Parameters.AddWithValue("$d", day); q.Parameters.AddWithValue("$s", service);
                var v = q.ExecuteScalar(); if (v != null && v != DBNull.Value) { verifie = Convert.ToDecimal(v); cloturee = true; }
            }
            result.Add(new CaisseJournaliereSummary(service, debut, entrees, sorties, theorique, soldeJournalierActuel, cloturee ? verifie - theorique : 0, cloturee, verifie));
        }
        return result;
    }

    public static List<CaisseJournaliereMouvementRow> GetCaisseJournaliereMouvements(DateTime date, string serviceCaisse, int limit = 300)
    {
        var list = new List<CaisseJournaliereMouvementRow>();
        using var c = Open(); using var cmd = c.CreateCommand();
        var start = date.Date.ToString("yyyy-MM-dd HH:mm:ss");
        var end = date.Date.AddDays(1).ToString("yyyy-MM-dd HH:mm:ss");
        cmd.CommandText = """
            SELECT substr(m.DateMouvement,12,8), m.TypeMouvement, m.Montant, COALESCE(m.Motif,''), COALESCE(m.Reference,''), COALESCE(o.TypeOperation,''), COALESCE(m.OperationId,0)
            FROM CaisseMouvements m LEFT JOIN Operations o ON o.Id=m.OperationId
            WHERE m.DateMouvement >= $start AND m.DateMouvement < $end AND m.ServiceCaisse=$s
              AND COALESCE(m.Motif,'') NOT LIKE 'Règlement dette ancienne hors caisse journalière%'
            ORDER BY m.Id DESC LIMIT $n
            """;
        cmd.Parameters.AddWithValue("$start", start); cmd.Parameters.AddWithValue("$end", end); cmd.Parameters.AddWithValue("$s", serviceCaisse); cmd.Parameters.AddWithValue("$n", Math.Clamp(limit,1,2000));
        using var r = cmd.ExecuteReader();
        while(r.Read()) list.Add(new CaisseJournaliereMouvementRow(Convert.ToString(r.GetValue(0)) ?? "", Convert.ToString(r.GetValue(1)) ?? "", Convert.ToDecimal(r.GetValue(2)), Convert.ToString(r.GetValue(3)) ?? "", Convert.ToString(r.GetValue(4)) ?? "", Convert.ToString(r.GetValue(5)) ?? "", Convert.ToInt64(r.GetValue(6))));
        return list;
    }

    public static void CloturerCaisseJournaliere(DateTime date, string serviceCaisse, decimal montantVerifie, string observation = "")
    {
        if (montantVerifie < 0) throw new ArgumentException("Le montant vérifié ne peut pas être négatif.");
        var day = date.ToString("yyyy-MM-dd");
        var summary = GetCaisseJournaliereSummaries(date).First(x => x.ServiceCaisse == serviceCaisse);
        using var c = Open(); using var tx = c.BeginTransaction();
        using var cmd = c.CreateCommand(); cmd.Transaction = tx;
        cmd.CommandText = """
            INSERT INTO CaisseJournaliereClotures(DateJour,ServiceCaisse,MontantTheorique,MontantVerifie,Ecart,DateCloture,Observation)
            VALUES($d,$s,$t,$v,$e,$now,$o)
            ON CONFLICT(DateJour,ServiceCaisse) DO UPDATE SET MontantTheorique=excluded.MontantTheorique,MontantVerifie=excluded.MontantVerifie,Ecart=excluded.Ecart,DateCloture=excluded.DateCloture,Observation=excluded.Observation
            """;
        cmd.Parameters.AddWithValue("$d", day); cmd.Parameters.AddWithValue("$s", serviceCaisse); cmd.Parameters.AddWithValue("$t", summary.SoldeTheorique); cmd.Parameters.AddWithValue("$v", montantVerifie); cmd.Parameters.AddWithValue("$e", montantVerifie-summary.SoldeTheorique); cmd.Parameters.AddWithValue("$now", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); cmd.Parameters.AddWithValue("$o", observation ?? ""); cmd.ExecuteNonQuery();
        AuditTx(c, tx, "Clôture caisse journalière", $"{serviceCaisse} — {day}", montantVerifie, observation);
        tx.Commit();
    }

    public sealed record CaisseRow(string DateMouvement, string TypeMouvement, decimal Montant, string Motif, string Reference, string ServiceCaisse);

    public static decimal GetCaisseSolde() => GetSolde("Caisse");
    public static decimal GetCaisseSolde(string serviceCaisse) => GetSolde(serviceCaisse);

    public static (decimal Initial, decimal Entrees, decimal Sorties, decimal Solde) GetCaisseSummary(DateTime date, string serviceCaisse = "Caisse")
    {
        using var c = Open();
        var start = date.Date.ToString("yyyy-MM-dd HH:mm:ss");
        var end = date.Date.AddDays(1).ToString("yyyy-MM-dd HH:mm:ss");
        decimal initial = 0, entrees = 0, sorties = 0;
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT COALESCE(SUM(CASE WHEN TypeMouvement='Solde initial' THEN Montant ELSE 0 END),0), COALESCE(SUM(CASE WHEN TypeMouvement='Entrée' THEN Montant ELSE 0 END),0), COALESCE(SUM(CASE WHEN TypeMouvement='Sortie' THEN Montant ELSE 0 END),0) FROM CaisseMouvements WHERE DateMouvement >= $start AND DateMouvement < $end AND ServiceCaisse=$s AND COALESCE(Motif,'') NOT LIKE 'Règlement dette ancienne hors caisse journalière%'";
        cmd.Parameters.AddWithValue("$start", start);
        cmd.Parameters.AddWithValue("$end", end);
        cmd.Parameters.AddWithValue("$s", serviceCaisse);
        using var r = cmd.ExecuteReader();
        if (r.Read()) { initial = Convert.ToDecimal(r.GetValue(0)); entrees = Convert.ToDecimal(r.GetValue(1)); sorties = Convert.ToDecimal(r.GetValue(2)); }
        return (initial, entrees, sorties, GetCaisseSolde(serviceCaisse));
    }

    public static (decimal Entrees, decimal Sorties) GetCaisseGeneralSummary()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT COALESCE(SUM(CASE WHEN TypeMouvement IN ('Solde initial','Entrée') THEN Montant ELSE 0 END),0), COALESCE(SUM(CASE WHEN TypeMouvement='Sortie' THEN Montant ELSE 0 END),0) FROM CaisseMouvements WHERE ServiceCaisse='Caisse'";
        using var r = cmd.ExecuteReader();
        if (!r.Read()) return (0, 0);
        return (Convert.ToDecimal(r.GetValue(0)), Convert.ToDecimal(r.GetValue(1)));
    }

    public static decimal GetCaisseOpeningToday(string serviceCaisse = "Caisse")
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT COALESCE(SUM(Montant),0) FROM CaisseMouvements WHERE substr(DateMouvement,1,10)=$d AND TypeMouvement='Solde initial' AND ServiceCaisse=$s";
        cmd.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd"));
        cmd.Parameters.AddWithValue("$s", serviceCaisse);
        return Convert.ToDecimal(cmd.ExecuteScalar() ?? 0);
    }

    public static void SetCaisseOpening(decimal montant, string observation, string serviceCaisse = "Caisse")
    {
        if (montant < 0) throw new ArgumentException("Le solde de départ ne peut pas être négatif.");
        serviceCaisse = NormalizeCaisseService(serviceCaisse);
        using var c = Open();
        using var tx = c.BeginTransaction();
        EnsureCaisseExists(c, tx, serviceCaisse);
        var day = DateTime.Now.ToString("yyyy-MM-dd");
        decimal ancien = 0;
        long? openingId = null;
        using (var find = c.CreateCommand())
        {
            find.Transaction = tx;
            find.CommandText = "SELECT Id, Montant FROM CaisseMouvements WHERE substr(DateMouvement,1,10)=$d AND TypeMouvement='Solde initial' AND ServiceCaisse=$s ORDER BY Id DESC LIMIT 1";
            find.Parameters.AddWithValue("$d", day);
            find.Parameters.AddWithValue("$s", serviceCaisse);
            using var r = find.ExecuteReader();
            if (r.Read()) { openingId = r.GetInt64(0); ancien = Convert.ToDecimal(r.GetValue(1)); }
        }
        var delta = montant - ancien;
        using (var check = c.CreateCommand())
        {
            check.Transaction = tx;
            check.CommandText = "SELECT COALESCE(Montant,0) FROM Soldes WHERE Service=$s";
            check.Parameters.AddWithValue("$s", serviceCaisse);
            var current = Convert.ToDecimal(check.ExecuteScalar() ?? 0);
            if (current + delta < 0) throw new InvalidOperationException($"Cette modification rendrait la {serviceCaisse} négative.");
        }
        if (openingId.HasValue)
        {
            using var update = c.CreateCommand();
            update.Transaction = tx;
            update.CommandText = "UPDATE CaisseMouvements SET Montant=$m, Motif=$motif WHERE Id=$id";
            update.Parameters.AddWithValue("$m", montant);
            update.Parameters.AddWithValue("$motif", string.IsNullOrWhiteSpace(observation) ? "Solde de départ de la journée" : observation);
            update.Parameters.AddWithValue("$id", openingId.Value);
            if (update.ExecuteNonQuery() != 1) throw new InvalidOperationException("Le solde de départ n’a pas été modifié.");
        }
        else
        {
            using var add = c.CreateCommand();
            add.Transaction = tx;
            add.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,ServiceCaisse) VALUES($date,'Solde initial',$m,$motif,'',$s)";
            add.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            add.Parameters.AddWithValue("$m", montant);
            add.Parameters.AddWithValue("$motif", string.IsNullOrWhiteSpace(observation) ? "Solde de départ de la journée" : observation);
            add.Parameters.AddWithValue("$s", serviceCaisse);
            if (add.ExecuteNonQuery() != 1) throw new InvalidOperationException("Le solde de départ n’a pas été enregistré.");
        }
        using (var solde = c.CreateCommand())
        {
            solde.Transaction = tx;
            solde.CommandText = "UPDATE Soldes SET Montant=Montant+$delta WHERE Service=$s";
            solde.Parameters.AddWithValue("$delta", delta);
            solde.Parameters.AddWithValue("$s", serviceCaisse);
            if (solde.ExecuteNonQuery() != 1) throw new InvalidOperationException($"Le solde de {serviceCaisse} n’a pas été mis à jour. La modification est annulée.");
        }
        tx.Commit();
    }

    static string HashPassword(string password)
    {
        using var sha = SHA256.Create();
        var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password ?? string.Empty));
        return Convert.ToHexString(bytes);
    }

    public static bool HasAccessPassword()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Value FROM AppSettings WHERE Key='AccessPasswordHash' LIMIT 1";
        var value = Convert.ToString(cmd.ExecuteScalar()) ?? "";
        return !string.IsNullOrWhiteSpace(value);
    }

    public static void EnsureDefaultAccessPassword()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Value FROM AppSettings WHERE Key='AccessPasswordHash' LIMIT 1";
        var value = Convert.ToString(cmd.ExecuteScalar()) ?? "";
        if (!string.IsNullOrWhiteSpace(value)) return;
        using var set = c.CreateCommand();
        set.CommandText = "UPDATE AppSettings SET Value=$v WHERE Key='AccessPasswordHash'";
        set.Parameters.AddWithValue("$v", HashPassword("1234"));
        set.ExecuteNonQuery();
    }

    public static bool VerifyAccessPassword(string password)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Value FROM AppSettings WHERE Key='AccessPasswordHash' LIMIT 1";
        var stored = Convert.ToString(cmd.ExecuteScalar()) ?? "";
        if (string.IsNullOrWhiteSpace(stored)) return false;
        var incoming = HashPassword(password);
        return string.Equals(stored, incoming, StringComparison.OrdinalIgnoreCase);
    }

    public static void ChangeAccessPassword(string currentPassword, string newPassword)
    {
        if (!VerifyAccessPassword(currentPassword))
            throw new InvalidOperationException("L'ancien mot de passe est incorrect.");
        if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 4)
            throw new ArgumentException("Le nouveau mot de passe doit contenir au moins 4 caractères.");
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "UPDATE AppSettings SET Value=$v WHERE Key='AccessPasswordHash'";
        cmd.Parameters.AddWithValue("$v", HashPassword(newPassword));
        cmd.ExecuteNonQuery();
    }

    public static string GetSetting(string key, string fallback = "")
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Value FROM AppSettings WHERE Key=$k LIMIT 1";
        cmd.Parameters.AddWithValue("$k", key);
        return Convert.ToString(cmd.ExecuteScalar()) ?? fallback;
    }

    public static decimal GetSettingDecimal(string key, decimal fallback)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Value FROM AppSettings WHERE Key=$k LIMIT 1";
        cmd.Parameters.AddWithValue("$k", key);
        var value = Convert.ToString(cmd.ExecuteScalar());
        return decimal.TryParse(value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var result)
            ? result : fallback;
    }

    public static void SetSetting(string key, string value)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "INSERT INTO AppSettings(Key,Value) VALUES($k,$v) ON CONFLICT(Key) DO UPDATE SET Value=excluded.Value";
        cmd.Parameters.AddWithValue("$k", key);
        cmd.Parameters.AddWithValue("$v", value ?? "");
        cmd.ExecuteNonQuery();
    }

    public static decimal AddSeddoOperation(string client, string telephone, decimal montant, decimal tauxCommission, string reference, string observation, bool paiementDiffere = false, string servicePaiement = "Caisse Seddo")
    {
        if (montant <= 0) throw new ArgumentException("Le montant doit être supérieur à zéro.");
        if (tauxCommission < 0) throw new ArgumentException("Le taux de commission ne peut pas être négatif.");
        var commission = Math.Round(montant * tauxCommission / 100m, 0, MidpointRounding.AwayFromZero);
        var totalDebite = montant + commission;

        using var c = Open();
        using var tx = c.BeginTransaction();

        // V191 CORRECTION : même en paiement différé, Seddo avance immédiatement
        // le montant au client. La Caisse Seddo doit donc être débitée dès la création.
        // Le paiement différé concerne uniquement l'encaissement du client, qui sera
        // crédité dans la caisse choisie au moment du règlement.
        {
            using var check = c.CreateCommand();
            check.Transaction = tx;
            check.CommandText = "SELECT Montant FROM Soldes WHERE Service='Caisse Seddo'";
            var current = Convert.ToDecimal(check.ExecuteScalar() ?? 0);
            if (current < totalDebite)
                throw new InvalidOperationException($"La Caisse Seddo ne dispose pas de suffisamment de liquidités. Solde : {current:N0} FCFA, nécessaire : {totalDebite:N0} FCFA.");
        }

        long clientId;
        using (var find = c.CreateCommand())
        {
            find.Transaction = tx;
            find.CommandText = "SELECT Id FROM Clients WHERE Telephone=$t LIMIT 1";
            find.Parameters.AddWithValue("$t", telephone ?? "");
            var existing = find.ExecuteScalar();
            if (existing != null && existing != DBNull.Value)
            {
                clientId = Convert.ToInt64(existing);
                using var upd = c.CreateCommand();
                upd.Transaction = tx;
                upd.CommandText = "UPDATE Clients SET Nom=$n WHERE Id=$id";
                upd.Parameters.AddWithValue("$n", client ?? "");
                upd.Parameters.AddWithValue("$id", clientId);
                upd.ExecuteNonQuery();
            }
            else
            {
                using var ins = c.CreateCommand();
                ins.Transaction = tx;
                ins.CommandText = "INSERT INTO Clients(Nom,Telephone) VALUES($n,$t); SELECT last_insert_rowid();";
                ins.Parameters.AddWithValue("$n", client ?? "");
                ins.Parameters.AddWithValue("$t", telephone ?? "");
                clientId = Convert.ToInt64(ins.ExecuteScalar());
            }
        }

        var now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        var desc = string.IsNullOrWhiteSpace(observation) ? $"Opération Seddo — commission {tauxCommission:0.##}%" : observation.Trim();
        using (var op = c.CreateCommand())
        {
            op.Transaction = tx;
            op.CommandText = "INSERT INTO Operations(DateOperation,Service,TypeOperation,ClientId,ClientNom,Telephone,Montant,Commission,Dette,Reference,Observation,PaiementDiffere) VALUES($d,'Seddo','Seddo',$cid,$n,$tel,$m,$co,0,$r,$o,$pd)";
            op.Parameters.AddWithValue("$d", now);
            op.Parameters.AddWithValue("$cid", clientId);
            op.Parameters.AddWithValue("$n", client ?? "");
            op.Parameters.AddWithValue("$tel", telephone ?? "");
            op.Parameters.AddWithValue("$m", montant);
            op.Parameters.AddWithValue("$co", commission);
            op.Parameters.AddWithValue("$r", reference ?? "");
            op.Parameters.AddWithValue("$o", desc);
            op.Parameters.AddWithValue("$pd", paiementDiffere ? 1 : 0);
            op.ExecuteNonQuery();
        }
        long operationId;
        using (var last = c.CreateCommand()) { last.Transaction = tx; last.CommandText = "SELECT last_insert_rowid();"; operationId = Convert.ToInt64(last.ExecuteScalar()); }

        {
            using (var mov = c.CreateCommand())
            {
                mov.Transaction = tx;
                mov.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($d,'Sortie',$m,$motif,$r,$id,'Caisse Seddo')";
                mov.Parameters.AddWithValue("$d", now);
                mov.Parameters.AddWithValue("$m", totalDebite);
                mov.Parameters.AddWithValue("$motif", $"Opération Seddo — client {client} — commission {tauxCommission:0.##}%");
                mov.Parameters.AddWithValue("$r", reference ?? "");
                mov.Parameters.AddWithValue("$id", operationId);
                mov.ExecuteNonQuery();
            }

            using (var solde = c.CreateCommand())
            {
                solde.Transaction = tx;
                solde.CommandText = "UPDATE Soldes SET Montant=Montant-$m WHERE Service='Caisse Seddo'";
                solde.Parameters.AddWithValue("$m", totalDebite);
                solde.ExecuteNonQuery();
            }
        }

        // En paiement différé, aucun encaissement client n'est crédité maintenant.
        // Le crédit sera effectué par AddSeddoPayment au moment du règlement.
        if (!paiementDiffere)
        {
            var caissePaiement = NormalizeSeddoPaymentService(servicePaiement);
            using (var movPay = c.CreateCommand())
            {
                movPay.Transaction = tx;
                movPay.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($d,'Entrée',$m,$motif,$r,$id,$s)";
                movPay.Parameters.AddWithValue("$d", now);
                movPay.Parameters.AddWithValue("$m", totalDebite);
                movPay.Parameters.AddWithValue("$motif", $"Encaissement Seddo — client {client} — {caissePaiement}");
                movPay.Parameters.AddWithValue("$r", reference ?? "");
                movPay.Parameters.AddWithValue("$id", operationId);
                movPay.Parameters.AddWithValue("$s", caissePaiement);
                movPay.ExecuteNonQuery();
            }
            using (var soldePay = c.CreateCommand())
            {
                soldePay.Transaction = tx;
                soldePay.CommandText = "UPDATE Soldes SET Montant=Montant+$m WHERE Service=$s";
                soldePay.Parameters.AddWithValue("$m", totalDebite);
                soldePay.Parameters.AddWithValue("$s", caissePaiement);
                soldePay.ExecuteNonQuery();
            }
        }
        AuditTx(c, tx, "Seddo", $"{client} — {servicePaiement} — {(paiementDiffere ? "Paiement différé" : "Payé")}", totalDebite, reference);
        tx.Commit();
        return commission;
    }

    static string NormalizeSeddoPaymentService(string service)
    {
        if (string.Equals(service, "Wave", StringComparison.OrdinalIgnoreCase) || string.Equals(service, "Caisse Wave", StringComparison.OrdinalIgnoreCase)) return "Caisse Wave";
        if (string.Equals(service, "Orange Money", StringComparison.OrdinalIgnoreCase) || string.Equals(service, "Caisse Orange Money", StringComparison.OrdinalIgnoreCase)) return "Caisse Orange Money";
        if (string.Equals(service, "Espèces", StringComparison.OrdinalIgnoreCase) || string.Equals(service, "Especes", StringComparison.OrdinalIgnoreCase) || string.Equals(service, "Caisse générale", StringComparison.OrdinalIgnoreCase)) return "Caisse";
        return "Caisse Seddo";
    }

    public sealed record SeddoOperationRow(long Id, string DateOperation, string ClientNom, string Telephone, decimal Montant, decimal Commission, decimal TauxCommission, string Reference, string Observation, bool PaiementDiffere, decimal MontantEncaisse, decimal Reste);

    public sealed record SeddoReportRow(
        long Id, string DateOperation, string ClientNom, string Telephone,
        decimal Montant, decimal Commission, decimal Total,
        decimal CaisseWave, decimal CaisseOrange, decimal CaisseGenerale,
        decimal CaisseSeddoSortie, string CaissesDescription,
        string Reference, string Statut, decimal Restant, string Description);

    public static List<SeddoReportRow> GetSeddoReport(DateTime start, DateTime endExclusive)
    {
        var list = new List<SeddoReportRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT o.Id,o.DateOperation,o.ClientNom,o.Telephone,o.Montant,o.Commission,
                   (o.Montant+o.Commission),o.Reference,o.Observation,o.PaiementDiffere,
                   COALESCE(SUM(CASE WHEN cm.TypeMouvement='Entrée' AND cm.ServiceCaisse='Caisse Wave' THEN cm.Montant ELSE 0 END),0),
                   COALESCE(SUM(CASE WHEN cm.TypeMouvement='Entrée' AND cm.ServiceCaisse='Caisse Orange Money' THEN cm.Montant ELSE 0 END),0),
                   COALESCE(SUM(CASE WHEN cm.TypeMouvement='Entrée' AND cm.ServiceCaisse='Caisse' THEN cm.Montant ELSE 0 END),0),
                   COALESCE(SUM(CASE WHEN cm.TypeMouvement='Sortie' AND cm.ServiceCaisse='Caisse Seddo' THEN cm.Montant ELSE 0 END),0),
                   COALESCE(SUM(CASE WHEN cm.TypeMouvement='Entrée' THEN cm.Montant ELSE 0 END),0)
            FROM Operations o
            LEFT JOIN CaisseMouvements cm ON cm.OperationId=o.Id
            WHERE o.Service='Seddo' AND o.DateOperation >= $start AND o.DateOperation < $end
            GROUP BY o.Id,o.DateOperation,o.ClientNom,o.Telephone,o.Montant,o.Commission,o.Reference,o.Observation,o.PaiementDiffere
            ORDER BY o.DateOperation ASC,o.Id ASC;
            """;
        cmd.Parameters.AddWithValue("$start", start.ToString("yyyy-MM-dd HH:mm:ss"));
        cmd.Parameters.AddWithValue("$end", endExclusive.ToString("yyyy-MM-dd HH:mm:ss"));
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            var montant = Convert.ToDecimal(r.GetValue(4));
            var commission = Convert.ToDecimal(r.GetValue(5));
            var total = Convert.ToDecimal(r.GetValue(6));
            var wave = Convert.ToDecimal(r.GetValue(10));
            var orange = Convert.ToDecimal(r.GetValue(11));
            var general = Convert.ToDecimal(r.GetValue(12));
            var seddoSortie = Convert.ToDecimal(r.GetValue(13));
            var encaisse = Convert.ToDecimal(r.GetValue(14));
            var differe = Convert.ToInt32(r.GetValue(9)) == 1;
            var restant = differe ? Math.Max(0, total - encaisse) : 0;
            var statut = differe ? (restant > 0 ? "À encaisser" : "Payé") : "Payé";
            var destinations = new List<string>();
            if (wave > 0) destinations.Add($"Caisse Wave : {wave:N0} FCFA");
            if (orange > 0) destinations.Add($"Caisse Orange Money : {orange:N0} FCFA");
            if (general > 0) destinations.Add($"Caisse générale : {general:N0} FCFA");
            var caisseDesc = destinations.Count == 0
                ? (differe ? "Aucun encaissement — paiement à encaisser" : "Aucun dépôt de paiement enregistré")
                : "Argent déposé dans : " + string.Join(" • ", destinations);
            var observation = Convert.ToString(r.GetValue(8)) ?? "";
            var description = string.IsNullOrWhiteSpace(observation) ? "Opération Seddo" : observation;
            list.Add(new SeddoReportRow(
                Convert.ToInt64(r.GetValue(0)), Convert.ToString(r.GetValue(1)) ?? "", Convert.ToString(r.GetValue(2)) ?? "",
                Convert.ToString(r.GetValue(3)) ?? "", montant, commission, total, wave, orange, general, seddoSortie,
                caisseDesc, Convert.ToString(r.GetValue(7)) ?? "", statut, restant, description));
        }
        return list;
    }

    public static string GetSeddoCaisseDescription(long operationId)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT ServiceCaisse, SUM(Montant)
            FROM CaisseMouvements
            WHERE OperationId=$id AND TypeMouvement='Entrée'
              AND ServiceCaisse IN ('Caisse Wave','Caisse Orange Money','Caisse')
            GROUP BY ServiceCaisse ORDER BY ServiceCaisse;
            """;
        cmd.Parameters.AddWithValue("$id", operationId);
        var parts = new List<string>();
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            var caisse = Convert.ToString(r.GetValue(0)) ?? "";
            var montant = Convert.ToDecimal(r.GetValue(1));
            var label = caisse == "Caisse" ? "Caisse générale" : caisse;
            parts.Add($"{label} : {montant:N0} FCFA");
        }
        return parts.Count == 0 ? "Aucun encaissement enregistré" : "Argent déposé dans : " + string.Join(" • ", parts);
    }
    public sealed record SeddoPendingRow(long Id, string DateOperation, string ClientNom, string Telephone, decimal Montant, decimal Commission, decimal Total, decimal Encaisse, decimal Reste, string Reference);

    public static List<SeddoOperationRow> GetSeddoOperations(int limit = 100)
    {
        var list = new List<SeddoOperationRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT o.Id,o.DateOperation,o.ClientNom,o.Telephone,o.Montant,o.Commission,o.Reference,o.Observation,
                   o.PaiementDiffere,COALESCE(SUM(p.Montant),0),
                   CASE WHEN o.PaiementDiffere=1 THEN MAX(0,(o.Montant+o.Commission)-COALESCE(SUM(p.Montant),0)) ELSE 0 END
            FROM Operations o
            LEFT JOIN SeddoPaiements p ON p.OperationId=o.Id
            WHERE o.Service='Seddo'
            GROUP BY o.Id,o.DateOperation,o.ClientNom,o.Telephone,o.Montant,o.Commission,o.Reference,o.Observation,o.PaiementDiffere
            ORDER BY o.Id DESC LIMIT $l
            """;
        cmd.Parameters.AddWithValue("$l", Math.Max(1, limit));
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            var observation = Convert.ToString(r.GetValue(7)) ?? "";
            decimal taux = 0;
            var marker = "commission ";
            var pos = observation.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
            if (pos >= 0)
            {
                var raw = observation.Substring(pos + marker.Length).TrimEnd('%', ' ');
                decimal.TryParse(raw.Replace(',', '.'), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out taux);
            }
            list.Add(new SeddoOperationRow(
                Convert.ToInt64(r.GetValue(0)), Convert.ToString(r.GetValue(1)) ?? "", Convert.ToString(r.GetValue(2)) ?? "",
                Convert.ToString(r.GetValue(3)) ?? "", Convert.ToDecimal(r.GetValue(4)), Convert.ToDecimal(r.GetValue(5)), taux,
                Convert.ToString(r.GetValue(6)) ?? "", observation, Convert.ToInt32(r.GetValue(8)) == 1,
                Convert.ToDecimal(r.GetValue(9)), Convert.ToDecimal(r.GetValue(10))));
        }
        return list;
    }

    public static List<SeddoPendingRow> GetSeddoPending(int limit = 100)
    {
        var list = new List<SeddoPendingRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT o.Id,o.DateOperation,o.ClientNom,o.Telephone,o.Montant,o.Commission,
                   (o.Montant+o.Commission),COALESCE(SUM(p.Montant),0),
                   MAX(0,(o.Montant+o.Commission)-COALESCE(SUM(p.Montant),0)),o.Reference
            FROM Operations o
            LEFT JOIN SeddoPaiements p ON p.OperationId=o.Id
            WHERE o.Service='Seddo' AND o.PaiementDiffere=1
            GROUP BY o.Id,o.DateOperation,o.ClientNom,o.Telephone,o.Montant,o.Commission,o.Reference
            HAVING MAX(0,(o.Montant+o.Commission)-COALESCE(SUM(p.Montant),0)) > 0
            ORDER BY o.Id DESC LIMIT $l
            """;
        cmd.Parameters.AddWithValue("$l", Math.Max(1, limit));
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            list.Add(new SeddoPendingRow(
                Convert.ToInt64(r.GetValue(0)), Convert.ToString(r.GetValue(1)) ?? "", Convert.ToString(r.GetValue(2)) ?? "",
                Convert.ToString(r.GetValue(3)) ?? "", Convert.ToDecimal(r.GetValue(4)), Convert.ToDecimal(r.GetValue(5)),
                Convert.ToDecimal(r.GetValue(6)), Convert.ToDecimal(r.GetValue(7)), Convert.ToDecimal(r.GetValue(8)),
                Convert.ToString(r.GetValue(9)) ?? ""));
        }
        return list;
    }

    public static void AddSeddoPayment(long operationId, decimal montant, string servicePaiement, string reference, string observation = "")
    {
        if (montant <= 0) throw new ArgumentException("Le montant encaissé doit être supérieur à zéro.");
        using var c = Open();
        using var tx = c.BeginTransaction();
        decimal reste;
        string client = "";
        using (var q = c.CreateCommand())
        {
            q.Transaction = tx;
            q.CommandText = """
                SELECT o.ClientNom, MAX(0,(o.Montant+o.Commission)-COALESCE((SELECT SUM(Montant) FROM SeddoPaiements WHERE OperationId=o.Id),0))
                FROM Operations o WHERE o.Id=$id AND o.Service='Seddo' AND o.PaiementDiffere=1 GROUP BY o.Id,o.ClientNom,o.Montant,o.Commission
                """;
            q.Parameters.AddWithValue("$id", operationId);
            using var r = q.ExecuteReader();
            if (!r.Read()) throw new InvalidOperationException("Cette opération Seddo n'est pas un paiement différé valide.");
            client = Convert.ToString(r.GetValue(0)) ?? "";
            reste = Convert.ToDecimal(r.GetValue(1));
        }
        if (montant > reste) throw new InvalidOperationException($"Le montant restant à encaisser est de {reste:N0} FCFA.");
        var caissePaiement = NormalizeSeddoPaymentService(servicePaiement);

        var now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        using (var ins = c.CreateCommand())
        {
            ins.Transaction = tx;
            ins.CommandText = "INSERT INTO SeddoPaiements(OperationId,DatePaiement,Montant,Reference,Observation,ServicePaiement) VALUES($id,$d,$m,$r,$o,$s)";
            ins.Parameters.AddWithValue("$id", operationId); ins.Parameters.AddWithValue("$d", now); ins.Parameters.AddWithValue("$m", montant);
            ins.Parameters.AddWithValue("$r", reference ?? ""); ins.Parameters.AddWithValue("$o", observation ?? ""); ins.Parameters.AddWithValue("$s", caissePaiement); ins.ExecuteNonQuery();
        }
        using (var mov = c.CreateCommand())
        {
            mov.Transaction = tx;
            mov.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,OperationId,ServiceCaisse) VALUES($d,'Entrée',$m,$motif,$r,$id,$s)";
            mov.Parameters.AddWithValue("$d", now); mov.Parameters.AddWithValue("$m", montant);
            mov.Parameters.AddWithValue("$motif", $"Encaissement Seddo — client {client} — {caissePaiement}"); mov.Parameters.AddWithValue("$r", reference ?? ""); mov.Parameters.AddWithValue("$id", operationId); mov.Parameters.AddWithValue("$s", caissePaiement); mov.ExecuteNonQuery();
        }
        using (var solde = c.CreateCommand())
        {
            solde.Transaction = tx;
            solde.CommandText = "UPDATE Soldes SET Montant=Montant+$m WHERE Service=$s";
            solde.Parameters.AddWithValue("$m", montant); solde.Parameters.AddWithValue("$s", caissePaiement); solde.ExecuteNonQuery();
        }
        tx.Commit();
    }

    public static void AddCaisseMovement(decimal montant, bool entree, string motif, string reference, string serviceCaisse = "Caisse")
    {
        if (montant <= 0) throw new ArgumentException("Le montant doit être supérieur à zéro.");
        serviceCaisse = NormalizeCaisseService(serviceCaisse);
        using var c = Open();
        using var tx = c.BeginTransaction();
        EnsureCaisseExists(c, tx, serviceCaisse);
        var delta = entree ? montant : -montant;
        using (var check = c.CreateCommand())
        {
            check.Transaction = tx;
            check.CommandText = "SELECT Montant FROM Soldes WHERE Service=$s";
            check.Parameters.AddWithValue("$s", serviceCaisse);
            var value = check.ExecuteScalar();
            if (value == null || value == DBNull.Value) throw new InvalidOperationException($"Impossible de trouver le solde de {serviceCaisse}.");
            var current = Convert.ToDecimal(value);
            if (!entree && current < montant) throw new InvalidOperationException($"La {serviceCaisse} ne dispose pas de suffisamment de liquidités.");
        }
        using (var add = c.CreateCommand())
        {
            add.Transaction = tx;
            add.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,ServiceCaisse) VALUES($date,$type,$m,$motif,$ref,$s)";
            add.Parameters.AddWithValue("$date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            add.Parameters.AddWithValue("$type", entree ? "Entrée" : "Sortie");
            add.Parameters.AddWithValue("$m", montant);
            add.Parameters.AddWithValue("$motif", string.IsNullOrWhiteSpace(motif) ? (entree ? "Entrée manuelle" : "Sortie manuelle") : motif.Trim());
            add.Parameters.AddWithValue("$ref", reference?.Trim() ?? "");
            add.Parameters.AddWithValue("$s", serviceCaisse);
            if (add.ExecuteNonQuery() != 1) throw new InvalidOperationException("Le mouvement n’a pas été enregistré.");
        }
        using (var solde = c.CreateCommand())
        {
            solde.Transaction = tx;
            solde.CommandText = "UPDATE Soldes SET Montant=Montant+$d WHERE Service=$s";
            solde.Parameters.AddWithValue("$d", delta);
            solde.Parameters.AddWithValue("$s", serviceCaisse);
            if (solde.ExecuteNonQuery() != 1) throw new InvalidOperationException($"Le solde de {serviceCaisse} n’a pas été mis à jour. L’opération est annulée.");
        }
        tx.Commit();
    }

    static string NormalizeCaisseService(string service) => (service ?? "").Trim() switch
    {
        "Caisse en espèces" or "Caisse en espèce" or "Espèces" => "Caisse",
        "Wave" => "Caisse Wave",
        "Orange Money" => "Caisse Orange Money",
        "Seddo" => "Caisse Seddo",
        "SAMA CAISSE" => "Sama caisse",
        _ => (service ?? "Caisse").Trim()
    };

    static void EnsureCaisseExists(SqliteConnection c, SqliteTransaction tx, string service)
    {
        using var ensure = c.CreateCommand();
        ensure.Transaction = tx;
        ensure.CommandText = "INSERT OR IGNORE INTO Soldes(Service,Montant) VALUES($s,0)";
        ensure.Parameters.AddWithValue("$s", service);
        ensure.ExecuteNonQuery();
    }

    /// <summary>Effectue un virement atomique entre deux caisses.</summary>
    public static void TransferCaisse(decimal montant, string source, string destination, string motif, string reference)
    {
        if (montant <= 0) throw new ArgumentException("Le montant du virement doit être supérieur à zéro.");
        if (string.IsNullOrWhiteSpace(source) || string.IsNullOrWhiteSpace(destination))
            throw new ArgumentException("Sélectionnez une caisse source et une caisse destinataire.");
        if (string.Equals(source, destination, StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("La caisse source et la caisse destinataire doivent être différentes.");

        var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "Caisse", "Caisse Wave", "Caisse Orange Money", "Caisse Seddo" };
        if (!allowed.Contains(source) || !allowed.Contains(destination))
            throw new ArgumentException("Caisse source ou destinataire invalide.");

        using var c = Open();
        using var tx = c.BeginTransaction();
        decimal current;
        using (var check = c.CreateCommand())
        {
            check.Transaction = tx;
            check.CommandText = "SELECT COALESCE(Montant,0) FROM Soldes WHERE Service=$s";
            check.Parameters.AddWithValue("$s", source);
            current = Convert.ToDecimal(check.ExecuteScalar() ?? 0);
        }
        if (current < montant)
            throw new InvalidOperationException($"La {source} ne dispose pas de suffisamment de liquidités. Solde disponible : {current:N0} FCFA.");

        var now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        var transferRef = string.IsNullOrWhiteSpace(reference) ? $"VIR-{DateTime.Now:yyyyMMddHHmmssfff}" : reference.Trim();
        var description = string.IsNullOrWhiteSpace(motif)
            ? $"Virement interne — {source} → {destination}"
            : $"Virement interne — {source} → {destination} — {motif.Trim()}";

        using (var outCmd = c.CreateCommand())
        {
            outCmd.Transaction = tx;
            outCmd.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,ServiceCaisse) VALUES($d,'Sortie',$m,$motif,$ref,$s)";
            outCmd.Parameters.AddWithValue("$d", now); outCmd.Parameters.AddWithValue("$m", montant);
            outCmd.Parameters.AddWithValue("$motif", description); outCmd.Parameters.AddWithValue("$ref", transferRef); outCmd.Parameters.AddWithValue("$s", source);
            outCmd.ExecuteNonQuery();
        }
        using (var inCmd = c.CreateCommand())
        {
            inCmd.Transaction = tx;
            inCmd.CommandText = "INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,ServiceCaisse) VALUES($d,'Entrée',$m,$motif,$ref,$s)";
            inCmd.Parameters.AddWithValue("$d", now); inCmd.Parameters.AddWithValue("$m", montant);
            inCmd.Parameters.AddWithValue("$motif", description); inCmd.Parameters.AddWithValue("$ref", transferRef); inCmd.Parameters.AddWithValue("$s", destination);
            inCmd.ExecuteNonQuery();
        }
        using (var sourceUpdate = c.CreateCommand())
        {
            sourceUpdate.Transaction = tx; sourceUpdate.CommandText = "UPDATE Soldes SET Montant=Montant-$m WHERE Service=$s";
            sourceUpdate.Parameters.AddWithValue("$m", montant); sourceUpdate.Parameters.AddWithValue("$s", source); sourceUpdate.ExecuteNonQuery();
        }
        using (var destinationUpdate = c.CreateCommand())
        {
            destinationUpdate.Transaction = tx; destinationUpdate.CommandText = "UPDATE Soldes SET Montant=Montant+$m WHERE Service=$s";
            destinationUpdate.Parameters.AddWithValue("$m", montant); destinationUpdate.Parameters.AddWithValue("$s", destination); destinationUpdate.ExecuteNonQuery();
        }
        tx.Commit();
    }

    public sealed record CaisseTransferRow(string DateMouvement, string Source, string Destination, decimal Montant, string Motif, string Reference);

    public static List<CaisseTransferRow> GetCaisseTransfers(DateTime start, DateTime endExclusive, string source = "", string destination = "", int limit = 500)
    {
        var list = new List<CaisseTransferRow>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            SELECT o.DateMouvement, o.ServiceCaisse, i.ServiceCaisse, o.Montant, o.Motif, o.Reference
            FROM CaisseMouvements o
            INNER JOIN CaisseMouvements i
              ON i.Reference=o.Reference
             AND i.TypeMouvement='Entrée'
             AND i.Montant=o.Montant
             AND i.Id<>o.Id
            WHERE o.TypeMouvement='Sortie'
              AND o.Motif LIKE 'Virement interne — %'
              AND o.DateMouvement >= $start
              AND o.DateMouvement < $end
              AND ($source='' OR o.ServiceCaisse=$source)
              AND ($destination='' OR i.ServiceCaisse=$destination)
            ORDER BY o.Id DESC LIMIT $limit
            """;
        cmd.Parameters.AddWithValue("$start", start.ToString("yyyy-MM-dd HH:mm:ss"));
        cmd.Parameters.AddWithValue("$end", endExclusive.ToString("yyyy-MM-dd HH:mm:ss"));
        cmd.Parameters.AddWithValue("$source", source ?? "");
        cmd.Parameters.AddWithValue("$destination", destination ?? "");
        cmd.Parameters.AddWithValue("$limit", Math.Max(1, limit));
        using var r=cmd.ExecuteReader();
        while(r.Read())
        {
            list.Add(new CaisseTransferRow(
                Convert.ToString(r.GetValue(0)) ?? "",
                Convert.ToString(r.GetValue(1)) ?? "",
                Convert.ToString(r.GetValue(2)) ?? "",
                Convert.ToDecimal(r.GetValue(3)),
                Convert.ToString(r.GetValue(4)) ?? "",
                Convert.ToString(r.GetValue(5)) ?? ""));
        }
        return list;
    }

    public static List<CaisseRow> GetCaisseJournal(string serviceCaisse = "Caisse", int limit = 100)
    {
        var list = new List<CaisseRow>();
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT DateMouvement,TypeMouvement,Montant,Motif,Reference,ServiceCaisse FROM CaisseMouvements WHERE ServiceCaisse=$s ORDER BY Id DESC LIMIT $l";
        cmd.Parameters.AddWithValue("$s", serviceCaisse);
        cmd.Parameters.AddWithValue("$l", Math.Max(1, limit));
        using var r = cmd.ExecuteReader();
        while (r.Read()) list.Add(new CaisseRow(Convert.ToString(r.GetValue(0)) ?? "", Convert.ToString(r.GetValue(1)) ?? "", Convert.ToDecimal(r.GetValue(2)), Convert.ToString(r.GetValue(3)) ?? "", Convert.ToString(r.GetValue(4)) ?? "", Convert.ToString(r.GetValue(5)) ?? "Caisse"));
        return list;
    }


    public sealed record BoutiqueEmployeeRow(long Id, int Poste, string Nom, string Telephone, string Note, bool Actif);
    public sealed record BoutiqueSessionRow(long Id, long EmployeId, string Employe, string Telephone, string DateJour, string Ouverture, string Fermeture, decimal WaveDonne, decimal OrangeDonne, decimal WaveRetour, decimal OrangeRetour, decimal EspecesDonne, decimal EspecesRetour, string Statut, string Observation);
    public sealed record BoutiqueOperationRow(long Id, long SessionId, string Employe, string DateOperation, string Service, string TypeOperation, string ClientNom, string Telephone, decimal Montant, decimal Commission, string Reference, string Observation);

    public static List<BoutiqueEmployeeRow> GetBoutiqueEmployees(bool activeOnly = false)
    {
        var list = new List<BoutiqueEmployeeRow>();
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = activeOnly
            ? "SELECT Id,COALESCE(Poste,0),Nom,COALESCE(Telephone,''),COALESCE(Note,''),Actif FROM BoutiqueEmployes WHERE Actif=1 ORDER BY Poste, Id"
            : "SELECT Id,COALESCE(Poste,0),Nom,COALESCE(Telephone,''),COALESCE(Note,''),Actif FROM BoutiqueEmployes ORDER BY Poste, Id";
        using var r = cmd.ExecuteReader();
        while (r.Read()) list.Add(new BoutiqueEmployeeRow(r.GetInt64(0), Convert.ToInt32(r.GetValue(1)), Convert.ToString(r.GetValue(2)) ?? "", Convert.ToString(r.GetValue(3)) ?? "", Convert.ToString(r.GetValue(4)) ?? "", Convert.ToInt32(r.GetValue(5)) != 0));
        return list;
    }

    public static long SaveBoutiqueEmployee(long id, int poste, string nom, string telephone, string note, bool actif = true)
    {
        if (string.IsNullOrWhiteSpace(nom)) throw new ArgumentException("Le nom de l'employé est obligatoire.");
        if (poste < 1 || poste > 6) throw new ArgumentException("Le poste doit être compris entre 1 et 6.");
        using var c = Open();
        using (var check = c.CreateCommand())
        {
            check.CommandText = "SELECT Id FROM BoutiqueEmployes WHERE Poste=$p AND Id<>$id AND Actif=1 LIMIT 1";
            check.Parameters.AddWithValue("$p", poste); check.Parameters.AddWithValue("$id", id);
            if (check.ExecuteScalar() is not null) throw new InvalidOperationException($"Le Poste {poste} est déjà attribué à un autre employé.");
        }
        if (id > 0)
        {
            using var cmd = c.CreateCommand();
            cmd.CommandText = "UPDATE BoutiqueEmployes SET Poste=$p,Nom=$n,Telephone=$t,Note=$o,Actif=$a WHERE Id=$id";
            cmd.Parameters.AddWithValue("$p", poste); cmd.Parameters.AddWithValue("$n", nom.Trim()); cmd.Parameters.AddWithValue("$t", telephone ?? ""); cmd.Parameters.AddWithValue("$o", note ?? ""); cmd.Parameters.AddWithValue("$a", actif ? 1 : 0); cmd.Parameters.AddWithValue("$id", id); cmd.ExecuteNonQuery(); return id;
        }
        using var ins = c.CreateCommand();
        ins.CommandText = "INSERT INTO BoutiqueEmployes(Poste,Nom,Telephone,Note,Actif) VALUES($p,$n,$t,$o,$a); SELECT last_insert_rowid();";
        ins.Parameters.AddWithValue("$p", poste); ins.Parameters.AddWithValue("$n", nom.Trim()); ins.Parameters.AddWithValue("$t", telephone ?? ""); ins.Parameters.AddWithValue("$o", note ?? ""); ins.Parameters.AddWithValue("$a", actif ? 1 : 0);
        return Convert.ToInt64(ins.ExecuteScalar());
    }

    public static BoutiqueEmployeeRow? GetBoutiqueEmployee(long id)
        => GetBoutiqueEmployees(false).FirstOrDefault(x => x.Id == id);

    public static long OpenBoutiqueSession(long employeeId, decimal waveDonne, decimal orangeDonne, decimal especesDonne, string observation = "")
    {
        if (employeeId <= 0) throw new ArgumentException("Employé invalide.");
        if (waveDonne < 0 || orangeDonne < 0 || especesDonne < 0) throw new ArgumentException("Les montants ne peuvent pas être négatifs.");
        using var c = Open(); using var tx = c.BeginTransaction();
        decimal w = GetSoldeTx(c, tx, "Caisse Wave"), o = GetSoldeTx(c, tx, "Caisse Orange Money"), cash = GetSoldeTx(c, tx, "Caisse");
        if (w < waveDonne) throw new InvalidOperationException($"La Caisse Wave ne dispose que de {waveDonne:0.##} FCFA disponibles.");
        if (o < orangeDonne) throw new InvalidOperationException($"La Caisse Orange Money ne dispose que de {o:0.##} FCFA disponibles.");
        if (cash < especesDonne) throw new InvalidOperationException($"La Caisse générale ne dispose que de {cash:0.##} FCFA disponibles.");
        using (var cmd = c.CreateCommand()) { cmd.Transaction=tx; cmd.CommandText="INSERT INTO BoutiqueSessions(EmployeId,DateJour,Ouverture,WaveDonne,OrangeDonne,EspecesDonne,Statut,Observation) VALUES($e,$d,$o,$w,$om,$es,'Ouverte',$obs); SELECT last_insert_rowid();"; cmd.Parameters.AddWithValue("$e",employeeId); cmd.Parameters.AddWithValue("$d",DateTime.Now.ToString("yyyy-MM-dd")); cmd.Parameters.AddWithValue("$o",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); cmd.Parameters.AddWithValue("$w",waveDonne); cmd.Parameters.AddWithValue("$om",orangeDonne); cmd.Parameters.AddWithValue("$es",especesDonne); cmd.Parameters.AddWithValue("$obs",observation ?? ""); var id=Convert.ToInt64(cmd.ExecuteScalar());
            AddCaisseMovementTx(c,tx,waveDonne,false,"Mise à disposition Boutique — Wave",$"Boutique session {id}","Caisse Wave");
            AddCaisseMovementTx(c,tx,orangeDonne,false,"Mise à disposition Boutique — Orange Money",$"Boutique session {id}","Caisse Orange Money");
            AddCaisseMovementTx(c,tx,especesDonne,false,"Mise à disposition Boutique — Espèces",$"Boutique session {id}","Caisse");
            tx.Commit(); return id;
        }
    }

    public static void AddBoutiqueOperation(long sessionId, string service, string type, string client, string telephone, decimal montant, decimal commission, string reference, string observation = "")
    {
        if (sessionId <= 0 || montant <= 0) throw new ArgumentException("Session ou montant invalide.");
        using var c=Open(); using var cmd=c.CreateCommand();
        cmd.CommandText="INSERT INTO BoutiqueOperations(SessionId,DateOperation,Service,TypeOperation,ClientNom,Telephone,Montant,Commission,Reference,Observation) SELECT $s,$d,$sv,$t,$n,$tel,$m,$co,$r,$o WHERE EXISTS(SELECT 1 FROM BoutiqueSessions WHERE Id=$s AND Statut='Ouverte')";
        cmd.Parameters.AddWithValue("$s",sessionId); cmd.Parameters.AddWithValue("$d",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); cmd.Parameters.AddWithValue("$sv",service); cmd.Parameters.AddWithValue("$t",type); cmd.Parameters.AddWithValue("$n",client ?? ""); cmd.Parameters.AddWithValue("$tel",telephone ?? ""); cmd.Parameters.AddWithValue("$m",montant); cmd.Parameters.AddWithValue("$co",commission); cmd.Parameters.AddWithValue("$r",reference ?? ""); cmd.Parameters.AddWithValue("$o",observation ?? "");
        if(cmd.ExecuteNonQuery()==0) throw new InvalidOperationException("La journée de cet employé est déjà clôturée.");
    }

    static void InsertBoutiqueOperationTx(SqliteConnection c, SqliteTransaction tx, long sessionId, string service, string type, string client, string telephone, decimal montant, decimal commission, string reference, string observation)
    {
        using var cmd = c.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = "INSERT INTO BoutiqueOperations(SessionId,DateOperation,Service,TypeOperation,ClientNom,Telephone,Montant,Commission,Reference,Observation) VALUES($s,$d,$sv,$t,$n,$tel,$m,$co,$r,$o)";
        cmd.Parameters.AddWithValue("$s", sessionId); cmd.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); cmd.Parameters.AddWithValue("$sv", service); cmd.Parameters.AddWithValue("$t", type); cmd.Parameters.AddWithValue("$n", client ?? ""); cmd.Parameters.AddWithValue("$tel", telephone ?? ""); cmd.Parameters.AddWithValue("$m", montant); cmd.Parameters.AddWithValue("$co", commission); cmd.Parameters.AddWithValue("$r", reference ?? ""); cmd.Parameters.AddWithValue("$o", observation ?? "");
        cmd.ExecuteNonQuery();
    }

    public static void AddBoutiqueFunds(long sessionId, decimal waveAjout, decimal orangeAjout, decimal especesAjout, string observation = "")
    {
        if (sessionId <= 0) throw new ArgumentException("Session boutique invalide.");
        if (waveAjout < 0 || orangeAjout < 0 || especesAjout < 0 || (waveAjout == 0 && orangeAjout == 0 && especesAjout == 0))
            throw new ArgumentException("Indiquez au moins un montant à ajouter.");
        using var c = Open(); using var tx = c.BeginTransaction();
        decimal w = GetSoldeTx(c, tx, "Caisse Wave"), o = GetSoldeTx(c, tx, "Caisse Orange Money"), cash = GetSoldeTx(c, tx, "Caisse");
        if (w < waveAjout) throw new InvalidOperationException($"La Caisse Wave ne dispose que de {w:0.##} FCFA disponibles.");
        if (o < orangeAjout) throw new InvalidOperationException($"La Caisse Orange Money ne dispose que de {o:0.##} FCFA disponibles.");
        if (cash < especesAjout) throw new InvalidOperationException($"La Caisse générale ne dispose que de {cash:0.##} FCFA disponibles.");
        using (var find = c.CreateCommand())
        {
            find.Transaction = tx;
            find.CommandText = "SELECT Statut FROM BoutiqueSessions WHERE Id=$id";
            find.Parameters.AddWithValue("$id", sessionId);
            var statut = Convert.ToString(find.ExecuteScalar()) ?? "";
            if (!string.Equals(statut, "Ouverte", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Cette journée est déjà clôturée.");
        }
        string employeeName = "";
        using (var who = c.CreateCommand())
        {
            who.Transaction = tx; who.CommandText = "SELECT e.Nom FROM BoutiqueSessions s JOIN BoutiqueEmployes e ON e.Id=s.EmployeId WHERE s.Id=$id"; who.Parameters.AddWithValue("$id", sessionId); employeeName = Convert.ToString(who.ExecuteScalar()) ?? "";
        }
        using (var upd = c.CreateCommand())
        {
            upd.Transaction = tx;
            upd.CommandText = "UPDATE BoutiqueSessions SET WaveDonne=WaveDonne+$w, OrangeDonne=OrangeDonne+$o, EspecesDonne=EspecesDonne+$es, Observation=CASE WHEN COALESCE(Observation,'')='' THEN $obs ELSE Observation || ' | ' || $obs END WHERE Id=$id AND Statut='Ouverte'";
            upd.Parameters.AddWithValue("$w", waveAjout); upd.Parameters.AddWithValue("$o", orangeAjout); upd.Parameters.AddWithValue("$es", especesAjout); upd.Parameters.AddWithValue("$obs", observation ?? ""); upd.Parameters.AddWithValue("$id", sessionId);
            if (upd.ExecuteNonQuery() == 0) throw new InvalidOperationException("Impossible d'augmenter cette distribution.");
        }
        // Enregistrer chaque complément comme une opération datée : le rapport Boutique
        // peut ainsi afficher précisément l'heure et le montant de chaque utilisation de + AJOUTER.
        if (waveAjout > 0) InsertBoutiqueOperationTx(c, tx, sessionId, "Wave", "Complément dotation", employeeName, "", waveAjout, 0, $"Boutique session {sessionId}", observation ?? "");
        if (orangeAjout > 0) InsertBoutiqueOperationTx(c, tx, sessionId, "Orange Money", "Complément dotation", employeeName, "", orangeAjout, 0, $"Boutique session {sessionId}", observation ?? "");
        if (especesAjout > 0) InsertBoutiqueOperationTx(c, tx, sessionId, "Espèces", "Complément dotation", employeeName, "", especesAjout, 0, $"Boutique session {sessionId}", observation ?? "");
        AddCaisseMovementTx(c, tx, waveAjout, false, "Complément Boutique — Wave", $"Boutique session {sessionId}", "Caisse Wave");
        AddCaisseMovementTx(c, tx, orangeAjout, false, "Complément Boutique — Orange Money", $"Boutique session {sessionId}", "Caisse Orange Money");
        AddCaisseMovementTx(c, tx, especesAjout, false, "Complément Boutique — Espèces", $"Boutique session {sessionId}", "Caisse");
        tx.Commit();
    }

    public static void CloseBoutiqueSession(long sessionId, decimal waveRetour, decimal orangeRetour, decimal especesRetour, string observation = "")
    {
        if (waveRetour < 0 || orangeRetour < 0 || especesRetour < 0) throw new ArgumentException("Les montants ne peuvent pas être négatifs.");
        if (waveRetour == 0 && orangeRetour == 0 && especesRetour == 0) throw new ArgumentException("Indiquez au moins un montant versé.");
        using var c=Open(); using var tx=c.BeginTransaction();
        using var find=c.CreateCommand(); find.Transaction=tx; find.CommandText="SELECT WaveDonne,OrangeDonne,EspecesDonne,WaveRetour,OrangeRetour,EspecesRetour,Statut FROM BoutiqueSessions WHERE Id=$id"; find.Parameters.AddWithValue("$id",sessionId); using var r=find.ExecuteReader();
        if(!r.Read()) throw new InvalidOperationException("Session boutique introuvable.");
        var waveDonne=Convert.ToDecimal(r.GetValue(0));
        var orangeDonne=Convert.ToDecimal(r.GetValue(1));
        var especesDonne=Convert.ToDecimal(r.GetValue(2));
        var waveRetourDeja=Convert.ToDecimal(r.GetValue(3));
        var orangeRetourDeja=Convert.ToDecimal(r.GetValue(4));
        var especesRetourDeja=Convert.ToDecimal(r.GetValue(5));
        var statut=Convert.ToString(r.GetValue(6))??"";
        if(!string.Equals(statut,"Ouverte",StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Cette journée est déjà clôturée.");
        var totalDistribue = waveDonne + orangeDonne + especesDonne;
        var totalDejaVerse = waveRetourDeja + orangeRetourDeja + especesRetourDeja;
        var versement = waveRetour + orangeRetour + especesRetour;
        var nouveauTotal = totalDejaVerse + versement;
        if (nouveauTotal > totalDistribue)
            throw new InvalidOperationException($"Le versement dépasse le montant restant.\n\nTotal distribué : {totalDistribue:N0} FCFA\nDéjà versé : {totalDejaVerse:N0} FCFA\nNouveau versement : {versement:N0} FCFA\nReste autorisé : {totalDistribue - totalDejaVerse:N0} FCFA");
        var nouveauWave = waveRetourDeja + waveRetour;
        var nouveauOrange = orangeRetourDeja + orangeRetour;
        var nouveauEspeces = especesRetourDeja + especesRetour;
        var cloture = nouveauTotal == totalDistribue;
        r.Close();

        using(var upd=c.CreateCommand())
        {
            upd.Transaction=tx;
            upd.CommandText=cloture
                ? "UPDATE BoutiqueSessions SET Fermeture=$f,WaveRetour=$w,OrangeRetour=$o,EspecesRetour=$es,Statut='Clôturée',Observation=CASE WHEN COALESCE(Observation,'')='' THEN $obs ELSE Observation || ' | ' || $obs END WHERE Id=$id"
                : "UPDATE BoutiqueSessions SET WaveRetour=$w,OrangeRetour=$o,EspecesRetour=$es,Observation=CASE WHEN COALESCE(Observation,'')='' THEN $obs ELSE Observation || ' | ' || $obs END WHERE Id=$id AND Statut='Ouverte'";
            upd.Parameters.AddWithValue("$f",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            upd.Parameters.AddWithValue("$w",nouveauWave); upd.Parameters.AddWithValue("$o",nouveauOrange); upd.Parameters.AddWithValue("$es",nouveauEspeces);
            upd.Parameters.AddWithValue("$obs",observation ?? ""); upd.Parameters.AddWithValue("$id",sessionId); upd.ExecuteNonQuery();
        }

        // Chaque versement partiel est enregistré séparément : le rapport permet donc de
        // voir exactement ce que l'employé a rendu en Wave, Orange Money et espèces.
        if (waveRetour > 0) InsertBoutiqueOperationTx(c, tx, sessionId, "Wave", "Remboursement employé", "", "", waveRetour, 0, $"Boutique session {sessionId}", observation ?? "");
        if (orangeRetour > 0) InsertBoutiqueOperationTx(c, tx, sessionId, "Orange Money", "Remboursement employé", "", "", orangeRetour, 0, $"Boutique session {sessionId}", observation ?? "");
        if (especesRetour > 0) InsertBoutiqueOperationTx(c, tx, sessionId, "Espèces", "Remboursement employé", "", "", especesRetour, 0, $"Boutique session {sessionId}", observation ?? "");

        AddCaisseMovementTx(c,tx,waveRetour,true,"Remboursement Boutique — Wave",$"Boutique session {sessionId}","Caisse Wave");
        AddCaisseMovementTx(c,tx,orangeRetour,true,"Remboursement Boutique — Orange Money",$"Boutique session {sessionId}","Caisse Orange Money");
        AddCaisseMovementTx(c,tx,especesRetour,true,"Remboursement Boutique — Espèces",$"Boutique session {sessionId}","Caisse");
        AuditTx(c, tx, cloture ? "Boutique — clôture" : "Boutique — remboursement partiel", $"Session {sessionId}", versement, $"Boutique session {sessionId}");
        tx.Commit();
    }

    static decimal GetSoldeTx(SqliteConnection c, SqliteTransaction tx, string service)
    { using var cmd=c.CreateCommand(); cmd.Transaction=tx; cmd.CommandText="SELECT COALESCE(Montant,0) FROM Soldes WHERE Service=$s"; cmd.Parameters.AddWithValue("$s",service); return Convert.ToDecimal(cmd.ExecuteScalar()??0); }
    static void AddCaisseMovementTx(SqliteConnection c, SqliteTransaction tx, decimal montant, bool entree, string motif, string reference, string service)
    { if(montant<=0)return; using var cmd=c.CreateCommand(); cmd.Transaction=tx; cmd.CommandText="INSERT INTO CaisseMouvements(DateMouvement,TypeMouvement,Montant,Motif,Reference,ServiceCaisse) VALUES($d,$t,$m,$mo,$r,$s); UPDATE Soldes SET Montant=Montant+$delta WHERE Service=$s;"; cmd.Parameters.AddWithValue("$d",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); cmd.Parameters.AddWithValue("$t",entree?"Entrée":"Sortie"); cmd.Parameters.AddWithValue("$m",montant); cmd.Parameters.AddWithValue("$mo",motif); cmd.Parameters.AddWithValue("$r",reference); cmd.Parameters.AddWithValue("$s",service); cmd.Parameters.AddWithValue("$delta",entree?montant:-montant); cmd.ExecuteNonQuery(); }

    public static List<BoutiqueSessionRow> GetBoutiqueSessions(DateTime start, DateTime endExclusive)
    {
        var list=new List<BoutiqueSessionRow>(); using var c=Open(); using var cmd=c.CreateCommand(); cmd.CommandText="SELECT s.Id,s.EmployeId,e.Nom,e.Telephone,s.DateJour,s.Ouverture,COALESCE(s.Fermeture,''),s.WaveDonne,s.OrangeDonne,s.WaveRetour,s.OrangeRetour,s.EspecesDonne,s.EspecesRetour,s.Statut,COALESCE(s.Observation,'') FROM BoutiqueSessions s JOIN BoutiqueEmployes e ON e.Id=s.EmployeId WHERE s.DateJour>=$d1 AND s.DateJour<$d2 ORDER BY s.DateJour DESC,s.Id DESC"; cmd.Parameters.AddWithValue("$d1",start.ToString("yyyy-MM-dd")); cmd.Parameters.AddWithValue("$d2",endExclusive.ToString("yyyy-MM-dd")); using var r=cmd.ExecuteReader(); while(r.Read()) list.Add(new BoutiqueSessionRow(r.GetInt64(0),r.GetInt64(1),Convert.ToString(r.GetValue(2))??"",Convert.ToString(r.GetValue(3))??"",Convert.ToString(r.GetValue(4))??"",Convert.ToString(r.GetValue(5))??"",Convert.ToString(r.GetValue(6))??"",Convert.ToDecimal(r.GetValue(7)),Convert.ToDecimal(r.GetValue(8)),Convert.ToDecimal(r.GetValue(9)),Convert.ToDecimal(r.GetValue(10)),Convert.ToDecimal(r.GetValue(11)),Convert.ToDecimal(r.GetValue(12)),Convert.ToString(r.GetValue(13))??"",Convert.ToString(r.GetValue(14))??"")); return list;
    }

    public static List<BoutiqueOperationRow> GetBoutiqueOperations(DateTime start, DateTime endExclusive, long employeeId=0)
    {
        var list=new List<BoutiqueOperationRow>(); using var c=Open(); using var cmd=c.CreateCommand(); var where="o.DateOperation >= $d1 AND o.DateOperation < $d2"; if(employeeId>0) where += " AND s.EmployeId=$e"; cmd.CommandText=$"SELECT o.Id,o.SessionId,e.Nom,o.DateOperation,o.Service,o.TypeOperation,COALESCE(o.ClientNom,''),COALESCE(o.Telephone,''),o.Montant,o.Commission,COALESCE(o.Reference,''),COALESCE(o.Observation,'') FROM BoutiqueOperations o JOIN BoutiqueSessions s ON s.Id=o.SessionId JOIN BoutiqueEmployes e ON e.Id=s.EmployeId WHERE {where} ORDER BY o.DateOperation DESC,o.Id DESC"; cmd.Parameters.AddWithValue("$d1",start.ToString("yyyy-MM-dd HH:mm:ss")); cmd.Parameters.AddWithValue("$d2",endExclusive.ToString("yyyy-MM-dd HH:mm:ss")); if(employeeId>0) cmd.Parameters.AddWithValue("$e",employeeId); using var r=cmd.ExecuteReader(); while(r.Read()) list.Add(new BoutiqueOperationRow(r.GetInt64(0),r.GetInt64(1),Convert.ToString(r.GetValue(2))??"",Convert.ToString(r.GetValue(3))??"",Convert.ToString(r.GetValue(4))??"",Convert.ToString(r.GetValue(5))??"",Convert.ToString(r.GetValue(6))??"",Convert.ToString(r.GetValue(7))??"",Convert.ToDecimal(r.GetValue(8)),Convert.ToDecimal(r.GetValue(9)),Convert.ToString(r.GetValue(10))??"",Convert.ToString(r.GetValue(11))??"")); return list;
    }

    static string Normalize(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        var n = value.Trim().Normalize(System.Text.NormalizationForm.FormD);
        var chars = n.Where(c => System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c) != System.Globalization.UnicodeCategory.NonSpacingMark);
        return new string(chars.ToArray()).ToLowerInvariant();
    }

}
