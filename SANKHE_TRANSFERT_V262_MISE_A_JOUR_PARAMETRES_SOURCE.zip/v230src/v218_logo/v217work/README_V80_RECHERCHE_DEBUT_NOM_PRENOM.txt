V80 — Rapport individuel client : recherche par début du prénom ou du nom.

Le champ client est maintenant saisissable avec autocomplétion. Il suffit de taper les premières lettres du prénom ou du nom pour retrouver le client, puis de sélectionner le résultat et imprimer le rapport individuel.
