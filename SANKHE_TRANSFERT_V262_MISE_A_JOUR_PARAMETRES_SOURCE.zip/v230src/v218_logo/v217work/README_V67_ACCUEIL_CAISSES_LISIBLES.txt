SANKHE TRANSFERT D'ARGENT - V67

Modification de l'accueil :
- Les badges CAISSE WAVE et CAISSE ORANGE MONEY ont ete redesignes.
- Montants plus grands et plus lisibles.
- Couleurs et bordures coherentes avec Wave / Orange Money.
- Suppression du rectangle gris clair peu lisible.
- Les soldes restent lies aux caisses existantes et sont mis a jour dans l'accueil.
- Aucun changement des 3 caisses de reglement des dettes.
