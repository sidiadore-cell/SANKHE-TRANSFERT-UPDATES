V150 — FORMAT AUTOMATIQUE DES SAISIES

- Téléphones : format visuel 00 000 00 00 (9 chiffres), espaces automatiques.
- Montants : format visuel 0 000 000, espaces automatiques.
- Les espaces ne sont jamais utilisés comme partie de la valeur numérique : ils sont retirés avant les calculs et enregistrements.
- Les contrôles de saisie montant acceptent uniquement les chiffres (hors touches de contrôle).
- Les calculs de caisse, opérations, Seddo, boutique, virements et rééquilibrages continuent à utiliser des valeurs numériques réelles.
