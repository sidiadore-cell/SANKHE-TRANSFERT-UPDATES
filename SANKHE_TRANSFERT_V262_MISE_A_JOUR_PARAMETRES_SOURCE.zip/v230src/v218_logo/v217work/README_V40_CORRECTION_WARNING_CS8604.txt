SANKHÉ TRANSFERT D’ARGENT — V40

Correction définitive du warning nullable CS8604 lié à Normalize().
Normalize accepte désormais une chaîne nullable et traite null comme une chaîne vide.
Cela sécurise toutes les recherches (dettes, nom/prénom, téléphone) sans modifier la logique de caisse.
