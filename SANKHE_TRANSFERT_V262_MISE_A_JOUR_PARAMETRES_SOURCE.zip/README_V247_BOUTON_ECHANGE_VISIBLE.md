V247 — Menu Opérations Orange Money
- Réglage de la largeur et des marges de la rangée des boutons pour que « Échange » reste entièrement visible à droite.
- Largeur des boutons adaptée à la carte de service élargie, en conservant le style.
