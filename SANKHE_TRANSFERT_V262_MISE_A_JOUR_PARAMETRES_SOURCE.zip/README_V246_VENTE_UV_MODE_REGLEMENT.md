V246 — Rapports : mode de règlement Vente UV

- Les opérations de rééquilibrage Vente UV affichent maintenant dans la description le mode de règlement : « Vente UV — réglée par Espèces » ou « Vente UV — réglée par Orange Money ».
- Si le paiement est différé, la description indique « Vente UV — paiement différé (dette) ».
- Les descriptions des nouvelles opérations et des mouvements de caisse sont explicites.
- Les opérations historiques déjà enregistrées ne sont pas modifiées rétroactivement.
