# Validation V262 avant publication

- [ ] Compiler le projet principal avec .NET 8 SDK sur Windows.
- [ ] Vérifier que la carte « Paramètres des caisses » n'apparaît plus dans Paramètres.
- [ ] Vérifier « Sécurité & mot de passe » et tester une modification de mot de passe.
- [ ] Vérifier « Carnet clients » et ouvrir le gestionnaire de clients.
- [ ] Vérifier l'enregistrement de la configuration WhatsApp.
- [ ] Sauvegarder puis restaurer une copie de test de la base.
- [ ] Comparer les dettes, remboursements, soldes Wave, Orange Money, espèces et historiques avant/après.
- [ ] Vérifier les rapports imprimés et PDF.
- [ ] Seulement après validation, préparer un paquet de mise à jour signé et publier une GitHub Release.
