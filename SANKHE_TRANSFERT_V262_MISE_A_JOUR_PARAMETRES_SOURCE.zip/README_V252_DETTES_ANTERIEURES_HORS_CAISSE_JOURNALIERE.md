SANKHÉ TRANSFERT — V252
Correction : remboursement des dettes antérieures

Règle appliquée :
- Une dette créée avant la date du jour et remboursée aujourd'hui crédite toujours la caisse choisie (Caisse Wave, Caisse Orange Money ou caisse en espèces/générale).
- Ce règlement est conservé dans l'historique global et dans les opérations/rapports.
- Il est exclu des entrées et mouvements de la caisse journalière afin de ne pas gonfler les totaux journaliers.
- Les dettes créées aujourd'hui continuent d'être comptées dans la caisse journalière lorsqu'elles sont réglées aujourd'hui.
- Le solde réel permanent de la caisse reste mis à jour normalement.

Validation effectuée : intégrité de l'archive ZIP. Compilation/exécution Windows non effectuée dans cet environnement.
