SANKHÉ TRANSFERT — V250

Correction des descriptions d’Échange dans les rapports :
- « Échange Wave vers Orange Money »
- « Échange Orange Money vers Wave »

Le rapport, l’impression et les exports réutilisent GetReportDescription ; ils affichent désormais le sens enregistré dans Observation au lieu du libellé générique « Échange ». Si les anciennes données ne contiennent pas le sens, le rapport indique « Échange — sens non précisé ».

Vérification effectuée : archive ZIP contrôlée. Compilation Windows/.NET non exécutée dans cet environnement.
