V248 — Menu Opérations : montants négatifs en rouge
- Les montants négatifs affichés dans les cages de caisse journalière du menu Opérations sont colorés en rouge.
- Les montants positifs gardent la couleur habituelle Wave/Orange Money.
