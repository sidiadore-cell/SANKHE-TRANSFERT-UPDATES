SANKHÉ TRANSFERT — V251
Correction des boutons Entrée, Sortie et Modifier solde pour Wave, Orange Money, Espèces et Seddo.

Corrections apportées :
- Correction du nom de la caisse Espèces : le libellé visible « Caisse en espèces » est maintenant converti en identifiant SQLite « Caisse ». C'était la cause principale : les boutons pouvaient enregistrer sous un nom différent du solde réellement utilisé.
- Normalisation des noms de caisses pour Wave, Orange Money, Espèces et Seddo.
- Entrée/Sortie : vérification de l'existence du solde, transaction atomique et annulation complète si l'historique ou le solde ne peut pas être mis à jour.
- Sortie : blocage si le montant dépasse le solde disponible.
- Modifier solde : accepte maintenant zéro comme solde de départ, vérifie les mises à jour et annule la transaction en cas d'échec.
- Motif facultatif avec une description automatique si le champ est vide.

Vérification effectuée : archive ZIP valide et fichiers sources contrôlés. La compilation et les essais interactifs doivent encore être réalisés sous Windows avec .NET SDK.
