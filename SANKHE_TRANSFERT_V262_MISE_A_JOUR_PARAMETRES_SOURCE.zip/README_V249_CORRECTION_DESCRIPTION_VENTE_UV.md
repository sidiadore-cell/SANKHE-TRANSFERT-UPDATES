V249 — Correction de l'affichage des descriptions dans les rapports
- Le rapport affiche désormais explicitement « Vente UV — réglée par Espèces » ou « Vente UV — réglée par Orange Money » lorsque le mode est présent dans l'observation.
- Le paiement différé est indiqué comme « Vente UV — paiement différé (dette) ».
- Le correctif porte sur GetReportDescription, utilisé par les grilles de rapports et les exports/impressions.
- Les anciennes opérations qui ne contiennent aucune information sur le mode de règlement ne peuvent pas être classées automatiquement; elles affichent « mode de règlement non précisé ».
