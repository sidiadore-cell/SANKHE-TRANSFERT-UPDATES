V244 — Ajustement visuel du menu Opérations
- Deux cartes Wave et Orange Money élargies et repositionnées pour une mise en page plus équilibrée.
- Cages de saisie, zones de boutons et champs élargis pour éviter les textes/champs coupés aux bordures.
- Boutons UV Orange Money avec flèches plus visibles et typographie agrandie.
- Logique métier conservée à partir de la base V243.
