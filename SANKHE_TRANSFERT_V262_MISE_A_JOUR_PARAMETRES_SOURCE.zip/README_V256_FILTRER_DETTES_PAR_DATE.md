# V256 — Distinguer les dettes d'aujourd'hui et des jours passés

Dans le menu Dettes, ajout d'un filtre de date avec trois choix :
- Toutes les dates
- Dettes d'aujourd'hui
- Dettes des jours passés

Le filtre se combine avec les filtres de service, de statut et la recherche client. Il filtre uniquement l'affichage des dettes; il ne modifie ni ne supprime les dettes enregistrées.

Vérification : archive ZIP testée. La compilation et les essais fonctionnels sous Windows/.NET restent à effectuer.
