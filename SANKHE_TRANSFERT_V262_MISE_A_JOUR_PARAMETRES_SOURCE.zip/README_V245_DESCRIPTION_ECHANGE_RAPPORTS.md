V245 — Description explicite des échanges dans les rapports

Les opérations d'échange enregistrent désormais une description explicite dans l'observation de l'opération et dans les mouvements de caisse :
- Échange Wave vers Orange Money
- Échange Orange Money vers Wave

Le rapport peut ainsi identifier clairement le sens de l'échange. Les données historiques déjà enregistrées ne sont pas réécrites rétroactivement.
